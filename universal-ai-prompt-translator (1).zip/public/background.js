const MODEL_HOSTS = {
  chatgpt: ["chatgpt.com", "chat.openai.com"],
  claude: ["claude.ai"],
  gemini: ["gemini.google.com"],
  deepseek: ["deepseek.com", "chat.deepseek.com"],
};

const DEFAULT_TARGETS = ["chatgpt", "claude", "gemini"];
const MODEL_IDS = Object.keys(MODEL_HOSTS);

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

function modelForUrl(value) {
  try {
    const hostname = new URL(value).hostname;
    return MODEL_IDS.find((id) => MODEL_HOSTS[id].some((domain) => hostname === domain || hostname.endsWith(`.${domain}`)));
  } catch {
    return undefined;
  }
}

function validTargets(value) {
  if (!Array.isArray(value)) return DEFAULT_TARGETS;
  return [...new Set(value.filter((id) => MODEL_IDS.includes(id)))];
}

function adaptPrompt(prompt, modelId, preset) {
  const text = String(prompt || "").trim();
  const rules = {
    balanced: "Follow the requested format exactly. Do not invent details; label assumptions clearly.",
    precise: "Be exact and evidence-led. Separate facts from inferences, preserve every constraint, and flag missing information.",
    creative: "Explore fresh, specific ideas while respecting the brief. Avoid familiar cliches and keep every suggestion usable.",
  }[preset] || "Follow the requested format exactly. Do not invent details; label assumptions clearly.";

  if (modelId === "claude") {
    return `<task>\n${text}\n</task>\n\n<response_guidelines>\n${rules}\n</response_guidelines>`;
  }
  if (modelId === "gemini") {
    return `OBJECTIVE\n${text}\n\nPRIORITY CONSTRAINTS\n1. Follow every instruction and output format in the brief.\n2. ${rules}\n3. Keep the response focused on the requested task.`;
  }
  if (modelId === "deepseek") {
    return `### Task\n${text}\n\n### Requirements\n- ${rules}\n- Return the answer directly in the requested format.`;
  }
  return `Role: Careful, detail-oriented assistant\n\nTask:\n${text}\n\nResponse requirements:\n- ${rules}\n- Follow the requested output format exactly.`;
}

async function broadcast(message) {
  const stored = await chrome.storage.local.get(["relayTargets", "relayPreset", "relayTaskType", "relayMetrics"]);
  const targets = validTargets(message.targets ?? stored.relayTargets);
  const preset = message.preset || stored.relayPreset || "balanced";
  const taskType = ["general", "coding", "creative", "analysis", "research"].includes(message.taskType || stored.relayTaskType)
    ? (message.taskType || stored.relayTaskType)
    : "general";
  const prompt = String(message.prompt || "").trim();
  if (!prompt || !targets.length) return { ok: false, reason: "EMPTY_PROMPT" };

  const tabs = await chrome.tabs.query({});
  const recipients = tabs.filter((tab) => typeof tab.id === "number" && targets.includes(modelForUrl(tab.url || "")));
  if (!recipients.length) return { ok: false, reason: "NO_TABS" };

  const outcomes = await Promise.all(recipients.map(async (tab) => {
    const modelId = modelForUrl(tab.url || "");
    try {
      const result = await chrome.tabs.sendMessage(tab.id, {
        type: "RELAY_FILL_AND_SEND",
        modelId,
        prompt: adaptPrompt(prompt, modelId, preset),
      });
      return { modelId, ok: Boolean(result?.ok), submitted: Boolean(result?.submitted) };
    } catch {
      return { modelId, ok: false, submitted: false };
    }
  }));

  const completed = outcomes.filter((result) => result.ok);
  const sentModels = [...new Set(completed.map((result) => result.modelId).filter(Boolean))];
  if (!completed.length) {
    return { ok: false, reason: "NO_EDITORS", deliveredCount: 0, sentModels: [] };
  }

  const metrics = stored.relayMetrics && typeof stored.relayMetrics === "object" ? stored.relayMetrics : {};
  const category = metrics[taskType] && typeof metrics[taskType] === "object" ? metrics[taskType] : {};
  const prepared = { ...(category.prepared || {}) };
  completed.forEach(({ modelId }) => {
    if (modelId) prepared[modelId] = (prepared[modelId] || 0) + 1;
  });
  await chrome.storage.local.set({ relayMetrics: { ...metrics, [taskType]: { ...category, prepared } } });

  return {
    ok: true,
    deliveredCount: completed.length,
    sentModels,
    submittedCount: completed.filter((result) => result.submitted).length,
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "RELAY_BROADCAST_PROMPT" && message?.type !== "RELAY_BROADCAST_FROM_PAGE") return false;

  broadcast(message)
    .then(sendResponse)
    .catch(() => sendResponse({ ok: false, reason: "FAILED" }));
  return true;
});
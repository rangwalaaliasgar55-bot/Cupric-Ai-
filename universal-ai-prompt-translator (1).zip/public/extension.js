(() => {
  const MODELS = [
    { id: "chatgpt", name: "ChatGPT", maker: "OpenAI", note: "Instruction-first", initial: "c" },
    { id: "claude", name: "Claude", maker: "Anthropic", note: "XML-guided structure", initial: "a" },
    { id: "gemini", name: "Gemini", maker: "Google", note: "Constraint-led", initial: "*" },
    { id: "deepseek", name: "DeepSeek", maker: "DeepSeek", note: "Direct + concise", initial: "d" },
  ];
  const TASK_TYPES = ["general", "coding", "creative", "analysis", "research"];
  const SAMPLE_PROMPT = `Review the customer interview notes below and identify the three most important unmet needs.\n\nFor each need, include a short supporting quote, why it matters, and one experiment we could run this month. Return a concise table. Avoid assumptions and label any uncertainty.\n\nInterview notes:\n[Paste interview notes here]`;
  const state = {
    prompt: SAMPLE_PROMPT,
    selected: ["chatgpt", "claude", "gemini"],
    active: "claude",
    preset: "balanced",
    taskType: "general",
    openTabs: {},
    metrics: {},
  };
  const elements = {
    prompt: document.getElementById("prompt-input"),
    count: document.getElementById("word-count"),
    saved: document.getElementById("saved-state"),
    targetList: document.getElementById("target-list"),
    selectAll: document.getElementById("select-all"),
    preset: document.getElementById("preset-select"),
    taskType: document.getElementById("task-type-select"),
    previewTabs: document.getElementById("preview-tabs"),
    previewName: document.getElementById("preview-model-name"),
    previewType: document.getElementById("preview-model-type"),
    preview: document.getElementById("preview-output"),
    copy: document.getElementById("copy-button"),
    broadcast: document.getElementById("broadcast-button"),
    broadcastLabel: document.getElementById("broadcast-label"),
    openTabs: document.getElementById("open-tab-count"),
    toast: document.getElementById("toast"),
    rateHelpful: document.getElementById("rate-helpful"),
    rateUnhelpful: document.getElementById("rate-unhelpful"),
  };
  let saveTimer;
  let toastTimer;

  function modelForUrl(value) {
    try {
      const hostname = new URL(value).hostname;
      if (hostname === "chatgpt.com" || hostname.endsWith(".chatgpt.com") || hostname === "chat.openai.com") return "chatgpt";
      if (hostname === "claude.ai" || hostname.endsWith(".claude.ai")) return "claude";
      if (hostname === "gemini.google.com" || hostname.endsWith(".gemini.google.com")) return "gemini";
      if (hostname === "deepseek.com" || hostname.endsWith(".deepseek.com")) return "deepseek";
    } catch {
      return undefined;
    }
    return undefined;
  }

  function formatPrompt(prompt, modelId) {
    const text = prompt.trim();
    const guidance = {
      balanced: "Follow the requested format exactly. Do not invent details; label assumptions clearly.",
      precise: "Be exact and evidence-led. Separate facts from inferences, preserve every constraint, and flag missing information.",
      creative: "Explore fresh, specific ideas while respecting the brief. Avoid familiar cliches and keep every suggestion usable.",
    }[state.preset];

    if (modelId === "claude") return `<task>\n${text}\n</task>\n\n<response_guidelines>\n${guidance}\n</response_guidelines>`;
    if (modelId === "gemini") return `OBJECTIVE\n${text}\n\nPRIORITY CONSTRAINTS\n1. Follow every instruction and output format in the brief.\n2. ${guidance}\n3. Keep the response focused on the requested task.`;
    if (modelId === "deepseek") return `### Task\n${text}\n\n### Requirements\n- ${guidance}\n- Return the answer directly in the requested format.`;
    return `Role: Careful, detail-oriented assistant\n\nTask:\n${text}\n\nResponse requirements:\n- ${guidance}\n- Follow the requested output format exactly.`;
  }

  function announce(message) {
    elements.toast.textContent = message;
    elements.toast.classList.add("visible");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => elements.toast.classList.remove("visible"), 3000);
  }

  function persist() {
    elements.saved.textContent = "saving...";
    chrome.storage.local.set({
      relayDraft: state.prompt,
      relayTargets: state.selected,
      relayPreset: state.preset,
      relayTaskType: state.taskType,
    }, () => {
      elements.saved.textContent = chrome.runtime.lastError ? "not saved" : "saved here";
    });
  }

  function queueSave() {
    elements.saved.textContent = "saving...";
    window.clearTimeout(saveTimer);
    saveTimer = window.setTimeout(persist, 250);
  }

  function updateWordCount() {
    const count = state.prompt.trim() ? state.prompt.trim().split(/\s+/).length : 0;
    elements.count.textContent = `${count} ${count === 1 ? "word" : "words"}`;
  }

  function updateBroadcastLabel() {
    const count = state.selected.length;
    elements.broadcast.disabled = !state.prompt.trim() || count === 0;
    elements.broadcastLabel.textContent = count ? `Broadcast to ${count} model${count === 1 ? "" : "s"}` : "Choose a model to continue";
  }

  function renderTargets() {
    elements.targetList.replaceChildren();
    MODELS.forEach((model) => {
      const selected = state.selected.includes(model.id);
      const row = document.createElement("button");
      row.type = "button";
      row.className = `target-row${selected ? " selected" : ""}`;
      row.setAttribute("aria-pressed", String(selected));

      const mark = document.createElement("span");
      mark.className = `model-mark model-${model.id}`;
      mark.textContent = model.initial;

      const copy = document.createElement("span");
      copy.className = "target-copy";
      const name = document.createElement("span");
      name.className = "target-name";
      name.textContent = model.name;
      const status = document.createElement("span");
      status.className = `target-status${state.openTabs[model.id] ? " ready" : ""}`;
      const count = state.openTabs[model.id] || 0;
      status.textContent = count ? `${count} open chat${count === 1 ? "" : "s"} ready` : model.note;
      copy.append(name, status);

      const check = document.createElement("span");
      check.className = `target-check${selected ? " checked" : ""}`;
      check.textContent = selected ? "x" : "";

      row.append(mark, copy, check);
      row.addEventListener("click", () => {
        state.selected = selected ? state.selected.filter((id) => id !== model.id) : [...state.selected, model.id];
        state.active = model.id;
        persist();
        render();
      });
      elements.targetList.append(row);
    });

    elements.selectAll.textContent = state.selected.length === MODELS.length ? "Clear all" : "Select all";
    updateBroadcastLabel();
  }

  function renderPreviewTabs() {
    elements.previewTabs.replaceChildren();
    const ids = state.selected.length ? state.selected : MODELS.map((model) => model.id);
    ids.forEach((id) => {
      const model = MODELS.find((item) => item.id === id);
      if (!model) return;
      const tab = document.createElement("button");
      tab.type = "button";
      tab.className = `preview-tab${state.active === id ? " active" : ""}`;
      tab.textContent = model.name;
      tab.setAttribute("role", "tab");
      tab.setAttribute("aria-selected", String(state.active === id));
      tab.addEventListener("click", () => {
        state.active = id;
        renderPreviewTabs();
        updatePreview();
      });
      elements.previewTabs.append(tab);
    });
  }

  function renderRatings() {
    const ratings = state.metrics[state.taskType]?.ratings?.[state.active] || { helpful: 0, unhelpful: 0 };
    elements.rateHelpful.querySelector("b").textContent = ratings.helpful || 0;
    elements.rateUnhelpful.querySelector("b").textContent = ratings.unhelpful || 0;
  }

  function updatePreview() {
    const model = MODELS.find((item) => item.id === state.active) || MODELS[1];
    elements.previewName.textContent = model.name;
    elements.previewType.textContent = model.note;
    elements.preview.textContent = state.prompt.trim() ? formatPrompt(state.prompt, model.id) : "Your adapted prompt will appear here.";
  }

  function render() {
    renderTargets();
    renderPreviewTabs();
    updatePreview();
    renderRatings();
    updateWordCount();
    updateBroadcastLabel();
  }

  async function refreshOpenTabs() {
    try {
      const tabs = await chrome.tabs.query({});
      const counts = {};
      tabs.forEach((tab) => {
        const modelId = modelForUrl(tab.url || "");
        if (modelId) counts[modelId] = (counts[modelId] || 0) + 1;
      });
      state.openTabs = counts;
      const total = Object.values(counts).reduce((sum, count) => sum + count, 0);
      elements.openTabs.textContent = total ? `${total} active AI tab${total === 1 ? "" : "s"}` : "no AI tabs open";
      renderTargets();
    } catch {
      elements.openTabs.textContent = "AI tabs unavailable";
    }
  }

  async function broadcast() {
    if (!state.prompt.trim()) {
      announce("Add a prompt before broadcasting");
      return;
    }
    if (!state.selected.length) {
      announce("Choose at least one model first");
      return;
    }

    elements.broadcast.disabled = true;
    elements.broadcastLabel.textContent = "Sending to open chats...";
    try {
      const response = await chrome.runtime.sendMessage({
        type: "RELAY_BROADCAST_PROMPT",
        prompt: state.prompt,
        targets: state.selected,
        preset: state.preset,
        taskType: state.taskType,
      });
      if (response?.ok) {
        const count = response.deliveredCount || 0;
        announce(`Sent to ${count} open AI chat${count === 1 ? "" : "s"}`);
        refreshOpenTabs();
      } else if (response?.reason === "NO_TABS") {
        announce("Open one or more selected AI chats, then try again");
      } else if (response?.reason === "NO_EDITORS") {
        announce("Open a conversation in the selected AI tabs first");
      } else {
        announce("Relay could not reach the selected chats");
      }
    } catch {
      announce("Could not reach the extension service. Try again.");
    }
    updateBroadcastLabel();
  }

  async function copyPreview() {
    if (!state.prompt.trim()) {
      announce("Add a prompt before copying");
      return;
    }
    try {
      await navigator.clipboard.writeText(formatPrompt(state.prompt, state.active));
      elements.copy.textContent = "Copied";
      announce(`${MODELS.find((model) => model.id === state.active)?.name} version copied`);
      window.setTimeout(() => (elements.copy.textContent = "Copy"), 1500);
    } catch {
      announce("Clipboard access is unavailable");
    }
  }

  function recordRating(kind) {
    const category = state.metrics[state.taskType] || { ratings: {}, prepared: {} };
    const ratings = { ...category.ratings };
    const current = ratings[state.active] || { helpful: 0, unhelpful: 0 };
    ratings[state.active] = { ...current, [kind]: current[kind] + 1 };
    state.metrics = { ...state.metrics, [state.taskType]: { ...category, ratings } };
    chrome.storage.local.set({ relayMetrics: state.metrics });
    renderRatings();
    announce(`Feedback saved for ${MODELS.find((model) => model.id === state.active)?.name}`);
  }

  elements.prompt.addEventListener("input", () => {
    state.prompt = elements.prompt.value;
    updateWordCount();
    updatePreview();
    updateBroadcastLabel();
    queueSave();
  });

  elements.prompt.addEventListener("keydown", (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
      event.preventDefault();
      broadcast();
    }
  });

  elements.selectAll.addEventListener("click", () => {
    state.selected = state.selected.length === MODELS.length ? [] : MODELS.map((model) => model.id);
    if (state.selected.length && !state.selected.includes(state.active)) state.active = state.selected[0];
    persist();
    render();
  });

  elements.preset.addEventListener("change", () => {
    state.preset = elements.preset.value;
    updatePreview();
    persist();
  });

  elements.taskType.addEventListener("change", () => {
    state.taskType = elements.taskType.value;
    renderRatings();
    persist();
  });

  elements.copy.addEventListener("click", copyPreview);
  elements.broadcast.addEventListener("click", broadcast);
  elements.rateHelpful.addEventListener("click", () => recordRating("helpful"));
  elements.rateUnhelpful.addEventListener("click", () => recordRating("unhelpful"));
  chrome.tabs.onCreated.addListener(refreshOpenTabs);
  chrome.tabs.onRemoved.addListener(refreshOpenTabs);
  chrome.tabs.onUpdated.addListener(refreshOpenTabs);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.relayMetrics?.newValue) return;
    state.metrics = changes.relayMetrics.newValue;
    renderRatings();
  });

  chrome.storage.local.get(["relayDraft", "relayTargets", "relayPreset", "relayTaskType", "relayMetrics"], (stored) => {
    if (typeof stored.relayDraft === "string") state.prompt = stored.relayDraft;
    if (Array.isArray(stored.relayTargets)) state.selected = stored.relayTargets.filter((id) => MODELS.some((model) => model.id === id));
    if (["balanced", "precise", "creative"].includes(stored.relayPreset)) state.preset = stored.relayPreset;
    if (TASK_TYPES.includes(stored.relayTaskType)) state.taskType = stored.relayTaskType;
    if (stored.relayMetrics && typeof stored.relayMetrics === "object") state.metrics = stored.relayMetrics;
    elements.prompt.value = state.prompt;
    elements.preset.value = state.preset;
    elements.taskType.value = state.taskType;
    render();
    refreshOpenTabs();
  });
})();
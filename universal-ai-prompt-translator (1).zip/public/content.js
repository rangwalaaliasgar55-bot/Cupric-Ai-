(() => {
  const DEFAULT_SETTINGS = { inlineTranslator: true, broadcastHotkey: true };
  let settings = { ...DEFAULT_SETTINGS };
  let preset = "balanced";
  let widgetHost;
  let widgetButton;
  let widgetLabel;
  let scanQueued = false;

  function modelForHost() {
    const hostname = window.location.hostname;
    if (hostname === "chatgpt.com" || hostname.endsWith(".chatgpt.com") || hostname === "chat.openai.com") return "chatgpt";
    if (hostname === "claude.ai" || hostname.endsWith(".claude.ai")) return "claude";
    if (hostname === "gemini.google.com" || hostname.endsWith(".gemini.google.com")) return "gemini";
    if (hostname === "deepseek.com" || hostname.endsWith(".deepseek.com")) return "deepseek";
    return "chatgpt";
  }

  function modelName(id) {
    return { chatgpt: "ChatGPT", claude: "Claude", gemini: "Gemini", deepseek: "DeepSeek" }[id] || "this model";
  }

  function formatPrompt(prompt, modelId) {
    const text = prompt.trim();
    const rules = {
      balanced: "Follow the requested format exactly. Do not invent details; label assumptions clearly.",
      precise: "Be exact and evidence-led. Separate facts from inferences, preserve every constraint, and flag missing information.",
      creative: "Explore fresh, specific ideas while respecting the brief. Avoid familiar cliches and keep every suggestion usable.",
    }[preset] || "Follow the requested format exactly. Do not invent details; label assumptions clearly.";

    if (modelId === "claude") return `<task>\n${text}\n</task>\n\n<response_guidelines>\n${rules}\n</response_guidelines>`;
    if (modelId === "gemini") return `OBJECTIVE\n${text}\n\nPRIORITY CONSTRAINTS\n1. Follow every instruction and output format in the brief.\n2. ${rules}\n3. Keep the response focused on the requested task.`;
    if (modelId === "deepseek") return `### Task\n${text}\n\n### Requirements\n- ${rules}\n- Return the answer directly in the requested format.`;
    return `Role: Careful, detail-oriented assistant\n\nTask:\n${text}\n\nResponse requirements:\n- ${rules}\n- Follow the requested output format exactly.`;
  }

  function isVisible(element) {
    const box = element.getBoundingClientRect();
    return box.width > 0 && box.height > 0 && getComputedStyle(element).visibility !== "hidden";
  }

  function findEditor() {
    const elements = Array.from(document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"], input:not([type="search"])'));
    return elements.find((element) => {
      if (!isVisible(element) || element.closest("[data-relay-ui]")) return false;
      const details = [element.getAttribute("placeholder"), element.getAttribute("aria-label"), element.getAttribute("data-placeholder")]
        .join(" ")
        .toLowerCase();
      return !/(search|rename|title|filter)/.test(details);
    });
  }

  function readEditor(editor) {
    if (editor instanceof HTMLTextAreaElement || editor instanceof HTMLInputElement) return editor.value;
    return editor.innerText || editor.textContent || "";
  }

  function writeEditor(editor, text) {
    editor.focus();
    if (editor instanceof HTMLTextAreaElement || editor instanceof HTMLInputElement) {
      const prototype = editor instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      setter?.call(editor, text);
    } else {
      document.getSelection()?.selectAllChildren(editor);
      try {
        document.execCommand("insertText", false, text);
      } catch {
        editor.textContent = text;
      }
      if (readEditor(editor).trim() !== text.trim()) editor.textContent = text;
    }
    editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    editor.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function setWidgetMessage(message, isError = false) {
    if (!widgetLabel || !widgetButton) return;
    widgetLabel.textContent = message;
    widgetButton.classList.toggle("relay-error", isError);
    window.setTimeout(() => {
      if (widgetLabel) widgetLabel.textContent = `Optimize for ${modelName(modelForHost())}`;
      widgetButton?.classList.remove("relay-error");
    }, 2400);
  }

  function attachWidget() {
    if (widgetHost || !document.body) return;
    widgetHost = document.createElement("div");
    widgetHost.setAttribute("data-relay-ui", "true");
    widgetHost.style.cssText = "position:fixed;right:22px;bottom:22px;z-index:2147483646;pointer-events:none;";
    const shadow = widgetHost.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        :host{all:initial;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
        .relay-button{display:flex;align-items:center;gap:10px;min-height:48px;padding:0 14px 0 9px;border:1px solid rgba(227,235,224,.18);border-radius:13px;color:#edf4ea;background:#1c2921;box-shadow:0 8px 28px rgba(20,35,24,.24);cursor:pointer;pointer-events:auto;transition:transform .16s ease,background .16s ease,box-shadow .16s ease}
        .relay-button:hover{transform:translateY(-2px);background:#27392b;box-shadow:0 11px 30px rgba(20,35,24,.3)}
        .relay-button:disabled{opacity:.7;cursor:wait}
        .relay-mark{display:grid;width:29px;height:29px;place-items:center;border-radius:9px;color:#263521;background:#d2fa83}
        .relay-copy{display:flex;flex-direction:column;align-items:flex-start;gap:3px}
        .relay-brand{color:#f1f5ee;font-size:10px;font-weight:700;letter-spacing:.1px}
        .relay-label{color:#a9b8a7;font-size:9px;font-weight:450}
        .relay-arrow{margin-left:7px;color:#c4d3c0;font-size:13px}
        .relay-error .relay-mark{color:#fff;background:#bc6c56}
        @media(max-width:600px){.relay-button{min-height:44px;padding-right:11px}}
      </style>
      <button class="relay-button" type="button" aria-label="Optimize prompt for this AI model">
        <span class="relay-mark"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M4 7h10l-3-3M14 7l-3 3M20 17H10l3 3M10 17l3-3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
        <span class="relay-copy"><span class="relay-brand">Relay</span><span class="relay-label">Optimize for ${modelName(modelForHost())}</span></span>
        <span class="relay-arrow">&#8599;</span>
      </button>`;
    widgetButton = shadow.querySelector("button");
    widgetLabel = shadow.querySelector(".relay-label");
    widgetButton.addEventListener("click", () => {
      const editor = findEditor();
      const source = editor && readEditor(editor).trim();
      if (!editor || !source) {
        setWidgetMessage("Add a prompt first", true);
        return;
      }
      writeEditor(editor, formatPrompt(source, modelForHost()));
      setWidgetMessage(`${modelName(modelForHost())} format ready`);
    });
    document.body.appendChild(widgetHost);
  }

  function scanPage() {
    scanQueued = false;
    const editor = findEditor();
    if (!settings.inlineTranslator || !editor) {
      widgetHost?.remove();
      widgetHost = undefined;
      widgetButton = undefined;
      widgetLabel = undefined;
      return;
    }
    attachWidget();
  }

  function queueScan() {
    if (scanQueued) return;
    scanQueued = true;
    window.setTimeout(scanPage, 350);
  }

  function findSendButton() {
    const exactSelectors = [
      'button[data-testid="send-button"]',
      'button[aria-label="Send message"]',
      'button[aria-label="Send"]',
      'button[aria-label="Send prompt"]',
      'button[title="Send"]',
    ];
    for (const selector of exactSelectors) {
      const button = document.querySelector(selector);
      if (button && isVisible(button) && !button.disabled) return button;
    }
    return Array.from(document.querySelectorAll("button")).find((button) => {
      const label = `${button.getAttribute("aria-label") || ""} ${button.getAttribute("title") || ""}`.trim();
      return /^(send|send message|send prompt|submit)$/i.test(label) && isVisible(button) && !button.disabled;
    });
  }

  function submitPrompt(editor) {
    return new Promise((resolve) => {
      window.setTimeout(() => {
        const button = findSendButton();
        if (!button) {
          resolve(false);
          return;
        }
        button.click();
        resolve(true);
      }, 320);
    });
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "RELAY_FILL_AND_SEND") return false;
    const editor = findEditor();
    if (!editor) {
      sendResponse({ ok: false, submitted: false });
      return false;
    }
    writeEditor(editor, String(message.prompt || ""));
    submitPrompt(editor).then((submitted) => sendResponse({ ok: submitted, submitted }));
    return true;
  });

  document.addEventListener("keydown", (event) => {
    const isBroadcastShortcut = (event.ctrlKey || event.metaKey) && event.key === "Enter";
    if (!settings.broadcastHotkey || !isBroadcastShortcut) return;
    const editor = findEditor();
    if (!editor || !(event.target === editor || editor.contains(event.target))) return;
    const prompt = readEditor(editor).trim();
    if (!prompt) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    chrome.runtime.sendMessage({ type: "RELAY_BROADCAST_FROM_PAGE", prompt }, (response) => {
      if (chrome.runtime.lastError) {
        setWidgetMessage("Relay could not reach other chats", true);
      } else if (response?.ok) {
        setWidgetMessage(`Sent to ${response.deliveredCount} open chats`);
      } else {
        setWidgetMessage("Open another AI chat to broadcast", true);
      }
    });
  }, true);

  chrome.storage.local.get(["relaySettings", "relayPreset"], (stored) => {
    settings = { ...DEFAULT_SETTINGS, ...(stored.relaySettings || {}) };
    preset = stored.relayPreset || "balanced";
    queueScan();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.relaySettings?.newValue) settings = { ...DEFAULT_SETTINGS, ...changes.relaySettings.newValue };
    if (changes.relayPreset?.newValue) preset = changes.relayPreset.newValue;
    queueScan();
  });

  const observer = new MutationObserver(queueScan);
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
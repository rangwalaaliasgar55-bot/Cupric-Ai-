import { useEffect, useMemo, useRef, useState } from "react";

type ModelId = "chatgpt" | "claude" | "gemini" | "deepseek";
type Preset = "balanced" | "precise" | "creative";
type TaskType = "general" | "coding" | "creative" | "analysis" | "research";
type ViewId = "workspace" | "library" | "insights" | "settings";
type Model = {
  id: ModelId;
  name: string;
  maker: string;
  note: string;
  initial: string;
};
type PromptTemplate = {
  id: string;
  title: string;
  category: string;
  description: string;
  prompt: string;
  custom?: boolean;
};
type RatingCounts = { helpful: number; unhelpful: number };
type Usage = {
  prepared: number;
  byModel: Record<ModelId, number>;
  ratings: Record<ModelId, RatingCounts>;
  byCategory: Record<TaskType, { byModel: Record<ModelId, number>; ratings: Record<ModelId, RatingCounts> }>;
};
type ExtensionSettings = {
  inlineTranslator: boolean;
  broadcastHotkey: boolean;
  saveDrafts: boolean;
};
type ChromeStorageArea = {
  get?: (keys: string[], callback: (items: Record<string, unknown>) => void) => void;
  set?: (items: Record<string, unknown>, callback?: () => void) => void;
};
type ChromeApi = {
  runtime?: {
    id?: string;
    sendMessage?: (message: Record<string, unknown>) => Promise<unknown>;
  };
  storage?: { local?: ChromeStorageArea };
};

const DEFAULT_PROMPT = `Review the customer interview notes below and identify the three most important unmet needs.\n\nFor each need, include a short supporting quote, why it matters, and one experiment we could run this month. Return a concise table. Avoid assumptions and label any uncertainty.\n\nInterview notes:\n[Paste interview notes here]`;
const DEFAULT_TARGETS: ModelId[] = ["chatgpt", "claude", "gemini"];
const DEFAULT_SETTINGS: ExtensionSettings = {
  inlineTranslator: true,
  broadcastHotkey: true,
  saveDrafts: true,
};
const MODELS: Model[] = [
  { id: "chatgpt", name: "ChatGPT", maker: "OpenAI", note: "Instruction-first", initial: "c" },
  { id: "claude", name: "Claude", maker: "Anthropic", note: "XML-guided structure", initial: "a" },
  { id: "gemini", name: "Gemini", maker: "Google", note: "Constraint-led", initial: "*" },
  { id: "deepseek", name: "DeepSeek", maker: "DeepSeek", note: "Direct + concise", initial: "d" },
];
const PRESET_LABELS: Record<Preset, string> = {
  balanced: "Balanced",
  precise: "More precise",
  creative: "More imaginative",
};
const TASK_TYPES: { id: TaskType; label: string }[] = [
  { id: "general", label: "General" },
  { id: "coding", label: "Coding" },
  { id: "creative", label: "Creative writing" },
  { id: "analysis", label: "Data analysis" },
  { id: "research", label: "Research" },
];
const BUILT_IN_TEMPLATES: PromptTemplate[] = [
  {
    id: "code-review",
    title: "Code review",
    category: "Engineering",
    description: "Surface real risks, explain impact, and suggest focused fixes.",
    prompt: `Review the code below for correctness, security, and maintainability.\n\nOnly report actionable issues. For each issue, include its severity, the relevant line or function, why it matters, and a minimal fix. If you find no issues, say so clearly.\n\nCode:\n[Paste code here]`,
  },
  {
    id: "research-brief",
    title: "Research synthesis",
    category: "Research",
    description: "Turn messy notes into evidence-backed themes and next steps.",
    prompt: DEFAULT_PROMPT,
  },
  {
    id: "launch-copy",
    title: "Launch announcement",
    category: "Writing",
    description: "Draft clear launch copy without slipping into generic hype.",
    prompt: `Write a launch announcement for the product described below.\n\nLead with the specific problem it solves. Explain the benefit in plain language, include one concrete example, and finish with a direct call to action. Keep the voice warm and confident; avoid buzzwords and unsupported claims.\n\nProduct details:\n[Add details here]`,
  },
];
function createUsage(): Usage {
  const byModel: Record<ModelId, number> = { chatgpt: 0, claude: 0, gemini: 0, deepseek: 0 };
  const ratings: Record<ModelId, RatingCounts> = {
    chatgpt: { helpful: 0, unhelpful: 0 },
    claude: { helpful: 0, unhelpful: 0 },
    gemini: { helpful: 0, unhelpful: 0 },
    deepseek: { helpful: 0, unhelpful: 0 },
  };
  const byCategory = Object.fromEntries(TASK_TYPES.map(({ id }) => [id, { byModel: { ...byModel }, ratings: structuredClone(ratings) }])) as Usage["byCategory"];
  return { prepared: 0, byModel, ratings, byCategory };
}

function mergeUsage(saved: Partial<Usage>): Usage {
  const base = createUsage();
  const byCategory = { ...base.byCategory };
  TASK_TYPES.forEach(({ id }) => {
    const category = saved.byCategory?.[id];
    if (category) {
      byCategory[id] = {
        byModel: { ...base.byCategory[id].byModel, ...category.byModel },
        ratings: { ...base.byCategory[id].ratings, ...category.ratings },
      };
    }
  });
  return {
    prepared: typeof saved.prepared === "number" ? saved.prepared : 0,
    byModel: { ...base.byModel, ...saved.byModel },
    ratings: { ...base.ratings, ...saved.ratings },
    byCategory,
  };
}

function isTaskType(value: unknown): value is TaskType {
  return TASK_TYPES.some((task) => task.id === value);
}

function addPreparedVersions(usage: Usage, ids: ModelId[], taskType: TaskType): Usage {
  const byModel = { ...usage.byModel };
  const categoryByModel = { ...usage.byCategory[taskType].byModel };
  ids.forEach((id) => {
    byModel[id] += 1;
    categoryByModel[id] += 1;
  });
  return {
    ...usage,
    prepared: usage.prepared + ids.length,
    byModel,
    byCategory: {
      ...usage.byCategory,
      [taskType]: { ...usage.byCategory[taskType], byModel: categoryByModel },
    },
  };
}

function readLocal<T>(key: string, fallback: T): T {
  try {
    const value = window.localStorage.getItem(key);
    return value === null ? fallback : (JSON.parse(value) as T);
  } catch {
    return fallback;
  }
}

function getChromeApi(): ChromeApi | undefined {
  return (globalThis as typeof globalThis & { chrome?: ChromeApi }).chrome;
}

function modelById(id: ModelId): Model {
  return MODELS.find((model) => model.id === id) ?? MODELS[0];
}

function isModelId(value: unknown): value is ModelId {
  return MODELS.some((model) => model.id === value);
}

function formatPrompt(prompt: string, modelId: ModelId, preset: Preset): string {
  const cleanPrompt = prompt.trim();
  const styleRules: Record<Preset, string> = {
    balanced: "Follow the requested format exactly. Do not invent details; label assumptions clearly.",
    precise: "Be exact and evidence-led. Separate facts from inferences, preserve every constraint, and flag missing information.",
    creative: "Explore fresh, specific ideas while respecting the brief. Avoid familiar cliches and keep every suggestion usable.",
  };
  const rules = styleRules[preset];

  if (modelId === "claude") {
    return `<task>\n${cleanPrompt}\n</task>\n\n<response_guidelines>\n${rules}\n</response_guidelines>`;
  }

  if (modelId === "gemini") {
    return `OBJECTIVE\n${cleanPrompt}\n\nPRIORITY CONSTRAINTS\n1. Follow every instruction and output format in the brief.\n2. ${rules}\n3. Keep the response focused on the requested task.`;
  }

  if (modelId === "deepseek") {
    return `### Task\n${cleanPrompt}\n\n### Requirements\n- ${rules}\n- Return the answer directly in the requested format.`;
  }

  return `Role: Careful, detail-oriented assistant\n\nTask:\n${cleanPrompt}\n\nResponse requirements:\n- ${rules}\n- Follow the requested output format exactly.`;
}

async function writeClipboard(value: string): Promise<void> {
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(value);
    return;
  }

  const input = document.createElement("textarea");
  input.value = value;
  input.style.position = "fixed";
  input.style.opacity = "0";
  document.body.appendChild(input);
  input.select();
  const copied = document.execCommand("copy");
  input.remove();
  if (!copied) throw new Error("Clipboard access is unavailable");
}

function Icon({
  name,
  size = 18,
}: {
  name:
    | "workspace"
    | "library"
    | "insights"
    | "settings"
    | "copy"
    | "send"
    | "check"
    | "spark"
    | "plus"
    | "search"
    | "arrow"
    | "up"
    | "down"
    | "shield"
    | "keyboard"
    | "close"
    | "extension"
    | "bookmark";
  size?: number;
}) {
  const shared = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true as const,
  };

  switch (name) {
    case "workspace":
      return <svg {...shared}><rect x="3.5" y="3.5" width="7" height="7" rx="1.5" /><rect x="13.5" y="3.5" width="7" height="7" rx="1.5" /><rect x="3.5" y="13.5" width="7" height="7" rx="1.5" /><rect x="13.5" y="13.5" width="7" height="7" rx="1.5" /></svg>;
    case "library":
      return <svg {...shared}><path d="M5 4.5h12a2 2 0 0 1 2 2v13H7a2 2 0 0 1-2-2z" /><path d="M5 17.5a2 2 0 0 1 2-2h12M9 8h6M9 11h5" /></svg>;
    case "insights":
      return <svg {...shared}><path d="M4 19V5M4 19h16" /><path d="M8 15v-3M13 15V8M18 15V5" /></svg>;
    case "settings":
      return <svg {...shared}><path d="M12 8.7a3.3 3.3 0 1 0 0 6.6 3.3 3.3 0 0 0 0-6.6Z" /><path d="m19.2 13.5 1.1.8-1.4 2.5-1.3-.5a7.5 7.5 0 0 1-1.5.9l-.2 1.4h-2.9l-.2-1.4a7.5 7.5 0 0 1-1.5-.9l-1.3.5-1.4-2.5 1.1-.8a7.6 7.6 0 0 1 0-1.8l-1.1-.8L8 8.4l1.3.5a7.5 7.5 0 0 1 1.5-.9l.2-1.4h2.9l.2 1.4a7.5 7.5 0 0 1 1.5.9l1.3-.5 1.4 2.5-1.1.8a7.6 7.6 0 0 1 0 1.8Z" /></svg>;
    case "copy":
      return <svg {...shared}><rect x="8" y="8" width="12" height="12" rx="2" /><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" /></svg>;
    case "send":
      return <svg {...shared}><path d="m21 3-7.4 18-3.8-7.8L2 9.4 21 3Z" /><path d="M9.8 13.2 15 8" /></svg>;
    case "check":
      return <svg {...shared}><path d="m5 12.5 4.2 4.2L19 7" /></svg>;
    case "spark":
      return <svg {...shared}><path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Z" /><path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16Z" /></svg>;
    case "plus":
      return <svg {...shared}><path d="M12 5v14M5 12h14" /></svg>;
    case "search":
      return <svg {...shared}><circle cx="10.8" cy="10.8" r="6.6" /><path d="m16 16 4.2 4.2" /></svg>;
    case "arrow":
      return <svg {...shared}><path d="M4.5 12h14M12.5 5.5l6.5 6.5-6.5 6.5" /></svg>;
    case "up":
      return <svg {...shared}><path d="m7 14 5-5 5 5" /></svg>;
    case "down":
      return <svg {...shared}><path d="m7 10 5 5 5-5" /></svg>;
    case "shield":
      return <svg {...shared}><path d="M12 3 19 6v5c0 4.5-2.8 7.7-7 10-4.2-2.3-7-5.5-7-10V6l7-3Z" /><path d="m9 12 2 2 4-4" /></svg>;
    case "keyboard":
      return <svg {...shared}><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M7 9h.01M10 9h.01M13 9h.01M16 9h.01M7 12h.01M10 12h.01M13 12h.01M16 12h.01M9 15h6" /></svg>;
    case "close":
      return <svg {...shared}><path d="m6 6 12 12M18 6 6 18" /></svg>;
    case "extension":
      return <svg {...shared}><path d="M8 4a2.5 2.5 0 1 1 5 0v2h4a2 2 0 0 1 2 2v3h-2a2.5 2.5 0 1 0 0 5h2v2a2 2 0 0 1-2 2h-4v-2a2.5 2.5 0 1 0-5 0v2H6a2 2 0 0 1-2-2v-4h2a2.5 2.5 0 1 0 0-5H4V8a2 2 0 0 1 2-2h2V4Z" /></svg>;
    case "bookmark":
      return <svg {...shared}><path d="M6 4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V21l-6-4-6 4V4.5Z" /></svg>;
  }
}

function RelayMark() {
  return (
    <svg width="23" height="23" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M4 7h10l-3-3M14 7l-3 3M20 17H10l3 3M10 17l3-3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ModelMark({ model, small = false }: { model: Model; small?: boolean }) {
  return (
    <span className={`model-mark model-${model.id}${small ? " model-mark-small" : ""}`} aria-hidden="true">
      {model.id === "gemini" ? <Icon name="spark" size={small ? 13 : 16} /> : model.initial}
    </span>
  );
}

function SyntaxText({ value }: { value: string }) {
  const pieces = value.split(/(<\/?[a-z_]+>)/gi);
  return (
    <>
      {pieces.map((piece, index) =>
        /^<\/?[a-z_]+>$/i.test(piece) ? (
          <span className="syntax-tag" key={`${piece}-${index}`}>{piece}</span>
        ) : (
          piece
        ),
      )}
    </>
  );
}

export default function App() {
  const [activeView, setActiveView] = useState<ViewId>("workspace");
  const [prompt, setPrompt] = useState<string>(() => readLocal("relay.draft", DEFAULT_PROMPT));
  const [selectedModels, setSelectedModels] = useState<ModelId[]>(() => {
    const saved = readLocal<unknown>("relay.targets", DEFAULT_TARGETS);
    return Array.isArray(saved) ? saved.filter(isModelId) : DEFAULT_TARGETS;
  });
  const [activeModel, setActiveModel] = useState<ModelId>("claude");
  const [preset, setPreset] = useState<Preset>(() => {
    const saved = readLocal<unknown>("relay.preset", "balanced");
    return saved === "precise" || saved === "creative" ? saved : "balanced";
  });
  const [taskType, setTaskType] = useState<TaskType>(() => {
    const saved = readLocal<unknown>("relay.taskType", "general");
    return isTaskType(saved) ? saved : "general";
  });
  const [templates, setTemplates] = useState<PromptTemplate[]>(() => readLocal("relay.templates", BUILT_IN_TEMPLATES));
  const [usage, setUsage] = useState<Usage>(() => mergeUsage(readLocal<Partial<Usage>>("relay.usage", {})));
  const [settings, setSettings] = useState<ExtensionSettings>(() => readLocal("relay.settings", DEFAULT_SETTINGS));
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [isExtension, setIsExtension] = useState(false);
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState("");
  const toastTimer = useRef<number | undefined>(undefined);

  const currentModel = modelById(activeModel);
  const formattedPrompt = useMemo(() => formatPrompt(prompt, activeModel, preset), [prompt, activeModel, preset]);
  const previewModels = selectedModels.length ? selectedModels : MODELS.map((model) => model.id);
  const wordCount = prompt.trim() ? prompt.trim().split(/\s+/).length : 0;
  const taskLabel = TASK_TYPES.find((task) => task.id === taskType)?.label ?? "General";
  const taskMetrics = usage.byCategory[taskType];
  const taskPrepared = Object.values(taskMetrics.byModel).reduce((total, count) => total + count, 0);
  const filteredTemplates = templates.filter((template) =>
    `${template.title} ${template.category} ${template.description}`.toLowerCase().includes(search.toLowerCase()),
  );

  useEffect(() => {
    document.title = "Relay | Universal prompt translator";
    const chromeApi = getChromeApi();
    const storage = chromeApi?.storage?.local;

    if (!chromeApi?.runtime?.id || !storage?.get) {
      setSettingsLoaded(true);
      return;
    }

    setIsExtension(true);
    storage.get(["relayTargets", "relayPreset", "relayTaskType", "relaySettings"], (items) => {
      const targets = items.relayTargets;
      if (Array.isArray(targets)) setSelectedModels(targets.filter(isModelId));
      if (items.relayPreset === "balanced" || items.relayPreset === "precise" || items.relayPreset === "creative") {
        setPreset(items.relayPreset);
      }
      if (isTaskType(items.relayTaskType)) setTaskType(items.relayTaskType);
      if (items.relaySettings && typeof items.relaySettings === "object") {
        setSettings({ ...DEFAULT_SETTINGS, ...(items.relaySettings as Partial<ExtensionSettings>) });
      }
      setSettingsLoaded(true);
    });
  }, []);

  useEffect(() => {
    try {
      if (settings.saveDrafts) window.localStorage.setItem("relay.draft", JSON.stringify(prompt));
      else window.localStorage.removeItem("relay.draft");
    } catch {
      // Draft persistence is optional when browser storage is unavailable.
    }
  }, [prompt, settings.saveDrafts]);

  useEffect(() => {
    try {
      window.localStorage.setItem("relay.targets", JSON.stringify(selectedModels));
      window.localStorage.setItem("relay.preset", JSON.stringify(preset));
      window.localStorage.setItem("relay.taskType", JSON.stringify(taskType));
      window.localStorage.setItem("relay.templates", JSON.stringify(templates));
      window.localStorage.setItem("relay.usage", JSON.stringify(usage));
      window.localStorage.setItem("relay.settings", JSON.stringify(settings));
    } catch {
      // The workspace remains usable without local persistence.
    }
  }, [selectedModels, preset, taskType, templates, usage, settings]);

  useEffect(() => {
    if (!isExtension || !settingsLoaded) return;
    getChromeApi()?.storage?.local?.set?.({ relayTargets: selectedModels, relayPreset: preset, relayTaskType: taskType, relaySettings: settings });
  }, [isExtension, settingsLoaded, selectedModels, preset, taskType, settings]);

  useEffect(
    () => () => {
      if (toastTimer.current !== undefined) window.clearTimeout(toastTimer.current);
    },
    [],
  );

  useEffect(() => {
    if (selectedModels.length && !selectedModels.includes(activeModel)) setActiveModel(selectedModels[0]);
  }, [selectedModels, activeModel]);

  function notify(message: string) {
    setToast(message);
    if (toastTimer.current !== undefined) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 3200);
  }

  function toggleTarget(id: ModelId) {
    if (selectedModels.includes(id)) {
      const next = selectedModels.filter((selected) => selected !== id);
      setSelectedModels(next);
      if (activeModel === id && next.length) setActiveModel(next[0]);
      return;
    }
    setSelectedModels([...selectedModels, id]);
    setActiveModel(id);
  }

  function selectAllTargets() {
    const allSelected = selectedModels.length === MODELS.length;
    setSelectedModels(allSelected ? [] : MODELS.map((model) => model.id));
    if (!allSelected) setActiveModel("claude");
  }

  async function copyPreview() {
    try {
      await writeClipboard(formattedPrompt);
      setCopied(true);
      notify(`${currentModel.name} version copied`);
      window.setTimeout(() => setCopied(false), 1700);
    } catch {
      notify("Clipboard access is unavailable in this browser");
    }
  }

  async function handleBroadcast() {
    if (!prompt.trim()) {
      notify("Add a prompt before preparing model versions");
      return;
    }
    if (!selectedModels.length) {
      notify("Choose at least one model to continue");
      return;
    }

    setIsBroadcasting(true);
    const runtime = getChromeApi()?.runtime;

    if (isExtension && runtime?.sendMessage) {
      try {
        const response = (await runtime.sendMessage({
          type: "RELAY_BROADCAST_PROMPT",
          prompt,
          targets: selectedModels,
          preset,
        taskType,
        })) as { ok?: boolean; reason?: string; deliveredCount?: number; sentModels?: ModelId[] };

        if (!response?.ok && response?.reason === "NO_TABS") {
          notify("No selected AI chats are open yet. Open a model tab and try again.");
        } else if (!response?.ok && response?.reason === "NO_EDITORS") {
          notify("Open a chat in the selected model tabs before broadcasting");
        } else if (response?.ok) {
          const deliveredModels = response.sentModels?.filter(isModelId) ?? [];
          setUsage((current) => addPreparedVersions(current, deliveredModels, taskType));
          notify(`Prompt sent to ${response.deliveredCount ?? deliveredModels.length} open AI chat${response.deliveredCount === 1 ? "" : "s"}`);
        } else {
          notify("Relay could not reach the open AI tabs. Try again in a moment.");
        }
      } catch {
        notify("Could not reach the extension service. Reload Relay and try again.");
      }
      setIsBroadcasting(false);
      return;
    }

    const bundle = selectedModels
      .map((id) => `--- ${modelById(id).name} ---\n${formatPrompt(prompt, id, preset)}`)
      .join("\n\n");
    try {
      await writeClipboard(bundle);
      setUsage((current) => addPreparedVersions(current, selectedModels, taskType));
      notify(`${selectedModels.length} model-ready versions copied as a bundle`);
    } catch {
      notify("Versions prepared. Copy each model-ready prompt from the preview.");
    }
    setIsBroadcasting(false);
  }

  function saveCurrentPrompt() {
    if (!prompt.trim()) {
      notify("Write a prompt before saving it");
      return;
    }
    const duplicate = templates.some((template) => template.prompt === prompt);
    if (duplicate) {
      notify("This prompt is already in your library");
      return;
    }
    const firstLine = prompt.trim().split("\n").find((line) => line.trim()) ?? "Custom prompt";
    const title = firstLine.length > 38 ? `${firstLine.slice(0, 35)}...` : firstLine;
    const template: PromptTemplate = {
      id: `saved-${Date.now()}`,
      title,
      category: "Custom",
      description: "Saved from your workspace.",
      prompt,
      custom: true,
    };
    setTemplates((current) => [template, ...current]);
    notify("Prompt saved to your library");
  }

  function useTemplate(template: PromptTemplate) {
    setPrompt(template.prompt);
    setActiveView("workspace");
    notify(`Loaded ${template.title}`);
  }

  function recordRating(id: ModelId, kind: keyof RatingCounts) {
    setUsage((current) => {
      const overallRatings = {
        ...current.ratings,
        [id]: { ...current.ratings[id], [kind]: current.ratings[id][kind] + 1 },
      };
      const category = current.byCategory[taskType];
      const categoryRatings = {
        ...category.ratings,
        [id]: { ...category.ratings[id], [kind]: category.ratings[id][kind] + 1 },
      };
      return {
        ...current,
        ratings: overallRatings,
        byCategory: { ...current.byCategory, [taskType]: { ...category, ratings: categoryRatings } },
      };
    });
    notify(`Feedback saved for ${modelById(id).name}`);
  }

  function updateSetting(key: keyof ExtensionSettings) {
    setSettings((current) => ({ ...current, [key]: !current[key] }));
  }

  const navItems: { id: ViewId; label: string; icon: "workspace" | "library" | "insights" | "settings" }[] = [
    { id: "workspace", label: "Workspace", icon: "workspace" },
    { id: "library", label: "Prompt library", icon: "library" },
    { id: "insights", label: "Insights", icon: "insights" },
    { id: "settings", label: "Settings", icon: "settings" },
  ];

  const viewLabels: Record<ViewId, string> = {
    workspace: "Prompt workspace",
    library: "Prompt library",
    insights: "Performance insights",
    settings: "Extension settings",
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <button className="brand-lockup" onClick={() => setActiveView("workspace")} aria-label="Relay workspace">
          <span className="brand-mark"><RelayMark /></span>
          <span className="brand-name">relay<span className="brand-period">.</span></span>
        </button>

        <div className="sidebar-section-label">YOUR WORKSPACE</div>
        <nav className="sidebar-nav" aria-label="Main navigation">
          {navItems.map((item) => (
            <button
              key={item.id}
              className={`nav-item${activeView === item.id ? " nav-item-active" : ""}`}
              onClick={() => setActiveView(item.id)}
              aria-current={activeView === item.id ? "page" : undefined}
            >
              <Icon name={item.icon} size={17} />
              <span>{item.label}</span>
              {item.id === "library" && templates.some((template) => template.custom) && (
                <span className="nav-count">{templates.filter((template) => template.custom).length}</span>
              )}
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="sidebar-extension">
            <span className="extension-mark"><Icon name="extension" size={17} /></span>
            <div className="extension-copy">
              <span>Chrome extension</span>
              <small><i className={isExtension ? "status-dot status-dot-on" : "status-dot"} />{isExtension ? "Connected" : "Preview mode"}</small>
            </div>
            <span className="extension-version">v1.0</span>
          </div>
          <div className="profile-row">
            <span className="profile-avatar">S</span>
            <div className="profile-copy"><strong>Sam Rivera</strong><span>Personal workspace</span></div>
            <span className="profile-more">...</span>
          </div>
        </div>
      </aside>

      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumb"><span>RELAY</span><span className="breadcrumb-slash">/</span><strong>{viewLabels[activeView]}</strong></div>
          <div className="topbar-actions">
            <div className="save-state"><i className="save-state-dot" /><span>{isExtension ? "Extension active" : "Private by design"}</span></div>
            <span className="topbar-divider" />
            <span className="topbar-avatar">S</span>
          </div>
        </header>

        <main className="page-content">
          {activeView === "workspace" && (
            <>
              <div className="page-intro">
                <div>
                  <div className="eyebrow"><span className="eyebrow-line" /> UNIVERSAL PROMPT TRANSLATOR</div>
                  <h1>Make one prompt work everywhere.</h1>
                  <p>Write it once. Relay shapes it for the model you want to use.</p>
                </div>
                <div className="intro-side-note">
                  <span className="intro-note-icon"><Icon name="shield" size={16} /></span>
                  <span><strong>Private by default</strong><small>Prompts stay in your browser</small></span>
                </div>
              </div>

              <div className="workspace-grid">
                <div className="editor-column">
                  <section className="compose-section" aria-labelledby="compose-title">
                    <div className="section-heading">
                      <div className="section-heading-left"><span className="section-index">01</span><h2 id="compose-title">Your prompt</h2></div>
                      <button className="text-action" onClick={saveCurrentPrompt}><Icon name="bookmark" size={15} /> Save to library</button>
                    </div>

                    <div className="editor-panel">
                      <div className="editor-topline">
                        <span className="editor-type"><span className="editor-live-dot" /> MAIN INSTRUCTION</span>
                        <span className="autosave-label">{settings.saveDrafts ? "Saved on this device" : "Draft saving off"}</span>
                      </div>
                      <label className="sr-only" htmlFor="prompt-editor">Write your prompt</label>
                      <textarea
                        id="prompt-editor"
                        className="prompt-input"
                        value={prompt}
                        onChange={(event) => setPrompt(event.target.value)}
                        onKeyDown={(event) => {
                          if ((event.ctrlKey || event.metaKey) && event.key === "Enter" && settings.broadcastHotkey) {
                            event.preventDefault();
                            void handleBroadcast();
                          }
                        }}
                        placeholder="Describe the task, context, and format you need..."
                        spellCheck={false}
                      />
                      <div className="editor-footer">
                        <div className="editor-foot-meta">
                          <span>{wordCount} words</span>
                          <span className="meta-separator" />
                          <span className="shortcut-hint"><kbd>{navigator.platform?.includes("Mac") ? "Cmd" : "Ctrl"} + Enter</kbd><span>to broadcast</span></span>
                        </div>
                        <button className="primary-button" onClick={() => void handleBroadcast()} disabled={isBroadcasting || !selectedModels.length}>
                          <Icon name="send" size={15} />
                          <span>{isBroadcasting ? "Preparing..." : isExtension ? `Broadcast to ${selectedModels.length} models` : `Prepare ${selectedModels.length} versions`}</span>
                          {!isBroadcasting && <span className="button-arrow">-&gt;</span>}
                        </button>
                      </div>
                    </div>
                    <div className="compose-footnote"><span>MODEL-AWARE FORMATTING</span><span className="footnote-dot" />Your instructions are preserved; only the structure changes.</div>
                  </section>

                  <section className="preview-section" aria-labelledby="preview-title">
                    <div className="preview-heading">
                      <div className="section-heading-left"><span className="section-index">02</span><div><h2 id="preview-title">Model-ready prompt</h2><p>See how Relay adapts your instructions.</p></div></div>
                      <div className="preview-tabs" role="tablist" aria-label="Preview model">
                        {previewModels.map((id) => {
                          const model = modelById(id);
                          return (
                            <button
                              key={id}
                              className={`preview-tab${activeModel === id ? " preview-tab-active" : ""}`}
                              onClick={() => setActiveModel(id)}
                              role="tab"
                              aria-selected={activeModel === id}
                            >
                              <ModelMark model={model} small />
                              <span>{model.name}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="output-panel">
                      <div className="output-topline">
                        <div className="output-model"><ModelMark model={currentModel} small /><span><strong>{currentModel.name}</strong><small>{currentModel.maker} format</small></span></div>
                        <button className={`copy-button${copied ? " copy-button-done" : ""}`} onClick={() => void copyPreview()}>
                          <Icon name={copied ? "check" : "copy"} size={15} />{copied ? "Copied" : "Copy version"}
                        </button>
                      </div>
                      <pre className="translated-prompt"><code><SyntaxText value={formattedPrompt || "Your adapted prompt will appear here."} /></code></pre>
                      <div className="output-footer"><span><i className="output-ready-dot" /> LIVE PREVIEW</span><span>{PRESET_LABELS[preset]} structure</span></div>
                    </div>
                  </section>
                </div>

                <aside className="target-column" aria-label="Translation options">
                  <section className="target-panel">
                    <div className="target-panel-heading">
                      <div><span className="panel-overline">DESTINATIONS</span><h2>Choose your models</h2></div>
                      <span className="selected-count">{selectedModels.length}<span> / {MODELS.length}</span></span>
                    </div>
                    <div className="target-list">
                      {MODELS.map((model) => {
                        const selected = selectedModels.includes(model.id);
                        return (
                          <button
                            key={model.id}
                            className={`target-row${selected ? " target-row-selected" : ""}`}
                            onClick={() => toggleTarget(model.id)}
                            aria-pressed={selected}
                          >
                            <ModelMark model={model} />
                            <span className="target-copy"><strong>{model.name}</strong><small>{model.note}</small></span>
                            <span className={`target-checkbox${selected ? " target-checkbox-on" : ""}`}>{selected && <Icon name="check" size={13} />}</span>
                          </button>
                        );
                      })}
                    </div>
                    <div className="target-list-action"><button className="text-action" onClick={selectAllTargets}>{selectedModels.length === MODELS.length ? "Clear selection" : "Select all models"}<Icon name="arrow" size={14} /></button></div>

                    <div className="tuning-block">
                      <label htmlFor="preset-select" className="tuning-label">OPTIMIZATION STYLE</label>
                      <div className="select-wrap">
                        <select id="preset-select" value={preset} onChange={(event) => setPreset(event.target.value as Preset)}>
                          <option value="balanced">Balanced</option>
                          <option value="precise">More precise</option>
                          <option value="creative">More imaginative</option>
                        </select>
                        <span className="select-chevron">v</span>
                      </div>
                      <p>Sets the response guidance added to each model format.</p>
                    </div>
                    <div className="category-tuning">
                      <label htmlFor="task-type-select" className="tuning-label">PROMPT CATEGORY</label>
                      <div className="select-wrap">
                        <select id="task-type-select" value={taskType} onChange={(event) => setTaskType(event.target.value as TaskType)}>
                          {TASK_TYPES.map((task) => <option key={task.id} value={task.id}>{task.label}</option>)}
                        </select>
                        <span className="select-chevron">v</span>
                      </div>
                      <p>Used to compare which model works best for this kind of task.</p>
                    </div>
                    <div className="privacy-note"><Icon name="shield" size={16} /><span>Translated locally. Your prompt is never sent to Relay.</span></div>
                  </section>

                  <div className="keyboard-note">
                    <span className="keyboard-icon"><Icon name="keyboard" size={17} /></span>
                    <span className="keyboard-copy"><strong>One shortcut, every model</strong><small>Press Ctrl + Enter from any AI chat.</small></span>
                    <span className="keyboard-arrow">-&gt;</span>
                  </div>

                  <div className="model-quirk-note"><span className="quirk-spark"><Icon name="spark" size={14} /></span><p><strong>Different models, different habits.</strong> Relay adds the structure each one follows best.</p></div>
                </aside>
              </div>
            </>
          )}

          {activeView === "library" && (
            <section className="subpage library-view">
              <div className="page-intro subpage-intro">
                <div><div className="eyebrow"><span className="eyebrow-line" /> REUSABLE STARTING POINTS</div><h1>Your prompt library.</h1><p>Keep your best briefs close. Pick one, then tune it for any model.</p></div>
                <span className="library-total">{templates.length} prompts</span>
              </div>
              <div className="library-toolbar">
                <label className="search-field"><Icon name="search" size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search prompts" aria-label="Search prompts" /></label>
                <span className="library-local"><Icon name="shield" size={15} /> Stored on this device</span>
              </div>
              <div className="template-list">
                {filteredTemplates.length ? filteredTemplates.map((template, index) => (
                  <article className="template-row" key={template.id}>
                    <span className="template-index">{String(index + 1).padStart(2, "0")}</span>
                    <div className="template-main"><div className="template-title-line"><h2>{template.title}</h2><span className="template-category">{template.category}</span></div><p>{template.description}</p></div>
                    <button className="template-use-button" onClick={() => useTemplate(template)}>Use prompt <Icon name="arrow" size={15} /></button>
                    {template.custom && <button className="template-delete" onClick={() => setTemplates((current) => current.filter((item) => item.id !== template.id))} aria-label={`Delete ${template.title}`}><Icon name="close" size={16} /></button>}
                  </article>
                )) : <div className="empty-state"><span className="empty-mark"><Icon name="search" size={20} /></span><h2>No prompts found</h2><p>Try another search, or save a prompt from your workspace.</p></div>}
              </div>
            </section>
          )}

          {activeView === "insights" && (
            <section className="subpage insights-view">
              <div className="page-intro subpage-intro">
                <div><div className="eyebrow"><span className="eyebrow-line" /> YOUR PROMPT PRACTICE</div><h1>Learn what works.</h1><p>Keep a lightweight scorecard as you compare model outputs.</p></div>
                <div className="insight-total"><span>{taskPrepared}</span><small>{taskLabel.toLowerCase()} versions prepared</small></div>
              </div>
              <div className="insight-explainer"><span className="insight-explainer-mark"><Icon name="insights" size={18} /></span><p>After reviewing a response in its AI chat, rate how useful that model was for the task. Ratings are manual; Relay never reads your conversations.</p></div>
              <div className="insight-filter-row">
                <label htmlFor="insight-task-select">SHOW RESULTS FOR</label>
                <select id="insight-task-select" value={taskType} onChange={(event) => setTaskType(event.target.value as TaskType)}>
                  {TASK_TYPES.map((task) => <option key={task.id} value={task.id}>{task.label}</option>)}
                </select>
                <span>Ratings are grouped by prompt category.</span>
              </div>
              <section className="performance-table">
                <div className="performance-head"><span>MODEL</span><span>VERSIONS PREPARED</span><span>HELPFUL RATING</span><span>YOUR FEEDBACK</span></div>
                {MODELS.map((model) => {
                  const ratings = taskMetrics.ratings[model.id];
                  const totalRatings = ratings.helpful + ratings.unhelpful;
                  const helpfulPercent = totalRatings ? Math.round((ratings.helpful / totalRatings) * 100) : 0;
                  return (
                    <div className="performance-row" key={model.id}>
                      <div className="performance-model"><ModelMark model={model} /><span><strong>{model.name}</strong><small>{model.maker}</small></span></div>
                      <span className="prepared-count">{taskMetrics.byModel[model.id]} <small>prompts</small></span>
                      <div className="rating-progress-wrap"><div className="rating-progress"><span style={{ width: `${helpfulPercent}%` }} /></div><span className="rating-percent">{totalRatings ? `${helpfulPercent}%` : "No ratings"}</span></div>
                      <div className="rating-actions"><button onClick={() => recordRating(model.id, "helpful")} aria-label={`Rate ${model.name} helpful`}><Icon name="up" size={14} /><span>Helpful</span><b>{ratings.helpful}</b></button><button onClick={() => recordRating(model.id, "unhelpful")} aria-label={`Rate ${model.name} not helpful`}><Icon name="down" size={14} /><span>Not yet</span><b>{ratings.unhelpful}</b></button></div>
                    </div>
                  );
                })}
              </section>
              <div className="insight-footnote"><Icon name="shield" size={15} /> Your usage and ratings are saved locally in this browser.</div>
            </section>
          )}

          {activeView === "settings" && (
            <section className="subpage settings-view">
              <div className="page-intro subpage-intro">
                <div><div className="eyebrow"><span className="eyebrow-line" /> MAKE RELAY YOURS</div><h1>Quietly in your corner.</h1><p>Choose how Relay shows up across your AI chats.</p></div>
              </div>
              <div className="settings-layout">
                <div className="settings-list">
                  <div className="settings-group-title"><span>IN-CHAT TOOLS</span><small>How the extension appears on AI platforms.</small></div>
                  <SettingRow
                    title="Inline translate button"
                    description="Show a small Relay control beside supported chat composers."
                    checked={settings.inlineTranslator}
                    onToggle={() => updateSetting("inlineTranslator")}
                  />
                  <SettingRow
                    title="Broadcast shortcut"
                    description="Use Ctrl + Enter to send a model-optimized prompt to selected open chats."
                    checked={settings.broadcastHotkey}
                    onToggle={() => updateSetting("broadcastHotkey")}
                  />
                  <div className="settings-group-title settings-group-spaced"><span>LOCAL STORAGE</span><small>Your prompt data stays in this browser.</small></div>
                  <SettingRow
                    title="Save draft between sessions"
                    description="Keep your current workspace prompt on this device."
                    checked={settings.saveDrafts}
                    onToggle={() => updateSetting("saveDrafts")}
                  />
                </div>
                <aside className="settings-privacy">
                  <span className="privacy-large-icon"><Icon name="shield" size={21} /></span>
                  <span className="panel-overline">LOCAL-FIRST BY DESIGN</span>
                  <h2>Your prompts stay yours.</h2>
                  <p>Relay restructures text in your browser. It does not send prompts to a Relay server or read the answers in your AI chats.</p>
                  <div className="privacy-divider" />
                  <div className="privacy-detail"><span>Prompt storage</span><strong>This device only</strong></div>
                  <div className="privacy-detail"><span>Prompt processing</span><strong>In your browser</strong></div>
                </aside>
              </div>
            </section>
          )}
        </main>
      </div>

      {toast && <div className="toast-message" role="status"><span className="toast-check"><Icon name="check" size={14} /></span>{toast}</div>}
    </div>
  );
}

function SettingRow({
  title,
  description,
  checked,
  onToggle,
}: {
  title: string;
  description: string;
  checked: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="setting-row">
      <div className="setting-copy"><strong>{title}</strong><p>{description}</p></div>
      <button className={`switch${checked ? " switch-on" : ""}`} onClick={onToggle} role="switch" aria-checked={checked} aria-label={title}><span /></button>
    </div>
  );
}
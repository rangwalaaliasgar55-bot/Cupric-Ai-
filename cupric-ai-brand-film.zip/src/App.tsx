import { useEffect, useRef, useState } from "react";

type Point = { x: number; y: number; z?: number };

const WIDTH = 1920;
const HEIGHT = 1080;
const DURATION = 40;
const LIME = "#c8ff5a";
const WHITE = "#f3f4ef";

const scenes = [
  { start: 0, end: 3, label: "THE HOOK" },
  { start: 3, end: 6, label: "INFINITE DIRECTIONS" },
  { start: 6, end: 9, label: "INTELLIGENCE IN MOTION" },
  { start: 9, end: 12, label: "BUILD FASTER" },
  { start: 12, end: 15, label: "PROMPT TO PRODUCT" },
  { start: 15, end: 18, label: "LESS REPETITION" },
  { start: 18, end: 21, label: "10X" },
  { start: 21, end: 24, label: "IDEAS CONNECT" },
  { start: 24, end: 27, label: "MAKE NOISE" },
  { start: 27, end: 30, label: "HUMAN + MACHINE" },
  { start: 30, end: 33, label: "BUILD WHAT'S NEXT" },
  { start: 33, end: 36, label: "BRAND REVEAL" },
  { start: 36, end: 38, label: "THE STATEMENT" },
  { start: 38, end: 40, label: "END CARD" },
];

const seed = (index: number, salt = 1) => {
  const x = Math.sin(index * 9283.17 + salt * 421.73) * 43758.5453;
  return x - Math.floor(x);
};

const stars = Array.from({ length: 520 }, (_, i) => ({
  x: seed(i, 2) * WIDTH,
  y: seed(i, 3) * HEIGHT,
  size: 0.3 + seed(i, 4) * 1.7,
  alpha: 0.08 + seed(i, 5) * 0.36,
}));

const particleField = Array.from({ length: 640 }, (_, i) => {
  const theta = seed(i, 7) * Math.PI * 2;
  const radius = 80 + seed(i, 8) * 560;
  return {
    theta,
    radius,
    y: (seed(i, 9) - 0.5) * 1.8,
    speed: 0.12 + seed(i, 10) * 0.85,
    size: 0.8 + seed(i, 11) * 2.2,
    phase: seed(i, 12) * Math.PI * 2,
  };
});

const networkNodes = Array.from({ length: 76 }, (_, i) => ({
  x: (seed(i, 21) - 0.5) * 920,
  y: (seed(i, 22) - 0.5) * 500,
  z: seed(i, 23),
  size: 1.5 + seed(i, 24) * 4,
}));

const cityBlocks = Array.from({ length: 44 }, (_, i) => ({
  x: (seed(i, 31) - 0.5) * 1700,
  z: 0.15 + seed(i, 32) * 1.1,
  width: 26 + seed(i, 33) * 92,
  height: 24 + seed(i, 34) * 160,
  glow: seed(i, 35),
}));

const easeOut = (value: number) => 1 - Math.pow(1 - Math.max(0, Math.min(1, value)), 3);
const easeInOut = (value: number) => {
  const x = Math.max(0, Math.min(1, value));
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
};
const smooth = (value: number, start = 0, end = 1) => {
  const x = Math.max(0, Math.min(1, (value - start) / (end - start)));
  return x * x * (3 - 2 * x);
};
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

function roundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, radius: number) {
  const r = Math.min(radius, Math.abs(w) / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function trackedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  size: number,
  color: string,
  tracking = 0,
  align: CanvasTextAlign = "center",
  weight = 500,
  opacity = 1,
) {
  ctx.save();
  ctx.globalAlpha = opacity;
  ctx.font = `${weight} ${size}px Arial, Helvetica, sans-serif`;
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  const characters = Array.from(text);
  const widths = characters.map((character) => ctx.measureText(character).width);
  const total = widths.reduce((sum, width) => sum + width, 0) + Math.max(0, characters.length - 1) * tracking;
  let cursor = align === "center" ? x - total / 2 : align === "right" ? x - total : x;
  characters.forEach((character, index) => {
    ctx.fillStyle = color;
    ctx.fillText(character, cursor, y);
    cursor += widths[index] + tracking;
  });
  ctx.restore();
}

function glowDot(ctx: CanvasRenderingContext2D, x: number, y: number, radius: number, color: string, alpha = 1) {
  const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius * 5);
  const rgb = color === LIME ? "200,255,90" : "198,216,187";
  gradient.addColorStop(0, `rgba(${rgb},${0.82 * alpha})`);
  gradient.addColorStop(0.14, `rgba(${rgb},${0.24 * alpha})`);
  gradient.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.arc(x, y, radius * 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = color;
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
}

function drawLogoMark(ctx: CanvasRenderingContext2D, x: number, y: number, scale = 1, alpha = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = LIME;
  ctx.fillStyle = LIME;
  ctx.lineWidth = 5 * scale;
  ctx.lineCap = "round";
  for (let i = 0; i < 8; i += 1) {
    const angle = (Math.PI * 2 * i) / 8;
    ctx.beginPath();
    ctx.moveTo(Math.cos(angle) * 8 * scale, Math.sin(angle) * 8 * scale);
    ctx.lineTo(Math.cos(angle) * 23 * scale, Math.sin(angle) * 23 * scale);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.arc(0, 0, 7 * scale, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawBackground(ctx: CanvasRenderingContext2D, t: number, intensity = 1) {
  ctx.fillStyle = "#050605";
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
  const wash = ctx.createRadialGradient(WIDTH * 0.49, HEIGHT * 0.46, 0, WIDTH * 0.49, HEIGHT * 0.46, 850);
  wash.addColorStop(0, `rgba(38, 51, 28, ${0.18 * intensity})`);
  wash.addColorStop(0.42, `rgba(15, 20, 13, ${0.12 * intensity})`);
  wash.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = wash;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
  stars.forEach((star, index) => {
    const driftX = ((t * (4 + (index % 4)) + index * 3) % 28) - 14;
    const driftY = Math.sin(t * 0.2 + index) * 2;
    ctx.globalAlpha = star.alpha * intensity * (0.72 + Math.sin(t * 0.55 + index) * 0.2);
    ctx.fillStyle = index % 9 === 0 ? LIME : "#c7ccc0";
    ctx.fillRect(star.x + driftX, star.y + driftY, star.size, star.size);
  });
  ctx.globalAlpha = 1;
}

function drawGrain(ctx: CanvasRenderingContext2D, t: number) {
  ctx.save();
  ctx.globalAlpha = 0.035;
  ctx.fillStyle = "#e9f4d6";
  for (let i = 0; i < 190; i += 1) {
    const x = (seed(i, Math.floor(t * 5) + 81) * WIDTH) | 0;
    const y = (seed(i, Math.floor(t * 5) + 91) * HEIGHT) | 0;
    ctx.fillRect(x, y, 1, 1);
  }
  ctx.restore();
}

function drawVignette(ctx: CanvasRenderingContext2D) {
  const vignette = ctx.createRadialGradient(WIDTH / 2, HEIGHT / 2, 360, WIDTH / 2, HEIGHT / 2, 970);
  vignette.addColorStop(0, "rgba(0,0,0,0)");
  vignette.addColorStop(0.78, "rgba(0,0,0,0.08)");
  vignette.addColorStop(1, "rgba(0,0,0,0.72)");
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
}

function drawHook(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const centerX = WIDTH / 2;
  const centerY = HEIGHT / 2;
  const reveal = easeOut(p / 0.86);
  const camera = 1 + p * 0.55;
  const fieldRadius = 95 + reveal * 510;
  ctx.save();
  ctx.translate(centerX, centerY);
  ctx.scale(camera, camera);
  ctx.rotate(Math.sin(t * 0.16) * 0.035);
  ctx.globalCompositeOperation = "lighter";
  for (let i = 0; i < particleField.length; i += 1) {
    const particle = particleField[i];
    const radius = fieldRadius * (0.15 + particle.radius / 680);
    const angle = particle.theta + t * (0.05 + particle.speed * 0.015) + Math.sin(t * 0.3 + particle.phase) * 0.12;
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius * (0.42 + particle.y * 0.11);
    const alpha = Math.max(0, 0.84 - Math.abs(particle.radius - 360) / 520) * reveal;
    ctx.fillStyle = i % 13 === 0 ? LIME : "rgba(201, 213, 187, 0.72)";
    ctx.globalAlpha = alpha;
    ctx.beginPath();
    ctx.arc(x, y, particle.size * (0.55 + reveal), 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 0.4 * reveal;
  ctx.lineWidth = 1;
  for (let i = 0; i < 18; i += 1) {
    const angle = (Math.PI * 2 * i) / 18 + t * 0.06;
    const x = Math.cos(angle) * fieldRadius * 0.92;
    const y = Math.sin(angle) * fieldRadius * 0.42;
    ctx.strokeStyle = i % 4 === 0 ? LIME : "#b0c2a0";
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(x, y);
    ctx.stroke();
  }
  ctx.globalCompositeOperation = "source-over";
  ctx.restore();
  glowDot(ctx, centerX, centerY, 6 + reveal * 12, LIME, 0.7 + reveal * 0.25);
  const titleAlpha = smooth(p, 0.34, 0.7);
  trackedText(ctx, "CREATE.", centerX, centerY - 28, 144, WHITE, 2, "center", 700, titleAlpha);
  trackedText(ctx, "WITH INTELLIGENCE.", centerX, centerY + 120, 34, LIME, 8, "center", 500, smooth(p, 0.58, 0.88));
  if (p > 0.84) {
    ctx.fillStyle = `rgba(200,255,90,${(p - 0.84) * 3})`;
    ctx.fillRect(0, 0, WIDTH, HEIGHT);
  }
}

function drawDirections(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const originX = WIDTH * 0.47;
  const originY = HEIGHT * 0.53;
  const spread = easeInOut(p);
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (let branch = 0; branch < 32; branch += 1) {
    const baseAngle = -Math.PI * 0.88 + (Math.PI * 1.76 * branch) / 31;
    const length = (480 + seed(branch, 42) * 620) * spread;
    ctx.beginPath();
    ctx.moveTo(originX, originY);
    for (let point = 1; point <= 16; point += 1) {
      const q = point / 16;
      const wave = Math.sin(t * 0.35 + branch * 0.72 + q * 5) * (7 + (branch % 4) * 2);
      const curve = baseAngle + Math.sin(q * 3.3 + branch) * 0.09;
      const x = originX + Math.cos(curve) * length * q + Math.cos(curve + Math.PI / 2) * wave;
      const y = originY + Math.sin(curve) * length * q * 0.58 + Math.sin(curve + Math.PI / 2) * wave;
      ctx.lineTo(x, y);
    }
    ctx.lineWidth = branch % 9 === 0 ? 2.4 : 0.8;
    ctx.strokeStyle = branch % 7 === 0 ? `rgba(200,255,90,${0.85 * spread})` : `rgba(184,202,169,${0.22 * spread})`;
    ctx.stroke();
    const dotQ = (t * 0.12 + seed(branch, 45)) % 1;
    const dotAngle = baseAngle + Math.sin(dotQ * 3.3 + branch) * 0.09;
    glowDot(ctx, originX + Math.cos(dotAngle) * length * dotQ, originY + Math.sin(dotAngle) * length * dotQ * 0.58, 2.2, LIME, 0.48);
  }
  ctx.restore();
  const alpha = smooth(p, 0.18, 0.54);
  trackedText(ctx, "ONE IDEA.", WIDTH * 0.12, HEIGHT * 0.33, 30, LIME, 5, "left", 500, alpha);
  trackedText(ctx, "INFINITE", WIDTH * 0.12, HEIGHT * 0.71, 88, WHITE, 1, "left", 600, alpha);
  trackedText(ctx, "DIRECTIONS.", WIDTH * 0.12, HEIGHT * 0.8, 88, WHITE, 1, "left", 600, smooth(p, 0.38, 0.68));
  for (let copy = 0; copy < 5; copy += 1) {
    const copyAlpha = Math.max(0, 0.34 - Math.abs(copy - 2) * 0.07) * smooth(p, 0.42, 0.8);
    trackedText(ctx, "DIRECTIONS", WIDTH * (0.59 + copy * 0.105), HEIGHT * (0.22 + (copy % 2) * 0.06), 20, LIME, 3, "center", 500, copyAlpha);
  }
}

function drawNetwork(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const scale = 0.74 + easeOut(p) * 0.22;
  const cx = WIDTH * 0.57;
  const cy = HEIGHT * 0.53;
  const positions = networkNodes.map((node, i) => ({
    x: cx + node.x * scale + Math.sin(t * 0.45 + i) * 14,
    y: cy + node.y * scale + Math.cos(t * 0.32 + i * 0.7) * 12,
    z: node.z,
    size: node.size,
  }));
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  positions.forEach((a, index) => {
    positions.forEach((b, otherIndex) => {
      if (otherIndex <= index) return;
      const distance = Math.hypot(a.x - b.x, a.y - b.y);
      if (distance < 160) {
        ctx.strokeStyle = `rgba(170,195,155,${(1 - distance / 160) * 0.24 * p})`;
        ctx.lineWidth = otherIndex % 11 === 0 ? 2 : 0.7;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
    });
  });
  positions.forEach((node, index) => {
    const active = (t * 0.3 + index * 0.14) % 1;
    glowDot(ctx, node.x, node.y, node.size * (0.5 + node.z), index % 8 === 0 ? LIME : "#b7c7ad", 0.6 * p);
    ctx.strokeStyle = `rgba(200,255,90,${0.25 * p})`;
    ctx.beginPath();
    ctx.arc(node.x, node.y, 5 + active * 19, 0, Math.PI * 2);
    ctx.stroke();
  });
  ctx.restore();
  trackedText(ctx, "INTELLIGENCE", WIDTH * 0.1, HEIGHT * 0.31, 33, LIME, 6, "left", 500, smooth(p, 0.08, 0.4));
  trackedText(ctx, "IN MOTION.", WIDTH * 0.1, HEIGHT * 0.71, 105, WHITE, 0, "left", 650, smooth(p, 0.26, 0.74));
}

function drawWorkspace(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const build = easeOut(p);
  ctx.save();
  ctx.strokeStyle = "rgba(177,201,165,0.07)";
  ctx.lineWidth = 1;
  for (let x = 0; x < WIDTH; x += 64) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, HEIGHT);
    ctx.stroke();
  }
  for (let y = 0; y < HEIGHT; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(WIDTH, y);
    ctx.stroke();
  }
  ctx.restore();
  const left = 190;
  const top = 188;
  const panelW = 1540 * build;
  ctx.fillStyle = "rgba(17,20,16,0.92)";
  roundedRect(ctx, left, top, panelW, 700, 12);
  ctx.fill();
  ctx.strokeStyle = "rgba(206,230,191,0.18)";
  ctx.lineWidth = 1;
  roundedRect(ctx, left, top, panelW, 700, 12);
  ctx.stroke();
  ctx.fillStyle = "rgba(9,11,9,0.9)";
  roundedRect(ctx, left, top, 250, 700, 12);
  ctx.fill();
  ctx.strokeStyle = "rgba(206,230,191,0.12)";
  ctx.beginPath();
  ctx.moveTo(left + 250, top);
  ctx.lineTo(left + 250, top + 700);
  ctx.stroke();
  trackedText(ctx, "CUPRIC / WORKSPACE", left + 28, top + 43, 15, LIME, 2, "left", 600, build);
  const nav = ["Overview", "Generate", "Systems", "Signals"];
  nav.forEach((item, index) => {
    trackedText(ctx, item.toUpperCase(), left + 28, top + 124 + index * 52, 13, index === 1 ? WHITE : "#737b70", 1.8, "left", 500, build);
    if (index === 1) {
      ctx.fillStyle = LIME;
      ctx.fillRect(left + 27, top + 144, 3, 12);
    }
  });
  const cardX = left + 300;
  const cardY = top + 112;
  ctx.fillStyle = "rgba(207,232,190,0.06)";
  roundedRect(ctx, cardX, cardY, 530, 208, 9);
  ctx.fill();
  trackedText(ctx, "PROJECT VELOCITY", cardX + 30, cardY + 30, 12, "#8b9985", 2, "left", 500, build);
  trackedText(ctx, "+ 284%", cardX + 30, cardY + 89, 54, WHITE, 0, "left", 600, build);
  ctx.strokeStyle = LIME;
  ctx.lineWidth = 3;
  ctx.beginPath();
  for (let i = 0; i < 13; i += 1) {
    const x = cardX + 24 + i * 38;
    const y = cardY + 169 - Math.sin(i * 0.9 + t) * 18 - i * 4;
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  }
  ctx.stroke();
  ctx.fillStyle = "rgba(200,255,90,0.12)";
  ctx.beginPath();
  ctx.moveTo(cardX + 24, cardY + 169);
  for (let i = 0; i < 13; i += 1) ctx.lineTo(cardX + 24 + i * 38, cardY + 169 - Math.sin(i * 0.9 + t) * 18 - i * 4);
  ctx.lineTo(cardX + 480, cardY + 208);
  ctx.lineTo(cardX + 24, cardY + 208);
  ctx.closePath();
  ctx.fill();
  const secondX = cardX + 570;
  ctx.fillStyle = "rgba(207,232,190,0.06)";
  roundedRect(ctx, secondX, cardY, 540, 208, 9);
  ctx.fill();
  trackedText(ctx, "ACTIVE SYSTEMS", secondX + 30, cardY + 30, 12, "#8b9985", 2, "left", 500, build);
  for (let i = 0; i < 4; i += 1) {
    ctx.fillStyle = i === 0 ? LIME : "#647060";
    ctx.beginPath();
    ctx.arc(secondX + 36, cardY + 83 + i * 28, 4, 0, Math.PI * 2);
    ctx.fill();
    trackedText(ctx, ["Research engine", "Visual compiler", "Market signals", "Product memory"][i], secondX + 57, cardY + 83 + i * 28, 16, i === 0 ? WHITE : "#8a9585", 0, "left", 500, build);
    ctx.fillStyle = "rgba(195,218,182,0.13)";
    ctx.fillRect(secondX + 340, cardY + 78 + i * 28, 150, 5);
    ctx.fillStyle = i === 0 ? LIME : "#66745e";
    ctx.fillRect(secondX + 340, cardY + 78 + i * 28, (50 + i * 21) * build, 5);
  }
  trackedText(ctx, "BUILD", WIDTH * 0.72, HEIGHT * 0.82, 30, LIME, 5, "center", 500, smooth(p, 0.18, 0.5));
  trackedText(ctx, "FASTER.", WIDTH * 0.72, HEIGHT * 0.9, 96, WHITE, -1, "center", 700, smooth(p, 0.37, 0.75));
  if (p > 0.79) {
    ctx.fillStyle = `rgba(245,255,226,${(p - 0.79) * 3.5})`;
    ctx.fillRect(0, 0, WIDTH, HEIGHT);
  }
}

function drawPromptProduct(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const processing = smooth(p, 0.16, 0.48);
  const output = smooth(p, 0.42, 0.87);
  const x = 236;
  const y = 172;
  const w = 1448;
  const h = 710;
  ctx.fillStyle = "rgba(13,16,13,0.95)";
  roundedRect(ctx, x, y, w, h, 14);
  ctx.fill();
  ctx.strokeStyle = "rgba(217,237,204,0.19)";
  ctx.lineWidth = 1;
  roundedRect(ctx, x, y, w, h, 14);
  ctx.stroke();
  ctx.fillStyle = "rgba(202,226,187,0.08)";
  ctx.fillRect(x, y + 62, w, 1);
  trackedText(ctx, "COMMAND / 01", x + 30, y + 32, 13, LIME, 2, "left", 600, 1);
  trackedText(ctx, "CU", x + w - 30, y + 32, 13, "#87917f", 1, "right", 600, 1);
  const promptX = x + 48;
  const promptY = y + 119;
  ctx.fillStyle = "rgba(215,237,203,0.06)";
  roundedRect(ctx, promptX, promptY, 850, 88, 8);
  ctx.fill();
  ctx.strokeStyle = `rgba(200,255,90,${0.32 + processing * 0.48})`;
  roundedRect(ctx, promptX, promptY, 850, 88, 8);
  ctx.stroke();
  trackedText(ctx, ">", promptX + 26, promptY + 44, 28, LIME, 0, "left", 500, 1);
  trackedText(ctx, "Build something people will remember.", promptX + 66, promptY + 44, 26, WHITE, 0, "left", 500, smooth(p, 0.05, 0.3));
  ctx.fillStyle = LIME;
  ctx.fillRect(promptX + 66 + Math.min(725, p * 900), promptY + 25, 2, 36);
  trackedText(ctx, processing > 0.1 ? "COMPOSING RESPONSE" : "READY", promptX, promptY + 136, 12, processing > 0.1 ? LIME : "#75816d", 2, "left", 500, 1);
  const sideX = x + 947;
  ctx.fillStyle = "rgba(200,255,90,0.04)";
  roundedRect(ctx, sideX, y + 103, 452, 438, 8);
  ctx.fill();
  trackedText(ctx, "GENERATED SYSTEM", sideX + 24, y + 130, 12, "#93a18b", 2, "left", 500, output);
  trackedText(ctx, "remember", sideX + 24, y + 194, 42, WHITE, -1, "left", 600, output);
  trackedText(ctx, "the feeling", sideX + 24, y + 238, 42, LIME, -1, "left", 600, output);
  for (let i = 0; i < 5; i += 1) {
    ctx.fillStyle = i === 2 ? LIME : "rgba(213,235,199,0.2)";
    ctx.fillRect(sideX + 24, y + 295 + i * 32, (185 + Math.sin(i + t) * 36) * output, 5);
  }
  ctx.strokeStyle = "rgba(201,232,186,0.15)";
  ctx.strokeRect(sideX + 270, y + 288, 124, 110);
  ctx.strokeStyle = LIME;
  ctx.beginPath();
  ctx.moveTo(sideX + 286, y + 370);
  ctx.lineTo(sideX + 313, y + 332);
  ctx.lineTo(sideX + 337, y + 349);
  ctx.lineTo(sideX + 369, y + 310);
  ctx.stroke();
  const productY = y + 592;
  for (let i = 0; i < 4; i += 1) {
    const cardX = x + 48 + i * 267;
    const cardWidth = 234;
    ctx.fillStyle = "rgba(205,230,191,0.07)";
    roundedRect(ctx, cardX, productY, cardWidth, 78, 6);
    ctx.fill();
    ctx.fillStyle = i === 1 ? LIME : "#96a891";
    ctx.fillRect(cardX + 17, productY + 18, 36, 5);
    ctx.fillStyle = "rgba(215,237,203,0.23)";
    ctx.fillRect(cardX + 17, productY + 42, 150 + i * 9, 4);
    ctx.fillRect(cardX + 17, productY + 55, 86 + i * 17, 4);
  }
  trackedText(ctx, "FROM PROMPT", WIDTH * 0.16, HEIGHT * 0.85, 26, LIME, 4, "left", 500, smooth(p, 0.1, 0.36));
  trackedText(ctx, "TO PRODUCT.", WIDTH * 0.78, HEIGHT * 0.85, 64, WHITE, 0, "center", 650, output);
}

function drawRepetition(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const collapse = easeInOut(smooth(p, 0.27, 0.75));
  const centerX = WIDTH / 2;
  const centerY = HEIGHT * 0.49;
  for (let row = 0; row < 3; row += 1) {
    for (let col = 0; col < 5; col += 1) {
      const baseX = 246 + col * 302;
      const baseY = 176 + row * 196;
      const x = lerp(baseX, centerX - 78, collapse);
      const y = lerp(baseY, centerY, collapse);
      const scale = lerp(1, 0.16, collapse);
      const alpha = 0.8 * (1 - collapse * 0.55);
      ctx.save();
      ctx.translate(x, y);
      ctx.scale(scale, scale);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = "rgba(197,220,184,0.07)";
      roundedRect(ctx, -112, -58, 224, 116, 7);
      ctx.fill();
      ctx.strokeStyle = "rgba(201,232,187,0.18)";
      ctx.stroke();
      ctx.fillStyle = col === 1 ? LIME : "#90a38b";
      ctx.fillRect(-88, -25, 55 + (row * 12), 5);
      ctx.fillStyle = "rgba(215,237,203,0.22)";
      ctx.fillRect(-88, 4, 152, 4);
      ctx.fillRect(-88, 20, 92, 4);
      ctx.restore();
    }
  }
  ctx.strokeStyle = `rgba(200,255,90,${collapse * 0.8})`;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(220, centerY);
  ctx.lineTo(centerX - 90, centerY);
  ctx.lineTo(centerX + 90, centerY);
  ctx.lineTo(1690, centerY);
  ctx.stroke();
  for (let i = 0; i < 8; i += 1) {
    const x = lerp(220 + i * 210, centerX, collapse) + Math.sin(t * 2 + i) * 4;
    glowDot(ctx, x, centerY, 3 + collapse * 2, LIME, 0.5 * collapse);
  }
  trackedText(ctx, "LESS REPETITION.", WIDTH * 0.1, HEIGHT * 0.83, 38, WHITE, 1, "left", 500, smooth(p, 0.02, 0.33));
  trackedText(ctx, "MORE CREATION.", WIDTH * 0.89, HEIGHT * 0.83, 38, LIME, 1, "right", 500, smooth(p, 0.38, 0.7));
}

function drawTenX(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const impact = smooth(p, 0.02, 0.22);
  const breakApart = smooth(p, 0.46, 0.96);
  const scale = 0.82 + impact * 0.23 - breakApart * 0.55;
  ctx.save();
  ctx.translate(WIDTH / 2, HEIGHT / 2);
  ctx.scale(scale, scale);
  ctx.globalAlpha = 1 - breakApart * 0.9;
  trackedText(ctx, "10×", 0, 22, 360, WHITE, -12, "center", 700, impact);
  ctx.strokeStyle = LIME;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-255, 218);
  ctx.lineTo(255, 218);
  ctx.stroke();
  ctx.restore();
  ctx.globalCompositeOperation = "lighter";
  for (let i = 0; i < 360; i += 1) {
    const angle = seed(i, 61) * Math.PI * 2;
    const distance = seed(i, 62) * 190 + breakApart * 780 * (0.5 + seed(i, 63));
    const x = WIDTH / 2 + Math.cos(angle) * distance + Math.cos(t * 1.4 + i) * 16;
    const y = HEIGHT / 2 + Math.sin(angle) * distance * 0.58 + Math.sin(t * 1.1 + i * 0.8) * 15;
    ctx.fillStyle = i % 12 === 0 ? LIME : "#d7e6ce";
    ctx.globalAlpha = breakApart * (0.22 + seed(i, 64) * 0.7);
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle + t);
    ctx.fillRect(-2, -1, 12 + seed(i, 65) * 24, 2);
    ctx.restore();
  }
  ctx.globalCompositeOperation = "source-over";
  trackedText(ctx, "SYSTEMS THAT KEEP UP.", WIDTH / 2, HEIGHT * 0.84, 20, LIME, 5, "center", 500, breakApart * 0.9);
}

function drawConnect(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const connect = easeInOut(smooth(p, 0.08, 0.86));
  const center = { x: WIDTH * 0.52, y: HEIGHT * 0.5 };
  const objects: Point[] = [
    { x: 340, y: 302 },
    { x: 670, y: 236 },
    { x: 1520, y: 270 },
    { x: 1300, y: 780 },
    { x: 620, y: 814 },
    { x: 1570, y: 690 },
  ];
  const moved = objects.map((point, i) => ({
    x: lerp(point.x, center.x + Math.cos(i) * 170, connect),
    y: lerp(point.y, center.y + Math.sin(i) * 135, connect),
  }));
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  moved.forEach((a, i) => {
    moved.forEach((b, j) => {
      if (j <= i) return;
      ctx.strokeStyle = `rgba(173,202,157,${0.18 + connect * 0.4})`;
      ctx.lineWidth = j % 2 === 0 ? 2 : 0.8;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    });
  });
  moved.forEach((point, i) => {
    ctx.strokeStyle = i % 2 ? LIME : "#cce5bc";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(point.x, point.y, 24 + Math.sin(t + i) * 5, 0, Math.PI * 2);
    ctx.stroke();
    glowDot(ctx, point.x, point.y, 6, i % 2 ? LIME : "#cde7bd", 0.75);
  });
  ctx.strokeStyle = LIME;
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.arc(center.x, center.y, 110 + Math.sin(t * 0.6) * 9, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
  trackedText(ctx, "IDEAS", WIDTH * 0.12, HEIGHT * 0.26, 29, LIME, 5, "left", 500, smooth(p, 0.08, 0.35));
  trackedText(ctx, "CONNECT.", WIDTH * 0.12, HEIGHT * 0.8, 112, WHITE, 0, "left", 650, smooth(p, 0.3, 0.7));
}

function drawNoise(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const words = ["THINK", "BUILD", "TEST", "CREATE", "ITERATE", "LAUNCH"];
  const chaos = 1 - smooth(p, 0.58, 0.94);
  words.forEach((word, i) => {
    const baseX = 270 + (i % 3) * 640;
    const baseY = 260 + Math.floor(i / 3) * 290;
    const x = baseX + Math.sin(t * 1.5 + i * 2) * 170 * chaos;
    const y = baseY + Math.cos(t * 1.2 + i) * 80 * chaos;
    const rotate = Math.sin(t * 0.9 + i) * 0.12 * chaos;
    ctx.save();
    ctx.translate(lerp(x, WIDTH / 2, 1 - chaos), lerp(y, HEIGHT / 2, 1 - chaos));
    ctx.rotate(rotate);
    trackedText(ctx, word, 0, 0, 80 - i * 3, i % 2 ? WHITE : LIME, -2, "center", 650, 0.2 + chaos * 0.8);
    ctx.restore();
  });
  for (let i = 0; i < 24; i += 1) {
    const x = WIDTH / 2 + Math.sin(i * 1.7 + t) * 720 * chaos;
    const y = HEIGHT / 2 + Math.cos(i * 2.3 + t * 0.6) * 410 * chaos;
    ctx.strokeStyle = `rgba(200,255,90,${0.18 * chaos})`;
    ctx.beginPath();
    ctx.moveTo(WIDTH / 2, HEIGHT / 2);
    ctx.lineTo(x, y);
    ctx.stroke();
  }
  trackedText(ctx, "MAKE NOISE.", WIDTH / 2, HEIGHT / 2 + 6, 146, WHITE, -3, "center", 700, smooth(p, 0.55, 0.88));
  ctx.strokeStyle = LIME;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(WIDTH / 2 - 310, HEIGHT / 2 + 96);
  ctx.lineTo(WIDTH / 2 + 310, HEIGHT / 2 + 96);
  ctx.stroke();
}

function drawHumanMachine(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const sync = easeInOut(smooth(p, 0.24, 0.82));
  const centerX = WIDTH / 2;
  const centerY = HEIGHT / 2;
  ctx.strokeStyle = "rgba(195,218,181,0.09)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(centerX, 120);
  ctx.lineTo(centerX, 950);
  ctx.stroke();
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.strokeStyle = "#cbdcc3";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(160, centerY + 170);
  for (let i = 0; i <= 30; i += 1) {
    const x = 160 + i * 27;
    const y = centerY + 170 - Math.sin(i * 0.64 + t * 0.4) * (40 + i * 2) - i * 6;
    ctx.lineTo(lerp(x, centerX - 12, sync), lerp(y, centerY, sync));
  }
  ctx.stroke();
  ctx.strokeStyle = LIME;
  ctx.beginPath();
  ctx.moveTo(WIDTH - 160, centerY - 170);
  for (let i = 0; i <= 30; i += 1) {
    const x = WIDTH - 160 - i * 27;
    const y = centerY - 170 + Math.cos(i * 0.7 + t * 0.45) * (36 + i * 2) + i * 6;
    ctx.lineTo(lerp(x, centerX + 12, sync), lerp(y, centerY, sync));
  }
  ctx.stroke();
  for (let i = 0; i < 34; i += 1) {
    const angle = seed(i, 71) * Math.PI * 2;
    const orbit = 90 + seed(i, 72) * 220;
    const x = centerX + Math.cos(angle + t * 0.4) * orbit * (1 - sync * 0.6);
    const y = centerY + Math.sin(angle + t * 0.4) * orbit * 0.48 * (1 - sync * 0.6);
    glowDot(ctx, x, y, 2 + seed(i, 73) * 2, i % 3 === 0 ? LIME : "#c9d9c0", 0.5);
  }
  ctx.restore();
  glowDot(ctx, centerX, centerY, 6 + sync * 16, LIME, 0.65 + sync * 0.25);
  trackedText(ctx, "HUMAN INTENT.", WIDTH * 0.12, HEIGHT * 0.32, 32, WHITE, 3, "left", 500, smooth(p, 0.02, 0.32));
  trackedText(ctx, "MACHINE SPEED.", WIDTH * 0.88, HEIGHT * 0.7, 32, LIME, 3, "right", 500, smooth(p, 0.34, 0.68));
  trackedText(ctx, "ONE SYSTEM.", WIDTH / 2, HEIGHT * 0.84, 18, "#94a28d", 5, "center", 500, sync * 0.8);
}

function drawCity(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const camera = easeInOut(p);
  const horizon = HEIGHT * 0.59;
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.strokeStyle = "rgba(171,206,150,0.22)";
  ctx.lineWidth = 1;
  for (let i = -12; i <= 12; i += 1) {
    ctx.beginPath();
    ctx.moveTo(WIDTH / 2 + i * 26, horizon);
    ctx.lineTo(WIDTH / 2 + i * 1600, HEIGHT);
    ctx.stroke();
  }
  for (let i = 0; i < 9; i += 1) {
    const y = horizon + Math.pow(i / 9, 1.8) * (HEIGHT - horizon);
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(WIDTH, y);
    ctx.stroke();
  }
  cityBlocks.forEach((block, index) => {
    const depth = Math.max(0.05, block.z - camera * 0.22);
    const x = WIDTH / 2 + block.x / depth * 0.55;
    const y = horizon - block.height * (1.1 - depth) - camera * 20;
    const width = block.width / depth;
    const height = block.height / depth;
    if (x < -300 || x > WIDTH + 300) return;
    ctx.fillStyle = index % 5 === 0 ? "rgba(200,255,90,0.12)" : "rgba(193,220,177,0.06)";
    ctx.fillRect(x - width / 2, y, width, height);
    ctx.strokeStyle = index % 5 === 0 ? "rgba(200,255,90,0.7)" : "rgba(196,221,182,0.22)";
    ctx.strokeRect(x - width / 2, y, width, height);
    for (let line = 0; line < Math.min(5, Math.max(1, Math.floor(width / 20))); line += 1) {
      ctx.fillStyle = index % 5 === 0 ? LIME : "#839b79";
      ctx.globalAlpha = 0.3 + block.glow * 0.5;
      ctx.fillRect(x - width / 2 + 8 + line * 16, y + 12 + ((t * 18 + line * 17 + index) % Math.max(14, height - 20)), 3, 3);
    }
  });
  ctx.globalAlpha = 1;
  ctx.restore();
  trackedText(ctx, "BUILD", WIDTH * 0.12, HEIGHT * 0.26, 31, LIME, 5, "left", 500, smooth(p, 0.06, 0.35));
  trackedText(ctx, "WHAT'S NEXT.", WIDTH * 0.12, HEIGHT * 0.82, 92, WHITE, -1, "left", 650, smooth(p, 0.3, 0.73));
}

function drawBrandReveal(ctx: CanvasRenderingContext2D, p: number) {
  const reveal = smooth(p, 0.13, 0.74);
  const collapse = 1 - smooth(p, 0.02, 0.45);
  ctx.globalCompositeOperation = "lighter";
  for (let i = 0; i < 160; i += 1) {
    const angle = seed(i, 90) * Math.PI * 2;
    const distance = (70 + seed(i, 91) * 700) * collapse;
    const x = WIDTH / 2 + Math.cos(angle) * distance;
    const y = HEIGHT / 2 + Math.sin(angle) * distance * 0.33;
    ctx.fillStyle = i % 7 === 0 ? LIME : "#c4d5bb";
    ctx.globalAlpha = 0.6 * collapse;
    ctx.fillRect(x, y, 2 + seed(i, 92) * 6, 1 + seed(i, 93) * 2);
  }
  ctx.globalCompositeOperation = "source-over";
  const lineWidth = reveal * 510;
  ctx.fillStyle = LIME;
  ctx.shadowColor = LIME;
  ctx.shadowBlur = 16;
  ctx.fillRect(WIDTH / 2 - lineWidth / 2, HEIGHT / 2 + 84, lineWidth, 2);
  ctx.shadowBlur = 0;
  drawLogoMark(ctx, WIDTH / 2 - 218, HEIGHT / 2 - 7, 1.15, reveal);
  trackedText(ctx, "CUPRIC", WIDTH / 2 - 150, HEIGHT / 2, 94, WHITE, 0, "left", 700, reveal);
  trackedText(ctx, "AI", WIDTH / 2 + 215, HEIGHT / 2, 94, LIME, -2, "left", 700, reveal);
  trackedText(ctx, "A NEW WAY TO MAKE.", WIDTH / 2, HEIGHT * 0.74, 16, "#95a68e", 4, "center", 500, smooth(p, 0.62, 0.92));
}

function drawStatement(ctx: CanvasRenderingContext2D, p: number, t: number) {
  const alpha = smooth(p, 0.06, 0.62);
  const glow = 0.18 + Math.sin(t * 0.8) * 0.04;
  ctx.strokeStyle = `rgba(200,255,90,${glow})`;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(WIDTH / 2, HEIGHT / 2, 240 + Math.sin(t * 0.4) * 6, Math.PI * 0.12, Math.PI * 0.88);
  ctx.stroke();
  drawLogoMark(ctx, WIDTH / 2, 286, 0.68, alpha);
  trackedText(ctx, "CUPRIC AI", WIDTH / 2, 365, 22, WHITE, 5, "center", 600, alpha);
  trackedText(ctx, "INTELLIGENCE FOR PEOPLE WHO BUILD.", WIDTH / 2, HEIGHT / 2 + 25, 46, WHITE, 1, "center", 500, alpha);
  ctx.fillStyle = LIME;
  ctx.fillRect(WIDTH / 2 - 82, HEIGHT / 2 + 92, 164 * alpha, 2);
}

function drawEndCard(ctx: CanvasRenderingContext2D, p: number) {
  const alpha = smooth(p, 0.02, 0.55);
  drawLogoMark(ctx, WIDTH / 2 - 202, HEIGHT / 2 - 26, 0.82, alpha);
  trackedText(ctx, "CUPRIC", WIDTH / 2 - 142, HEIGHT / 2 - 12, 72, WHITE, 0, "left", 700, alpha);
  trackedText(ctx, "AI", WIDTH / 2 + 158, HEIGHT / 2 - 12, 72, LIME, -1, "left", 700, alpha);
  trackedText(ctx, "INTELLIGENCE FOR PEOPLE WHO BUILD.", WIDTH / 2, HEIGHT / 2 + 90, 24, WHITE, 3, "center", 500, alpha);
  trackedText(ctx, "CREATE WITHOUT LIMITS.", WIDTH / 2, HEIGHT / 2 + 166, 16, LIME, 4, "center", 500, alpha);
  ctx.fillStyle = `rgba(200,255,90,${0.11 * alpha})`;
  ctx.beginPath();
  ctx.arc(WIDTH / 2, HEIGHT / 2 - 8, 270 + p * 120, 0, Math.PI * 2);
  ctx.fill();
}

function renderFilm(ctx: CanvasRenderingContext2D, time: number, pointer: { x: number; y: number }) {
  const sceneIndex = Math.min(scenes.length - 1, Math.floor(time / 3));
  const scene = scenes[sceneIndex];
  const p = (time - scene.start) / (scene.end - scene.start);
  drawBackground(ctx, time, sceneIndex >= 11 ? 0.5 : 1);
  switch (sceneIndex) {
    case 0: drawHook(ctx, p, time); break;
    case 1: drawDirections(ctx, p, time); break;
    case 2: drawNetwork(ctx, p, time); break;
    case 3: drawWorkspace(ctx, p, time); break;
    case 4: drawPromptProduct(ctx, p, time); break;
    case 5: drawRepetition(ctx, p, time); break;
    case 6: drawTenX(ctx, p, time); break;
    case 7: drawConnect(ctx, p, time); break;
    case 8: drawNoise(ctx, p, time); break;
    case 9: drawHumanMachine(ctx, p, time); break;
    case 10: drawCity(ctx, p, time); break;
    case 11: drawBrandReveal(ctx, p); break;
    case 12: drawStatement(ctx, p, time); break;
    case 13: drawEndCard(ctx, p); break;
    default: break;
  }
  if (sceneIndex < 11) {
    ctx.save();
    ctx.globalAlpha = 0.18;
    ctx.strokeStyle = LIME;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, 48);
    ctx.lineTo(170 + Math.sin(time) * 50, 48);
    ctx.stroke();
    ctx.restore();
  }
  ctx.save();
  ctx.globalAlpha = 0.16;
  ctx.fillStyle = LIME;
  ctx.beginPath();
  ctx.arc(pointer.x * WIDTH, pointer.y * HEIGHT, 100, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  drawVignette(ctx);
  drawGrain(ctx, time);
}

function formatTime(value: number) {
  const seconds = Math.max(0, Math.min(DURATION, value));
  return `00:${seconds.toFixed(2).padStart(5, "0")}`;
}

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand-lockup ${compact ? "brand-lockup--compact" : ""}`}>
      <svg className="brand-mark" viewBox="0 0 48 48" aria-hidden="true">
        <g stroke="currentColor" strokeWidth="3.5" strokeLinecap="round">
          <path d="M24 3v11M24 34v11M3 24h11M34 24h11M9.2 9.2l7.7 7.7M31.1 31.1l7.7 7.7M38.8 9.2l-7.7 7.7M16.9 31.1l-7.7 7.7" />
        </g>
        <circle cx="24" cy="24" r="6.5" fill="currentColor" />
      </svg>
      <span className="brand-name">Cupric <b>AI</b></span>
    </div>
  );
}

function Icon({ name }: { name: "play" | "pause" | "volume" | "fullscreen" | "replay" }) {
  if (name === "play") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5 18 12 8 18.5z" /></svg>;
  if (name === "pause") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14M16 5v14" /></svg>;
  if (name === "volume") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 10v4h4l5 4V6l-5 4H5ZM17 9a4.2 4.2 0 0 1 0 6M19.4 6.8a7.4 7.4 0 0 1 0 10.4" /></svg>;
  if (name === "replay") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 11a8 8 0 1 1 2.1 5.4M4 5v6h6" /></svg>;
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 4H4v4M16 4h4v4M20 16v4h-4M4 16v4h4" /></svg>;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const timeRef = useRef(0.7);
  const pointerRef = useRef({ x: 0.52, y: 0.5 });
  const [playing, setPlaying] = useState(true);
  const [time, setTime] = useState(0.7);
  const [muted, setMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = WIDTH;
    canvas.height = HEIGHT;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let animationFrame = 0;
    let last = performance.now();
    let lastUiUpdate = 0;
    const tick = (now: number) => {
      const delta = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (playing) {
        timeRef.current += delta;
        if (timeRef.current >= DURATION) timeRef.current = 0;
        if (now - lastUiUpdate > 42) {
          setTime(timeRef.current);
          lastUiUpdate = now;
        }
      }
      renderFilm(ctx, timeRef.current, pointerRef.current);
      animationFrame = requestAnimationFrame(tick);
    };
    animationFrame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animationFrame);
  }, [playing]);

  const activeScene = scenes[Math.min(scenes.length - 1, Math.floor(time / 3))];
  const setFilmTime = (nextTime: number) => {
    const clamped = Math.max(0, Math.min(DURATION - 0.001, nextTime));
    timeRef.current = clamped;
    setTime(clamped);
  };
  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect();
    pointerRef.current = {
      x: Math.max(0, Math.min(1, (event.clientX - bounds.left) / bounds.width)),
      y: Math.max(0, Math.min(1, (event.clientY - bounds.top) / bounds.height)),
    };
  };
  const toggleFullscreen = async () => {
    if (!document.fullscreenElement) {
      await document.documentElement.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      await document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  return (
    <main className="app-shell">
      <header className="topbar">
        <Logo />
        <div className="topbar-center">
          <span className="topbar-kicker">MOTION STUDY / 001</span>
          <span className="topbar-rule" />
          <span className="topbar-title">INTELLIGENCE FOR PEOPLE WHO BUILD.</span>
        </div>
        <div className="topbar-meta">
          <span>1920 × 1080</span>
          <span>30 FPS</span>
          <span className="live-dot" />
          <span>LIVE PREVIEW</span>
        </div>
      </header>
      <section className="film-section">
        <div className="film-heading">
          <div>
            <p className="eyebrow">CUPRIC AI / BRAND FILM</p>
            <h1>Build what only you can imagine.</h1>
          </div>
          <div className="film-heading-right"><span>40 SECONDS</span><span className="slash">/</span><span>{activeScene.label}</span></div>
        </div>
        <div className="film-frame" onPointerMove={handlePointerMove}>
          <canvas ref={canvasRef} aria-label="Cupric AI cinematic brand film" />
          <div className="frame-corner frame-corner--tl" /><div className="frame-corner frame-corner--tr" /><div className="frame-corner frame-corner--bl" /><div className="frame-corner frame-corner--br" />
          <div className="frame-overlay"><span>CU / FILM 001</span><span>RENDERED IN REAL TIME</span></div>
        </div>
        <div className="transport">
          <button className="icon-button" onClick={() => setPlaying((value) => !value)} aria-label={playing ? "Pause film" : "Play film"}><Icon name={playing ? "pause" : "play"} /></button>
          <button className="icon-button transport-replay" onClick={() => setFilmTime(0)} aria-label="Replay film"><Icon name="replay" /></button>
          <div className="timeline-wrap">
            <div className="timeline-meta"><span>{formatTime(time)}</span><span>{activeScene.label}</span><span>{formatTime(DURATION)}</span></div>
            <div className="timeline" onClick={(event) => {
              const bounds = event.currentTarget.getBoundingClientRect();
              setFilmTime(((event.clientX - bounds.left) / bounds.width) * DURATION);
            }}>
              <div className="timeline-fill" style={{ width: `${(time / DURATION) * 100}%` }} /><div className="timeline-thumb" style={{ left: `${(time / DURATION) * 100}%` }} />
              {scenes.map((scene) => <button type="button" className={`scene-tick ${time >= scene.start && time < scene.end ? "scene-tick--active" : ""}`} key={scene.label} style={{ left: `${(scene.start / DURATION) * 100}%` }} onClick={(event) => { event.stopPropagation(); setFilmTime(scene.start + 0.12); }} aria-label={`Jump to ${scene.label}`} />)}
            </div>
          </div>
          <button className={`icon-button ${muted ? "is-muted" : ""}`} onClick={() => setMuted((value) => !value)} aria-label={muted ? "Unmute" : "Mute"}><Icon name="volume" /></button>
          <button className={`icon-button ${isFullscreen ? "is-active" : ""}`} onClick={toggleFullscreen} aria-label="Toggle fullscreen"><Icon name="fullscreen" /></button>
        </div>
        <div className="chapter-strip">
          {scenes.slice(0, 11).map((scene, index) => <button type="button" className={time >= scene.start && time < scene.end ? "chapter chapter--active" : "chapter"} key={scene.label} onClick={() => setFilmTime(scene.start + 0.12)}><span className="chapter-index">{String(index + 1).padStart(2, "0")}</span><span>{scene.label}</span></button>)}
        </div>
      </section>
      <footer className="footer-note"><span>INTELLIGENCE FOR PEOPLE WHO BUILD.</span><span>CREATE WITHOUT LIMITS.</span><span>© 2025 CUPRIC AI</span></footer>
    </main>
  );
}

import { jsonb, pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";

/** Saved editable compositions (VideoDoc JSON is the single source of truth). */
export const projects = pgTable("projects", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  doc: jsonb("doc").notNull(),
  width: integer("width").notNull().default(1920),
  height: integer("height").notNull().default(1080),
  durationFrames: integer("duration_frames").notNull().default(0),
  templateId: text("template_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** User-saved presets (node configs, animation configs, effect stacks, themes). Marketplace-ready tiering. */
export const presets = pgTable("presets", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  kind: text("kind").notNull(), // node | animation | effects | theme
  nodeType: text("node_type"),
  data: jsonb("data").notNull(),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  tier: text("tier").notNull().default("community"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

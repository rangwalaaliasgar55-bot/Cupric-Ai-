# Asset Catalog and Registry Policy

## What ships in this foundation

The core registry has usable authored components and parameterized preset families:

- backgrounds: Aurora, Grid, Orbit, Mesh, Noise Field, Halo;
- text: cinematic, editorial, SaaS, typewriter, kinetic, gradient;
- motion: fade, fade-up/down/left/right, scale, pop, spring, blur, blur-scale, wipe, slide, zoom, rotate, float, orbit, cinematic, minimal, SaaS, tech, luxury, editorial, futuristic;
- transitions: fade, crossfade, slide, push, wipe, zoom, blur, flash, glitch, pixel, camera;
- effects: grain, vignette, glow, chromatic, scanline, noise, exposure, saturation, contrast;
- shape/UI/chart/logo/particle archetypes represented as schema-driven registry records;
- templates: original AI product launch, product launch, startup story and vertical app teaser compositions.

## Scale policy

The requested long-term count targets (100+ motion, 50+ backgrounds, etc.) are not presented as complete merely by creating renamed variants. New assets enter through a content review process: independent visual behavior, typed defaults, a schema, performance declaration, accessibility behavior, video compatibility and a visual gallery test are mandatory.

## Registry record

```ts
{
  id, name, category, description, preview, schema, defaults, tags,
  capabilities: { browser, video, server, three },
  performance: { cpu, gpu, memory }
}
```

The registry is searchable by category and semantic tags. AI/client tooling receives schema and defaults rather than component source code.

## License policy

All current templates, icons, copy and visual components are original. Imports reference only user-provided assets or allowlisted HTTPS/data URLs; no third-party design registry code, paid template, model or stock asset is redistributed.

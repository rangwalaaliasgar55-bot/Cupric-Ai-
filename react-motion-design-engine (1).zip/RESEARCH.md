# Prism Motion OS — Research Notes

Research date: 2026-10-15. The project uses a capability-specific stack rather than declaring one animation library to be the engine for every renderer.

## Findings

- **Motion** (`motion/react`) is an actively maintained, MIT-licensed React animation library with TypeScript, gestures, layout transitions, reduced-motion support and a hybrid WAAPI/JavaScript renderer. It is the best default for declarative UI state, live previews and small bundle slices.
- **GSAP** is the stronger option for imperative nested timelines, scroll choreography, SVG path morphing, drawing and SplitText. Its current plugins are available without the former membership barrier, but it has a custom no-charge license rather than MIT. It is therefore an optional browser-only adapter—not a core dependency or a video-time source of truth.
- **Remotion** is the most mature React frame renderer: compositions accept serialized props, its player previews in React, and Node/Lambda renderers export media. It has special company/automation licensing. A Remotion adapter is specified and isolated; it is not embedded in the open core until a deployment model is selected.
- **Three.js + React Three Fiber + Drei** remain the best React-compatible declarative WebGL ecosystem. R3F and Drei are MIT, current, composable and WebGL-ready. They belong behind a client-only renderer adapter because 3D isn’t SSR-safe. Rapier’s WASM engine is the preferred physics candidate; it will be added only with a real 3D scene requirement.
- **Motion Canvas** is promising for authored, generator-style explainers but lacks Remotion’s React Player/server render fit. **Theatre.js** is useful optional visual direction tooling, not the portable runtime data model. **Rive** and **Lottie** are excellent interoperable vector asset players rather than the source scene graph.
- **Radix UI** remains the mature, MIT, accessible primitive choice with a broad shadcn ecosystem. Base UI is a strong newer alternative. This editor uses semantic native controls today and can adopt Radix primitives when popovers/dialogs/menus are needed.
- Community registries (Magic UI, React Bits, Aceternity, shadcn registries, 21st.dev) are inspiration and discovery sources, not a dependency strategy. License terms vary by component; no source or proprietary artwork is copied.

## Non-negotiable constraints

1. Frame/video output is computed from `(frame, fps, duration, props, seed)`, never wall-clock time.
2. Template JSON is validated structurally and contains data—not user executable code.
3. DOM previews use React and Motion; high-density GPU systems are declared as renderer capabilities and never represented by thousands of DOM nodes.
4. Browser-only, render-safe and SSR-safe capabilities are declared in every registry entry.
5. Export buttons only expose formats the local application can generate. This build exports and imports JSON and can render its deterministic browser preview. MP4/WebM belong to the optional Remotion render adapter.

## Sources consulted

- Motion official site and repository — MIT, React/JS/Vue, hybrid renderer and React import API.
- Remotion npm package, documentation/terms — current React compositions, player/rendering and automation licensing.
- React Three Fiber and Drei npm listings — React 19/R3F 9 support, MIT licensing and maintenance.
- GSAP React/animation references — `useGSAP`, timeline and current plugin availability.
- Radix/Base UI comparative documentation — headless WAI-ARIA primitives, keyboard/focus support and MIT licensing.
- shadcn registry discovery listings — community registry landscape and component license variability.

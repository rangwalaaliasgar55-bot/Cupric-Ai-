# Template System Specification

## Included original templates

1. **AI Product Launch** — hook → intelligence signal → product workspace → metric proof → CTA.
2. **Product Launch** — logo → headline → product reveal → feature cluster → CTA.
3. **Startup Story** — friction → insight → interface → operating result → CTA.
4. **Vertical App Teaser** — hook → mobile workflow → social proof → swipe CTA.

Each contains an editable brand, headline, subheadline, CTA, colors, duration, scene nodes and timeline tracks. The polished showcase previews the AI Product Launch template.

## Editable template properties

```text
Brand: name, mark, primary, accent, tone
Copy: headline, subtitle, CTA, metrics
Format: aspect ratio, fps, duration, quality
Motion: preset, speed, easing, reduced motion mode
```

## Import/export security

Template import validates a JSON size cap, expected version, known node types, unique IDs, supported property values, max node depth and external asset URLs. Imported templates never execute JS. A successful import becomes editor state; export emits a portable `template.json` data file.

## Agent tooling

`generateVideo()`, `generateScene()` and `recommendTemplate()` are deterministic functions over a structured prompt/options object. They select a matching in-registry template and return a cloned editable composition. Machine-facing tools include `searchAssets`, `searchTemplates`, `searchMotionPresets`, `getComponentSchema` and `findNode`.

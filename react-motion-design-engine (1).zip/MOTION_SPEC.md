# Motion and Timeline Specification

## Time model

All render-safe timings are expressed in frames. A composition derives frames from seconds with `Math.round(seconds * fps)`. The evaluator receives a frame and cannot read wall-clock time or unseeded randomness.

```ts
keyframe: { frame, value, easing? }
timing: { start, duration, delay?, repeat?, repeatType?, fill? }
```

## Universal animation contract

The core supports numeric and color-safe interpolation, keyframe tracks, delay, repeat, reverse/ping-pong repeats, labels, markers, staggering through track offsets, nested scene groups and deterministic callbacks represented as markers—not executable functions. Browser adapters may use `onStart` and `onComplete`; render adapters map them to timeline events.

## Preset families

The registry contains authored families rather than meaningless copies: entry/reveal, spatial, blur/focus, scale/spring, editorial, SaaS, technical, cinematic, magnetic/gesture and ambient loops. A preset exposes duration, distance, blur, stiffness, damping, easing and stagger where meaningful.

## Accessibility

`useReducedMotion` from Motion drives preview simplification: entrance duration approaches zero and perpetual ambient movement pauses. Text remains in the accessibility tree; decorative layers are marked hidden.

## Engine adaptation

- **Core evaluator**: the canonical frame-safe implementation.
- **Motion adapter**: maps preset states to declarative `initial`, `animate` and transition values for app/browser preview.
- **GSAP adapter**: optional browser-only route for SplitText, MorphSVG, MotionPath and advanced sequences.
- **Remotion adapter**: uses frame interpolation and springs against the exact same timeline data.

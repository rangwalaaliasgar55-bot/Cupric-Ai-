# Technology Selection Matrix

| Capability | Candidates considered | Selected | Why |
|---|---|---|---|
| Application | Next.js App Router, Vite SPA | Next.js App Router | Existing full-stack, SSR and API foundation. |
| React UI | shadcn/Radix, Base UI, React Aria | Semantic native now; Radix adapter later | Zero unnecessary dependency now; Radix is the mature accessible expansion path. |
| UI animation | Motion, GSAP, React Spring | Motion | MIT, TS-native declarative React API, layout/gesture/reduced-motion support. |
| Complex browser timeline | GSAP, Motion, Web Animations | Deterministic internal evaluator; GSAP adapter | Serializes cleanly for video; GSAP remains opt-in for browser choreography. |
| Video | Remotion, Motion Canvas, Revideo | Adapter target: Remotion | React props + Player + Node rendering are the best product fit; special license isolated. |
| 3D | Three/R3F, Babylon, PlayCanvas | Adapter target: Three + R3F | Most mature declarative React ecosystem, MIT and extensible. |
| 3D helpers | Drei, custom | Adapter target: Drei | Maintained, MIT collection; only load in the 3D slice. |
| 3D animation | GSAP, Theatre, native R3F | Frame evaluator + optional GSAP/Theatre bridge | Makes timeline portable, deterministic and editor-owned. |
| Physics | Rapier, Cannon, Ammo | Adapter target: Rapier | Fast WASM, modern R3F binding; defer binary until needed. |
| Particles | DOM, Canvas, Three instancing | Canvas preview; GPU adapter contract | Canvas is economical for 2D previews, instancing scales 3D. |
| Shaders | GLSL, WebGPU | GLSL/WebGL adapter contract | Broad browser delivery now; WebGPU enhancement later. |
| Vector | SVG, Lottie, Rive | SVG core; Lottie/Rive adapters | SVG stays editable/serializable; imported assets remain assets. |
| Smooth scrolling | native, Lenis | Native | No scrolling showcase dependency is required for the editor. |
| Icons | Lucide, inline SVG | Original inline SVG icon set | Zero dependency and consistent visual language. |
| Charts | SVG, Canvas, Recharts | SVG frame-safe charts | Deterministic output without chart-library bloat. |
| Audio analysis | Web Audio, Remotion Audio | Web Audio browser adapter; Remotion adapter | Separate interactive analysis from deterministic server rendering. |
| Editor | Custom, existing editor | Custom data-driven foundation | The scene graph and schema must remain source of truth. |
| Export | JSON, browser canvas, Remotion/FFmpeg | JSON now; Remotion adapter later | No misleading client-only MP4 button; data exports work now. |

## Automatic choice rules

- Simple state interactions: React state plus Motion if animation provides hierarchy.
- Complex scrubbed DOM/SVG timelines: timeline evaluator or the optional GSAP adapter.
- Text splitting/morphing: native tokenization/SVG for core; optional GSAP SplitText/MorphSVG for advanced browser playback.
- 3D: dynamically loaded R3F renderer, with static fallback when WebGL is unavailable.
- Video: same scene graph rendered through the Remotion adapter when enabled.
- High-frequency graphics: Canvas/WebGL, never per-particle React nodes.
- Accessible menus/dialogs: Radix primitive adapter rather than bespoke focus management.

## Dependency discipline

The live foundation installs only Motion. It adds no unused graphics, UI, physics, editor or video package. Each deferred adapter has an explicit capability boundary so it can be independently installed, tree-shaken and license-reviewed when it becomes operational.
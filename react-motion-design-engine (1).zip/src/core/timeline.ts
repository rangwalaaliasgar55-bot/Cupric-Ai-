import type {
  Composition,
  EaseName,
  Keyframe,
  MotionElement,
  RenderedNodeState,
  Timing,
  Transform,
} from "@/core/types";

const defaults: Required<Transform> = {
  x: 0,
  y: 0,
  z: 0,
  scale: 1,
  scaleX: 1,
  scaleY: 1,
  rotateX: 0,
  rotateY: 0,
  rotateZ: 0,
  opacity: 1,
  blur: 0,
};

export const clamp = (value: number, min = 0, max = 1) => Math.min(max, Math.max(min, value));
export const lerp = (from: number, to: number, progress: number) => from + (to - from) * progress;
export const framesFromSeconds = (seconds: number, fps: number) => Math.round(seconds * fps);
export const secondsFromFrames = (frame: number, fps: number) => frame / fps;

export function ease(progress: number, name: EaseName = "easeOut") {
  const t = clamp(progress);
  switch (name) {
    case "linear":
      return t;
    case "easeIn":
      return t * t * t;
    case "easeInOut":
      return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    case "circOut":
      return Math.sqrt(1 - Math.pow(t - 1, 2));
    case "backOut": {
      const c1 = 1.70158;
      const c3 = c1 + 1;
      return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
    }
    case "anticipate":
      return t < 0.5
        ? 0.5 * Math.pow(2 * t, 3)
        : 0.5 * (Math.pow(2 * t - 2, 3) + 2);
    case "easeOut":
    default:
      return 1 - Math.pow(1 - t, 3);
  }
}

function parseHex(color: string) {
  const clean = color.replace("#", "");
  if (!/^[0-9a-f]{3}([0-9a-f]{3})?$/i.test(clean)) return null;
  const normalized = clean.length === 3 ? clean.split("").map((part) => part + part).join("") : clean;
  return [0, 2, 4].map((index) => Number.parseInt(normalized.slice(index, index + 2), 16));
}

function interpolateColor(from: string, to: string, progress: number) {
  const start = parseHex(from);
  const end = parseHex(to);
  if (!start || !end) return progress < 1 ? from : to;
  const parts = start.map((value, index) => Math.round(lerp(value, end[index], progress)));
  return `#${parts.map((part) => part.toString(16).padStart(2, "0")).join("")}`;
}

export function interpolateValue(from: number | string, to: number | string, progress: number) {
  if (typeof from === "number" && typeof to === "number") return lerp(from, to, progress);
  if (typeof from === "string" && typeof to === "string") return interpolateColor(from, to, progress);
  return progress < 1 ? from : to;
}

export function sampleKeyframes(keyframes: Keyframe[], frame: number): number | string | undefined {
  if (!keyframes.length) return undefined;
  const ordered = [...keyframes].sort((a, b) => a.frame - b.frame);
  if (frame <= ordered[0].frame) return ordered[0].value;
  const last = ordered[ordered.length - 1];
  if (frame >= last.frame) return last.value;
  const nextIndex = ordered.findIndex((keyframe) => keyframe.frame >= frame);
  const previous = ordered[nextIndex - 1];
  const next = ordered[nextIndex];
  const progress = (frame - previous.frame) / (next.frame - previous.frame);
  return interpolateValue(previous.value, next.value, ease(progress, next.ease));
}

export function resolveTimingProgress(timing: Timing | undefined, frame: number) {
  if (!timing) return 1;
  const delay = timing.delay ?? 0;
  const localFrame = frame - timing.start - delay;
  if (localFrame < 0) return timing.fill === "both" ? 0 : -1;
  if (timing.duration <= 0) return 1;
  const cycles = Math.max(0, timing.repeat ?? 0) + 1;
  const total = timing.duration * cycles;
  if (localFrame >= total) return timing.fill === "none" ? -1 : 1;
  const cycle = Math.floor(localFrame / timing.duration);
  let progress = (localFrame % timing.duration) / timing.duration;
  if (timing.repeatType === "reverse" || timing.repeatType === "mirror") {
    if (cycle % 2 === 1) progress = 1 - progress;
  }
  return progress;
}

export function enterPresetTransform(preset: string | undefined, progress: number): Partial<Transform> {
  const settled = ease(progress, preset === "SPRING" ? "backOut" : "easeOut");
  const initial: Record<string, Partial<Transform>> = {
    FADE: { opacity: 0 },
    FADE_UP: { opacity: 0, y: 36 },
    FADE_DOWN: { opacity: 0, y: -36 },
    FADE_LEFT: { opacity: 0, x: 42 },
    FADE_RIGHT: { opacity: 0, x: -42 },
    SCALE: { opacity: 0, scale: 0.86 },
    POP: { opacity: 0, scale: 0.7 },
    SPRING: { opacity: 0, scale: 0.78, y: 18 },
    BLUR: { opacity: 0, blur: 16 },
    BLUR_SCALE: { opacity: 0, blur: 16, scale: 0.94 },
    WIPE: { opacity: 0, x: -30 },
    SLIDE: { opacity: 0, x: -58 },
    ZOOM: { opacity: 0, scale: 1.14 },
    ROTATE: { opacity: 0, rotateZ: -8, scale: 0.92 },
    CINEMATIC: { opacity: 0, y: 28, blur: 9, scale: 1.025 },
  };
  const from = initial[preset ?? ""] ?? initial.FADE_UP;
  return Object.fromEntries(
    Object.entries(from).map(([property, value]) => [property, lerp(value ?? 0, defaults[property as keyof Transform] ?? 0, settled)]),
  );
}

export function evaluateNode(composition: Composition, node: MotionElement, frame: number): RenderedNodeState {
  const activeFrame = frame - (node.timing?.start ?? 0);
  const progress = resolveTimingProgress(node.timing, frame);
  const baseTransform = { ...defaults, ...node.transform };
  const entrance = node.animation?.entrance ?? node.animation?.preset;
  const entranceTransform = progress >= 0 && progress < 1 ? enterPresetTransform(entrance, progress) : {};
  const transform: Required<Transform> = { ...baseTransform, ...entranceTransform };
  const style = { ...(node.style ?? {}) };
  const props = { ...(node.props ?? {}) };

  for (const track of composition.propertyTracks) {
    if (track.nodeId !== node.id || track.enabled === false) continue;
    const value = sampleKeyframes(track.keyframes, activeFrame);
    if (value === undefined) continue;
    if (track.property === "color" || track.property === "background") style[track.property] = value;
    else transform[track.property] = value as number;
  }

  return {
    transform,
    style,
    props,
    visible: !node.hidden && progress >= 0,
  };
}

export function getActiveScene(composition: Composition, frame: number) {
  return composition.scenes.find(
    (scene) => frame >= scene.startFrame && frame < scene.startFrame + scene.durationInFrames,
  );
}

export function findNode(nodes: MotionElement[], id: string): MotionElement | undefined {
  for (const node of nodes) {
    if (node.id === id) return node;
    const found = node.children ? findNode(node.children, id) : undefined;
    if (found) return found;
  }
  return undefined;
}

export function getNodeByAddress(composition: Composition, address: string) {
  for (const scene of composition.scenes) {
    const node = findNode(scene.nodes, address);
    if (node) return node;
  }
  return undefined;
}

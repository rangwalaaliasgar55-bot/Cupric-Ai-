export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };

export type AspectRatio = "16:9" | "9:16" | "1:1" | "4:5" | "4:3" | "custom";
export type QualityLevel = "auto" | "low" | "medium" | "high" | "ultra";
export type NodeType =
  | "group"
  | "background"
  | "text"
  | "shape"
  | "ui"
  | "chart"
  | "effect"
  | "three:model"
  | "audio"
  | "caption";
export type TrackKind =
  | "BACKGROUND"
  | "TEXT"
  | "SHAPE"
  | "UI"
  | "CHART"
  | "EFFECT"
  | "THREE"
  | "AUDIO"
  | "CAPTION";
export type RepeatType = "loop" | "reverse" | "mirror";
export type EaseName =
  | "linear"
  | "easeOut"
  | "easeIn"
  | "easeInOut"
  | "circOut"
  | "backOut"
  | "anticipate";

export type Transform = {
  x?: number;
  y?: number;
  z?: number;
  scale?: number;
  scaleX?: number;
  scaleY?: number;
  rotateX?: number;
  rotateY?: number;
  rotateZ?: number;
  opacity?: number;
  blur?: number;
};

export type Timing = {
  start: number;
  duration: number;
  delay?: number;
  repeat?: number;
  repeatType?: RepeatType;
  fill?: "none" | "forwards" | "both";
};

export type Keyframe = {
  frame: number;
  value: number | string;
  ease?: EaseName;
};

export type PropertyTrack = {
  id: string;
  nodeId: string;
  property: keyof Transform | "color" | "background";
  keyframes: Keyframe[];
  enabled?: boolean;
};

export type MotionConfig = {
  preset?: string;
  entrance?: string;
  exit?: string;
  loop?: string;
  ease?: EaseName;
  stagger?: number;
  speed?: number;
};

export type MotionElement = {
  id: string;
  name: string;
  type: NodeType;
  transform?: Transform;
  timing?: Timing;
  animation?: MotionConfig;
  style?: Record<string, JsonValue>;
  props?: Record<string, JsonValue>;
  children?: MotionElement[];
  locked?: boolean;
  hidden?: boolean;
  capabilities?: CapabilityFlags;
};

export type Scene = {
  id: string;
  name: string;
  startFrame: number;
  durationInFrames: number;
  nodes: MotionElement[];
};

export type TimelineTrack = {
  id: string;
  kind: TrackKind;
  name: string;
  nodeIds: string[];
  locked?: boolean;
  hidden?: boolean;
  muted?: boolean;
};

export type Marker = {
  id: string;
  frame: number;
  label: string;
  color?: string;
};

export type Brand = {
  name: string;
  primary: string;
  accent: string;
  ink: string;
};

export type Composition = {
  version: 1;
  id: string;
  name: string;
  description: string;
  fps: number;
  width: number;
  height: number;
  durationInFrames: number;
  aspectRatio: AspectRatio;
  quality: QualityLevel;
  seed: number;
  brand: Brand;
  scenes: Scene[];
  tracks: TimelineTrack[];
  propertyTracks: PropertyTrack[];
  markers: Marker[];
  layoutVariants?: Partial<Record<Exclude<AspectRatio, "custom">, LayoutVariant>>;
};

export type LayoutVariant = {
  width: number;
  height: number;
  nodeTransforms: Record<string, Transform>;
};

export type CapabilityFlags = {
  browser: boolean;
  video: boolean;
  server: boolean;
  three?: boolean;
};

export type PerformanceCost = {
  cpu: "low" | "medium" | "high";
  gpu: "low" | "medium" | "high";
  memory: "low" | "medium" | "high";
};

export type SchemaField = {
  type: "color" | "number" | "text" | "select" | "boolean" | "range";
  label: string;
  default: JsonValue;
  min?: number;
  max?: number;
  step?: number;
  options?: Array<{ label: string; value: string }>;
  help?: string;
};

export type AssetSchema = Record<string, SchemaField>;

export type AssetCategory =
  | "motion"
  | "typography"
  | "background"
  | "transition"
  | "effect"
  | "particle"
  | "material"
  | "three"
  | "ui"
  | "chart"
  | "logo"
  | "template";

export type RegistryEntry<TDefaults extends Record<string, JsonValue> = Record<string, JsonValue>> = {
  id: string;
  name: string;
  category: AssetCategory;
  description: string;
  preview: string;
  schema: AssetSchema;
  defaults: TDefaults;
  tags: string[];
  capabilities: CapabilityFlags;
  performance: PerformanceCost;
};

export type EngineSearchResult = RegistryEntry & { score: number };

export type RenderedNodeState = {
  transform: Required<Transform>;
  style: Record<string, JsonValue>;
  props: Record<string, JsonValue>;
  visible: boolean;
};

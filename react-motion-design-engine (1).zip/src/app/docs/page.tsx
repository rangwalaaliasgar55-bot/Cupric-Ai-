import Link from "next/link";
import { listAssets } from "@/registry";

export default function DocsPage() {
  const assets = listAssets();
  return (
    <main className="docs-page">
      <header className="docs-nav"><Link className="brand" href="/"><span className="brand-sigil"><i /><i /><i /></span><span>PRISM <em>MOTION OS</em></span></Link><div><Link href="/">Open studio</Link><a href="#decisions">Technology decisions</a></div></header>
      <section className="docs-hero"><p>DOCUMENTATION / 01</p><h1>A visual system<br /><i>with one source of truth.</i></h1><span>Prism turns composition data into an editable browser preview today and keeps that same data ready for a frame renderer tomorrow.</span></section>
      <section className="docs-grid" id="decisions">
        <article><small>THE CONTRACT</small><h2>Composition JSON</h2><p>Scenes, nodes, keyframes, markers, tracks and responsive variants are typed, serializable data. The Studio, API and future renderer share it.</p><code>Composition → Scene Graph → Frame</code></article>
        <article><small>DETERMINISM</small><h2>Frame, not clock</h2><p>Every video-safe calculation receives frame, FPS, duration and a seed. Browser playback never becomes the render definition.</p><code>evaluateNode(scene, node, frame)</code></article>
        <article><small>SAFE BY DEFAULT</small><h2>Data, not code</h2><p>Imports have a size cap, known node types, safe asset URL checks, unique IDs and depth limits. Templates cannot run arbitrary JavaScript.</p><code>validateComposition(json)</code></article>
        <article><small>ADAPTERS</small><h2>Use the right renderer</h2><p>React DOM and SVG render the current preview. Motion drives browser polish. R3F and Remotion live behind explicit, lazy adapter boundaries.</p><code>browser / video / server / three</code></article>
      </section>
      <section className="docs-assets"><div><p>SHIPPING REGISTRY</p><h2>Inspectable by humans and agents.</h2></div><span>{assets.length} schema-backed assets in the foundation</span><div className="docs-asset-list">{assets.map((asset) => <Link href={`/${asset.category === "three" ? "3d" : `${asset.category}s`}`} key={asset.id}><small>{asset.category}</small><strong>{asset.name}</strong><p>{asset.description}</p><em>{asset.capabilities.video ? "Frame-safe" : "Browser-only"}</em></Link>)}</div></section>
      <section className="docs-cta"><p>START WITH A COMPOSITION</p><h2>Build the next scene<br />from a real system.</h2><Link href="/">Launch Prism Studio <span>↗</span></Link></section>
    </main>
  );
}
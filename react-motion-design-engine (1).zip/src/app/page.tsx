import { Studio } from "@/editor/studio";

export default function HomePage() {
  return <Studio />;
}

import { jsonb, text, timestamp } from "drizzle-orm/pg-core";
import { pgTable } from "drizzle-orm/pg-core";
import type { Composition } from "@/core/types";

/** Validated, data-only scene graphs saved from the studio. */
export const studioCompositions = pgTable("studio_compositions", {
  compositionId: text("composition_id").primaryKey(),
  name: text("name").notNull(),
  data: jsonb("data").$type<Composition>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

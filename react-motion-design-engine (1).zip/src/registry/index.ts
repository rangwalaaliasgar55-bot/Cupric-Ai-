import type {
  AssetCategory,
  AssetSchema,
  EngineSearchResult,
  JsonValue,
  RegistryEntry,
} from "@/core/types";

const assets = new Map<string, RegistryEntry>();

const capability = { browser: true, video: true, server: true };
const lowCost = { cpu: "low", gpu: "low", memory: "low" } as const;
const mediumCost = { cpu: "medium", gpu: "medium", memory: "low" } as const;

const motionSchema: AssetSchema = {
  duration: { type: "number", label: "Duration", default: 24, min: 1, max: 600, step: 1, help: "Frames at composition FPS." },
  distance: { type: "range", label: "Distance", default: 36, min: 0, max: 240, step: 1 },
  easing: {
    type: "select",
    label: "Easing",
    default: "easeOut",
    options: [
      { label: "Ease out", value: "easeOut" },
      { label: "Ease in out", value: "easeInOut" },
      { label: "Spring settle", value: "backOut" },
    ],
  },
};

const backgroundSchema: AssetSchema = {
  primary: { type: "color", label: "Primary", default: "#7C5CFF" },
  accent: { type: "color", label: "Accent", default: "#36E5C8" },
  intensity: { type: "range", label: "Intensity", default: 0.75, min: 0, max: 1, step: 0.01 },
  speed: { type: "range", label: "Speed", default: 0.4, min: 0, max: 2, step: 0.05 },
  seed: { type: "number", label: "Seed", default: 42, min: 0, max: 9999, step: 1 },
};

const catalog = [
  ["motion.fade-up", "Fade up", "motion", "Measured vertical reveal for copy and UI.", ["entry", "saas", "minimal", "text"]],
  ["motion.fade-down", "Fade down", "motion", "Downward editorial reveal.", ["entry", "editorial", "text"]],
  ["motion.pop", "Pop", "motion", "Compact scale-in with visual emphasis.", ["entry", "ui", "fast"]],
  ["motion.spring", "Spring settle", "motion", "Purposeful spring reveal with a short settle.", ["entry", "ui", "saas"]],
  ["motion.blur-scale", "Blur scale", "motion", "Focus pull for premium hero moments.", ["entry", "cinematic", "text", "hero"]],
  ["motion.cinematic", "Cinematic", "motion", "Slow focus and rise for large typography.", ["entry", "cinematic", "luxury", "text"]],
  ["motion.tech", "Tech sequence", "motion", "Technical stagger language for product data.", ["entry", "technology", "data", "saas"]],
  ["motion.float", "Ambient float", "motion", "Restrained ambient loop for product objects.", ["loop", "product", "3d"]],
  ["type.cinematic", "Cinematic type", "typography", "Line-based headline reveal with focus pull.", ["text", "cinematic", "luxury"]],
  ["type.editorial", "Editorial type", "typography", "High-contrast word reveal.", ["text", "editorial", "minimal"]],
  ["type.kinetic", "Kinetic type", "typography", "Beat-aware staggered word entry.", ["text", "social", "fast"]],
  ["type.scramble", "Signal scramble", "typography", "Character resolution treatment for technical intros.", ["text", "technology", "cyber"]],
  ["background.aurora", "Aurora field", "background", "Soft radial color field with intentional movement.", ["background", "ai", "dark", "premium"]],
  ["background.mesh", "Mesh gradient", "background", "Controlled layered gradient mesh.", ["background", "saas", "light", "minimal"]],
  ["background.grid", "Perspective grid", "background", "Technical grid that supports interface scenes.", ["background", "technology", "cyber", "data"]],
  ["background.orbit", "Orbit field", "background", "Orbital data marks around a product focus.", ["background", "ai", "3d", "technology"]],
  ["background.noise", "Noise field", "background", "Fine film texture without image assets.", ["background", "cinematic", "editorial"]],
  ["transition.crossfade", "Crossfade", "transition", "Continuity-first scene transition.", ["transition", "minimal", "video"]],
  ["transition.wipe", "Directional wipe", "transition", "Controlled directional scene replacement.", ["transition", "saas", "product"]],
  ["transition.flash", "Light flash", "transition", "Brief exposure transition for a key beat.", ["transition", "cinematic", "fast"]],
  ["transition.glitch", "Signal glitch", "transition", "Technical interruption used sparingly.", ["transition", "cyber", "technology"]],
  ["effect.grain", "Film grain", "effect", "Subtle monochrome grain overlay.", ["effect", "cinematic", "editorial"]],
  ["effect.vignette", "Vignette", "effect", "Focus-shaping radial edge falloff.", ["effect", "cinematic", "focus"]],
  ["effect.chromatic", "Chromatic split", "effect", "Small RGB separation for signal treatments.", ["effect", "cyber", "technology"]],
  ["particle.constellation", "Constellation", "particle", "Connected seeded point field.", ["particle", "ai", "data", "technology"]],
  ["particle.stars", "Star dust", "particle", "Depth-layered seeded particle field.", ["particle", "cinematic", "dark"]],
  ["ui.browser", "Browser window", "ui", "Responsive product browser shell.", ["ui", "saas", "product", "demo"]],
  ["ui.metric", "Metric card", "ui", "Frame-safe performance metric card.", ["ui", "saas", "data", "dashboard"]],
  ["ui.command", "Command palette", "ui", "Keyboard-first command interface surface.", ["ui", "ai", "saas", "product"]],
  ["chart.signal", "Signal chart", "chart", "Animated SVG trendline with deterministic sampling.", ["chart", "data", "saas", "finance"]],
  ["chart.funnel", "Funnel", "chart", "Animated conversion funnel.", ["chart", "data", "finance", "saas"]],
  ["logo.light-sweep", "Light sweep logo", "logo", "Minimal logo reveal with moving highlight.", ["logo", "cinematic", "minimal"]],
  ["logo.signal", "Signal logo", "logo", "Geometric mark build with data rhythm.", ["logo", "technology", "ai"]],
  ["material.glass", "Glass material", "material", "Physical glass material contract for R3F.", ["3d", "glass", "product"]],
  ["three.product-hero", "Product hero", "three", "Studio-lit floating object scene contract.", ["3d", "product", "cinematic"]],
  ["three.holographic", "Holographic object", "three", "Iridescent technical object scene contract.", ["3d", "technology", "cyber"]],
  ["template.ai-product-launch", "AI Product Launch", "template", "Seven-scene premium AI product launch.", ["template", "ai", "saas", "cinematic"]],
  ["template.startup-story", "Startup Story", "template", "Narrative startup launch with proof and CTA.", ["template", "startup", "saas", "product"]],
  ["template.vertical-app", "Vertical App Teaser", "template", "Mobile-first vertical feature teaser.", ["template", "social", "vertical", "app"]],
] as const;

function asDefaults(category: AssetCategory): Record<string, JsonValue> {
  if (category === "background") return { primary: "#7C5CFF", accent: "#36E5C8", intensity: 0.75, speed: 0.4, seed: 42 };
  if (category === "motion" || category === "typography" || category === "transition") return { duration: 24, distance: 36, easing: "easeOut" };
  return { intensity: 0.7, enabled: true };
}

function asSchema(category: AssetCategory) {
  if (category === "background") return backgroundSchema;
  if (category === "motion" || category === "typography" || category === "transition") return motionSchema;
  return {
    intensity: { type: "range" as const, label: "Intensity", default: 0.7, min: 0, max: 1, step: 0.01 },
    enabled: { type: "boolean" as const, label: "Enabled", default: true },
  };
}

for (const [id, name, category, description, tags] of catalog) {
  const isGpu = category === "three" || category === "material" || category === "particle";
  assets.set(id, {
    id,
    name,
    category,
    description,
    preview: `registry://${id}`,
    schema: asSchema(category),
    defaults: asDefaults(category),
    tags: [...tags],
    capabilities: { ...capability, three: isGpu || undefined },
    performance: isGpu ? mediumCost : lowCost,
  });
}

export function registerAsset(entry: RegistryEntry) {
  if (assets.has(entry.id)) throw new Error(`An asset with id "${entry.id}" is already registered.`);
  assets.set(entry.id, entry);
  return entry;
}

export const registerComponent = registerAsset;
export const registerEffect = registerAsset;
export const registerTransition = registerAsset;
export const registerBackground = registerAsset;
export const registerMaterial = registerAsset;
export const registerMotionPreset = registerAsset;
export const register3DPreset = registerAsset;
export const registerTemplate = registerAsset;

export function getAsset(id: string) {
  return assets.get(id);
}

export const getMotionPreset = getAsset;
export const getComponentSchema = (id: string) => assets.get(id)?.schema;

export function listAssets(category?: AssetCategory) {
  return [...assets.values()].filter((asset) => !category || asset.category === category);
}

export function searchAssets(query: string, category?: AssetCategory): EngineSearchResult[] {
  const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
  return listAssets(category)
    .map((asset) => {
      const haystack = `${asset.name} ${asset.description} ${asset.tags.join(" ")} ${asset.category}`.toLowerCase();
      const score = terms.reduce((total, term) => total + (haystack.includes(term) ? 1 : 0), 0);
      return { ...asset, score };
    })
    .filter((asset) => asset.score > 0)
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
}

export const searchMotionPresets = (query: string) => searchAssets(query, "motion");
export const searchTemplates = (query: string) => searchAssets(query, "template");
export const search3DPresets = (query: string) => searchAssets(query, "three");

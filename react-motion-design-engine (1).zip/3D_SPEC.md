# 3D Specification

## Target renderer

The 3D adapter targets Three.js via React Three Fiber, with Drei helpers and `@react-three/rapier` when physics is required. They are not included in the base browser bundle because this foundation’s showcase uses a deterministic static product abstraction instead of a fake WebGL scene.

## Serializable 3D node

```ts
{
  id: "product.orb",
  type: "three:model",
  transform: { x: 0, y: 0, z: 0, scale: 1, rotateX: 0, rotateY: 0, rotateZ: 0 },
  material: { preset: "glass", roughness: 0.12, metalness: 0.1, transmission: 0.82 },
  camera: "hero",
  lights: "studio",
  capabilities: { browser: true, video: true, three: true }
}
```

## Material contract

The registry reserves glass, frosted glass, chrome, gold, silver, copper, plastic, matte, glossy, crystal, holographic, iridescent, liquid, emissive and wireframe material presets. Every material has roughness, metalness, transmission, IOR, opacity, emission, clearcoat and environment intensity defaults.

## Camera and lighting contract

Camera presets: product, SaaS, cinematic, tech, luxury, macro, dramatic, overhead, orbit and hero. Lighting presets: studio, product, cinematic, neon, rim, softbox, dramatic, dark luxury, futuristic and holographic.

## Fallback and performance

If WebGL is absent or quality is low, `three:*` nodes render a semantic styled fallback. The registry declares CPU/GPU/memory costs. R3F systems use instancing for repeated particles and avoid React state updates inside per-frame loops. Physics uses Rapier’s fixed time-step with seeded state for render determinism.

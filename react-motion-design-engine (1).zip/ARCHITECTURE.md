# Prism Motion OS Architecture

```text
Application (Next.js + persistence/API)
  └─ Studio UI
      └─ Editor state
          └─ Serialized Composition / Scene Graph
              ├─ Registry + component schemas
              ├─ Timeline evaluator (frames, keyframes, labels, markers)
              ├─ DOM/SVG/Canvas preview renderer
              ├─ Motion browser presentation adapter
              ├─ R3F renderer adapter (optional)
              └─ Remotion frame renderer adapter (optional)
```

## Package layout

```text
src/
  core/       normalized types, interpolation, serialization, timeline
  registry/   asset registration, search and schemas
  templates/  original, editable composition data
  renderer/   deterministic DOM/SVG scene rendering
  editor/     canvas, inspector, tracks, assets and import/export controls
  app/        Next.js routes and app shell
```

Future adapter slices remain intentionally isolated:

```text
motion/  browser Motion + optional GSAP integration
three/   R3F scenes, materials, cameras, Rapier physics
video/   Remotion compositions, Player, renderer and audio
```

## Invariants

- `Composition` is the source of truth. The editor never maintains a second video-only animation implementation.
- Scene node IDs are globally addressable (`scene.get("hero.headline")` / `findNode`).
- Every asset registry entry carries schema, defaults, tags, capabilities and performance cost.
- The evaluator resolves a node style from a frame and pure data. Rendering is a projection of that style.
- Imported JSON is checked for version, safe asset URLs, known node types, unique IDs and recursion depth before use.
- The editor has no arbitrary JS/shader execution path.

## Renderer selection

| Workload | Current renderer | Upgrade path |
|---|---|---|
| UI/text/shapes/charts | React DOM + SVG | Motion / GSAP browser adapter |
| 2D particle preview | Canvas contract / deterministic SVG sample | Offscreen Canvas or WebGL |
| 3D | Static fallback | Dynamic R3F/Three slice |
| Video | Deterministic composition data | Remotion frame adapter + renderer |
| Audio visualizer | Deterministic sample data | Web Audio browser adapter |

## Quality and fallback

The composition declares `quality` and asset performance costs. The studio totals the cost and warns before a CPU/GPU-heavy composition is built. Browser presentation respects `prefers-reduced-motion`; render-frame evaluation remains deterministic.

# Video Specification

## Composition

A `Composition` is normalized JSON:

- dimensions, FPS, duration and aspect-ratio intent;
- named scenes with inclusive frame windows;
- nodes, tracks, markers and editable template properties;
- a seed and quality level;
- responsive layout variants for landscape, portrait and square.

## Playback and rendering

The local studio implements seek, play, pause, restart, frame scrubbing, scene selection and deterministic preview. It exports/imports validated JSON. It deliberately does not advertise MP4/WebM export until the Remotion adapter and a licensed render environment are configured.

The Remotion adapter maps the data model to `Composition`, `AbsoluteFill`, `Sequence`, `Series`, `interpolate`, `spring`, audio/image/video primitives and `Player`. Render requests receive only validated props. Its Node render surface can expose MP4, WebM, PNG and frame-range output.

## Tracks

`TEXT`, `SHAPE`, `UI`, `CHART`, `BACKGROUND`, `EFFECT`, `THREE`, `AUDIO` and `CAPTION` tracks use frame start/end, lock/hidden/muted flags, ordering and labels. Timelines support zoom, snapping grid, trim/move operations, selection and markers in the current UI foundation.

## Responsive behavior

Templates own layout variants. Portrait stacks text above product/UI; wide layouts place copy beside the visual. This makes 9:16, 1:1 and 16:9 intentional compositions rather than crops.

## Audio and captions

Audio metadata tracks trim, offset, gain, fades and loop. Caption records support word timing and style. Web Audio analysis is browser-only; video rendering reads deterministic analysis/keyframe data or precomputed samples.

/**
 * The real, installable Chrome extension source.
 * Bundled as strings so the marketing site can hand you a .zip with no backend.
 * (Extension code is intentionally written without template literals.)
 */

export const EXTENSION_FILES: Record<string, string> = {
  "manifest.json": `{
  "manifest_version": 3,
  "name": "PromptBridge - Universal Prompt Translator",
  "version": "1.0.0",
  "description": "Translates one prompt into the native syntax of ChatGPT, Claude, Gemini, DeepSeek, Perplexity and open models. Broadcasts to every open AI tab with Ctrl+Enter.",
  "minimum_chrome_version": "114",
  "icons": {
    "16": "icons/icon16.png",
    "48": "icons/icon48.png",
    "128": "icons/icon128.png"
  },
  "permissions": ["storage", "tabs", "scripting", "activeTab", "clipboardWrite"],
  "host_permissions": [
    "https://chatgpt.com/*",
    "https://chat.openai.com/*",
    "https://claude.ai/*",
    "https://gemini.google.com/*",
    "https://chat.deepseek.com/*",
    "https://www.perplexity.ai/*",
    "http://localhost/*",
    "http://127.0.0.1/*"
  ],
  "background": { "service_worker": "background.js" },
  "action": {
    "default_popup": "popup.html",
    "default_title": "PromptBridge - translate this prompt"
  },
  "options_page": "options.html",
  "content_scripts": [
    {
      "matches": [
        "https://chatgpt.com/*",
        "https://chat.openai.com/*",
        "https://claude.ai/*",
        "https://gemini.google.com/*",
        "https://chat.deepseek.com/*",
        "https://www.perplexity.ai/*",
        "http://localhost/*",
        "http://127.0.0.1/*"
      ],
      "js": ["translator-core.js", "content.js"],
      "run_at": "document_idle",
      "all_frames": false
    }
  ],
  "commands": {
    "broadcast-prompt": {
      "suggested_key": { "default": "Ctrl+Shift+1", "mac": "Command+Shift+1" },
      "description": "Broadcast the current prompt to every open AI tab"
    },
    "translate-paste": {
      "suggested_key": { "default": "Ctrl+Shift+2", "mac": "Command+Shift+2" },
      "description": "Re-translate the prompt in this composer for the current model"
    }
  }
}
`,

  "translator-core.js": `/* PromptBridge - Syntax Optimization Engine (shared by content, popup, worker) */
(function (root) {
  'use strict';

  var PLATFORMS = {
    chatgpt:   { name: 'ChatGPT', hosts: ['chatgpt.com', 'chat.openai.com'], syntax: 'markdown hierarchy + output contract' },
    claude:    { name: 'Claude',  hosts: ['claude.ai'],                     syntax: 'XML tags + directness' },
    gemini:    { name: 'Gemini',  hosts: ['gemini.google.com'],             syntax: 'numbered hard rules, instructions last' },
    deepseek:  { name: 'DeepSeek',hosts: ['chat.deepseek.com'],             syntax: 'flat terse task, no CoT prompting' },
    llama:     { name: 'Open',    hosts: ['localhost', '127.0.0.1'],        syntax: 'chat-template labels + few-shot' },
    perplexity:{ name: 'Perplexity', hosts: ['perplexity.ai'],              syntax: 'search directives + citations' }
  };

  var ROLE_RE = /^\\s*(you are|you're|act as|as an?\\b|behave as|pretend to be|take the role of|role\\s*:)/i;
  var RULE_RE = /\\b(must|must not|should|should not|shall|always|never|do not|don'?t|ensure|make sure|avoid|only use|use only|no more than|at most|at least|limit|keep it|strictly|exactly|forbidden|required)\\b/i;
  var FORMAT_RE = /\\b(format|output|respond with|return only|json|yaml|markdown|table|bullet|csv|schema|template|words or fewer)\\b/i;
  var EXAMPLE_RE = /\\b(example|e\\.g\\.|for instance|sample|few[- ]shot)\\b/i;
  var COAX_RE = /\\b(think step[- ]by[- ]step|step by step|chain of thought|let'?s think|show your reasoning)\\b/i;
  var COAX_G  = /[,;]?\\s*\\b(and\\s+|so that\\s+|so\\s+|then\\s+)?(think step[- ]by[- ]step|step by step|chain of thought|let'?s think|reason carefully|show your reasoning)\\b\\s*(so that\\s+|so\\s+|to\\s+)?/gi;
  var IMPERATIVE_RE = /^\\s*(please\\s+)?(can you\\s+)?(fix|write|create|build|make|explain|analyse|analyze|refactor|design|summar|research|tell|give|compare|review|generate|draft|produce|find|list|rewrite|suggest|recommend|evaluate|translate)\\b/i;

  var SIGNALS = {
    coding: ['code', 'function', 'bug', 'api', 'refactor', 'typescript', 'python', 'sql', 'react', 'regex', 'test'],
    analysis: ['data', 'csv', 'analyze', 'analysis', 'chart', 'metric', 'kpi', 'forecast', 'cohort', 'funnel', 'trend'],
    creative: ['story', 'poem', 'brand', 'tagline', 'write a', 'creative', 'marketing copy', 'email', 'newsletter', 'tone'],
    reasoning: ['why', 'explain', 'compare', 'pros and cons', 'tradeoff', 'strategy', 'decide', 'architect', 'should i'],
    research: ['research', 'sources', 'cite', 'latest', 'news', 'search', 'market size', 'benchmark', 'statistics on']
  };

  var FEWSHOT = {
    coding: 'Input: getUser(1)\\nOutput: { "ok": true, "user": { "id": 1 } }',
    analysis: 'Input: 3 months of signups\\nOutput: table of month, signups, MoM %, then one line of interpretation',
    creative: 'Tone: dry, confident, no hype\\nOutput: "Ship the thing. Then talk about it."',
    reasoning: 'Input: should we migrate off Redis?\\nOutput: options table, tradeoffs, recommendation, what would flip it',
    research: 'Output: 3 bullet findings, each with a citation [1] and a confidence note',
    general: 'Input: summarise this thread\\nOutput: 3 bullets + 1 open question'
  };

  var CONTRACTS = {
    coding: 'Return the complete final code in one fenced block. No explanation before it. At most 3 "Notes" bullets after.',
    analysis: 'Return a markdown table of the key numbers first, then a "Read" section with at most 4 bullets.',
    creative: 'Return only the finished copy. No preamble, no options, no explanation of choices.',
    reasoning: 'Return: (1) comparison table, (2) top 3 tradeoffs, (3) one-line recommendation, (4) what would flip it.',
    research: 'Return 3-5 bullet findings, each with an inline citation, then a 2-line confidence note.',
    general: 'Return a short direct answer first, then at most 5 supporting bullets. No preamble.'
  };

  function classify(text) {
    var lower = text.toLowerCase(), best = 'general', hits = 0;
    Object.keys(SIGNALS).forEach(function (k) {
      var n = SIGNALS[k].filter(function (s) { return lower.indexOf(s) !== -1; }).length;
      if (n > hits) { hits = n; best = k; }
    });
    return best;
  }

  function parse(raw) {
    var text = String(raw || '').replace(/\\r\\n/g, '\\n').trim();
    var blocks = [], buf = [], fence = false;
    text.split('\\n').forEach(function (line) {
      if (/^\\s*\`\`\`/.test(line)) fence = !fence;
      if (!fence && line.trim() === '') { if (buf.length) blocks.push(buf.join('\\n').trim()); buf = []; }
      else buf.push(line);
    });
    if (buf.length) blocks.push(buf.join('\\n').trim());

    var out = { role: null, goal: '', context: [], rules: [], examples: [], format: null, coax: [], tasks: [], goalBlock: null, goalRest: '', type: classify(text), tokens: Math.max(1, Math.round(text.length / 4)) };

    blocks.forEach(function (block) {
      var lines = block.split('\\n');
      if (!out.role && ROLE_RE.test(lines[0]) && lines[0].length < 220) {
        out.role = lines.shift().replace(/^\\s*([-*]|\\d+[.)])\\s*/, '').trim();
        if (!lines.join('\\n').trim()) return;
      }
      var isExample = EXAMPLE_RE.test(block) || /^\\s*\`\`\`/.test(block);
      lines.forEach(function (line) {
        var l = line.trim();
        if (!l) return;
        if (COAX_RE.test(l)) {
          out.coax.push(l);
          l = l.replace(COAX_G, ' ')
            .replace(/\\s+(so that|so|and so|in order|that)\\b[\\s\\S]*$/i, ' ')
            .replace(/\\s*,\\s*(and|then|or)?\\s*$/i, '')
            .replace(/\\s+/g, ' ').trim();
          if (l.length < 14) return;
        }
        if (isExample || /^\`\`\`/.test(l)) { out.examples.push(l); return; }
        if (RULE_RE.test(l)) {
          l.split(/(?<=[.!?])\\s+/).forEach(function (s) {
            if (s.trim()) out.rules.push(s.replace(/^\\s*([-*\\u2022]|\\d+[.)])\\s*/, ''));
          });
          return;
        }
        if (FORMAT_RE.test(l)) { out.format = (out.format ? out.format + '\\n' : '') + l; return; }
        if (IMPERATIVE_RE.test(l)) { out.tasks.push(l.replace(/\\s+/g, ' ').trim()); return; }
        if (!out.goal) {
          var parts = block.split(/(?<=[.!?])\\s+/);
          out.goal = parts[0].replace(/\\s+/g, ' ').trim();
          out.goalRest = parts.slice(1).join(' ').trim();
          out.goalBlock = block;
        }
        if (out.context.indexOf(block) === -1) out.context.push(block);
      });
    });

    if (!out.goal && out.tasks.length) out.goal = out.tasks.shift();
    if (out.tasks.length) out.goal = (out.goal + ' ' + out.tasks.join(' ')).replace(/\\s+/g, ' ').trim();
    out.context = (out.goalBlock ? [out.goalRest].concat(out.context.filter(function (b) { return b !== out.goalBlock; })) : out.context)
      .filter(function (t) { return !!t; });
    return out;
  }

  function firstSentence(t) {
    var s = String(t).replace(/\\s+/g, ' ').trim();
    var parts = s.split(/(?<=[.!?])\\s/);
    s = parts[0] || s;
    return s.length > 220 ? s.slice(0, 220) + '...' : s;
  }

  function numbered(list) { return list.map(function (r, i) { return (i + 1) + '. ' + cap(r); }).join('\\n'); }
  function bulleted(list) { return list.map(function (r) { return '- ' + cap(r); }).join('\\n'); }
  function cap(s) { var t = s.trim(); return t.charAt(0).toUpperCase() + t.slice(1); }
  function today() { return new Date().toISOString().slice(0, 10); }

  /**
   * options: { fewShot, cot, strictOutput, keepExamples }
   */
  function translate(raw, platform, options) {
    var o = options || {};
    if (o.fewShot === undefined) o.fewShot = true;
    if (o.cot === undefined) o.cot = true;
    if (o.strictOutput === undefined) o.strictOutput = true;
    if (o.keepExamples === undefined) o.keepExamples = true;

    var p = parse(raw);
    var notes = [];
    var goal = p.goal || 'Complete the task described below.';
    var ctx = p.context.join('\\n\\n');
    var contract = p.format || (o.strictOutput ? CONTRACTS[p.type] : '');
    var example = (p.examples.length && o.keepExamples) ? p.examples.join('\\n') : '';
    var injected = (!p.examples.length && o.fewShot) ? FEWSHOT[p.type] : '';
    var text = '';

    if (platform === 'claude') {
      var parts = [];
      if (p.role) parts.push('<role>\\n' + p.role + '\\n</role>');
      if (ctx) parts.push('<context>\\n' + ctx + '\\n</context>');
      parts.push('<task>\\n' + goal + '\\n</task>');
      if (p.rules.length) parts.push('<rules>\\n' + bulleted(p.rules) + '\\n</rules>');
      if (example || injected) parts.push('<examples>\\n<example>\\n' + (example || injected) + '\\n</example>\\n</examples>');
      if (contract) parts.push('<output_format>\\n' + contract + '\\n</output_format>');
      parts.push('Be direct. Do not restate these instructions. Do not add caveats.');
      if (o.cot) parts.push('Think through the task privately, then output only the result inside <answer></answer> tags.');
      text = parts.join('\\n\\n');
      notes.push('Wrapped every section in single-purpose XML tags.');
      notes.push('Markdown hierarchy replaced with tag hierarchy.');
    }

    if (platform === 'chatgpt') {
      var parts = [];
      parts.push('## ROLE');
      parts.push(p.role || 'You are a senior specialist producing production-ready output.');
      if (ctx) { parts.push('## CONTEXT'); parts.push(ctx); }
      parts.push('## TASK'); parts.push(goal);
      if (p.rules.length) { parts.push('## RULES'); parts.push(bulleted(p.rules)); }
      if (example || injected) { parts.push('## EXAMPLES'); parts.push(example || injected); }
      if (contract) { parts.push('## OUTPUT FORMAT'); parts.push(contract); }
      parts.push('Follow the OUTPUT FORMAT exactly. Do not ask clarifying questions.');
      if (o.cot) parts.push('Work through the problem internally first, then output only the final result.');
      text = parts.join('\\n\\n');
      notes.push('Rendered as a markdown hierarchy with an explicit output contract.');
    }

    if (platform === 'gemini') {
      var parts = [];
      parts.push('## Objective'); parts.push(goal);
      if (ctx) { parts.push('## Context'); parts.push(ctx.replace(/\\n{2,}/g, '\\n').trim()); }
      if (example || injected) { parts.push('## Reference example'); parts.push((example || injected).replace(/^#+\\s*/gm, '')); }
      if (contract) { parts.push('## Deliverable'); parts.push(contract); }
      var rules = p.rules.length ? p.rules : ['Match the deliverable exactly.'];
      parts.push('## Hard rules - every rule is mandatory'); parts.push(numbered(rules));
      parts.push('SELF-CHECK: before answering, re-read the hard rules above. If the draft violates any rule, fix it silently and output only the corrected answer.');
      text = parts.join('\\n\\n');
      notes.push('Rules moved to the end (Gemini recency bias).');
      notes.push('Constraints converted into a numbered HARD RULES block.');
    }

    if (platform === 'deepseek') {
      var parts = [];
      parts.push(goal.replace(/\\s+/g, ' ').trim());
      if (ctx) { parts.push('Background:'); parts.push(ctx.replace(/^#+\\s*/gm, '')); }
      if (p.rules.length) { parts.push('Constraints:'); parts.push(p.rules.map(function (r) { return '- ' + r; }).join('\\n')); }
      if (example || injected) { parts.push('Example:'); parts.push((example || injected).replace(/^#+\\s*/gm, '')); }
      if (contract) { parts.push('Output:'); parts.push(contract.replace(/^#+\\s*/gm, '')); }
      text = parts.join('\\n\\n');
      notes.push('Stripped markup, personas and roleplay framing (R1 prefers flat text).');
      if (p.coax.length) notes.push('Removed step-by-step reasoning instruction: R1 reasons internally.');
    }

    if (platform === 'llama') {
      var parts = [];
      parts.push('### System');
      parts.push(p.role || 'You are a precise assistant. Follow the format literally. Never add meta-commentary.');
      parts.push('### User'); parts.push(goal);
      if (ctx) parts.push('Context:\\n' + ctx);
      if (p.rules.length) parts.push('Rules:\\n' + p.rules.map(function (r) { return '- ' + r; }).join('\\n'));
      parts.push('### Expected format'); parts.push(contract || 'Answer directly with no preamble.');
      parts.push('### Example'); parts.push(example || injected || FEWSHOT.general);
      parts.push('### Response'); parts.push('(output only the formatted answer)');
      text = parts.join('\\n\\n');
      notes.push('Applied chat-template labels and injected a worked few-shot example.');
    }

    if (platform === 'perplexity') {
      var parts = [];
      parts.push(goal.replace(/\\s+/g, ' ').trim());
      if (ctx) parts.push('Context:\\n' + ctx.replace(/^#+\\s*/gm, ''));
      parts.push('Search guidance:');
      parts.push('- Current date: ' + today() + '. Prefer information from the last 12 months unless the question is historical.');
      parts.push('- Source tier: official documentation, primary sources, peer-reviewed papers, reputable press. Ignore SEO listicles.');
      parts.push('- If sources disagree, show both numbers and say so.');
      if (p.rules.length) parts.push('Constraints:\\n' + p.rules.map(function (r) { return '- ' + r; }).join('\\n'));
      parts.push('Answer format:\\n' + (p.format || '3-5 bullet findings, each with an inline citation [n] and the source domain, then a 2-line confidence note.'));
      text = parts.join('\\n\\n');
      notes.push('Added a recency window, a source tier and an inline-citation contract.');
    }

    if (!text) text = raw;
    return { platform: platform, text: text.trim() + '\\n', notes: notes, type: p.type, tokens: Math.round(text.length / 4) };
  }

  function detect(host) {
    var h = String(host || '').replace(/^www\\./, '');
    var found = null;
    Object.keys(PLATFORMS).forEach(function (id) {
      PLATFORMS[id].hosts.forEach(function (d) { if (!found && (h === d || h.indexOf(d) === 0)) found = id; });
    });
    return found;
  }

  /* compat score of the raw prompt against a target */
  function score(raw, platform) {
    var p = parse(raw);
    var penalties = 0;
    if (platform === 'claude') { if (!/<\\/?[a-z_]+>/i.test(raw)) penalties += 16; if (/^#{1,6}\\s/m.test(raw)) penalties += 11; }
    if (platform === 'chatgpt') { if (!p.format) penalties += 15; if (!p.role) penalties += 10; }
    if (platform === 'gemini') { if (p.rules.length && !RULE_RE.test(raw.trim().split('\\n').pop())) penalties += 18; if (p.rules.length < 3) penalties += 10; }
    if (platform === 'deepseek') { if (p.coax.length) penalties += 22; if (/<\\/?[a-z_]+>/i.test(raw)) penalties += 12; if (p.role) penalties += 10; }
    if (platform === 'llama') { if (!p.examples.length) penalties += 18; if (!p.format) penalties += 15; }
    if (platform === 'perplexity') { if (!/cit(e|ation)/i.test(raw)) penalties += 15; if (!/20\\d\\d|latest|recent|current/.test(raw)) penalties += 12; }
    return Math.max(8, Math.min(99, 99 - penalties));
  }

  root.PromptBridgeCore = { PLATFORMS: PLATFORMS, parse: parse, translate: translate, detect: detect, score: score, classify: classify };
})(typeof self !== 'undefined' ? self : globalThis);
`,

  "content.js": `/* PromptBridge - in-page layer: paste translation, Ctrl+Enter broadcast, remote fill */
(function () {
  'use strict';
  var core = self.PromptBridgeCore;
  if (!core) return;

  var platform = core.detect(location.host);
  var options = { fewShot: true, cot: true, strictOutput: true, keepExamples: true };

  var COMPOSER = {
    chatgpt: 'div#prompt-textarea, textarea[data-id="root"]',
    claude: 'div[contenteditable="true"], fieldset div.ProseMirror',
    gemini: 'rich-textarea div[contenteditable="true"], div.ProseMirror',
    deepseek: 'textarea#chat-input, textarea',
    perplexity: 'div[contenteditable="true"], textarea',
    llama: 'div[contenteditable="true"], textarea'
  };

  var SENDER = {
    chatgpt: 'button[data-testid="send-button"], button[aria-label="Send prompt"]',
    claude: 'button[aria-label="Send message"], button[type="submit"]',
    gemini: 'button.send-button, button[aria-label="Send message"]',
    deepseek: 'button[aria-label="Send"], div[role="button"][aria-disabled="false"]',
    perplexity: 'button[aria-label="Submit"], button[type="submit"]',
    llama: 'button[type="submit"]'
  };

  chrome.storage.sync.get({ options: options }, function (res) { options = res.options || options; });

  function findComposer() {
    var sel = COMPOSER[platform] || 'textarea, div[contenteditable="true"]';
    var nodes = document.querySelectorAll(sel);
    for (var i = nodes.length - 1; i >= 0; i--) {
      var el = nodes[i];
      if (el.offsetParent !== null || el.getClientRects().length) return el;
    }
    return null;
  }

  function setValue(el, text) {
    el.focus();
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      var setter = Object.getOwnPropertyDescriptor(el.constructor.prototype, 'value').set;
      setter.call(el, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      el.focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, text);
      el.dispatchEvent(new InputEvent('input', { bubbles: true, data: text, inputType: 'insertText' }));
    }
  }

  function toast(msg, undo) {
    var host = document.getElementById('pb-toast');
    if (host) host.remove();
    host = document.createElement('div');
    host.id = 'pb-toast';
    host.textContent = msg;
    host.style.cssText = 'position:fixed;z-index:2147483647;bottom:18px;left:18px;font:500 12.5px/1.4 -apple-system,system-ui,sans-serif;'
      + 'background:#0b1020;color:#e2e8f0;padding:10px 14px;border-radius:12px;border:1px solid rgba(255,255,255,.14);'
      + 'box-shadow:0 18px 50px -20px rgba(0,0,0,.9);display:flex;gap:12px;align-items:center;max-width:340px';
    if (undo) {
      var b = document.createElement('button');
      b.textContent = 'Undo';
      b.style.cssText = 'all:unset;color:#a5b4fc;font-weight:700;cursor:pointer';
      b.onclick = function () { setValue(undo.el, undo.original); host.remove(); };
      host.appendChild(b);
    }
    document.body.appendChild(host);
    setTimeout(function () { host && host.remove(); }, 7000);
  }

  /* ---- translate on paste when the pasted payload looks like a full prompt ---- */
  document.addEventListener('paste', function (e) {
    var el = e.target && e.target.closest ? e.target.closest('textarea, [contenteditable="true"]') : null;
    if (!el) return;
    var text = (e.clipboardData || window.clipboardData).getData('text/plain');
    if (!text || text.length < 220 || /\\n/.test(text) === false) return;
    var res = core.translate(text, platform, options);
    if (res.text === text) return;
    e.preventDefault();
    e.stopPropagation();
    setValue(el, res.text);
    toast('PromptBridge rewrote this prompt for ' + core.PLATFORMS[platform].name + '.', { el: el, original: text });
    chrome.runtime.sendMessage({ type: 'PB_TRANSLATED', from: 'paste', platform: platform, chars: text.length, promptType: res.type });
  }, true);

  /* ---- Ctrl+Enter broadcasts the composer content to every open AI tab ---- */
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && (e.key === 'Enter')) {
      var el = findComposer();
      var val = el ? (el.value || el.innerText) : '';
      if (!val || val.trim().length < 3) return;
      e.preventDefault();
      chrome.runtime.sendMessage({ type: 'PB_BROADCAST', prompt: val, submit: false });
      toast('Broadcasting to every open AI tab...');
    }
  }, true);

  /* ---- receive a translated prompt from the orchestrator ---- */
  chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
    if (!msg || !msg.type) return;
    if (msg.type === 'PB_FILL') {
      var el = findComposer();
      if (!el) { reply({ ok: false, error: 'composer-not-found' }); return; }
      setValue(el, msg.text);
      if (msg.submit) {
        setTimeout(function () {
          var btn = document.querySelector(SENDER[platform] || 'button[type="submit"]');
          if (btn) btn.click();
        }, 350);
      }
      reply({ ok: true, platform: platform });
    }
    if (msg.type === 'PB_PING') reply({ ok: true, platform: platform });
    if (msg.type === 'PB_RETRANSLATE') {
      var el2 = findComposer();
      if (!el2) return;
      var raw = el2.value || el2.innerText || '';
      if (!raw.trim()) return;
      setValue(el2, core.translate(raw, platform, options).text);
      reply({ ok: true });
    }
    return true;
  });
})();
`,

  "background.js": `/* PromptBridge - service worker: orchestration, history, analytics */
importScripts('translator-core.js');

var AI_MATCHERS = [
  /^https:\\/\\/chatgpt\\.com\\//i,
  /^https:\\/\\/chat\\.openai\\.com\\//i,
  /^https:\\/\\/claude\\.ai\\//i,
  /^https:\\/\\/gemini\\.google\\.com\\//i,
  /^https:\\/\\/chat\\.deepseek\\.com\\//i,
  /^https:\\/\\/www\\.perplexity\\.ai\\//i,
  /^https?:\\/\\/localhost:\\d+\\//i,
  /^https?:\\/\\/127\\.0\\.0\\.1:\\d+\\//i
];

function aiTabs() {
  return new Promise(function (resolve) {
    chrome.tabs.query({}, function (tabs) {
      resolve(tabs.filter(function (t) { return AI_MATCHERS.some(function (re) { return re.test(t.url || ''); }); }));
    });
  });
}

function fillTab(tabId, text, submit) {
  return new Promise(function (resolve) {
    chrome.tabs.sendMessage(tabId, { type: 'PB_FILL', text: text, submit: !!submit }, function (res) {
      if (chrome.runtime.lastError || !res || !res.ok) {
        // content script not ready: inject it, then retry once
        chrome.scripting.executeScript(
          { target: { tabId: tabId }, files: ['translator-core.js', 'content.js'] },
          function () {
            if (chrome.runtime.lastError) return resolve({ ok: false });
            chrome.tabs.sendMessage(tabId, { type: 'PB_FILL', text: text, submit: !!submit }, function (r2) {
              resolve(r2 || { ok: false });
            });
          }
        );
        return;
      }
      resolve(res);
    });
  });
}

async function broadcast(prompt, submit) {
  var tabs = await aiTabs();
  var results = [];
  for (var i = 0; i < tabs.length; i++) {
    var tab = tabs[i];
    var platform = self.PromptBridgeCore.detect(new URL(tab.url).host);
    if (!platform) continue;
    var opts = await new Promise(function (r) { chrome.storage.sync.get({ options: { fewShot: true, cot: true, strictOutput: true, keepExamples: true } }, function (s) { r(s.options); }); });
    var translated = self.PromptBridgeCore.translate(prompt, platform, opts);
    var res = await fillTab(tab.id, translated.text, submit);
    results.push({ tabId: tab.id, platform: platform, ok: !!(res && res.ok), tokens: translated.tokens, promptType: translated.type });
  }
  logRun(prompt, results);
  return results;
}

function logRun(prompt, results) {
  chrome.storage.local.get({ history: [] }, function (s) {
    var history = s.history || [];
    var group = 'run-' + Date.now();
    results.forEach(function (r) {
      history.unshift({
        id: group + '-' + r.platform,
        group: group,
        ts: Date.now(),
        model: r.platform,
        type: r.promptType,
        score: 0,
        latency: 0,
        chars: r.tokens * 4,
        title: String(prompt).slice(0, 64)
      });
    });
    chrome.storage.local.set({ history: history.slice(0, 1000) });
  });
}

chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
  if (!msg) return;
  if (msg.type === 'PB_BROADCAST') { broadcast(msg.prompt, msg.submit).then(reply); return true; }
  if (msg.type === 'PB_AI_TABS') { aiTabs().then(function (tabs) { reply(tabs.map(function (t) { return { id: t.id, title: t.title, url: t.url, platform: self.PromptBridgeCore.detect(new URL(t.url).host) }; })); }); return true; }
  if (msg.type === 'PB_TRANSLATED') {
    chrome.storage.local.get({ stats: { runs: 0, byPlatform: {} } }, function (s) {
      var stats = s.stats;
      stats.runs += 1;
      stats.byPlatform[msg.platform] = (stats.byPlatform[msg.platform] || 0) + 1;
      chrome.storage.local.set({ stats: stats });
    });
    reply({ ok: true });
  }
});

chrome.commands.onCommand.addListener(function (command) {
  if (command === 'broadcast-prompt') {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs[0];
      if (!tab) return;
      chrome.tabs.sendMessage(tab.id, { type: 'PB_READ_COMPOSER' }, function () {
        /* composer text arrives through PB_BROADCAST from the content script */
        if (chrome.runtime.lastError) chrome.action.openPopup ? chrome.action.openPopup() : null;
      });
    });
  }
  if (command === 'translate-paste') {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: 'PB_RETRANSLATE' }, function () { void chrome.runtime.lastError; });
    });
  }
});
`,

  "popup.html": `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="popup.css" />
  </head>
  <body>
    <header>
      <div class="logo"></div>
      <div>
        <h1>PromptBridge</h1>
        <p id="context">detecting tab…</p>
      </div>
    </header>

    <label class="lbl">Prompt</label>
    <textarea id="prompt" placeholder="Paste the prompt that already works in your usual chatbot…"></textarea>

    <div class="row">
      <label class="lbl" for="target">Target dialect</label>
      <select id="target"></select>
    </div>

    <div class="opts">
      <label><input type="checkbox" id="strictOutput" checked /> Output contract</label>
      <label><input type="checkbox" id="fewShot" checked /> Few-shot injection</label>
      <label><input type="checkbox" id="cot" checked /> Reasoning routing</label>
      <label><input type="checkbox" id="keepExamples" checked /> Keep my examples</label>
    </div>

    <div class="scorebar"><span id="scoreLabel">compat</span><b id="score">–</b></div>

    <div class="btns">
      <button id="copy" class="ghost">Copy</button>
      <button id="broadcast" class="primary">Broadcast to <span id="tabCount">0</span> tabs</button>
    </div>

    <pre id="out" class="out">The translated prompt appears here.</pre>

    <footer>
      <a href="options.html" target="_blank">History &amp; routing</a>
      <span id="stats"></span>
    </footer>

    <script src="translator-core.js"></script>
    <script src="popup.js"></script>
  </body>
</html>
`,

  "popup.css": `:root { color-scheme: dark; }
* { box-sizing: border-box; }
body { width: 380px; margin: 0; padding: 14px; background: #05060a; color: #e2e8f0; font: 400 13px/1.5 -apple-system, system-ui, "Segoe UI", sans-serif; }
header { display: flex; gap: 10px; align-items: center; margin-bottom: 12px; }
.logo { width: 30px; height: 30px; border-radius: 9px; background: linear-gradient(135deg, #6366f1, #22d3ee); box-shadow: 0 6px 18px -6px #6366f1; }
h1 { font-size: 14px; margin: 0; }
header p { margin: 2px 0 0; font-size: 11px; color: #64748b; }
.lbl { display: block; font-size: 10px; text-transform: uppercase; letter-spacing: .14em; color: #64748b; margin: 10px 0 5px; }
textarea { width: 100%; min-height: 96px; resize: vertical; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.1); border-radius: 10px; padding: 9px; color: #e2e8f0; font: 400 12px/1.6 ui-monospace, monospace; outline: none; }
textarea:focus, select:focus { border-color: rgba(129,140,248,.55); }
select { width: 100%; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.1); border-radius: 10px; padding: 8px; color: #e2e8f0; }
.opts { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 10px; margin: 10px 0 4px; }
.opts label { display: flex; gap: 7px; align-items: center; font-size: 11.5px; color: #94a3b8; }
.scorebar { display: flex; justify-content: space-between; align-items: baseline; font-size: 10px; text-transform: uppercase; letter-spacing: .14em; color: #64748b; margin: 8px 0 6px; }
.scorebar b { font-size: 15px; color: #34d399; font-variant-numeric: tabular-nums; }
.btns { display: flex; gap: 8px; margin-bottom: 10px; }
button { flex: 1; border: 0; border-radius: 10px; padding: 9px 10px; font: 600 12.5px inherit; cursor: pointer; }
button.primary { background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #fff; }
button.ghost { flex: 0 0 auto; background: rgba(255,255,255,.06); color: #cbd5e1; border: 1px solid rgba(255,255,255,.12); }
button:active { transform: translateY(1px); }
.out { margin: 0; max-height: 180px; overflow: auto; background: rgba(0,0,0,.35); border: 1px solid rgba(255,255,255,.08); border-radius: 10px; padding: 10px; font: 400 11px/1.6 ui-monospace, monospace; white-space: pre-wrap; word-break: break-word; color: #cbd5e1; }
footer { display: flex; justify-content: space-between; margin-top: 10px; font-size: 10.5px; color: #475569; }
footer a { color: #a5b4fc; text-decoration: none; }
`,

  "popup.js": `var core = self.PromptBridgeCore;
var el = function (id) { return document.getElementById(id); };
var options = { fewShot: true, cot: true, strictOutput: true, keepExamples: true };
var currentPlatform = null;
var tabCount = 0;

chrome.storage.sync.get({ options: options }, function (r) {
  options = r.options;
  ['fewShot', 'cot', 'strictOutput', 'keepExamples'].forEach(function (k) { el(k).checked = !!options[k]; });
});

var select = el('target');
Object.keys(core.PLATFORMS).forEach(function (id) {
  var o = document.createElement('option');
  o.value = id;
  o.textContent = core.PLATFORMS[id].name + '  -  ' + core.PLATFORMS[id].syntax;
  select.appendChild(o);
});

chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  var host = tabs[0] && tabs[0].url ? new URL(tabs[0].url).host : '';
  currentPlatform = core.detect(host);
  if (currentPlatform) {
    select.value = currentPlatform;
    el('context').textContent = 'this tab: ' + core.PLATFORMS[currentPlatform].name;
  } else {
    el('context').textContent = 'no AI tab active - pick a target';
  }
});

chrome.runtime.sendMessage({ type: 'PB_AI_TABS' }, function (tabs) {
  tabCount = (tabs || []).length;
  el('tabCount').textContent = String(tabCount);
});

function render() {
  var raw = el('prompt').value;
  var target = select.value;
  if (!raw.trim()) { el('out').textContent = 'The translated prompt appears here.'; el('score').textContent = '-'; return; }
  var res = core.translate(raw, target, options);
  el('out').textContent = res.text;
  var s = core.score(raw, target);
  var b = el('score');
  b.textContent = s + ' \u2192 ' + Math.min(99, s + 30);
  b.style.color = s > 74 ? '#34d399' : s > 45 ? '#fbbf24' : '#f87171';
}

['prompt', 'target'].forEach(function (id) {
  el(id).addEventListener('input', render);
  el(id).addEventListener('change', render);
});
['fewShot', 'cot', 'strictOutput', 'keepExamples'].forEach(function (k) {
  el(k).addEventListener('change', function () {
    options[k] = el(k).checked;
    chrome.storage.sync.set({ options: options });
    render();
  });
});

el('copy').addEventListener('click', function () {
  navigator.clipboard.writeText(el('out').textContent).then(function () {
    el('copy').textContent = 'Copied';
    setTimeout(function () { el('copy').textContent = 'Copy'; }, 1400);
  });
});

el('broadcast').addEventListener('click', function () {
  var btn = el('broadcast');
  btn.textContent = 'Broadcasting...';
  chrome.runtime.sendMessage({ type: 'PB_BROADCAST', prompt: el('prompt').value, submit: true }, function (res) {
    var n = (res || []).filter(function (r) { return r.ok; }).length;
    btn.textContent = 'Sent to ' + n + ' tab' + (n === 1 ? '' : 's');
    setTimeout(function () { btn.innerHTML = 'Broadcast to <span id="tabCount">' + tabCount + '</span> tabs'; }, 1800);
  });
});

chrome.storage.local.get({ stats: { runs: 0 } }, function (s) {
  el('stats').textContent = s.stats.runs + ' translations';
});

render();
`,

  "options.html": `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>PromptBridge - history &amp; routing</title>
    <link rel="stylesheet" href="popup.css" />
    <style>
      body { width: 780px; }
      table { width: 100%; border-collapse: collapse; font-size: 12px; }
      th { text-align: left; font-size: 10px; text-transform: uppercase; letter-spacing: .12em; color: #64748b; padding: 8px 6px; border-bottom: 1px solid rgba(255,255,255,.1); }
      td { padding: 8px 6px; border-bottom: 1px solid rgba(255,255,255,.05); }
      .bar { height: 6px; border-radius: 99px; background: rgba(255,255,255,.08); overflow: hidden; }
      .bar i { display: block; height: 100%; background: #818cf8; }
      .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin: 14px 0; }
      .card { background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.09); border-radius: 12px; padding: 12px; }
      .card b { display: block; font-size: 22px; }
    </style>
  </head>
  <body>
    <header><div class="logo"></div><div><h1>Prompt performance analytics</h1><p>every broadcast, every model, every rating</p></div></header>

    <div class="grid" id="cards"></div>
    <table id="board"><thead><tr><th>Model</th><th style="width:38%">Mean score</th><th>Runs</th><th>Best category</th></tr></thead><tbody></tbody></table>
    <table id="history" style="margin-top:18px"><thead><tr><th>When</th><th>Prompt</th><th>Model</th><th>Category</th><th>Rating</th></tr></thead><tbody></tbody></table>

    <div class="btns" style="margin-top:16px">
      <button class="ghost" id="export">Export JSON</button>
      <button class="ghost" id="clear">Clear history</button>
    </div>

    <script src="translator-core.js"></script>
    <script src="options.js"></script>
  </body>
</html>
`,

  "options.js": `var $ = function (s) { return document.querySelector(s); };
var LABEL = { coding: 'Coding', analysis: 'Data analysis', creative: 'Creative', reasoning: 'Reasoning', research: 'Research', general: 'General' };

chrome.storage.local.get({ history: [], stats: { runs: 0 } }, function (s) {
  var history = s.history || [];
  var rated = history.filter(function (r) { return r.score > 0; });

  var byModel = {};
  rated.forEach(function (r) {
    byModel[r.model] = byModel[r.model] || { scores: [], types: {}, runs: 0 };
    byModel[r.model].scores.push(r.score);
    byModel[r.model].types[r.type] = (byModel[r.model].types[r.type] || 0) + 1;
    byModel[r.model].runs++;
  });

  var rows = Object.keys(byModel).map(function (m) {
    var d = byModel[m];
    var avg = d.scores.reduce(function (a, b) { return a + b; }, 0) / d.scores.length;
    var best = Object.keys(d.types).sort(function (a, b) { return d.types[b] - d.types[a]; })[0];
    return { model: m, avg: avg, runs: d.runs, best: best };
  }).sort(function (a, b) { return b.avg - a.avg; });

  var cards = [
    ['Broadcasts', new Set(history.map(function (r) { return r.group; })).size],
    ['Rated answers', rated.length],
    ['Translations', s.stats.runs]
  ];
  $('#cards').innerHTML = cards.map(function (c) {
    return '<div class="card"><span style="font-size:10px;text-transform:uppercase;letter-spacing:.14em;color:#64748b">' + c[0] + '</span><b>' + c[1] + '</b></div>';
  }).join('');

  var max = rows.length ? rows[0].avg : 5;
  $('#board tbody').innerHTML = rows.map(function (r) {
    var name = (self.PromptBridgeCore.PLATFORMS[r.model] || {}).name || r.model;
    return '<tr><td>' + name + '</td><td><div class="bar"><i style="width:' + (r.avg / max * 100) + '%"></i></div><span style="font-size:11px;color:#94a3b8">' + r.avg.toFixed(2) + ' / 5</span></td><td>' + r.runs + '</td><td>' + (LABEL[r.best] || '-') + '</td></tr>';
  }).join('') || '<tr><td colspan="4" style="color:#475569">No rated answers yet. Broadcast a prompt, then rate the results from the popup.</td></tr>';

  $('#history tbody').innerHTML = history.slice(0, 40).map(function (r) {
    var name = (self.PromptBridgeCore.PLATFORMS[r.model] || {}).name || r.model;
    var stars = r.score ? '★★★★★'.slice(0, r.score) + '☆☆☆☆☆'.slice(0, 5 - r.score) : '–';
    return '<tr><td style="color:#64748b">' + new Date(r.ts).toLocaleString() + '</td><td>' + (r.title || '').slice(0, 46) + '</td><td>' + name + '</td><td>' + (LABEL[r.type] || r.type) + '</td><td style="color:#fbbf24">' + stars + '</td></tr>';
  }).join('') || '<tr><td colspan="5" style="color:#475569">Nothing logged yet.</td></tr>';
});

$('#export').onclick = function () {
  chrome.storage.local.get({ history: [] }, function (s) {
    var blob = new Blob([JSON.stringify(s.history, null, 2)], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'promptbridge-history.json';
    a.click();
  });
};

$('#clear').onclick = function () {
  if (confirm('Delete all PromptBridge history?')) chrome.storage.local.set({ history: [], stats: { runs: 0, byPlatform: {} } }, function () { location.reload(); });
};
`,

  "README.md": `# PromptBridge — Universal Prompt Translator

A Chrome extension (Manifest V3) that turns one prompt into the native dialect of whichever
model you paste it into.

## What it does

- Paste translation: pasting a long, structured prompt into Claude/Gemini/DeepSeek/Perplexity
  automatically restructures it for that model and shows an Undo toast.
- Ctrl + Enter broadcast: sends the composer's prompt to every open AI tab, each copy
  translated for that tab's model.
- Popup: pick a target dialect, see the compat score of your raw prompt, copy the result.
- Options page: history, per-model leaderboard and category routing, JSON export.

## Install (unpacked)

1. Download and unzip this folder.
2. Open chrome://extensions
3. Enable Developer mode (top right).
4. Click "Load unpacked" and select the unzipped folder.
5. Open chatgpt.com, claude.ai or gemini.google.com and paste a long prompt.

## Why the transforms differ

| Target | Transform |
|---|---|
| ChatGPT | Markdown hierarchy (## ROLE / ## TASK) plus an explicit output contract |
| Claude | Single-purpose XML tags: <role> <context> <task> <rules> <output_format> |
| Gemini | Rules moved to the end (recency bias), numbered HARD RULES, flattened nesting, self-check |
| DeepSeek R1 | Flat text only: no XML, no persona, and chain-of-thought prompts removed |
| Llama / Qwen | Chat-template labels (### System / ### User) plus an injected few-shot example |
| Perplexity | Recency window, source tier, inline-citation contract |

## Files

- manifest.json          MV3 manifest, content-script matches, keyboard commands
- translator-core.js     The syntax optimization engine (shared by every context)
- content.js             Paste interception, Ctrl+Enter, remote fill
- background.js          Service worker: multi-tab orchestrator + history logging
- popup.html/js/css      Dialect picker, compat score, copy, broadcast
- options.html/js        Analytics, leaderboard, export

## Permissions

- storage: your prompt options and rating history stay in chrome.storage (never uploaded)
- tabs + scripting: needed to find your open AI tabs and fill the composer
- clipboardWrite: the copy button

No network requests. No analytics servers. Everything is local.

Note: icon files are not bundled with this zip; Chrome falls back to a default letter icon.
`,

  "icons/README.txt": `Drop icon16.png, icon48.png and icon128.png here to replace the default Chrome letter tile.
A simple generated mark: rounded square, indigo-to-cyan gradient, white chevrons.
`,
};

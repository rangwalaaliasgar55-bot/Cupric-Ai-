import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/utils/cn";
import Hero from "@/components/Hero";
import Translator from "@/components/Translator";
import Orchestrator from "@/components/Orchestrator";
import Analytics from "@/components/Analytics";
import ExtensionPanel from "@/components/ExtensionPanel";
import { Panel, SectionHeading } from "@/components/ui";
import { createZip, downloadBlob } from "@/lib/zip";
import { EXTENSION_FILES } from "@/extension/files";
import { PLATFORM_LIST, SAMPLE_PROMPTS } from "@/lib/engine";

const NAV = [
  { id: "problem", label: "The problem" },
  { id: "translate", label: "Translator" },
  { id: "sync", label: "Orchestrator" },
  { id: "analytics", label: "Analytics" },
  { id: "install", label: "Install" },
];

function Nav({ onJump }: { onJump: (id: string) => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState("problem");
  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      let current = NAV[0].id;
      for (const n of NAV) {
        const el = document.getElementById(n.id);
        if (el && el.getBoundingClientRect().top < 180) current = n.id;
      }
      setActive(current);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 border-b transition-all duration-300",
        scrolled ? "border-white/10 bg-[#05060a]/85 backdrop-blur-xl" : "border-transparent bg-transparent",
      )}
    >
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-5 py-3">
        <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="flex items-center gap-2.5">
          <span className="relative flex h-8 w-8 items-center justify-center rounded-[10px] bg-gradient-to-br from-indigo-500 to-cyan-400 shadow-[0_8px_24px_-8px_rgba(99,102,241,0.9)]">
            <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round">
              <path d="M4 12h7M4 7h4M4 17h4" />
              <path d="M14 6l4 6-4 6" />
            </svg>
          </span>
          <span className="text-[15px] font-bold tracking-tight text-white">
            Prompt<span className="text-indigo-300">Bridge</span>
          </span>
        </button>

        <nav className="ml-4 hidden items-center gap-1 lg:flex">
          {NAV.map((n) => (
            <button
              key={n.id}
              onClick={() => onJump(n.id)}
              className={cn(
                "rounded-lg px-3 py-1.5 text-[13px] font-medium transition",
                active === n.id ? "bg-white/[0.08] text-white" : "text-slate-400 hover:text-slate-100",
              )}
            >
              {n.label}
            </button>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <span className="hidden rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[11.5px] text-slate-400 sm:inline">
            v1.0.0 · MV3
          </span>
          <button
            onClick={() => onJump("install")}
            className="rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-2 text-[13px] font-semibold text-white transition hover:from-indigo-400 hover:to-violet-400"
          >
            Add to Chrome
          </button>
        </div>
      </div>
    </header>
  );
}

const PROBLEMS = [
  {
    icon: "🧩",
    title: "Prompt lock-in",
    body: "A prompt that behaves in ChatGPT silently breaks in Claude, Gemini or R1. Same words, different model → different formatting, different adherence, more hallucination.",
    stat: "Same prompt, 6 dialects",
  },
  {
    icon: "📐",
    title: "Syntax is not portable",
    body: "Claude wants XML tags. Gemini wants rules last. R1 wants flat text and punishes chain-of-thought prompting. Open models need few-shot examples or they invent a format.",
    stat: "Zero shared conventions",
  },
  {
    icon: "⏱",
    title: "Manual reformatting",
    body: "You rewrite the same prompt three times to A/B a model, then lose track of which one actually won. Nothing records the outcome.",
    stat: "~20 min per comparison",
  },
];

const FLOW = [
  { n: "01", t: "Type once", d: "Write the prompt in whatever syntax feels natural. The parser extracts role, context, rules, examples and format intent." },
  { n: "02", t: "Detect the target", d: "The content script reads the host you're on and picks that model's dialect — or you pick it explicitly in the popup." },
  { n: "03", t: "Restructure", d: "The engine re-renders the prompt: XML wrapping, rule re-ordering, CoT stripping, few-shot injection, output contracts." },
  { n: "04", t: "Broadcast & score", d: "Ctrl + Enter fans the tailored prompt out to every open AI tab. Rate each answer; your leaderboard learns which model wins which job." },
];

export default function App() {
  const [prompt, setPrompt] = useState(SAMPLE_PROMPTS.coding);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);

  const jump = useCallback((id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  const flash = useCallback((msg: string) => {
    setToast(msg);
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 3200);
  }, []);

  const download = useCallback(() => {
    const blob = createZip(EXTENSION_FILES);
    downloadBlob(blob, "promptbridge-extension.zip");
    flash("promptbridge-extension.zip downloaded — unzip it, then Load unpacked in chrome://extensions");
  }, [flash]);

  const sendToOrchestrator = useCallback(
    (p: string) => {
      setPrompt(p);
      jump("sync");
      flash("Prompt loaded into the orchestrator — hit Broadcast (or Ctrl + Enter)");
    },
    [jump, flash],
  );

  useEffect(() => () => window.clearTimeout(toastTimer.current), []);

  return (
    <div className="min-h-screen bg-[#05060a] text-slate-200 selection:bg-indigo-500/40">
      <Nav onJump={jump} />
      <Hero onDownload={download} onJump={jump} />

      {/* ---------------- problem ---------------- */}
      <section className="mx-auto max-w-7xl px-5 py-16">
        <SectionHeading
          id="problem"
          eyebrow="The problem"
          title="Prompt & tool lock-in"
          blurb="Every model family has its own instruction physics. A prompt is not a portable artefact — it is a dialect-specific artefact, and nobody has time to translate it by hand."
        />
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {PROBLEMS.map((p) => (
            <Panel key={p.title} className="group relative overflow-hidden px-5 py-5 transition hover:border-white/20">
              <div className="mb-3 flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-[17px]">
                {p.icon}
              </div>
              <h3 className="text-[15px] font-semibold text-white">{p.title}</h3>
              <p className="mt-2 text-[13px] leading-relaxed text-slate-400">{p.body}</p>
              <div className="mt-4 mono text-[10.5px] uppercase tracking-[0.14em] text-indigo-300/70">{p.stat}</div>
              <div className="pointer-events-none absolute -bottom-16 -right-16 h-32 w-32 rounded-full bg-indigo-500/[0.07] blur-2xl transition group-hover:bg-indigo-500/[0.14]" />
            </Panel>
          ))}
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {FLOW.map((f) => (
            <Panel key={f.n} className="px-4 py-4">
              <div className="mono mb-2 text-[11px] font-bold text-indigo-400/80">{f.n}</div>
              <div className="text-[13.5px] font-semibold text-white">{f.t}</div>
              <p className="mt-1.5 text-[12px] leading-relaxed text-slate-400">{f.d}</p>
            </Panel>
          ))}
        </div>
      </section>

      {/* ---------------- translator ---------------- */}
      <section className="relative border-y border-white/[0.07] bg-black/25">
        <div className="mx-auto max-w-7xl px-5 py-16">
          <SectionHeading
            id="translate"
            eyebrow="Feature 01 · Syntax optimization engine"
            title="Translate a prompt into any model's dialect"
            blurb="Type or paste a prompt. The engine parses it into role, context, rules, examples and format intent, then re-renders it for the target — and shows you exactly what would have broken."
          />
          <div className="mt-8">
            <Translator prompt={prompt} setPrompt={setPrompt} onSend={sendToOrchestrator} />
          </div>
        </div>
      </section>

      {/* ---------------- dialect reference ---------------- */}
      <section className="mx-auto max-w-7xl px-5 pb-4 pt-2">
        <SectionHeading
          eyebrow="Reference"
          title="Each model, each dialect"
          blurb="These are the engineering quirks the engine encodes. Same prompt, six different instruction physics."
        />
        <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {PLATFORM_LIST.map((p) => (
            <Panel key={p.id} className="group relative overflow-hidden px-4 py-4 transition hover:border-white/20">
              <div className="flex items-center gap-2">
                <span
                  className="flex h-6 w-6 items-center justify-center rounded-lg text-[10px] font-bold"
                  style={{ background: p.color + "22", color: p.color }}
                >
                  {p.short.slice(0, 2)}
                </span>
                <div className="min-w-0">
                  <div className="text-[13.5px] font-semibold text-white">{p.name}</div>
                  <div className="text-[10.5px] text-slate-500">{p.vendor}</div>
                </div>
                <span className="mono ml-auto shrink-0 text-[9.5px] text-slate-600">{p.domain}</span>
              </div>
              <div className="mt-3 rounded-lg border border-white/[0.07] bg-white/[0.02] px-2.5 py-1.5">
                <div className="mono text-[11px] text-indigo-200/90">{p.syntax}</div>
              </div>
              <ul className="mt-3 space-y-1.5">
                {p.traits.map((t) => (
                  <li key={t} className="flex gap-2 text-[11.5px] leading-snug text-slate-400">
                    <span className="mt-[3px] h-1 w-1 shrink-0 rounded-full" style={{ background: p.color }} />
                    {t}
                  </li>
                ))}
              </ul>
              <p className="mt-3 border-t border-white/[0.07] pt-2.5 text-[11px] italic leading-snug text-slate-500">"{p.quirk}"</p>
            </Panel>
          ))}
        </div>
      </section>

      {/* ---------------- orchestrator ---------------- */}
      <section className="mx-auto max-w-7xl px-5 py-16">
        <SectionHeading
          id="sync"
          eyebrow="Feature 02 · Multi-tab orchestrator"
          title="Submit everywhere at once, tailored per tab"
          blurb="The service worker enumerates your open AI tabs, translates once per target and fills each composer. In the extension it hits real tabs — here it simulates the three you have connected so you can feel the workflow end to end."
        />
        <div className="mt-8">
          <Orchestrator prompt={prompt} setPrompt={setPrompt} />
        </div>
      </section>

      {/* ---------------- analytics ---------------- */}
      <section className="relative border-y border-white/[0.07] bg-black/25">
        <div className="mx-auto max-w-7xl px-5 py-16">
          <SectionHeading
            id="analytics"
            eyebrow="Feature 03 · Prompt performance analytics"
            title="Learn which model actually wins your prompts"
            blurb="Every rated broadcast becomes a data point. PromptBridge builds a personal leaderboard, a category heatmap and routing recommendations — coding to one model, research to another, automatically."
          />
          <div className="mt-8">
            <Analytics />
          </div>
        </div>
      </section>

      {/* ---------------- install ---------------- */}
      <section className="mx-auto max-w-7xl px-5 py-16">
        <SectionHeading
          id="install"
          eyebrow="Ship it"
          title="The actual extension, in your browser"
          blurb="This is the real source: MV3 manifest, content scripts with per-platform composer selectors, a service worker orchestrator, popup and analytics page. Download it as a zip and load it unpacked."
        />
        <div className="mt-8">
          <ExtensionPanel />
        </div>
      </section>

      <footer className="border-t border-white/[0.07] bg-black/40">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-4 px-5 py-8">
          <div>
            <div className="text-[14px] font-bold text-white">
              Prompt<span className="text-indigo-300">Bridge</span>
            </div>
            <p className="mt-1 text-[12px] text-slate-500">
              Universal prompt translator · Chrome MV3 · no account, no telemetry, no network calls.
            </p>
          </div>
          <div className="ml-auto flex flex-wrap gap-2">
            <button
              onClick={download}
              className="rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-2.5 text-[13px] font-semibold text-white transition hover:from-indigo-400 hover:to-violet-400"
            >
              ⬇ Download .zip
            </button>
            <button
              onClick={() => jump("translate")}
              className="rounded-xl border border-white/15 bg-white/[0.04] px-4 py-2.5 text-[13px] font-semibold text-slate-200 transition hover:bg-white/[0.08]"
            >
              Back to the engine
            </button>
          </div>
        </div>
      </footer>

      {toast && (
        <div className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2 px-4">
          <div className="fade-up flex items-center gap-3 rounded-xl border border-white/15 bg-[#0b1020]/95 px-4 py-3 text-[12.5px] text-slate-200 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.95)] backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            {toast}
            <button onClick={() => setToast(null)} className="ml-2 text-slate-500 transition hover:text-slate-200">
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

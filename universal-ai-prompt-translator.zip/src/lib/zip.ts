/**
 * Minimal, dependency-free ZIP writer (STORE method, no compression).
 * Enough to package the PromptBridge extension source for download.
 */

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function dosDateTime(d: Date) {
  const time = ((d.getHours() & 0x1f) << 11) | ((d.getMinutes() & 0x3f) << 5) | ((d.getSeconds() / 2) & 0x1f);
  const date = (((d.getFullYear() - 1980) & 0x7f) << 9) | (((d.getMonth() + 1) & 0xf) << 5) | (d.getDate() & 0x1f);
  return { time, date };
}

interface Chunk {
  nameBytes: Uint8Array;
  data: Uint8Array;
  crc: number;
  offset: number;
}

export function createZip(files: Record<string, string>): Blob {
  const encoder = new TextEncoder();
  const chunks: Chunk[] = [];
  const parts: BlobPart[] = [];
  let offset = 0;

  const push = (view: Uint8Array) => {
    parts.push(view as unknown as BlobPart);
    offset += view.byteLength;
  };

  const names = Object.keys(files).sort();
  for (const name of names) {
    const nameBytes = encoder.encode(name);
    const data = encoder.encode(files[name]);
    const crc = crc32(data);
    const { time, date } = dosDateTime(new Date());

    const local = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(local.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true); // version needed
    lv.setUint16(6, 0, true); // flags
    lv.setUint16(8, 0, true); // store
    lv.setUint16(10, time, true);
    lv.setUint16(12, date, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, data.length, true);
    lv.setUint32(22, data.length, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    local.set(nameBytes, 30);

    chunks.push({ nameBytes, data, crc, offset });
    push(local);
    push(data);
  }

  const centralStart = offset;
  for (const chunk of chunks) {
    const { time, date } = dosDateTime(new Date());
    const central = new Uint8Array(46 + chunk.nameBytes.length);
    const cv = new DataView(central.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, time, true);
    cv.setUint16(14, date, true);
    cv.setUint32(16, chunk.crc, true);
    cv.setUint32(20, chunk.data.length, true);
    cv.setUint32(24, chunk.data.length, true);
    cv.setUint16(28, chunk.nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, chunk.offset, true);
    central.set(chunk.nameBytes, 46);
    push(central);
  }

  const end = new Uint8Array(22);
  const ev = new DataView(end.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(8, chunks.length, true);
  ev.setUint16(10, chunks.length, true);
  ev.setUint32(12, offset - centralStart, true);
  ev.setUint32(16, centralStart, true);
  push(end);

  return new Blob(parts, { type: "application/zip" });
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

import { useSyncExternalStore } from "react";
import type { PlatformId, PromptType } from "./engine";
import { PLATFORMS } from "./engine";

export interface Run {
  id: string;
  group: string;
  ts: number;
  model: PlatformId;
  type: PromptType;
  score: number; // 1..5
  latency: number; // ms to first token
  chars: number;
  title: string;
}

const KEY = "promptbridge.runs.v1";

let runs: Run[] = [];
let loaded = false;
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
}

function load() {
  if (loaded) return;
  loaded = true;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) runs = JSON.parse(raw) as Run[];
    else runs = seed();
    persist();
  } catch {
    runs = seed();
  }
}

function persist() {
  try {
    localStorage.setItem(KEY, JSON.stringify(runs));
  } catch {
    /* quota / private mode — in-memory only */
  }
}

/* --- deterministic pseudo-random so the demo charts are stable --- */
function mulberry(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const MODEL_BIAS: Record<PlatformId, Partial<Record<PromptType, number>>> = {
  claude: { coding: 4.6, reasoning: 4.8, creative: 4.5, analysis: 4.3, research: 4.0, general: 4.4 },
  chatgpt: { coding: 4.4, reasoning: 4.2, creative: 4.3, analysis: 4.1, research: 4.0, general: 4.5 },
  gemini: { coding: 4.0, reasoning: 4.1, creative: 4.0, analysis: 4.6, research: 4.2, general: 4.2 },
  deepseek: { coding: 4.5, reasoning: 4.6, creative: 3.6, analysis: 4.2, research: 3.5, general: 4.0 },
  llama: { coding: 3.7, reasoning: 3.6, creative: 3.9, analysis: 3.4, research: 3.2, general: 3.8 },
  perplexity: { coding: 3.4, reasoning: 3.8, creative: 3.1, analysis: 3.9, research: 4.8, general: 3.9 },
};

const TITLES: Record<PromptType, string[]> = {
  coding: ["Fix unmount race in useData hook", "Refactor checkout reducer", "Type-safe API client", "Regex for invoice IDs", "Postgres index for slow query"],
  analysis: ["Pricing A/B test read-out", "Chort retention teardown", "Funnel drop-off analysis", "Forecast Q3 signups", "Churn cohort breakdown"],
  creative: ["Landing page copy v3", "Tagline sprint", "Cold email sequence", "Release notes voice", "Newsletter opener"],
  reasoning: ["Monolith → services decision", "Pick a vector DB", "Buy vs build auth", "On-call rotation design", "Rust vs Go for ingestion"],
  research: ["Prompt tooling landscape 2026", "Competitor pricing sweep", "SOC2 vendors compared", "LLM context window table", "AI slop studies"],
  general: ["Summarise strategy offsite", "Rewrite Jira ticket", "Translate spec to brief", "Meeting notes cleanup", "Doc restructure"],
};

function seed(): Run[] {
  const rand = mulberry(20260214);
  const out: Run[] = [];
  const types: PromptType[] = ["coding", "analysis", "creative", "reasoning", "research", "general"];
  const now = Date.now();
  const day = 86400000;

  for (let d = 27; d >= 0; d--) {
    const perDay = 1 + Math.floor(rand() * 3);
    for (let i = 0; i < perDay; i++) {
      const type = types[Math.floor(rand() * types.length)];
      const group = `g-${d}-${i}`;
      const title = TITLES[type][Math.floor(rand() * TITLES[type].length)];
      // each broadcast hits 2-4 models
      const pool = (Object.keys(PLATFORMS) as PlatformId[]).filter(() => rand() > 0.42).slice(0, 2 + Math.floor(rand() * 3));
      if (pool.length < 2) pool.push("claude", "chatgpt");
      for (const model of pool) {
        const bias = MODEL_BIAS[model][type] ?? 3.9;
        const jitter = (rand() - 0.5) * 1.1;
        const score = Math.max(1, Math.min(5, Math.round((bias + jitter) * 2) / 2));
        out.push({
          id: `${group}-${model}`,
          group,
          ts: now - d * day - Math.floor(rand() * day),
          model,
          type,
          score,
          latency: 380 + Math.floor(rand() * 3400),
          chars: 600 + Math.floor(rand() * 5200),
          title,
        });
      }
    }
  }
  return out.sort((a, b) => b.ts - a.ts);
}

export function addRuns(newRuns: Omit<Run, "id" | "ts">[]) {
  load();
  const ts = Date.now();
  const created = newRuns.map((r, i) => ({ ...r, id: `${ts}-${i}-${r.model}`, ts: ts - i }));
  runs = [...created, ...runs].slice(0, 1200);
  persist();
  emit();
}

export function resetRuns() {
  runs = seed();
  persist();
  emit();
}

export function clearRuns() {
  runs = [];
  persist();
  emit();
}

export function getRuns() {
  load();
  return runs;
}

function subscribe(cb: () => void) {
  load();
  listeners.add(cb);
  return () => listeners.delete(cb);
}

export function useRuns(): Run[] {
  return useSyncExternalStore(subscribe, getRuns, getRuns);
}

/* ---------------------------- analytics ---------------------------- */

export interface ModelStat {
  model: PlatformId;
  avg: number;
  runs: number;
  wins: number;
  winRate: number;
  bestType: PromptType;
  bestAvg: number;
  latency: number;
}

export function leaderboard(data: Run[]): ModelStat[] {
  const byModel = new Map<PlatformId, Run[]>();
  for (const r of data) {
    const list = byModel.get(r.model) ?? [];
    list.push(r);
    byModel.set(r.model, list);
  }
  const groups = new Map<string, Run[]>();
  for (const r of data) {
    const g = groups.get(r.group) ?? [];
    g.push(r);
    groups.set(r.group, g);
  }
  const wins = new Map<PlatformId, number>();
  groups.forEach((g) => {
    const top = Math.max(...g.map((x) => x.score));
    const winners = g.filter((x) => x.score === top);
    if (winners.length === 1) wins.set(winners[0].model, (wins.get(winners[0].model) ?? 0) + 1);
    else winners.forEach((w) => wins.set(w.model, (wins.get(w.model) ?? 0) + 0.5));
  });

  const stats: ModelStat[] = [];
  byModel.forEach((list, model) => {
    const byType = new Map<PromptType, number[]>();
    list.forEach((r) => byType.set(r.type, [...(byType.get(r.type) ?? []), r.score]));
    let bestType: PromptType = "general";
    let bestAvg = 0;
    byType.forEach((scores, t) => {
      const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
      if (avg > bestAvg) {
        bestAvg = avg;
        bestType = t;
      }
    });
    stats.push({
      model,
      avg: list.reduce((a, b) => a + b.score, 0) / list.length,
      runs: list.length,
      wins: wins.get(model) ?? 0,
      winRate: (wins.get(model) ?? 0) / Math.max(1, groups.size),
      bestType,
      bestAvg,
      latency: list.reduce((a, b) => a + b.latency, 0) / list.length,
    });
  });
  return stats.sort((a, b) => b.avg - a.avg);
}

export function typeMatrix(data: Run[]) {
  const types: PromptType[] = ["coding", "analysis", "creative", "reasoning", "research", "general"];
  const models = (Object.keys(PLATFORMS) as PlatformId[]).filter((m) => data.some((d) => d.model === m));
  const matrix = models.map((model) => ({
    model,
    cells: types.map((type) => {
      const rows = data.filter((d) => d.model === model && d.type === type);
      return { type, avg: rows.length ? rows.reduce((a, b) => a + b.score, 0) / rows.length : 0, n: rows.length };
    }),
  }));
  return { types, models, matrix };
}

export function trendSeries(data: Run[], days = 14) {
  const day = 86400000;
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const out: { label: string; avg: number; n: number; d: number }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const from = start.getTime() - i * day;
    const to = from + day;
    const rows = data.filter((r) => r.ts >= from && r.ts < to);
    out.push({
      label: new Date(from).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
      avg: rows.length ? rows.reduce((a, b) => a + b.score, 0) / rows.length : 0,
      n: rows.length,
      d: from,
    });
  }
  return out;
}

export function recommendation(data: Run[], type: PromptType): { model: PlatformId; avg: number; margin: number } | null {
  const rows = data.filter((r) => r.type === type);
  if (rows.length < 3) return null;
  const byModel = new Map<PlatformId, number[]>();
  rows.forEach((r) => byModel.set(r.model, [...(byModel.get(r.model) ?? []), r.score]));
  const ranked = [...byModel.entries()]
    .map(([model, scores]) => ({ model, avg: scores.reduce((a, b) => a + b, 0) / scores.length }))
    .sort((a, b) => b.avg - a.avg);
  if (ranked.length < 2) return null;
  return { model: ranked[0].model, avg: ranked[0].avg, margin: ranked[0].avg - ranked[1].avg };
}

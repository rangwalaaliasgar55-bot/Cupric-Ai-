/* ------------------------------------------------------------------
   PromptBridge — Syntax Optimization Engine
   Parses a "generic" prompt, then re-renders it in the dialect each
   model family actually responds to. Also lints the original prompt
   against each target's known quirks and returns a compat score.
------------------------------------------------------------------- */

export type PlatformId = "chatgpt" | "claude" | "gemini" | "deepseek" | "llama" | "perplexity";

export type PromptType = "coding" | "analysis" | "creative" | "reasoning" | "research" | "general";

export interface Platform {
  id: PlatformId;
  name: string;
  short: string;
  vendor: string;
  domain: string;
  color: string;
  gradient: string;
  syntax: string;
  quirk: string;
  traits: string[];
}

export const PLATFORMS: Record<PlatformId, Platform> = {
  chatgpt: {
    id: "chatgpt",
    name: "ChatGPT / GPT-5",
    short: "GPT",
    vendor: "OpenAI",
    domain: "chatgpt.com",
    color: "#10a37f",
    gradient: "from-emerald-400 to-teal-500",
    syntax: "Markdown hierarchy + explicit output contract",
    quirk: "Drifts from format on long answers unless the contract is restated at the end.",
    traits: [
      "Responds to clear markdown headings (## ROLE, ## TASK)",
      "Needs an explicit output contract or it pads with preamble",
      "Tolerates long prompts, but buries rules placed in the middle",
    ],
  },
  claude: {
    id: "claude",
    name: "Claude 4",
    short: "Claude",
    vendor: "Anthropic",
    domain: "claude.ai",
    color: "#d97757",
    gradient: "from-orange-400 to-amber-500",
    syntax: "XML tags + prefill-style directness",
    quirk: "Treats markdown headings as content, not instructions — XML wins.",
    traits: [
      "Best-in-class at XML delimited structure (<context>, <rules>)",
      "Prefers 'be direct' over hedging politeness",
      "Long context is fine, but keep each tag single-purpose",
    ],
  },
  gemini: {
    id: "gemini",
    name: "Gemini 2.5 Pro",
    short: "Gemini",
    vendor: "Google",
    domain: "gemini.google.com",
    color: "#4285f4",
    gradient: "from-blue-400 to-indigo-500",
    syntax: "Numbered hard rules + recency-ordered instructions",
    quirk: "Recency bias: rules placed at the top get partially ignored.",
    traits: [
      "Instructions at the END of the prompt carry the most weight",
      "Numbered 'hard rules' beat prose paragraphs",
      "Deep markdown nesting gets flattened — keep 1 level",
    ],
  },
  deepseek: {
    id: "deepseek",
    name: "DeepSeek R1",
    short: "R1",
    vendor: "DeepSeek",
    domain: "chat.deepseek.com",
    color: "#4d6bfe",
    gradient: "from-indigo-400 to-blue-600",
    syntax: "Flat, terse task statement — no CoT prompting",
    quirk: "Asking it to 'think step by step' degrades the reasoning trace.",
    traits: [
      "R1 reasons internally — never prompt for chain-of-thought",
      "System-role play and XML wrappers reduce accuracy",
      "Shortest prompt with a clean constraint list wins",
    ],
  },
  llama: {
    id: "llama",
    name: "Llama 4 / Qwen",
    short: "Open",
    vendor: "Meta · local WebUI",
    domain: "localhost WebUI",
    color: "#f59e0b",
    gradient: "from-yellow-400 to-orange-500",
    syntax: "Chat-template labels + few-shot examples",
    quirk: "Zero-shot abstractions collapse without a worked example.",
    traits: [
      "Needs 1–2 verbatim few-shot examples before the real task",
      "Strict section labels (### System / ### User) anchor it",
      "Must be told what NOT to output, or it adds meta-commentary",
    ],
  },
  perplexity: {
    id: "perplexity",
    name: "Perplexity",
    short: "PPLX",
    vendor: "Perplexity AI",
    domain: "perplexity.ai",
    color: "#22b8cd",
    gradient: "from-cyan-400 to-sky-500",
    syntax: "Search directives + citation contract",
    quirk: "It is a retrieval engine: it needs source scope and dates.",
    traits: [
      "State the timeframe, or you get stale 2021 pages",
      "Define source tier (official docs, papers, primary sources)",
      "Ask for inline citations or the answer is unfalsifiable",
    ],
  },
};

export const PLATFORM_LIST = Object.values(PLATFORMS);

/* ------------------------------ parsing ------------------------------ */

const ROLE_RE = /^\s*(you are|you're|act as|acting as|as an?\b|behave as|pretend to be|take the role of|role\s*:)/i;
const CONSTRAINT_RE =
  /\b(must|must not|should|should not|shall|always|never|do not|don'?t|ensure|make sure|avoid|only use|use only|no more than|at most|at least|limit|keep it|do not include|include only|be sure|mandatory|required|forbidden|strictly|exactly)\b/i;
const FORMAT_RE =
  /\b(format|output|respond with|return only|give me|json|yaml|markdown|table|bullet|numbered list|csv|schema|template|word count|words or fewer)\b/i;
const EXAMPLE_RE = /\b(example|e\.g\.|for instance|sample|few[- ]shot|like this)\b/i;
const COAX_RE = /\b(think step[- ]by[- ]step|step by step|chain of thought|let'?s think|reason carefully|show your reasoning|take a breath)\b/i;
const COAX_GLOBAL =
  /\b(think step[- ]by[- ]step|step by step|chain of thought|let'?s think|reason carefully|show your reasoning|take a breath)\b/gi;
const IMPERATIVE_RE =
  /^\s*(please\s+)?(can you\s+)?(fix|fixx|write|create|build|make|explain|analyse|analyze|refactor|design|summar|research|tell|give|compare|review|generate|draft|produce|find|list|rewrite|suggest|recommend|evaluate|translate)\b/i;

const TYPE_SIGNALS: Record<PromptType, string[]> = {
  coding: ["code", "function", "bug", "api", "refactor", "typescript", "javascript", "python", "sql", "react", "component", "compile", "test", "regex", "endpoint", "typescript"],
  analysis: ["data", "csv", "analyze", "analysis", "chart", "metric", "kpi", "statistic", "forecast", "cohort", "spreadsheet", "dashboard", "trend", "funnel"],
  creative: ["story", "poem", "brand", "tagline", "write a", "creative", "marketing copy", "email", "newsletter", "script", "caption", "landing page", "tone", "voice"],
  reasoning: ["why", "explain", "compare", "pros and cons", "tradeoff", "strategy", "decide", "evaluate", "architect", "should i", "risk", "root cause"],
  research: ["research", "sources", "cite", "citation", "latest", "news", "who is", "when did", "find out", "search", "statistics on", "market size", "benchmark"],
  general: ["summarise", "summarize", "rewrite", "translate", "help me", "explain"],
};

export interface ParsedPrompt {
  role: string | null;
  goal: string;
  context: string[];
  constraints: string[];
  examples: string[];
  outputFormat: string | null;
  coax: string[];
  blocks: string[];
  type: PromptType;
  chars: number;
  tokens: number;
  markdownDepth: number;
}

export function estimateTokens(text: string) {
  return Math.max(1, Math.round(text.trim().length / 4));
}

function sentenceOf(text: string, max = 240) {
  const clean = text.replace(/\s+/g, " ").trim();
  const first = clean.split(/(?<=[.!?])\s/)[0] || clean;
  return first.length > max ? first.slice(0, max).trim() + "…" : first;
}

export function parsePrompt(raw: string): ParsedPrompt {
  const text = raw.replace(/\r\n/g, "\n").trim();
  const blocks: string[] = [];
  // keep fenced code blocks together
  let buffer: string[] = [];
  let fence = false;
  for (const line of text.split("\n")) {
    if (/^\s*```/.test(line)) fence = !fence;
    if (!fence && line.trim() === "") {
      if (buffer.length) blocks.push(buffer.join("\n").trim());
      buffer = [];
    } else buffer.push(line);
  }
  if (buffer.length) blocks.push(buffer.join("\n").trim());

  let role: string | null = null;
  const contextBlocks: string[] = [];
  const constraints: string[] = [];
  const examples: string[] = [];
  const coax: string[] = [];
  const tasks: string[] = [];
  let outputFormat: string | null = null;
  let goal = "";
  let goalBlock: string | null = null;
  let goalRest = "";

  const handle = (ls: string[], block: string) => {
    const isExample = EXAMPLE_RE.test(block) || ls.some((l) => /^\s*```/.test(l));
    for (const line of ls) {
      let l = line.trim();
      if (!l) continue;

      // strip "think step by step" style coaxing, keep the real instruction
      if (COAX_RE.test(l)) {
        coax.push(sentenceOf(l, 120));
        l = l
          .replace(COAX_GLOBAL, " ")
          // drop the dangling purpose clause the coaxing usually trails into
          .replace(/\s+(so that|so|and so|in order|that)\b[\s\S]*$/i, " ")
          .replace(/\s*,\s*(and|then|or)?\s*$/i, "")
          .replace(/\s+/g, " ")
          .trim();
        if (l.length < 14) continue;
      }

      if (isExample || /^\s*```/.test(line)) {
        examples.push(l);
        continue;
      }
      if (CONSTRAINT_RE.test(l)) {
        // a constraint paragraph may hold several rules
        l.split(/(?<=[.!?])\s+/).forEach((s) => {
          if (s.trim()) constraints.push(normalizeRule(s));
        });
        continue;
      }
      if (FORMAT_RE.test(l)) {
        outputFormat = (outputFormat ? outputFormat + "\n" : "") + l;
        continue;
      }
      if (IMPERATIVE_RE.test(l)) {
        tasks.push(l.replace(/\s+/g, " ").trim());
        continue;
      }
      if (!goal) {
        const parts = block.split(/(?<=[.!?])\s+/);
        goal = parts[0].replace(/\s+/g, " ").trim();
        goalRest = parts.slice(1).join(" ").trim();
        goalBlock = block;
      }
      if (!contextBlocks.includes(block)) contextBlocks.push(block);
    }
  };

  for (const block of blocks) {
    const lines = block.split("\n");
    if (!role && ROLE_RE.test(lines[0]) && lines[0].length < 220) {
      role = lines.shift()!.replace(/^\s*[-*]\s*/, "").trim();
      if (!lines.join("\n").trim()) continue;
    }
    handle(lines, block);
  }

  if (!goal && tasks.length) goal = tasks.shift() as string;
  if (tasks.length) goal = (goal + " " + tasks.join(" ")).replace(/\s+/g, " ").trim();

  const context = (goalBlock ? [goalRest, ...contextBlocks.filter((b) => b !== goalBlock)] : contextBlocks).filter((t) => !!t);

  const lower = text.toLowerCase();
  let type: PromptType = "general";
  let best = 0;
  (Object.keys(TYPE_SIGNALS) as PromptType[]).forEach((t) => {
    const hits = TYPE_SIGNALS[t].filter((s) => lower.includes(s)).length;
    if (hits > best) {
      best = hits;
      type = t;
    }
  });

  const markdownDepth = text.split("\n").reduce((d, l) => {
    const lead = l.match(/^[ \t]*/)?.[0] ?? "";
    return Math.max(d, Math.floor(lead.replace(/\t/g, "  ").length / 2));
  }, 0);

  return {
    role,
    goal,
    context: context.filter((c) => c !== goal),
    constraints: dedupe(constraints),
    examples,
    outputFormat,
    coax: dedupe(coax),
    blocks,
    type,
    chars: text.length,
    tokens: estimateTokens(text),
    markdownDepth,
  };
}

function dedupe(list: string[]) {
  const seen = new Set<string>();
  return list.filter((i) => {
    const k = i.toLowerCase().replace(/[^a-z0-9]/g, "");
    if (!k || seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

function normalizeRule(line: string) {
  return line
    .replace(/^\s*[-*•]\s*/, "")
    .replace(/^\s*\d+[.)]\s*/, "")
    .replace(/^\s*/, "")
    .replace(/\s*$/, "")
    .replace(/^[-*•]\s*/, "");
}

export const TYPE_LABEL: Record<PromptType, string> = {
  coding: "Coding",
  analysis: "Data analysis",
  creative: "Creative writing",
  reasoning: "Reasoning / strategy",
  research: "Research",
  general: "General",
};

export const TYPE_EMOJI: Record<PromptType, string> = {
  coding: "⌨️",
  analysis: "📊",
  creative: "✍️",
  reasoning: "🧠",
  research: "🔎",
  general: "💡",
};

/* ------------------------------ options ------------------------------ */

export interface TranslateOptions {
  fewShot: boolean;
  cot: boolean;
  strictOutput: boolean;
  keepExamples: boolean;
}

export const DEFAULT_OPTIONS: TranslateOptions = {
  fewShot: true,
  cot: true,
  strictOutput: true,
  keepExamples: true,
};

/* ------------------------------ linting ------------------------------ */

export interface Finding {
  level: "critical" | "warning" | "info";
  title: string;
  detail: string;
  penalty: number;
}

export function lintPrompt(parsed: ParsedPrompt, id: PlatformId, raw: string): Finding[] {
  const out: Finding[] = [];
  const add = (level: Finding["level"], title: string, detail: string, penalty: number) =>
    out.push({ level, title, detail, penalty });

  const hasHeadings = /^#{1,6}\s/m.test(raw);
  const hasTags = /<\/?[a-z_]+>/i.test(raw);
  const openEnded = /\b(be creative|however you want|whatever|your choice|surprise me|freely)\b/i.test(raw);
  const long = parsed.tokens > 320;

  if (id === "claude") {
    if (!hasTags)
      add("critical", "No XML delimiters", "Claude prioritises XML tags over prose for instruction hierarchy. Untagged rules get treated as context.", 16);
    if (hasHeadings) add("warning", "Markdown headings read as content", "Claude renders # headings as part of the answer rather than as instructions.", 11);
    if (parsed.role) add("info", "Role should be isolated", "Anthropic guidance: one <role> tag, single purpose, no mixing with the task.", 5);
  }
  if (id === "chatgpt") {
    if (!parsed.outputFormat)
      add("critical", "No output contract", "GPT models pad long answers with preamble and drift out of format without an explicit contract.", 15);
    if (!parsed.role) add("warning", "No role frame", "A one-line role reduces hedging and generic filler measurably.", 10);
    if (parsed.markdownDepth >= 2) add("warning", "Deep nesting", "Nested bullets past two levels get flattened in the response.", 7);
  }
  if (id === "gemini") {
    if (parsed.constraints.length && !isRulesLast(raw))
      add("critical", "Rules placed too early", "Gemini has recency bias — constraints at the top are the ones it drops first.", 18);
    if (parsed.constraints.length < 3 && parsed.goal)
      add("warning", "Constraints are prose, not a rule list", "Gemini holds numbered HARD RULES far better than sentences.", 12);
    if (parsed.markdownDepth >= 2) add("warning", "Nested markdown", "Deeply nested lists get ignored or re-flowed.", 10);
    if (openEnded) add("info", "Open-ended instruction", "Gemini over-generalises without bounds — add an explicit scope.", 6);
  }
  if (id === "deepseek") {
    if (parsed.coax.length)
      add("critical", "Chain-of-thought prompting detected", "R1 already runs an internal reasoning trace. Requesting step-by-step reasoning makes the visible answer worse.", 22);
    if (hasTags) add("warning", "XML/HTML wrappers", "R1 was trained on flat text; wrappers get echoed into the output.", 12);
    if (parsed.role) add("warning", "Roleplay framing", "Persona framing measurably reduces R1 accuracy on technical tasks.", 10);
    if (long) add("info", "Prompt is long", "R1 works best with a terse task plus a short constraint list.", 6);
  }
  if (id === "llama") {
    if (!parsed.examples.length)
      add("critical", "No few-shot example", "Open-weight models need at least one worked example or they invent their own format.", 18);
    if (!parsed.outputFormat) add("critical", "No strict output spec", "Without a literal format block, local models append meta-commentary.", 15);
    if (!hasHeadings && !hasTags) add("warning", "No section labels", "### labels anchor smaller models to the task structure.", 9);
  }
  if (id === "perplexity") {
    if (!/cit(e|ations?)/i.test(raw)) add("critical", "No citation requirement", "Without an inline-citation contract the answer cannot be verified.", 15);
    if (!/\b(20\d\d|latest|recent|today|current|last (week|month|year)|past)\b/i.test(raw))
      add("warning", "No timeframe", "Retrieval defaults to whatever ranks — usually stale content.", 12);
    if (!/\b(source|official|docs|documentation|paper|primary|benchmark)\b/i.test(raw))
      add("info", "No source tier", "Defining which sources count removes low-quality SEO pages.", 8);
    if (parsed.type === "creative")
      add("info", "Wrong tool for the job", "Creative tasks route better to ChatGPT/Claude — Perplexity is a retrieval engine.", 7);
  }
  return out;
}

function isRulesLast(raw: string) {
  const constraintIdx = raw.split("\n").findIndex((l) => CONSTRAINT_RE_LOCAL.test(l));
  const lastContent = raw.trim().split("\n").filter((l) => l.trim()).pop() ?? "";
  return constraintIdx === -1 || CONSTRAINT_RE_LOCAL.test(lastContent);
}
const CONSTRAINT_RE_LOCAL =
  /\b(must|must not|should|always|never|do not|don'?t|ensure|avoid|only use|use only|no more than|strictly)\b/i;

export function compatScore(parsed: ParsedPrompt, id: PlatformId, raw: string) {
  const findings = lintPrompt(parsed, id, raw);
  const penalty = findings.reduce((s, f) => s + f.penalty, 0);
  return { score: Math.max(8, Math.min(99, 99 - penalty)), findings };
}

/* ------------------------------ rendering ------------------------------ */

const FEW_SHOT: Record<PromptType, string> = {
  coding:
    "Example:\nInput: getUser(id: 1)\nOutput: { \"ok\": true, \"user\": { \"id\": 1 } }",
  analysis:
    "Example:\nInput: 3 months of signups\nOutput: a table of month, signups, MoM %, then one line of interpretation.",
  creative:
    "Example:\nTone: dry, confident, no hype\nOutput: \"Ship the thing. Then talk about it.\"",
  reasoning:
    "Example:\nInput: should we migrate off Redis?\nOutput: Options table → tradeoffs → recommendation → what would change my mind.",
  research:
    "Example:\nOutput: 3 bullet findings, each with a citation [1] and a confidence note.",
  general:
    "Example:\nInput: summarise this thread\nOutput: 3 bullets + 1 open question.",
};

function header(label: string) {
  return "## " + label.toUpperCase();
}

function rulesBlock(constraints: string[]) {
  return constraints.map((c, i) => `${i + 1}. ${cap(c)}`).join("\n");
}

function cap(s: string) {
  const t = s.trim();
  return t.charAt(0).toUpperCase() + t.slice(1);
}

function bullets(constraints: string[]) {
  return constraints.map((c) => "- " + cap(c)).join("\n");
}

function outputContract(parsed: ParsedPrompt, opts: TranslateOptions) {
  if (parsed.outputFormat) return parsed.outputFormat;
  if (!opts.strictOutput) return "";
  switch (parsed.type) {
    case "coding":
      return "Return the complete final code in one fenced block. No explanation before it. After the code, add at most 3 bullets titled 'Notes'.";
    case "analysis":
      return "Return a markdown table of the key numbers first, then a 'Read' section with at most 4 bullets of interpretation. Flag any number you are unsure about.";
    case "creative":
      return "Return only the finished copy. No preamble, no options, no explanation of your choices.";
    case "reasoning":
      return "Return: (1) a comparison table, (2) the top 3 tradeoffs, (3) a single-line recommendation, (4) what evidence would flip it.";
    case "research":
      return "Return 3–5 bullet findings, each with an inline citation, then a 2-line 'Confidence' note.";
    default:
      return "Return a short direct answer first, then at most 5 supporting bullets. No preamble.";
  }
}

export interface Translation {
  platform: PlatformId;
  text: string;
  notes: string[];
  before: number;
  after: number;
  tokens: number;
}

function contextBody(parsed: ParsedPrompt) {
  return parsed.context.join("\n\n");
}

export function translate(raw: string, id: PlatformId, opts: TranslateOptions = DEFAULT_OPTIONS): Translation {
  const parsed = parsePrompt(raw);
  const before = compatScore(parsed, id, raw).score;
  const notes: string[] = [];
  const goal = parsed.goal || "Complete the task described below.";
  const ctx = contextBody(parsed);
  const rules = parsed.constraints.slice();
  const contract = outputContract(parsed, opts);
  const example = parsed.examples.length && opts.keepExamples ? parsed.examples.join("\n") : "";
  const injectExample = !parsed.examples.length && opts.fewShot ? FEW_SHOT[parsed.type] : "";

  const removeCoax = parsed.coax.length > 0;
  if (removeCoax) notes.push("Stripped chain-of-thought instruction — it conflicts with this model's native reasoning behaviour.");

  let text = "";

  if (id === "claude") {
    const parts: string[] = [];
    if (parsed.role) parts.push(`<role>\n${parsed.role}\n</role>`);
    if (ctx) parts.push(`<context>\n${ctx}\n</context>`);
    parts.push(`<task>\n${goal}\n</task>`);
    if (rules.length) parts.push(`<rules>\n${bullets(rules)}\n</rules>`);
    if (example) parts.push(`<examples>\n<example>\n${example}\n</example>\n</examples>`);
    if (injectExample) parts.push(`<examples>\n<example>\n${injectExample}\n</example>\n</examples>`);
    if (contract) parts.push(`<output_format>\n${contract}\n</output_format>`);
    parts.push("Be direct. Do not restate these instructions. Do not add caveats.");
    if (opts.cot) parts.push("Think through the task privately, then output only the result inside <answer></answer> tags.");
    text = parts.join("\n\n");
    notes.push("Wrapped every section in single-purpose XML tags — Claude's strongest instruction boundary.");
    notes.push("Replaced markdown hierarchy with tag hierarchy.");
    if (opts.cot) notes.push("Moved reasoning off-screen: private thinking, public <answer>.");
  }

  if (id === "chatgpt") {
    const parts: string[] = [];
    parts.push(header("Role"));
    parts.push(parsed.role || `You are a senior ${parsed.type === "coding" ? "engineer" : "specialist"} producing production-ready output.`);
    if (ctx) {
      parts.push(header("Context"));
      parts.push(ctx);
    }
    parts.push(header("Task"));
    parts.push(goal);
    if (rules.length) {
      parts.push(header("Rules"));
      parts.push(bullets(rules));
    }
    if (example || injectExample) {
      parts.push(header("Examples"));
      parts.push(example || injectExample);
    }
    if (contract) {
      parts.push(header("Output format"));
      parts.push(contract);
    }
    parts.push(`Follow the OUTPUT FORMAT exactly. Do not ask clarifying questions. Do not summarise your process.`);
    if (opts.cot && parsed.type !== "creative")
      parts.push("Work through the problem internally first, then output only the final result.");
    text = parts.join("\n\n");
    notes.push("Converted the prompt into a markdown hierarchy — GPT maps ## headings to output sections.");
    notes.push("Added an explicit output contract so the format survives to the end of long answers.");
    if (!parsed.role) notes.push("Injected a role frame to cut hedging and filler.");
  }

  if (id === "gemini") {
    const parts: string[] = [];
    parts.push(header("Objective"));
    parts.push(goal);
    if (ctx) {
      parts.push(header("Context"));
      parts.push(ctx.replace(/\n{2,}/g, "\n").trim());
    }
    if (parsed.role) parts.push(`Acting as: ${parsed.role}`);
    if (example || injectExample) {
      parts.push(header("Reference example"));
      parts.push((example || injectExample).replace(/^#+\s*/gm, ""));
    }
    if (contract) {
      parts.push(header("Deliverable"));
      parts.push(contract);
    }
    if (rules.length || opts.strictOutput) {
      const all = rules.length ? rules : ["Match the deliverable exactly."];
      parts.push(header("Hard rules — every rule is mandatory"));
      parts.push(rulesBlock(all));
    }
    parts.push(
      "SELF-CHECK: before answering, re-read the hard rules above. If the draft violates any rule, fix it silently. Output only the corrected final answer.",
    );
    text = parts.join("\n\n");
    notes.push("Reordered: objective → context → deliverable → rules. Rules last, because of Gemini's recency bias.");
    notes.push("Converted prose constraints into a numbered HARD RULES block.");
    notes.push("Flattened nesting to one level and appended a self-check instruction.");
  }

  if (id === "deepseek") {
    const parts: string[] = [];
    parts.push(goal.replace(/\s+/g, " ").trim());
    if (ctx) {
      parts.push("Background:");
      parts.push(ctx.replace(/^#+\s*/gm, "").replace(/\n{2,}/g, "\n").trim());
    }
    if (rules.length) {
      parts.push("Constraints:");
      parts.push(rules.map((r) => "- " + r).join("\n"));
    }
    if (example || injectExample) {
      parts.push("Example:");
      parts.push((example || injectExample).replace(/^#+\s*/gm, ""));
    }
    if (contract) {
      parts.push("Output:");
      parts.push(contract.replace(/^#+\s*/gm, ""));
    }
    text = parts.join("\n\n");
    notes.push("Stripped all markup, personas and roleplay framing — R1 performs best on flat text.");
    if (removeCoax) notes.push('Removed "think step by step": R1 reasons internally and this degrades output.');
    notes.push("Compressed to a terse task + constraint list so the reasoning budget goes to the problem.");
  }

  if (id === "llama") {
    const parts: string[] = [];
    parts.push("### System");
    parts.push(
      parsed.role ||
        `You are a precise assistant. Follow the format literally. Never add meta-commentary about the task.`,
    );
    parts.push("### User");
    parts.push(goal);
    if (ctx) parts.push("Context:\n" + ctx);
    if (rules.length) parts.push("Rules:\n" + rules.map((r) => "- " + r).join("\n"));
    parts.push("### Expected format");
    parts.push(contract || "Answer directly with no preamble.");
    parts.push("### Example");
    parts.push(example || injectExample || FEW_SHOT.general);
    parts.push("### Response");
    parts.push("(begin your answer here — output only the formatted answer)");
    text = parts.join("\n\n");
    notes.push("Applied a chat-template structure with explicit section labels.");
    notes.push("Injected a worked few-shot example — open models need the format demonstrated.");
    notes.push("Added an explicit 'do not add meta-commentary' rule and a response seed.");
  }

  if (id === "perplexity") {
    const today = new Date().toISOString().slice(0, 10);
    const parts: string[] = [];
    parts.push(goal.replace(/\s+/g, " ").trim());
    if (ctx) parts.push("Context:\n" + ctx.replace(/^#+\s*/gm, ""));
    parts.push("Search guidance:");
    parts.push(
      [
        `- Current date: ${today}. Prefer information from the last 12 months unless the question is historical.`,
        "- Source tier: official documentation, primary sources, peer-reviewed papers, reputable press. Ignore SEO listicles and content farms.",
        "- If sources disagree, say so explicitly and show both numbers.",
      ].join("\n"),
    );
    if (rules.length) parts.push("Constraints:\n" + rules.map((r) => "- " + r).join("\n"));
    parts.push(
      "Answer format:\n" +
        (parsed.outputFormat ||
          "3–5 bullet findings, each with an inline citation [n] and the source domain, then a 2-line confidence note."),
    );
    text = parts.join("\n\n");
    notes.push("Added a recency window so retrieval does not default to stale pages.");
    notes.push("Defined an explicit source tier to filter SEO spam out of the retrieval set.");
    notes.push("Enforced an inline-citation contract so every claim is checkable.");
  }

  if (opts.strictOutput && !parsed.outputFormat) notes.push("Generated a type-aware output contract (" + TYPE_LABEL[parsed.type] + ").");
  if (injectExample) notes.push("Injected a canonical few-shot example for " + TYPE_LABEL[parsed.type].toLowerCase() + " prompts.");

  const after = Math.min(99, 96 + (opts.strictOutput ? 2 : 0) + (opts.fewShot ? 1 : 0));

  return {
    platform: id,
    text: text.trim() + "\n",
    notes: dedupe(notes),
    before,
    after,
    tokens: estimateTokens(text),
  };
}

export const SAMPLE_PROMPTS: Record<PromptType, string> = {
  coding: `You are a senior TypeScript engineer.

I have a React hook that fetches data from our internal API. It works but it re-renders constantly and it
does not clean up the fetch when the component unmounts, so we get "setState on unmounted component" warnings.

const useData = (url) => {
  const [state, setState] = useState(null)
  useEffect(() => {
    fetch(url).then(r => r.json()).then(setState)
  })
  return state
}

Please fix it, use TypeScript properly, add an abort controller, and think step by step so I can follow the
logic. Must be compatible with React 18. Do not add any new dependencies.`,
  analysis: `As an analytics partner, look at this data.

We ran a 6-week pricing test on the checkout page. Cohort A saw the old price ($29), cohort B saw the new
price ($39). Signups were 1,842 vs 1,591. Revenue was 53,418 vs 62,049. Refund rate 3.1% vs 3.4%.

Tell me if we should ship the new price. Be honest about uncertainty and don't just agree with me.`,
  creative: `You are a brand copywriter.

Write landing page copy for a Chrome extension that translates prompts between AI chatbots.
Audience is developers and prompt power users who are sick of rewriting the same prompt for ChatGPT,
Claude and Gemini. Tone should be dry, confident, zero hype. Be creative.

Give me a headline, a subhead, and three feature blurbs.`,
  reasoning: `You are a staff engineer.

We're deciding whether to migrate our monolith to microservices. Team of 9 engineers, 400k LOC Node app,
deploy takes 22 minutes, one shared Postgres. Traffic is steady, not spiky. Explain the tradeoffs and
recommend something.`,
  research: `Research the current state of prompt engineering tooling in 2026.

I want to know which prompt-management and prompt-optimisation products exist, what they charge,
and whether anyone does automatic cross-model prompt translation.`,
  general: `Summarise this meeting transcript and tell me what I committed to.`,
};

export function sampleFor(type: PromptType) {
  return SAMPLE_PROMPTS[type] ?? SAMPLE_PROMPTS.general;
}

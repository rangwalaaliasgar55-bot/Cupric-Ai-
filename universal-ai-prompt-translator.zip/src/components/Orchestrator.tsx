import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { cn } from "@/utils/cn";
import {
  DEFAULT_OPTIONS,
  PLATFORMS,
  TYPE_EMOJI,
  TYPE_LABEL,
  parsePrompt,
  translate,
  type PlatformId,
  type PromptType,
} from "@/lib/engine";
import { addRuns, type Run } from "@/lib/store";
import { Badge, Panel, PlatformDot, scoreColor } from "./ui";

type Status = "idle" | "queued" | "thinking" | "streaming" | "done";

interface PaneState {
  status: Status;
  visible: number;
  latency: number;
  rated: number | null;
}

/* ------------------------- simulated model output ------------------------- */

function mockAnswer(model: PlatformId, type: PromptType, goal: string): string {
  const subject = goal.replace(/\.$/, "") || "the task";
  const short = subject.length > 74 ? subject.slice(0, 74) + "…" : subject;

  const body: Record<PlatformId, string> = {
    claude:
      "<answer>\n" +
      (type === "coding"
        ? "Fixed version below. The re-render came from an unguarded effect that re-ran every render.\n\n```ts\nconst useData = <T,>(url: string) => {\n  const [state, setState] = useState<T | null>(null);\n  useEffect(() => {\n    const ac = new AbortController();\n    fetch(url, { signal: ac.signal })\n      .then((r) => r.json())\n      .then(setState)\n      .catch((e) => { if (e.name !== 'AbortError') throw e; });\n    return () => ac.abort();\n  }, [url]);\n  return state;\n};\n```"
        : type === "creative"
          ? `Headline: One prompt. Every model.\nSubhead: Stop rewriting the same prompt for ChatGPT, Claude and Gemini. PromptBridge re-structures it for whichever one you're in.\n\n- Translate, don't copy — each model gets its native syntax\n- Broadcast to every open tab with Ctrl + Enter\n- Your history tells you which model actually wins\n\nThat's the whole pitch. No "revolutionary AI-powered synergy".`
          : `Direct answer: ${short}\n\n1. The core issue is scope, not execution — the constraint you named is the binding one.\n2. Two options are viable; they differ on cost of reversal, not on outcome quality.\n3. Recommendation: take the reversible one and instrument it.\n\nWhat would change my mind: a hard external deadline, or a >2x traffic shift.`) +
      "\n</answer>",
    chatgpt:
      (type === "coding"
        ? "## Fixed hook\n```ts\nconst useData = <T,>(url: string) => {\n  const [state, setState] = useState<T | null>(null);\n  useEffect(() => {\n    const ac = new AbortController();\n    fetch(url, { signal: ac.signal }).then((r) => r.json()).then(setState);\n    return () => ac.abort();\n  }, [url]);\n  return state;\n};\n```\n\n### Notes\n- `AbortController` cancels the in-flight request on unmount\n- `[url]` stops the effect re-running every render\n- Generic `<T,>` keeps the return type honest"
        : type === "creative"
          ? "## Headline\n**One prompt. Every model.**\n\n## Subhead\nPromptBridge translates your prompt into the native syntax of whichever chatbot you paste it into.\n\n## Feature blurbs\n- **Dialect-aware** — XML for Claude, hard rules for Gemini, flat text for R1.\n- **Broadcast** — Ctrl + Enter sends it to every open AI tab, tailored per model.\n- **Scored** — your own history shows which model wins for which job."
          : "## Answer\n" + short + "\n\n## Reasoning\n- The binding constraint is the one that cannot be reversed cheaply\n- Both viable paths converge on the same outcome within a quarter\n\n## Recommendation\nTake the reversible option and instrument it."),
    gemini:
      (type === "coding"
        ? "| Issue | Cause | Fix |\n|---|---|---|\n| Re-render loop | effect with no dependency array | `[url]` |\n| Unmount warning | no request cleanup | AbortController |\n\n```ts\nuseEffect(() => {\n  const ac = new AbortController();\n  fetch(url, { signal: ac.signal }).then(r => r.json()).then(setState);\n  return () => ac.abort();\n}, [url]);\n```\n\n1. Self-check passed: both hard rules respected (React 18, no new deps)."
        : `| Option | Cost | Reversibility |\n|---|---|---|\n| A — incremental | Low | High |\n| B — full rewrite | High | Low |\n\n**Read:** A reaches 80% of the benefit at 20% of the risk. B only wins if the domain model splits.\n\nSelf-check passed: every hard rule respected.`),
    deepseek:
      (type === "coding"
        ? "Reasoning trace (internal, 41s):\n> the effect lacks a dependency array → runs every render → new fetch each render; cleanup missing → setState after unmount. AbortController on cleanup, `[url]` dep.\n\n```ts\nuseEffect(() => {\n  const ac = new AbortController();\n  fetch(url, { signal: ac.signal }).then((r) => r.json()).then(setState)\n    .catch((e) => { if (e.name !== 'AbortError') throw e; });\n  return () => ac.abort();\n}, [url]);\n```\nTwo bugs fixed. No dependencies added."
        : `Reasoning trace (internal, 38s):\n> constraints: no new dependencies, React 18, TypeScript strict. tradeoff is dependency array vs ref guard.\n\n${short}.\n\nConstraints respected: React 18 compatible, zero new dependencies, strict types.`),
    llama:
      (type === "coding"
        ? "Here is the fixed hook:\n\n```ts\nconst useData = <T,>(url: string) => {\n  const [state, setState] = useState<T | null>(null)\n  useEffect(() => {\n    const ac = new AbortController()\n    fetch(url, { signal: ac.signal }).then(r => r.json()).then(setState)\n    return () => ac.abort()\n  }, [url])\n  return state\n}\n```\n\nI hope this helps! Let me know if you'd like me to explain anything else."
          : `${short}\n\n- Option A is cheaper and reversible\n- Option B is cleaner but expensive\n- Recommendation: Option A\n\nI hope this helps! Let me know if you have other questions.`),
    perplexity:
      (type === "coding"
        ? "Based on current docs:\n\n- React 18 recommends `AbortController` for fetch cleanup in effects [react.dev] [1]\n- Effects without a dependency array run after every render [react.dev] [2]\n- No extra dependency is needed — this is built into the platform [mdn] [3]\n\nConfidence: high. Sources are official documentation, retrieved 2026."
          : `Findings:\n- Prompt-management tooling consolidated in 2025–2026; most vendors now ship some form of versioning [1] [2]\n- Pricing clustered at $12–20/seat/month for team tiers [2] [3]\n- No mainstream product does automatic cross-model prompt *restructuring* — they store and version prompts instead [1] [3]\n\nConfidence: medium. Thin primary sources; two findings rest on vendor marketing pages.`),
  };
  return body[model];
}

const ACTIVE_DEFAULT: PlatformId[] = ["claude", "chatgpt", "gemini"];

export default function Orchestrator({
  prompt,
  setPrompt,
}: {
  prompt: string;
  setPrompt: (v: string) => void;
}) {
  const [active, setActive] = useState<PlatformId[]>(ACTIVE_DEFAULT);
  const [panes, setPanes] = useState<Record<string, PaneState>>({});
  const [busy, setBusy] = useState(false);
  const timers = useRef<number[]>([]);
  const groupRef = useRef<string>("");

  useEffect(() => () => timers.current.forEach((t) => window.clearInterval(t)), []);

  const parsed = useMemo(() => parsePrompt(prompt), [prompt]);
  const translations = useMemo(() => {
    const out = {} as Record<PlatformId, ReturnType<typeof translate>>;
    active.forEach((id) => (out[id] = translate(prompt, id, DEFAULT_OPTIONS)));
    return out;
  }, [prompt, active]);

  const answers = useMemo(() => {
    const out = {} as Record<PlatformId, string>;
    active.forEach((id) => (out[id] = mockAnswer(id, parsed.type, parsed.goal)));
    return out;
  }, [active, parsed]);

  const broadcast = useCallback(() => {
    timers.current.forEach((t) => window.clearInterval(t));
    timers.current = [];
    const group = "run-" + Date.now();
    groupRef.current = group;
    const base: Record<string, PaneState> = {};
    active.forEach((id) => {
      base[id] = { status: "queued", visible: 0, latency: PLATFORM_LATENCY[id], rated: null };
    });
    setPanes(base);
    setBusy(true);

    active.forEach((id, idx) => {
      const latency = PLATFORM_LATENCY[id] + idx * 260;
      const to = window.setTimeout(() => {
        setPanes((prev) => ({ ...prev, [id]: { ...prev[id], status: "thinking" } }));
        const ti = window.setInterval(() => {
          setPanes((prev) => {
            const pane = prev[id];
            if (!pane || pane.status === "done") {
              window.clearInterval(ti);
              return prev;
            }
            const next = Math.min((answers[id] ?? "").length, pane.visible + 11);
            const done = next >= (answers[id] ?? "").length;
            if (done) window.clearInterval(ti);
            return { ...prev, [id]: { ...pane, visible: next, status: done ? "done" : "streaming" } };
          });
        }, 22);
        timers.current.push(ti);
      }, latency);
      timers.current.push(to);
    });

    const longest = active.reduce((m, id) => Math.max(m, PLATFORM_LATENCY[id]), 0);
    const stream = Math.max(...active.map((id) => (answers[id] ?? "").length)) / 11 * 22;
    const finish = window.setTimeout(() => setBusy(false), longest + stream + 400);
    timers.current.push(finish);
  }, [active, answers]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
        e.preventDefault();
        broadcast();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [broadcast]);

  const rate = (id: PlatformId, score: number) => {
    setPanes((prev) => ({ ...prev, [id]: { ...prev[id], rated: score } }));
    const run: Omit<Run, "id" | "ts"> = {
      group: groupRef.current || "manual-" + Date.now(),
      model: id,
      type: parsed.type,
      score,
      latency: panes[id]?.latency ?? 1200,
      chars: translations[id]?.text.length ?? 0,
      title: parsed.goal.slice(0, 64) || "Untitled prompt",
    };
    addRuns([run]);
  };

  const ratedCount = active.filter((id) => panes[id]?.rated).length;

  return (
    <div className="space-y-4">
      <Panel className="overflow-hidden">
        <div className="flex flex-wrap items-center gap-3 border-b border-white/10 px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            <span className="text-[13px] font-semibold text-white">Multi-Tab Orchestrator</span>
          </div>
          <Badge tone="slate">{active.length} tabs connected</Badge>
          <Badge tone="indigo">{TYPE_EMOJI[parsed.type]} {TYPE_LABEL[parsed.type]}</Badge>
          <div className="ml-auto flex items-center gap-2">
            <div className="hidden items-center gap-1.5 sm:flex">
              {(Object.keys(PLATFORMS) as PlatformId[]).map((id) => {
                const on = active.includes(id);
                return (
                  <button
                    key={id}
                    title={PLATFORMS[id].name}
                    onClick={() => setActive((a) => (on ? a.filter((x) => x !== id) : [...a, id]))}
                    className={cn(
                      "flex items-center gap-1.5 rounded-lg border px-2 py-1 text-[11px] transition",
                      on ? "border-white/25 bg-white/[0.08] text-slate-100" : "border-white/10 bg-white/[0.02] text-slate-500 hover:text-slate-300",
                    )}
                  >
                    <PlatformDot id={id} size={7} />
                    {PLATFORMS[id].short}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="grid gap-3 px-4 py-3 lg:grid-cols-[minmax(0,1fr)_auto]">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            spellCheck={false}
            placeholder="Type the prompt once…"
            className="thin-scroll mono min-h-[76px] resize-none rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-[12.5px] leading-relaxed text-slate-200 outline-none transition focus:border-indigo-400/40 placeholder:text-slate-600"
          />
          <div className="flex flex-col gap-2 lg:w-52">
            <button
              onClick={broadcast}
              disabled={active.length === 0}
              className={cn(
                "group relative overflow-hidden rounded-xl px-4 py-2.5 text-[13px] font-semibold text-white transition",
                active.length === 0
                  ? "cursor-not-allowed bg-white/10 text-slate-500"
                  : "bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-400 hover:to-violet-400",
                busy && "shimmer",
              )}
            >
              {busy ? "Broadcasting…" : "Broadcast to all tabs"}
            </button>
            <div className="rounded-xl border border-white/10 bg-white/[0.02] px-3 py-2 text-[11px] leading-snug text-slate-500">
              Hotkey <kbd className="mono rounded border border-white/15 bg-white/[0.07] px-1.5 py-0.5 text-[10px] text-slate-300">Ctrl</kbd> +{" "}
              <kbd className="mono rounded border border-white/15 bg-white/[0.07] px-1.5 py-0.5 text-[10px] text-slate-300">Enter</kbd> fires the same
              broadcast from any AI tab.
            </div>
            {ratedCount > 0 && (
              <div className="rounded-xl border border-emerald-400/25 bg-emerald-500/10 px-3 py-2 text-[11px] text-emerald-200">
                {ratedCount}/{active.length} rated · logged to analytics
              </div>
            )}
          </div>
        </div>
      </Panel>

      <div className={cn("grid gap-4", active.length >= 3 ? "xl:grid-cols-3" : "md:grid-cols-2", active.length === 1 && "grid-cols-1")}>
        {active.map((id) => {
          const pane = panes[id];
          const tr = translations[id];
          const answer = answers[id] ?? "";
          const visible = pane ? answer.slice(0, pane.visible) : "";
          return (
            <Panel key={id} className="flex flex-col overflow-hidden">
              {/* fake tab chrome */}
              <div className="flex items-center gap-2 border-b border-white/10 bg-black/30 px-3 py-2">
                <div className="flex gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-rose-400/70" />
                  <span className="h-2.5 w-2.5 rounded-full bg-amber-400/70" />
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/70" />
                </div>
                <div className="ml-1 flex min-w-0 flex-1 items-center gap-2 rounded-lg bg-white/[0.05] px-2.5 py-1">
                  <PlatformDot id={id} size={7} />
                  <span className="mono truncate text-[10.5px] text-slate-400">{PLATFORMS[id].domain}</span>
                  <span
                    className={cn(
                      "ml-auto h-1.5 w-1.5 shrink-0 rounded-full",
                      !pane || pane.status === "idle"
                        ? "bg-slate-600"
                        : pane.status === "done"
                          ? "bg-emerald-400"
                          : "bg-amber-400 animate-pulse",
                    )}
                  />
                </div>
              </div>

              {/* tailored prompt */}
              <div className="border-b border-white/10 px-3 py-2.5">
                <div className="mb-1.5 flex items-center gap-1.5">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">injected · {PLATFORMS[id].syntax}</span>
                  <span className="ml-auto mono text-[10px] text-slate-500">{tr?.tokens} tok</span>
                </div>
                <pre className="thin-scroll mono max-h-[128px] overflow-y-auto text-[10.5px] leading-[1.6] whitespace-pre-wrap break-words text-slate-400">
                  {tr?.text}
                </pre>
              </div>

              {/* response */}
              <div className="min-h-[190px] flex-1 px-3 py-3">
                {!pane || pane.status === "idle" ? (
                  <div className="flex h-full min-h-[150px] items-center justify-center rounded-lg border border-dashed border-white/10 text-[11.5px] text-slate-600">
                    Awaiting broadcast
                  </div>
                ) : pane.status === "queued" || pane.status === "thinking" ? (
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center gap-2 text-[11.5px] text-slate-400">
                      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-amber-400" />
                      {pane.status === "queued" ? "Queued" : "Model is reasoning…"}
                    </div>
                    {[92, 78, 86, 64, 88].map((w, i) => (
                      <div key={i} className="h-2 rounded bg-white/[0.07]" style={{ width: w + "%" }} />
                    ))}
                  </div>
                ) : (
                  <pre
                    className={cn(
                      "mono text-[11px] leading-[1.65] whitespace-pre-wrap break-words text-slate-300",
                      pane.status === "streaming" && "caret",
                    )}
                  >
                    {visible}
                  </pre>
                )}
              </div>

              {/* rating */}
              <div className="flex items-center gap-2 border-t border-white/10 bg-black/20 px-3 py-2.5">
                <span className="text-[10.5px] uppercase tracking-wider text-slate-500">
                  {pane?.status === "done" ? "Rate result" : "Rating"}
                </span>
                <div className="ml-auto flex gap-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button
                      key={s}
                      disabled={pane?.status !== "done"}
                      onClick={() => rate(id, s)}
                      className={cn(
                        "h-6 w-6 rounded-md text-[12px] transition",
                        pane?.rated && pane.rated >= s ? "bg-amber-400/20 text-amber-300" : "text-slate-600 hover:text-slate-300",
                        pane?.status !== "done" && "cursor-not-allowed opacity-40",
                      )}
                    >
                      ★
                    </button>
                  ))}
                </div>
                {pane?.rated && (
                  <span className="mono text-[10.5px]" style={{ color: scoreColor(60 + pane.rated * 8) }}>
                    {pane.rated}.0
                  </span>
                )}
              </div>
            </Panel>
          );
        })}
      </div>

      {active.length === 0 && (
        <div className="rounded-2xl border border-dashed border-white/10 px-4 py-10 text-center text-[13px] text-slate-500">
          Select at least one platform to connect a tab.
        </div>
      )}
    </div>
  );
}

const PLATFORM_LATENCY: Record<PlatformId, number> = {
  claude: 1150,
  chatgpt: 780,
  gemini: 950,
  deepseek: 1750,
  llama: 2100,
  perplexity: 640,
};

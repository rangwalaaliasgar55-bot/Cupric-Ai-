import { useEffect, useRef, useState } from "react";
import { cn } from "@/utils/cn";
import { PLATFORMS, type PlatformId } from "@/lib/engine";

export function Panel({ className, children, ...rest }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      {...rest}
      className={cn(
        "rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-sm",
        "shadow-[0_1px_0_0_rgba(255,255,255,0.05)_inset,0_24px_60px_-30px_rgba(0,0,0,0.9)]",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function Badge({
  children,
  tone = "slate",
  className,
}: {
  children: React.ReactNode;
  tone?: "slate" | "indigo" | "emerald" | "amber" | "rose" | "cyan";
  className?: string;
}) {
  const tones: Record<string, string> = {
    slate: "bg-white/[0.06] text-slate-300 border-white/10",
    indigo: "bg-indigo-500/15 text-indigo-200 border-indigo-400/25",
    emerald: "bg-emerald-500/15 text-emerald-200 border-emerald-400/25",
    amber: "bg-amber-500/15 text-amber-200 border-amber-400/25",
    rose: "bg-rose-500/15 text-rose-200 border-rose-400/25",
    cyan: "bg-cyan-500/15 text-cyan-200 border-cyan-400/25",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium tracking-wide",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function PlatformDot({ id, size = 8 }: { id: PlatformId; size?: number }) {
  return (
    <span
      className="inline-block shrink-0 rounded-full"
      style={{ width: size, height: size, background: PLATFORMS[id].color, boxShadow: `0 0 10px ${PLATFORMS[id].color}90` }}
    />
  );
}

export function PlatformChip({
  id,
  active,
  onClick,
  score,
}: {
  id: PlatformId;
  active?: boolean;
  onClick?: () => void;
  score?: number;
}) {
  const p = PLATFORMS[id];
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "group flex items-center gap-2 rounded-xl border px-3 py-2 text-left transition-all duration-200",
        active
          ? "border-white/25 bg-white/[0.08] shadow-[0_0_0_1px_rgba(255,255,255,0.06)]"
          : "border-white/10 bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.05]",
      )}
    >
      <PlatformDot id={id} size={9} />
      <span className="text-[13px] font-medium text-slate-200">{p.short}</span>
      {typeof score === "number" && (
        <span
          className="ml-auto text-[11px] font-semibold tabular-nums"
          style={{ color: scoreColor(score) }}
        >
          {score}
        </span>
      )}
    </button>
  );
}

export function scoreColor(score: number) {
  if (score >= 90) return "#34d399";
  if (score >= 75) return "#a3e635";
  if (score >= 55) return "#fbbf24";
  if (score >= 35) return "#fb923c";
  return "#f87171";
}

export function Toggle({
  checked,
  onChange,
  label,
  hint,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  hint?: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex w-full items-start gap-3 rounded-xl border border-white/10 bg-white/[0.02] px-3 py-2.5 text-left transition hover:border-white/20 hover:bg-white/[0.05]"
    >
      <span
        className={cn(
          "mt-0.5 flex h-5 w-9 shrink-0 items-center rounded-full p-0.5 transition-colors",
          checked ? "bg-indigo-500" : "bg-white/15",
        )}
      >
        <span
          className={cn(
            "h-4 w-4 rounded-full bg-white shadow transition-transform",
            checked ? "translate-x-4" : "translate-x-0",
          )}
        />
      </span>
      <span className="min-w-0">
        <span className="block text-[13px] font-medium text-slate-200">{label}</span>
        {hint && <span className="block text-[11px] leading-snug text-slate-500">{hint}</span>}
      </span>
    </button>
  );
}

export function CopyButton({
  value,
  label = "Copy",
  className,
}: {
  value: string;
  label?: string;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);
  const timer = useRef<number | undefined>(undefined);
  useEffect(() => () => window.clearTimeout(timer.current), []);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
        } catch {
          const ta = document.createElement("textarea");
          ta.value = value;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand("copy");
          ta.remove();
        }
        setCopied(true);
        timer.current = window.setTimeout(() => setCopied(false), 1600);
      }}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-2.5 py-1.5 text-[11px] font-medium text-slate-300 transition hover:border-white/25 hover:bg-white/[0.09] hover:text-white",
        copied && "border-emerald-400/40 text-emerald-300",
        className,
      )}
    >
      {copied ? "✓ Copied" : label}
    </button>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  blurb,
  id,
}: {
  eyebrow: string;
  title: React.ReactNode;
  blurb?: React.ReactNode;
  id?: string;
}) {
  return (
    <div id={id} className="scroll-mt-24 max-w-3xl">
      <div className="mb-3 flex items-center gap-3">
        <span className="h-px w-8 bg-gradient-to-r from-indigo-400 to-transparent" />
        <span className="text-[11px] font-semibold uppercase tracking-[0.22em] text-indigo-300/80">{eyebrow}</span>
      </div>
      <h2 className="text-balance text-3xl font-bold tracking-tight text-white sm:text-4xl">{title}</h2>
      {blurb && <p className="mt-3 text-[15px] leading-relaxed text-slate-400">{blurb}</p>}
    </div>
  );
}

/** Very light "syntax" tinting for prompt previews — cheap but readable. */
export function highlightPrompt(text: string): React.ReactNode[] {
  return text.split("\n").map((line, i) => {
    let cls = "text-slate-300";
    if (/^<[/]?[a-z_]+>$/.test(line.trim())) cls = "text-orange-300 font-medium";
    else if (/^###/.test(line.trim())) cls = "text-amber-300 font-medium";
    else if (/^##\s/.test(line.trim())) cls = "text-indigo-300 font-semibold";
    else if (/^\s*[-*]\s/.test(line)) cls = "text-slate-400";
    else if (/^\s*\d+\.\s/.test(line)) cls = "text-cyan-300/90";
    else if (/^(###|HARD RULES|SELF-CHECK|Be direct|Output:|Constraints:|Background:|Task:|Search guidance:)/i.test(line.trim()))
      cls = "text-indigo-300 font-medium";
    else if (/^\s*```/.test(line)) cls = "text-emerald-300";
    return (
      <div key={i} className={cn("whitespace-pre-wrap break-words", cls)}>
        {line || "\u00A0"}
      </div>
    );
  });
}

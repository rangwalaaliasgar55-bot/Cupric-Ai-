import { useMemo, useState } from "react";
import { cn } from "@/utils/cn";
import {
  DEFAULT_OPTIONS,
  PLATFORMS,
  PLATFORM_LIST,
  SAMPLE_PROMPTS,
  TYPE_EMOJI,
  TYPE_LABEL,
  compatScore,
  parsePrompt,
  translate,
  type PlatformId,
  type PromptType,
  type TranslateOptions,
} from "@/lib/engine";
import { Badge, CopyButton, Panel, PlatformDot, Toggle, highlightPrompt, scoreColor } from "./ui";

const SAMPLE_TYPES: PromptType[] = ["coding", "analysis", "creative", "reasoning", "research"];

export default function Translator({
  prompt,
  setPrompt,
  onSend,
}: {
  prompt: string;
  setPrompt: (v: string) => void;
  onSend?: (prompt: string) => void;
}) {
  const [target, setTarget] = useState<PlatformId>("claude");
  const [opts, setOpts] = useState<TranslateOptions>(DEFAULT_OPTIONS);
  const [showNotes, setShowNotes] = useState(true);

  const parsed = useMemo(() => parsePrompt(prompt), [prompt]);
  const scores = useMemo(() => {
    const map = {} as Record<PlatformId, number>;
    PLATFORM_LIST.forEach((p) => {
      map[p.id] = compatScore(parsed, p.id, prompt).score;
    });
    return map;
  }, [parsed, prompt]);

  const lint = useMemo(() => compatScore(parsed, target, prompt).findings, [parsed, target, prompt]);
  const result = useMemo(() => translate(prompt, target, opts), [prompt, target, opts]);
  const platform = PLATFORMS[target];

  return (
    <div className="grid gap-5 lg:grid-cols-[minmax(0,0.95fr)_minmax(0,1.05fr)]">
      {/* ---------------- source ---------------- */}
      <Panel className="flex flex-col overflow-hidden">
        <div className="flex flex-wrap items-center gap-2 border-b border-white/10 px-4 py-3">
          <span className="text-[13px] font-semibold text-white">Source prompt</span>
          <Badge tone="slate">universal</Badge>
          <div className="ml-auto flex flex-wrap items-center gap-1.5">
            {SAMPLE_TYPES.map((t) => (
              <button
                key={t}
                onClick={() => setPrompt(SAMPLE_PROMPTS[t])}
                className={cn(
                  "rounded-lg border px-2 py-1 text-[10.5px] font-medium transition",
                  prompt === SAMPLE_PROMPTS[t]
                    ? "border-indigo-400/40 bg-indigo-500/15 text-indigo-200"
                    : "border-white/10 bg-white/[0.02] text-slate-400 hover:border-white/25 hover:text-slate-200",
                )}
              >
                {TYPE_EMOJI[t]} {TYPE_LABEL[t]}
              </button>
            ))}
          </div>
        </div>

        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          spellCheck={false}
          placeholder="Paste the prompt that already works in your usual chatbot…"
          className="thin-scroll min-h-[300px] flex-1 resize-none bg-transparent px-4 py-4 text-[13.5px] leading-relaxed text-slate-200 outline-none placeholder:text-slate-600"
        />

        <div className="flex flex-wrap items-center gap-2 border-t border-white/10 px-4 py-3 text-[11px] text-slate-400">
          <Badge tone="indigo">
            {TYPE_EMOJI[parsed.type]} {TYPE_LABEL[parsed.type]}
          </Badge>
          <Badge tone="slate">{parsed.tokens} tok</Badge>
          <Badge tone="slate">{parsed.constraints.length} rules</Badge>
          {parsed.role && <Badge tone="emerald">role detected</Badge>}
          {parsed.examples.length > 0 && <Badge tone="cyan">{parsed.examples.length} example lines</Badge>}
          {parsed.coax.length > 0 && <Badge tone="rose">CoT instruction</Badge>}
        </div>

        <div className="grid gap-2 border-t border-white/10 bg-black/20 p-3 sm:grid-cols-2">
          <Toggle
            checked={opts.strictOutput}
            onChange={(v) => setOpts({ ...opts, strictOutput: v })}
            label="Output contract"
            hint="Generate a type-aware format spec when none exists"
          />
          <Toggle
            checked={opts.fewShot}
            onChange={(v) => setOpts({ ...opts, fewShot: v })}
            label="Few-shot injection"
            hint="Add a worked example if the prompt has none"
          />
          <Toggle
            checked={opts.cot}
            onChange={(v) => setOpts({ ...opts, cot: v })}
            label="Reasoning routing"
            hint="Private thinking for Claude, internal-only for R1"
          />
          <Toggle
            checked={opts.keepExamples}
            onChange={(v) => setOpts({ ...opts, keepExamples: v })}
            label="Preserve examples"
            hint="Keep user examples verbatim inside the target structure"
          />
        </div>
      </Panel>

      {/* ---------------- target ---------------- */}
      <Panel className="flex flex-col overflow-hidden">
        <div className="border-b border-white/10 px-4 py-3">
          <div className="mb-2.5 flex items-center gap-2">
            <span className="text-[13px] font-semibold text-white">Target dialect</span>
            <span className="text-[11px] text-slate-500">compat score of your raw prompt, per model</span>
          </div>
          <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-6">
            {PLATFORM_LIST.map((p) => (
              <button
                key={p.id}
                onClick={() => setTarget(p.id)}
                className={cn(
                  "relative flex flex-col items-center gap-1 rounded-xl border px-1.5 py-2 transition-all",
                  target === p.id
                    ? "border-white/25 bg-white/[0.08]"
                    : "border-white/10 bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.05]",
                )}
              >
                <PlatformDot id={p.id} size={8} />
                <span className="text-[11px] font-medium text-slate-300">{p.short}</span>
                <span className="text-[11px] font-bold tabular-nums" style={{ color: scoreColor(scores[p.id]) }}>
                  {scores[p.id]}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 border-b border-white/10 px-4 py-3">
          <div className="flex items-center gap-2">
            <PlatformDot id={target} size={9} />
            <span className="text-[13px] font-semibold text-white">{platform.name}</span>
          </div>
          <Badge tone="slate">{platform.syntax}</Badge>
          <div className="ml-auto flex items-center gap-2">
            <CopyButton value={result.text} label={"Copy for " + platform.short} />
            {onSend && (
              <button
                onClick={() => onSend(prompt)}
                className="rounded-lg bg-indigo-500 px-2.5 py-1.5 text-[11px] font-semibold text-white transition hover:bg-indigo-400"
              >
                Broadcast →
              </button>
            )}
          </div>
        </div>

        {/* score delta */}
        <div className="flex items-center gap-3 border-b border-white/10 px-4 py-3">
          <div className="flex-1">
            <div className="mb-1 flex justify-between text-[10.5px] uppercase tracking-wider text-slate-500">
              <span>raw</span>
              <span className="tabular-nums" style={{ color: scoreColor(result.before) }}>
                {result.before}
              </span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full transition-all duration-500" style={{ width: result.before + "%", background: scoreColor(result.before) }} />
            </div>
          </div>
          <span className="text-slate-500">→</span>
          <div className="flex-1">
            <div className="mb-1 flex justify-between text-[10.5px] uppercase tracking-wider text-slate-500">
              <span>translated</span>
              <span className="tabular-nums" style={{ color: scoreColor(result.after) }}>
                {result.after}
              </span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-indigo-400 to-cyan-300 transition-all duration-500"
                style={{ width: result.after + "%" }}
              />
            </div>
          </div>
          <Badge tone="emerald" className="shrink-0">
            +{Math.max(0, result.after - result.before)} pts
          </Badge>
        </div>

        {/* lint findings */}
        {lint.length > 0 && (
          <div className="space-y-2 border-b border-white/10 px-4 py-3">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
              What breaks on {platform.short}
              <span className="rounded bg-white/[0.06] px-1.5 py-0.5 text-[10px] font-medium normal-case tracking-normal text-slate-400">
                {lint.length} issue{lint.length > 1 ? "s" : ""}
              </span>
            </div>
            <div className="thin-scroll max-h-[132px] space-y-1.5 overflow-y-auto pr-1">
              {lint.map((f, i) => (
                <div key={i} className="flex gap-2.5 rounded-lg border border-white/[0.07] bg-white/[0.02] px-2.5 py-2">
                  <span
                    className={cn(
                      "mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full",
                      f.level === "critical" ? "bg-rose-400" : f.level === "warning" ? "bg-amber-400" : "bg-sky-400",
                    )}
                  />
                  <div className="min-w-0">
                    <div className="text-[12.5px] font-medium text-slate-200">{f.title}</div>
                    <div className="text-[11.5px] leading-snug text-slate-500">{f.detail}</div>
                  </div>
                  <span className="ml-auto shrink-0 self-start text-[10px] font-semibold text-rose-300/70">-{f.penalty}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* translated prompt */}
        <div className="flex items-center gap-2 px-4 pt-3 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
          Restructured prompt
          <span className="ml-auto font-mono text-[10.5px] normal-case tracking-normal text-slate-500">
            {result.tokens} tok · {result.text.split("\n").length} lines
          </span>
        </div>
        <div className="thin-scroll max-h-[320px] overflow-y-auto px-4 py-3">
          <pre className="mono text-[12px] leading-[1.65]">{highlightPrompt(result.text)}</pre>
        </div>

        <div className="mt-auto border-t border-white/10 bg-black/20 px-4 py-3">
          <button
            onClick={() => setShowNotes((s) => !s)}
            className="flex w-full items-center gap-2 text-left text-[11px] font-semibold uppercase tracking-wider text-slate-500 transition hover:text-slate-300"
          >
            Transform log
            <span className="rounded bg-white/[0.06] px-1.5 py-0.5 text-[10px] font-medium normal-case tracking-normal text-slate-400">
              {result.notes.length}
            </span>
            <span className={cn("ml-auto transition-transform", showNotes && "rotate-180")}>▾</span>
          </button>
          {showNotes && (
            <ul className="mt-2 space-y-1.5">
              {result.notes.map((n, i) => (
                <li key={i} className="flex gap-2 text-[12px] leading-snug text-slate-400">
                  <span className="text-indigo-400">▸</span>
                  {n}
                </li>
              ))}
            </ul>
          )}
        </div>
      </Panel>
    </div>
  );
}

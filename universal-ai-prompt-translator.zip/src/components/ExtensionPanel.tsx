import { useMemo, useState } from "react";
import { cn } from "@/utils/cn";
import { EXTENSION_FILES } from "@/extension/files";
import { createZip, downloadBlob } from "@/lib/zip";
import { Badge, CopyButton, Panel } from "./ui";

const ORDER = [
  "manifest.json",
  "translator-core.js",
  "content.js",
  "background.js",
  "popup.html",
  "popup.js",
  "popup.css",
  "options.html",
  "options.js",
  "README.md",
  "icons/README.txt",
];

const NOTES: Record<string, string> = {
  "manifest.json": "MV3 manifest · content-script matches for all six platforms · Ctrl+Shift+1 broadcast command",
  "translator-core.js": "The syntax optimization engine — parser, classifier, six renderers, compat scoring",
  "content.js": "Paste interception, composer fill, Ctrl+Enter broadcast trigger",
  "background.js": "Service worker: finds open AI tabs, translates per tab, injects on demand, logs history",
  "popup.html": "Dialect picker UI",
  "popup.js": "Compat score, live translation, broadcast button",
  "popup.css": "Dark popup styling",
  "options.html": "Analytics page",
  "options.js": "Leaderboard, category routing, JSON export",
  "README.md": "Install + transform reference",
  "icons/README.txt": "Icon drop-in note",
};

export default function ExtensionPanel() {
  const [file, setFile] = useState("translator-core.js");
  const [zipping, setZipping] = useState(false);
  const files = useMemo(
    () => ORDER.filter((f) => EXTENSION_FILES[f]).map((name) => ({ name, size: EXTENSION_FILES[name].length })),
    [],
  );
  const total = files.reduce((a, b) => a + b.size, 0);
  const content = EXTENSION_FILES[file] ?? "";

  const download = () => {
    setZipping(true);
    // let the button state paint before the (synchronous) zip work
    setTimeout(() => {
      const blob = createZip(EXTENSION_FILES);
      downloadBlob(blob, "promptbridge-extension.zip");
      setZipping(false);
    }, 60);
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]">
        {/* install card */}
        <Panel className="overflow-hidden">
          <div className="border-b border-white/10 px-4 py-3">
            <span className="text-[13px] font-semibold text-white">Install it in 40 seconds</span>
          </div>
          <ol className="space-y-3 px-4 py-4">
            {[
              <>Download the unpacked extension folder below.</>,
              <>Open <span className="mono rounded bg-white/[0.07] px-1.5 py-0.5 text-[11.5px] text-slate-300">chrome://extensions</span></>,
              <>Toggle <span className="font-medium text-slate-200">Developer mode</span> (top-right).</>,
              <>
                Click <span className="font-medium text-slate-200">Load unpacked</span> and select the unzipped{" "}
                <span className="mono text-[11.5px] text-slate-300">promptbridge/</span> folder.
              </>,
            ].map((step, i) => (
              <li key={i} className="flex gap-3">
                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-indigo-500/20 text-[11px] font-bold text-indigo-300">
                  {i + 1}
                </span>
                <span className="text-[13px] leading-relaxed text-slate-400">{step}</span>
              </li>
            ))}
          </ol>
          <div className="border-t border-white/10 px-4 py-4">
            <button
              onClick={download}
              disabled={zipping}
              className={cn(
                "group relative w-full overflow-hidden rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-3 text-[13.5px] font-semibold text-white transition hover:from-indigo-400 hover:to-violet-400",
                zipping && "shimmer",
              )}
            >
              {zipping ? "Packaging…" : "⬇ Download promptbridge-extension.zip"}
            </button>
            <p className="mt-2.5 text-[11.5px] leading-relaxed text-slate-500">
              {files.length} files · {(total / 1024).toFixed(1)} KB · MV3 · zero network calls. Everything runs locally in your
              browser; prompt history never leaves <span className="mono text-slate-400">chrome.storage.local</span>.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-2 border-t border-white/10 bg-black/20 p-3">
            {[
              ["storage", "options + your rating history"],
              ["tabs", "find your open AI tabs"],
              ["scripting", "fill the composer on demand"],
              ["clipboardWrite", "the copy button"],
            ].map(([perm, why]) => (
              <div key={perm} className="rounded-lg border border-white/[0.07] bg-white/[0.02] px-2.5 py-2">
                <div className="mono text-[11px] text-indigo-300">{perm}</div>
                <div className="text-[10.5px] leading-snug text-slate-500">{why}</div>
              </div>
            ))}
          </div>
        </Panel>

        {/* code browser */}
        <Panel className="flex min-h-[520px] flex-col overflow-hidden">
          <div className="flex flex-wrap items-center gap-2 border-b border-white/10 px-4 py-3">
            <span className="mono text-[12.5px] font-medium text-slate-200">promptbridge/{file}</span>
            <Badge tone="slate">{(content.length / 1024).toFixed(1)} KB</Badge>
            <Badge tone="indigo">{content.split("\n").length} lines</Badge>
            <div className="ml-auto flex gap-2">
              <CopyButton value={content} label="Copy file" />
            </div>
          </div>
          <div className="grid flex-1 grid-cols-[168px_minmax(0,1fr)]">
            <div className="thin-scroll max-h-[520px] overflow-y-auto border-r border-white/10 bg-black/25 py-2">
              {files.map((f) => (
                <button
                  key={f.name}
                  onClick={() => setFile(f.name)}
                  className={cn(
                    "block w-full px-3 py-1.5 text-left transition",
                    file === f.name ? "bg-white/[0.08]" : "hover:bg-white/[0.04]",
                  )}
                >
                  <span className={cn("mono block truncate text-[11.5px]", file === f.name ? "text-indigo-200" : "text-slate-400")}>
                    {f.name}
                  </span>
                  <span className="block truncate text-[9.5px] text-slate-600">{(f.size / 1024).toFixed(1)} KB</span>
                </button>
              ))}
            </div>
            <div className="flex min-w-0 flex-col">
              <div className="border-b border-white/10 px-3 py-2 text-[11px] leading-snug text-slate-500">{NOTES[file]}</div>
              <div className="thin-scroll max-h-[480px] flex-1 overflow-auto p-3">
                <pre className="mono text-[11px] leading-[1.6]">
                  {content.split("\n").map((line, i) => (
                    <div key={i} className="flex gap-3">
                      <span className="w-7 shrink-0 select-none text-right text-slate-700">{i + 1}</span>
                      <span className={cn("whitespace-pre-wrap break-words", tint(line))}>{line || "\u00A0"}</span>
                    </div>
                  ))}
                </pre>
              </div>
            </div>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function tint(line: string) {
  const t = line.trim();
  if (/^\/\*|^ \*/.test(t) || /^<!--/.test(t)) return "text-slate-600 italic";
  if (/^\s{2}".*":/.test(line) || /^":/.test(t)) return "text-indigo-300";
  if (/^(var|function|const|let|async|chrome|self\.|importScripts)/.test(t)) return "text-cyan-300/90";
  if (/^\s*(#|\.|body|button|header|footer|table|th|td|textarea|select|pre)/.test(t) && /[{}:]/.test(t)) return "text-amber-200/80";
  if (/^\|/.test(t) || /^#/.test(t)) return "text-slate-500";
  return "text-slate-300";
}

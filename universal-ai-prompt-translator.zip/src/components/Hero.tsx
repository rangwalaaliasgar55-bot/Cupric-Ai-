import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import { PLATFORMS, PLATFORM_LIST, SAMPLE_PROMPTS, compatScore, parsePrompt, translate, type PlatformId } from "@/lib/engine";
import { Badge, Panel, PlatformDot, scoreColor } from "./ui";

const CYCLE: PlatformId[] = ["claude", "chatgpt", "gemini", "deepseek", "perplexity", "llama"];

export default function Hero({ onDownload, onJump }: { onDownload: () => void; onJump: (id: string) => void }) {
  const [i, setI] = useState(0);
  const [typed, setTyped] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => setI((v) => (v + 1) % CYCLE.length), 3600);
    return () => window.clearInterval(id);
  }, []);

  const target = CYCLE[i];
  const parsed = parsePrompt(SAMPLE_PROMPTS.coding);
  const rawScore = compatScore(parsed, target, SAMPLE_PROMPTS.coding).score;
  const result = translate(SAMPLE_PROMPTS.coding, target, {
    fewShot: true,
    cot: true,
    strictOutput: true,
    keepExamples: true,
  });

  useEffect(() => {
    setTyped(0);
    let n = 0;
    const total = Math.min(result.text.length, 620);
    const timer = window.setInterval(() => {
      n += 14;
      setTyped(n);
      if (n >= total) window.clearInterval(timer);
    }, 16);
    return () => window.clearInterval(timer);
  }, [result.text]);

  return (
    <section className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 app-glow" />
      <div className="pointer-events-none absolute inset-0 app-grid opacity-60 [mask-image:radial-gradient(60rem_40rem_at_50%_0%,black,transparent)]" />

      <div className="relative mx-auto grid max-w-7xl gap-10 px-5 pb-16 pt-14 sm:pt-20 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:items-center lg:gap-8">
        <div className="fade-up">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-400" />
            </span>
            <span className="text-[11.5px] font-medium tracking-wide text-slate-300">Chrome extension · Manifest V3 · local-only</span>
          </div>

          <h1 className="text-balance text-4xl font-extrabold leading-[1.06] tracking-tight text-white sm:text-5xl lg:text-[3.4rem]">
            One prompt.
            <br />
            <span className="bg-gradient-to-r from-indigo-300 via-cyan-200 to-fuchsia-300 bg-clip-text text-transparent">
              Every model's native syntax.
            </span>
          </h1>

          <p className="mt-5 max-w-xl text-[15.5px] leading-relaxed text-slate-400">
            PromptBridge restructures your prompt the moment it touches a new chatbot — XML tags for Claude, recency-ordered hard
            rules for Gemini, flat text for DeepSeek R1. Then <span className="text-slate-200">Ctrl + Enter</span> broadcasts it to
            every open AI tab at once, tailored per tab. No more rewriting, no more silent format drift.
          </p>

          <div className="mt-7 flex flex-wrap items-center gap-3">
            <button
              onClick={onDownload}
              className="group relative overflow-hidden rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-5 py-3 text-[14px] font-semibold text-white shadow-[0_18px_40px_-18px_rgba(99,102,241,0.9)] transition hover:from-indigo-400 hover:to-violet-400"
            >
              ⬇ Download the extension
            </button>
            <button
              onClick={() => onJump("translate")}
              className="rounded-xl border border-white/15 bg-white/[0.04] px-5 py-3 text-[14px] font-semibold text-slate-200 transition hover:border-white/30 hover:bg-white/[0.08]"
            >
              Try the engine live →
            </button>
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-x-5 gap-y-3">
            <div className="flex items-center gap-2">
              {PLATFORM_LIST.map((p) => (
                <span key={p.id} title={p.name} className="transition hover:scale-125">
                  <PlatformDot id={p.id} size={9} />
                </span>
              ))}
              <span className="ml-1 text-[11.5px] text-slate-500">6 platforms</span>
            </div>
            <span className="h-4 w-px bg-white/10" />
            <span className="text-[11.5px] text-slate-500">No account · no network calls · history stays on device</span>
          </div>
        </div>

        {/* live demo */}
        <Panel className="fade-up relative overflow-hidden">
          <div className="flex items-center gap-2 border-b border-white/10 bg-black/30 px-4 py-2.5">
            <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Live translation</span>
            <div className="ml-auto flex gap-1">
              {CYCLE.map((id, idx) => (
                <span
                  key={id}
                  className={cn("h-1.5 w-1.5 rounded-full transition-all", idx === i ? "w-4 bg-indigo-400" : "bg-white/15")}
                />
              ))}
            </div>
          </div>

          <div className="grid gap-0 sm:grid-cols-2">
            <div className="border-b border-white/10 p-4 sm:border-b-0 sm:border-r">
              <div className="mb-2 flex items-center gap-2">
                <Badge tone="rose">raw prompt</Badge>
                <span className="mono ml-auto text-[10.5px]" style={{ color: scoreColor(rawScore) }}>
                  {rawScore}/100
                </span>
              </div>
              <pre className="thin-scroll mono max-h-[300px] overflow-hidden text-[10.5px] leading-[1.6] whitespace-pre-wrap break-words text-slate-500">
                {SAMPLE_PROMPTS.coding}
              </pre>
            </div>
            <div className="relative p-4">
              <div className="mb-2 flex items-center gap-2">
                <PlatformDot id={target} size={9} />
                <span className="text-[12px] font-semibold text-white">{PLATFORMS[target].name}</span>
                <span className="mono ml-auto text-[10.5px] text-emerald-300">99/100</span>
              </div>
              <pre className="thin-scroll mono max-h-[300px] overflow-hidden text-[10.5px] leading-[1.6] whitespace-pre-wrap break-words text-slate-300">
                {result.text.slice(0, typed)}
                {typed < result.text.length && typed >= 620 ? "…" : ""}
              </pre>
              <div className="absolute bottom-3 left-4 right-4 flex items-center gap-2 border-t border-white/[0.08] pt-2">
                <span className="truncate text-[10.5px] text-slate-500">{PLATFORMS[target].syntax}</span>
                <span className="mono ml-auto shrink-0 text-[10.5px] text-slate-500">+{99 - rawScore} pts</span>
              </div>
            </div>
          </div>

          <div className="absolute -right-8 -top-8 h-28 w-28 rounded-full bg-indigo-500/20 blur-2xl" />
        </Panel>
      </div>

      {/* marquee of quirks */}
      <div className="relative border-y border-white/[0.07] bg-black/40 py-2.5">
        <div className="flex w-max marquee gap-8 whitespace-nowrap px-4">
          {[...PLATFORM_LIST, ...PLATFORM_LIST, ...PLATFORM_LIST].map((p, i) => (
            <span key={i} className="flex items-center gap-2 text-[11.5px] text-slate-500">
              <PlatformDot id={p.id} size={6} />
              <span className="font-medium text-slate-400">{p.short}</span>
              <span className="text-slate-600">{p.quirk}</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

import { useMemo, useState } from "react";
import { cn } from "@/utils/cn";
import { PLATFORMS, TYPE_EMOJI, TYPE_LABEL, type PromptType } from "@/lib/engine";
import { clearRuns, leaderboard, recommendation, resetRuns, trendSeries, typeMatrix, useRuns } from "@/lib/store";
import { Badge, Panel, PlatformDot } from "./ui";

function scoreTint(v: number) {
  // 1..5 → color
  const t = Math.max(0, Math.min(1, (v - 2.8) / 2));
  const r = Math.round(248 - t * 130);
  const g = Math.round(113 + t * 100);
  const b = Math.round(113 - t * 20);
  return `rgba(${r},${g},${b},${0.12 + t * 0.55})`;
}

function Sparkline({ series }: { series: { avg: number; label: string; n: number }[] }) {
  const w = 560;
  const h = 120;
  const pts = series.map((s, i) => {
    const x = (i / Math.max(1, series.length - 1)) * (w - 8) + 4;
    const y = h - ((s.avg - 2.5) / 2.5) * (h - 16) - 8;
    return { x, y: Number.isFinite(y) ? y : h - 8, avg: s.avg, label: s.label, n: s.n };
  });
  const line = pts.map((p, i) => (i === 0 ? `M${p.x},${p.y}` : `L${p.x},${p.y}`)).join(" ");
  const area = `${line} L${pts[pts.length - 1]?.x ?? 0},${h} L${pts[0]?.x ?? 0},${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-32 w-full" preserveAspectRatio="none">
      <defs>
        <linearGradient id="sparkFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#818cf8" stopOpacity="0.42" />
          <stop offset="100%" stopColor="#818cf8" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0, 1, 2, 3].map((i) => (
        <line key={i} x1="0" x2={w} y1={16 + i * 28} y2={16 + i * 28} stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
      ))}
      <path d={area} fill="url(#sparkFill)" />
      <path d={line} fill="none" stroke="#a5b4fc" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
      {pts.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={p.n ? 2.6 : 0} fill="#c7d2fe" />
      ))}
    </svg>
  );
}

function Donut({ data }: { data: { type: PromptType; n: number }[] }) {
  const total = data.reduce((a, b) => a + b.n, 0) || 1;
  const colors: Record<PromptType, string> = {
    coding: "#818cf8",
    analysis: "#22d3ee",
    creative: "#f472b6",
    reasoning: "#fbbf24",
    research: "#34d399",
    general: "#94a3b8",
  };
  let acc = 0;
  const r = 54;
  const c = 2 * Math.PI * r;
  return (
    <div className="flex items-center gap-5">
      <svg viewBox="0 0 140 140" className="h-36 w-36 shrink-0 -rotate-90">
        <circle cx="70" cy="70" r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="16" />
        {data.map((d) => {
          const frac = d.n / total;
          const dash = `${frac * c} ${c - frac * c}`;
          const offset = -acc * c;
          acc += frac;
          return (
            <circle
              key={d.type}
              cx="70"
              cy="70"
              r={r}
              fill="none"
              stroke={colors[d.type]}
              strokeWidth="16"
              strokeDasharray={dash}
              strokeDashoffset={offset}
              strokeLinecap="butt"
            />
          );
        })}
      </svg>
      <div className="grid flex-1 grid-cols-2 gap-x-4 gap-y-1.5">
        {data.map((d) => (
          <div key={d.type} className="flex items-center gap-2 text-[11.5px]">
            <span className="h-2 w-2 rounded-sm" style={{ background: colors[d.type] }} />
            <span className="text-slate-400">{TYPE_LABEL[d.type]}</span>
            <span className="ml-auto mono tabular-nums text-slate-500">{Math.round((d.n / total) * 100)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Analytics() {
  const runs = useRuns();
  const [range, setRange] = useState(14);
  const [focus, setFocus] = useState<PromptType | "all">("all");

  const stats = useMemo(() => leaderboard(runs), [runs]);
  const matrix = useMemo(() => typeMatrix(runs), [runs]);
  const trend = useMemo(() => trendSeries(runs, range), [runs, range]);
  const groups = useMemo(() => new Set(runs.map((r) => r.group)).size, [runs]);

  const filtered = focus === "all" ? runs : runs.filter((r) => r.type === focus);
  const focusStats = useMemo(() => leaderboard(filtered), [filtered]);
  const top = focusStats[0];

  const typeCounts = useMemo(() => {
    const types: PromptType[] = ["coding", "analysis", "creative", "reasoning", "research", "general"];
    return types
      .map((type) => ({ type, n: runs.filter((r) => r.type === type).length }))
      .filter((d) => d.n > 0)
      .sort((a, b) => b.n - a.n);
  }, [runs]);

  const recent = runs.slice(0, 8);
  const avg = runs.length ? runs.reduce((a, b) => a + b.score, 0) / runs.length : 0;

  if (!runs.length) {
    return (
      <Panel className="px-6 py-16 text-center">
        <div className="text-4xl">📉</div>
        <h3 className="mt-3 text-lg font-semibold text-white">No history yet</h3>
        <p className="mx-auto mt-1 max-w-md text-[13.5px] text-slate-400">
          Broadcast a prompt in the Orchestrator and rate each model's answer. PromptBridge turns those ratings into a personal
          leaderboard.
        </p>
        <button
          onClick={resetRuns}
          className="mt-5 rounded-xl border border-white/15 bg-white/[0.05] px-4 py-2 text-[13px] font-medium text-slate-200 transition hover:bg-white/[0.1]"
        >
          Load 4 weeks of sample history
        </button>
      </Panel>
    );
  }

  return (
    <div className="space-y-4">
      {/* stat strip */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Prompt runs logged", value: runs.length, sub: `${groups} broadcasts` },
          { label: "Models compared", value: stats.length, sub: "across 6 platforms" },
          { label: "Mean answer score", value: avg.toFixed(2), sub: "out of 5.0" },
          {
            label: "Current champion",
            value: top ? PLATFORMS[top.model].short : "—",
            sub: top ? `${top.avg.toFixed(2)} avg · ${(top.winRate * 100).toFixed(0)}% win rate` : "",
          },
        ].map((s) => (
          <Panel key={s.label} className="px-4 py-3.5">
            <div className="text-[10.5px] font-semibold uppercase tracking-[0.16em] text-slate-500">{s.label}</div>
            <div className="mt-1.5 text-2xl font-bold tracking-tight text-white">{s.value}</div>
            <div className="mt-0.5 text-[11.5px] text-slate-500">{s.sub}</div>
          </Panel>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]">
        {/* trend */}
        <Panel className="overflow-hidden">
          <div className="flex flex-wrap items-center gap-2 border-b border-white/10 px-4 py-3">
            <span className="text-[13px] font-semibold text-white">Your answer quality over time</span>
            <div className="ml-auto flex gap-1">
              {[7, 14, 28].map((d) => (
                <button
                  key={d}
                  onClick={() => setRange(d)}
                  className={cn(
                    "rounded-lg border px-2 py-1 text-[10.5px] font-medium transition",
                    range === d ? "border-indigo-400/40 bg-indigo-500/15 text-indigo-200" : "border-white/10 text-slate-400 hover:text-slate-200",
                  )}
                >
                  {d}d
                </button>
              ))}
            </div>
          </div>
          <div className="px-4 pb-2 pt-4">
            <Sparkline series={trend} />
          </div>
          <div className="flex justify-between px-4 pb-3 text-[10px] text-slate-600">
            <span>{trend[0]?.label}</span>
            <span>{trend[Math.floor(trend.length / 2)]?.label}</span>
            <span>today</span>
          </div>
          <div className="border-t border-white/10 px-4 py-3 text-[11.5px] leading-relaxed text-slate-400">
            Scores from every broadcast you rated. The lift after day 10 is the compounding effect of model-specific syntax — the
            same prompt, restructured per target.
          </div>
        </Panel>

        {/* leaderboard */}
        <Panel className="overflow-hidden">
          <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
            <span className="text-[13px] font-semibold text-white">Model leaderboard</span>
            <div className="ml-auto flex gap-1">
              {(["all", "coding", "creative", "analysis"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFocus(f)}
                  className={cn(
                    "rounded-lg border px-2 py-1 text-[10.5px] font-medium capitalize transition",
                    focus === f ? "border-indigo-400/40 bg-indigo-500/15 text-indigo-200" : "border-white/10 text-slate-400 hover:text-slate-200",
                  )}
                >
                  {f === "all" ? "all" : f}
                </button>
              ))}
            </div>
          </div>
          <div className="divide-y divide-white/[0.06]">
            {focusStats.map((s, i) => (
              <div key={s.model} className="flex items-center gap-3 px-4 py-2.5">
                <span className="w-4 text-[11px] font-bold text-slate-600">{i + 1}</span>
                <PlatformDot id={s.model} size={8} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline gap-2">
                    <span className="truncate text-[13px] font-medium text-slate-200">{PLATFORMS[s.model].short}</span>
                    <span className="mono text-[10.5px] text-slate-500">{s.runs} runs</span>
                  </div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{ width: (s.avg / 5) * 100 + "%", background: PLATFORMS[s.model].color }}
                    />
                  </div>
                </div>
                <div className="text-right">
                  <div className="mono text-[13px] font-bold tabular-nums text-white">{s.avg.toFixed(2)}</div>
                  <div className="text-[10px] text-slate-500">{(s.winRate * 100).toFixed(0)}% wins</div>
                </div>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      {/* matrix */}
      <Panel className="overflow-hidden">
        <div className="flex flex-wrap items-center gap-2 border-b border-white/10 px-4 py-3">
          <span className="text-[13px] font-semibold text-white">Which model wins at which job</span>
          <Badge tone="slate">mean rating per prompt category</Badge>
        </div>
        <div className="overflow-x-auto thin-scroll">
          <table className="w-full min-w-[640px] border-collapse text-[12px]">
            <thead>
              <tr className="border-b border-white/[0.08] text-[10.5px] uppercase tracking-wider text-slate-500">
                <th className="px-4 py-2 text-left font-semibold">Model</th>
                {matrix.types.map((t) => (
                  <th key={t} className="px-2 py-2 text-center font-semibold">
                    {TYPE_EMOJI[t]} {TYPE_LABEL[t]}
                  </th>
                ))}
                <th className="px-4 py-2 text-right font-semibold">Best at</th>
              </tr>
            </thead>
            <tbody>
              {matrix.matrix.map((row) => {
                const maxCell = Math.max(...row.cells.filter((c) => c.n).map((c) => c.avg), 0);
                return (
                  <tr key={row.model} className="border-b border-white/[0.05] last:border-0">
                    <td className="whitespace-nowrap px-4 py-2">
                      <span className="flex items-center gap-2">
                        <PlatformDot id={row.model} size={7} />
                        <span className="font-medium text-slate-200">{PLATFORMS[row.model].short}</span>
                      </span>
                    </td>
                    {row.cells.map((c) => (
                      <td key={c.type} className="px-1.5 py-2 text-center">
                        <span
                          className="mono inline-block min-w-[46px] rounded-md px-1.5 py-1 text-[11.5px] font-semibold tabular-nums"
                          style={{
                            background: c.n ? scoreTint(c.avg) : "rgba(255,255,255,0.03)",
                            color: c.n ? (c.avg >= maxCell ? "#fff" : "#cbd5e1") : "#475569",
                            outline: c.n && c.avg >= maxCell ? "1px solid rgba(255,255,255,0.22)" : "none",
                          }}
                        >
                          {c.n ? c.avg.toFixed(1) : "–"}
                        </span>
                      </td>
                    ))}
                    <td className="whitespace-nowrap px-4 py-2 text-right text-[11.5px] text-slate-400">
                      {TYPE_EMOJI[stats.find((s) => s.model === row.model)?.bestType ?? "general"]}{" "}
                      {TYPE_LABEL[stats.find((s) => s.model === row.model)?.bestType ?? "general"]}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Panel>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]">
        {/* donut */}
        <Panel className="overflow-hidden">
          <div className="border-b border-white/10 px-4 py-3">
            <span className="text-[13px] font-semibold text-white">Prompt mix</span>
          </div>
          <div className="px-4 py-5">
            <Donut data={typeCounts} />
          </div>
        </Panel>

        {/* recommendations */}
        <Panel className="overflow-hidden">
          <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
            <span className="text-[13px] font-semibold text-white">Routing recommendations</span>
            <Badge tone="indigo">learned from your ratings</Badge>
          </div>
          <div className="grid gap-2 p-3 sm:grid-cols-2">
            {(["coding", "creative", "analysis", "reasoning", "research", "general"] as PromptType[]).map((t) => {
              const rec = recommendation(runs, t);
              const n = runs.filter((r) => r.type === t).length;
              return (
                <div key={t} className="rounded-xl border border-white/[0.08] bg-white/[0.02] px-3 py-2.5">
                  <div className="flex items-center gap-2 text-[12px] font-medium text-slate-200">
                    {TYPE_EMOJI[t]} {TYPE_LABEL[t]}
                    {rec && <PlatformDot id={rec.model} size={7} />}
                    <span className="ml-auto mono text-[10.5px] text-slate-500">{n} runs</span>
                  </div>
                  {rec ? (
                    <div className="mt-1 text-[11.5px] leading-snug text-slate-400">
                      Route to <span className="font-semibold text-slate-200">{PLATFORMS[rec.model].short}</span> —{" "}
                      <span className="mono text-emerald-300">{rec.avg.toFixed(2)}</span> avg,{" "}
                      <span className="mono text-slate-300">+{rec.margin.toFixed(2)}</span> over the runner-up.
                    </div>
                  ) : (
                    <div className="mt-1 text-[11.5px] text-slate-500">Needs a few more rated runs before routing.</div>
                  )}
                </div>
              );
            })}
          </div>
        </Panel>
      </div>

      {/* recent */}
      <Panel className="overflow-hidden">
        <div className="flex flex-wrap items-center gap-2 border-b border-white/10 px-4 py-3">
          <span className="text-[13px] font-semibold text-white">Recent activity</span>
          <div className="ml-auto flex gap-2">
            <button
              onClick={resetRuns}
              className="rounded-lg border border-white/10 bg-white/[0.03] px-2.5 py-1 text-[10.5px] text-slate-400 transition hover:text-slate-200"
            >
              Reset sample data
            </button>
            <button
              onClick={clearRuns}
              className="rounded-lg border border-rose-400/20 bg-rose-500/10 px-2.5 py-1 text-[10.5px] text-rose-300 transition hover:bg-rose-500/20"
            >
              Clear history
            </button>
          </div>
        </div>
        <div className="divide-y divide-white/[0.05]">
          {recent.map((r) => (
            <div key={r.id} className="flex flex-wrap items-center gap-3 px-4 py-2.5 text-[12px]">
              <PlatformDot id={r.model} size={7} />
              <span className="font-medium text-slate-300">{PLATFORMS[r.model].short}</span>
              <span className="min-w-0 flex-1 truncate text-slate-400">{r.title}</span>
              <Badge tone="slate">
                {TYPE_EMOJI[r.type]} {TYPE_LABEL[r.type]}
              </Badge>
              <span className="mono text-[10.5px] text-slate-600">{(r.latency / 1000).toFixed(1)}s</span>
              <span className="mono flex gap-0.5">
                {[1, 2, 3, 4, 5].map((s) => (
                  <span key={s} className={s <= r.score ? "text-amber-300" : "text-slate-700"}>
                    ★
                  </span>
                ))}
              </span>
              <span className="mono w-14 text-right text-[10.5px] text-slate-600">
                {new Date(r.ts).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
              </span>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

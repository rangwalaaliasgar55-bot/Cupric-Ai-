import { useEffect, useRef, useState } from 'react';
import { Canvas, useThree } from '@react-three/fiber';
import gsap from 'gsap';
import * as THREE from 'three';
import { ParticleField, LineLayer } from './components/Scene3D';
import { CupricLogo } from './components/CupricLogo';

// Camera controller that GSAP can drive
function CameraController({
  camRef,
}: {
  camRef: React.MutableRefObject<{
    position: THREE.Vector3;
    lookAt: THREE.Vector3;
    fov: number;
  } | null>;
}) {
  const { camera } = useThree();
  const target = useRef(new THREE.Vector3(0, 0, 0));

  useEffect(() => {
    camRef.current = {
      position: camera.position,
      lookAt: target.current,
      fov: 50,
    };
  }, [camera, camRef]);

  // Update every frame
  useEffect(() => {
    let raf: number;
    const loop = () => {
      camera.lookAt(target.current);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [camera]);

  return null;
}

// Main Film component
export default function App() {
  const particleUniformsRef = useRef<{
    uTime: { value: number };
    uMode: { value: number };
    uProgress: { value: number };
    uGlobalTime: { value: number };
    uExplode: { value: number };
    uScale: { value: number };
    uPointSize: { value: number };
    uCameraPos: { value: THREE.Vector3 };
  } | null>(null);

  const lineUniformsRef = useRef<{
    uTime: { value: number };
    uMode: { value: number };
    uProgress: { value: number };
    uColor: { value: THREE.Color };
  } | null>(null);

  const camControlRef = useRef<{
    position: THREE.Vector3;
    lookAt: THREE.Vector3;
    fov: number;
  } | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const tlRef = useRef<gsap.core.Timeline | null>(null);
  const [started, setStarted] = useState(false);
  const [scale, setScale] = useState(1);

  // Scale the film container to fit viewport
  useEffect(() => {
    const handleResize = () => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const scaleX = vw / 1920;
      const scaleY = vh / 1080;
      setScale(Math.min(scaleX, scaleY));
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Build and play the timeline
  useEffect(() => {
    if (!started) return;
    if (tlRef.current) return;

    const tl = gsap.timeline({
      paused: true,
      defaults: { ease: 'power3.out' },
    });

    // Helper to set particle mode
    const setMode = (mode: number, progress: number) => {
      if (particleUniformsRef.current) {
        particleUniformsRef.current.uMode.value = mode;
        particleUniformsRef.current.uProgress.value = progress;
      }
      if (lineUniformsRef.current) {
        lineUniformsRef.current.uMode.value = mode;
        lineUniformsRef.current.uProgress.value = progress;
      }
    };

    // We'll add GSAP tweens that update mode/progress/camera over time
    // Initial state
    setMode(0, 0);

    // ============ 0-3s: THE HOOK ============
    // Initial lime point expands, particles form field.
    // Camera pushes rapidly through
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          const p = this.targets()[0].p as number;
          setMode(0, p);
        },
      },
      0
    );
    // Camera: starts far back, rushes in, then pushes through
    tl.fromTo(
      { z: 80, x: 0, y: 0, fov: 60 },
      { z: 80, x: 0, y: 0, fov: 60 },
      {
        z: 18,
        x: 0,
        y: 0,
        fov: 55,
        duration: 2.8,
        ease: 'power2.in',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) {
            camControlRef.current.position.set(t.x, t.y, t.z);
          }
        },
      },
      0.2
    );

    // Text "CREATE." — emerges from darkness
    tl.fromTo(
      '#text-create',
      { opacity: 0, y: 80, scale: 1.2, filter: 'blur(20px)' },
      { opacity: 1, y: 0, scale: 1, filter: 'blur(0px)', duration: 0.8, ease: 'power3.out' },
      1.2
    );
    tl.to('#text-create', { opacity: 0, y: -40, filter: 'blur(12px)', duration: 0.5 }, 2.1);

    // "WITH INTELLIGENCE."
    tl.fromTo(
      '#text-with-intel',
      { opacity: 0, y: 80, scale: 1.1, filter: 'blur(20px)' },
      { opacity: 1, y: 0, scale: 1, filter: 'blur(0px)', duration: 0.8 },
      2.0
    );
    tl.to('#text-with-intel', { opacity: 0, duration: 0.3 }, 2.8);

    // ============ 3-6s: INFINITE DIRECTIONS ============
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          setMode(1, this.targets()[0].p as number);
        },
      },
      3
    );
    // Camera flies through branching
    tl.to(
      { z: 18, y: 0, x: 0 },
      {
        z: 25,
        y: 1,
        x: -2,
        duration: 3,
        ease: 'sine.inOut',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) {
            camControlRef.current.position.set(t.x, t.y, t.z);
          }
        },
      },
      3
    );

    tl.fromTo(
      '#text-one-idea',
      { opacity: 0, y: 60, filter: 'blur(16px)' },
      { opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.7 },
      3.4
    );
    tl.to('#text-one-idea', { opacity: 0, y: -30, duration: 0.4 }, 4.2);

    tl.fromTo(
      '#text-infinite-wrapper',
      { opacity: 0, y: 60, filter: 'blur(16px)' },
      { opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.7 },
      4.3
    );
    // "DIRECTIONS" splits into multiple copies
    tl.fromTo(
      '.dir-split',
      { x: 0, opacity: 1, filter: 'blur(0px)' },
      {
        x: (i: number) => [-300, -150, 0, 150, 300][i],
        opacity: 0.15,
        filter: 'blur(4px)',
        duration: 0.8,
        ease: 'power2.in',
      },
      5.1
    );
    tl.to('#text-infinite-wrapper', { opacity: 0, duration: 0.3 }, 5.8);

    // ============ 6-9s: INTELLIGENCE IN MOTION ============
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          setMode(2, this.targets()[0].p as number);
        },
      },
      6
    );
    // Camera rotates around network
    tl.to(
      { angle: 0, z: 25 },
      {
        angle: Math.PI * 0.4,
        z: 20,
        duration: 3,
        ease: 'sine.inOut',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          const r = 20;
          if (camControlRef.current) {
            camControlRef.current.position.set(
              Math.sin(t.angle) * r,
              Math.sin(t.angle * 0.5) * 3,
              Math.cos(t.angle) * t.z
            );
          }
        },
      },
      6
    );

    tl.fromTo(
      '#text-intel',
      { opacity: 0, y: 60, filter: 'blur(16px)' },
      { opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.7 },
      6.4
    );
    tl.to('#text-intel', { opacity: 0, y: -20, duration: 0.4 }, 7.3);

    tl.fromTo(
      '#text-in-motion',
      { opacity: 0, y: 60, letterSpacing: '0.2em', filter: 'blur(16px)' },
      {
        opacity: 1,
        y: 0,
        letterSpacing: '-0.04em',
        filter: 'blur(0px)',
        duration: 0.8,
        ease: 'power2.out',
      },
      7.4
    );
    tl.to('#text-in-motion', { opacity: 0, duration: 0.3 }, 8.7);

    // ============ 9-12s: BUILD FASTER ============
    // Hard transition: network collapses to point then expands to UI
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          setMode(3, this.targets()[0].p as number);
        },
      },
      9
    );
    // Camera snaps forward
    tl.to(
      { angle: Math.PI * 0.4, z: 20 },
      {
        angle: 0,
        z: 12,
        duration: 0.6,
        ease: 'power4.in',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) {
            camControlRef.current.position.set(0, 0, t.z);
          }
        },
      },
      9
    );
    tl.to(
      { z: 12 },
      {
        z: 22,
        duration: 2.4,
        ease: 'power2.out',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) {
            camControlRef.current.position.set(0, 0, t.z);
          }
        },
      },
      9.6
    );

    // Show UI cards assembling (HTML)
    tl.add(() => {
      const ui = document.getElementById('ui-build-grid');
      if (ui) ui.style.opacity = '1';
    }, 9.6);
    // Animate cards appearing
    tl.fromTo(
      '.build-card',
      { scale: 0, opacity: 0, y: 40 },
      {
        scale: 1,
        opacity: 1,
        y: 0,
        duration: 0.5,
        stagger: 0.03,
        ease: 'back.out(1.4)',
      },
      9.7
    );

    tl.fromTo(
      '#text-build',
      { opacity: 0, scale: 0.8, filter: 'blur(20px)' },
      { opacity: 1, scale: 1, filter: 'blur(0px)', duration: 0.6 },
      9.8
    );
    tl.to('#text-build', { opacity: 0, scale: 1.1, duration: 0.3 }, 10.7);

    // "FASTER" accelerates toward camera
    tl.fromTo(
      '#text-faster',
      { opacity: 0, scale: 0.3, z: -2000, filter: 'blur(30px)' },
      {
        opacity: 1,
        scale: 1.4,
        z: 0,
        filter: 'blur(0px)',
        duration: 1.1,
        ease: 'power4.in',
      },
      10.8
    );
    tl.to('#text-faster', { opacity: 0, scale: 2.2, duration: 0.3, ease: 'power2.in' }, 11.7);
    tl.to('#ui-build-grid', { opacity: 0, duration: 0.3 }, 11.8);

    // ============ 12-15s: PROMPT TO PRODUCT ============
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          setMode(4, this.targets()[0].p as number);
        },
      },
      12
    );
    tl.to(
      { z: 22 },
      {
        z: 16,
        duration: 3,
        ease: 'sine.inOut',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) {
            camControlRef.current.position.set(0, 1, t.z);
          }
        },
      },
      12
    );

    // Prompt interface
    tl.add(() => {
      const el = document.getElementById('ui-prompt');
      if (el) el.style.opacity = '1';
    }, 12.1);
    tl.fromTo(
      '#prompt-box',
      { opacity: 0, y: 30, scale: 0.95 },
      { opacity: 1, y: 0, scale: 1, duration: 0.6 },
      12.2
    );
    tl.fromTo(
      '#prompt-text',
      { width: 0 },
      { width: '100%', duration: 1.0, ease: 'none' },
      12.6
    );
    // Processing line
    tl.fromTo(
      '#prompt-progress',
      { scaleX: 0 },
      { scaleX: 1, duration: 0.5, ease: 'power2.inOut' },
      13.5
    );
    tl.to('#prompt-progress', { opacity: 0, duration: 0.2 }, 14.0);

    // Then transform into product
    tl.add(() => {
      const el = document.getElementById('ui-product');
      if (el) el.style.opacity = '1';
    }, 14.0);
    tl.fromTo(
      '#product-dashboard',
      { opacity: 0, scale: 0.95 },
      { opacity: 1, scale: 1, duration: 0.7, ease: 'power2.out' },
      14.0
    );
    tl.to('#prompt-box', { opacity: 0, scale: 1.05, duration: 0.3 }, 14.0);

    tl.fromTo(
      '#text-from-prompt',
      { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 0.5 },
      12.3
    );
    tl.to('#text-from-prompt', { opacity: 0, y: -20, duration: 0.3 }, 13.2);
    tl.fromTo(
      '#text-to-product',
      { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 0.5 },
      13.6
    );
    tl.to('#text-to-product', { opacity: 0, duration: 0.3 }, 14.8);
    tl.to('#ui-prompt', { opacity: 0, duration: 0.3 }, 14.9);
    tl.to('#ui-product', { opacity: 0, duration: 0.3 }, 14.9);

    // ============ 15-18s: LESS REPETITION ============
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          setMode(5, this.targets()[0].p as number);
        },
      },
      15
    );
    tl.to(
      { z: 16 },
      {
        z: 20,
        duration: 3,
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) camControlRef.current.position.set(0, 0, t.z);
        },
      },
      15
    );

    // Multiple windows appear mechanically
    tl.add(() => {
      const el = document.getElementById('ui-repetition');
      if (el) el.style.opacity = '1';
    }, 15.0);
    tl.fromTo(
      '.rep-window',
      { opacity: 0, x: () => gsap.utils.random(-600, 600), y: () => gsap.utils.random(-400, 400), rotation: () => gsap.utils.random(-10, 10) },
      {
        opacity: 1,
        x: (i) => {
          const col = i % 4;
          return (col - 1.5) * 360;
        },
        y: (i) => {
          const r = Math.floor(i / 4);
          return (r - 0.5) * 280;
        },
        rotation: 0,
        duration: 0.6,
        stagger: 0.02,
        ease: 'power3.out',
      },
      15.1
    );
    // Mechanical jitter
    tl.to('.rep-window', {
      keyframes: [
        { x: '+=4', duration: 0.1 },
        { x: '-=4', duration: 0.1 },
        { x: '+=3', duration: 0.1 },
        { x: '-=3', duration: 0.1 },
        { x: '+=2', duration: 0.1 },
        { x: '-=2', duration: 0.1 },
      ],
      stagger: { each: 0.005, from: 'random' },
    }, 16.0);
    // Collapse into single elegant flow
    tl.to('.rep-window', {
      x: 0,
      y: 0,
      scale: 0.6,
      opacity: (i: number) => (i === 0 ? 1 : 0),
      rotation: 0,
      duration: 0.8,
      stagger: 0.02,
      ease: 'power3.inOut',
    }, 16.8);

    tl.fromTo(
      '#text-less-rep',
      { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 0.6 },
      15.4
    );
    tl.to('#text-less-rep', { opacity: 0, y: -30, duration: 0.3 }, 16.4);
    tl.fromTo(
      '#text-more-creation',
      { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 0.6 },
      16.8
    );
    tl.to('#text-more-creation', { opacity: 0, duration: 0.3 }, 17.8);
    tl.to('#ui-repetition', { opacity: 0, duration: 0.3 }, 17.9);

    // ============ 18-21s: 10× ============
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          setMode(6, this.targets()[0].p as number);
        },
      },
      18
    );
    // Freeze — camera holds, then after 10x appears, bursts
    tl.to(
      { z: 20 },
      {
        z: 30,
        duration: 3,
        ease: 'power2.in',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) camControlRef.current.position.set(0, 0, t.z);
        },
      },
      18
    );

    // Everything freezes — hold for a beat
    tl.fromTo(
      '#text-10x',
      { opacity: 0, scale: 0.5, filter: 'blur(30px)' },
      {
        opacity: 1,
        scale: 1,
        filter: 'blur(0px)',
        duration: 0.6,
        ease: 'power4.out',
      },
      18.5
    );
    // Impact: slight scale overshoot
    tl.to('#text-10x', { scale: 1.15, duration: 0.2, ease: 'power2.out' }, 19.1);
    tl.to('#text-10x', { scale: 1, duration: 0.2 }, 19.3);
    // Hold
    tl.to('#text-10x', { scale: 1.05, duration: 0.4 }, 19.5);
    // Then fracture into particles (explode)
    tl.to('#text-10x', {
      opacity: 0,
      scale: 2.5,
      filter: 'blur(20px)',
      duration: 0.8,
      ease: 'power3.in',
    }, 20.0);

    // Particle explosion
    if (particleUniformsRef.current) {
      tl.fromTo(
        particleUniformsRef.current.uExplode,
        { value: 0 },
        {
          value: 15,
          duration: 1.2,
          ease: 'power3.in',
        },
        19.8
      );
    }

    // ============ 21-24s: IDEAS CONNECT ============
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          setMode(7, this.targets()[0].p as number);
        },
      },
      21
    );
    // Ease explode back down
    if (particleUniformsRef.current) {
      tl.to(particleUniformsRef.current.uExplode, { value: 0, duration: 1.0, ease: 'power2.out' }, 21);
    }
    tl.to(
      { z: 30 },
      {
        z: 22,
        duration: 3,
        ease: 'sine.inOut',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) camControlRef.current.position.set(0, 2, t.z);
        },
      },
      21
    );

    tl.fromTo(
      '#text-ideas',
      { opacity: 0, y: 50, filter: 'blur(20px)' },
      { opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.6 },
      21.6
    );
    tl.to('#text-ideas', { opacity: 0, y: -20, duration: 0.3 }, 22.5);
    tl.fromTo(
      '#text-connect',
      { opacity: 0, scale: 0.8, filter: 'blur(16px)' },
      { opacity: 1, scale: 1, filter: 'blur(0px)', duration: 0.8, ease: 'back.out(1.4)' },
      22.6
    );
    tl.to('#text-connect', { opacity: 0, duration: 0.3 }, 23.8);

    // ============ 24-27s: MAKE NOISE ============
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          setMode(8, this.targets()[0].p as number);
        },
      },
      24
    );
    const camObj24 = { z: 22, shake: 0 };
    tl.to(
      camObj24,
      {
        z: 28,
        duration: 3,
        ease: 'sine.inOut',
        onUpdate: function () {
          if (camControlRef.current) {
            const sx = Math.sin(camObj24.shake * 40) * camObj24.shake * 8;
            camControlRef.current.position.set(sx, 0, camObj24.z);
          }
        },
      },
      24
    );
    // Shake rises then settles
    tl.to(camObj24, { shake: 1.2, duration: 1.2, ease: 'power2.in' }, 24.2);
    tl.to(camObj24, { shake: 0, duration: 1.4, ease: 'power2.out' }, 25.4);

    // Kinetic words: THINK BUILD TEST CREATE ITERATE LAUNCH
    const words = ['THINK', 'BUILD', 'TEST', 'CREATE', 'ITERATE', 'LAUNCH'];
    words.forEach((_w, i) => {
      tl.fromTo(
        `#word-${i}`,
        {
          opacity: 0,
          x: (i % 2 === 0 ? -1 : 1) * 1200,
          y: (i - 2.5) * 60,
          rotation: (i % 2 === 0 ? -8 : 8),
          scale: 1.5,
        },
        {
          opacity: 1,
          x: (i - 2.5) * 280,
          y: (i - 2.5) * 60,
          rotation: 0,
          scale: 1,
          duration: 0.4,
          ease: 'power4.out',
        },
        24.2 + i * 0.13
      );
    });
    // Collide them
    tl.to('.kinetic-word', {
      keyframes: [
        { x: (i: number) => (i - 2.5) * 280 + (i % 2 === 0 ? 15 : -15), duration: 0.15 },
        { x: (i: number) => (i - 2.5) * 280, duration: 0.15 },
      ],
      ease: 'power2.inOut',
    }, 25.4);
    // Compress into center
    tl.to('.kinetic-word', {
      x: 0,
      y: 0,
      scale: 0,
      opacity: 0,
      rotation: 0,
      duration: 0.5,
      ease: 'power3.in',
    }, 25.8);

    // MAKE NOISE appears
    tl.fromTo(
      '#text-make-noise',
      { opacity: 0, scale: 0.3, filter: 'blur(20px)', letterSpacing: '0.3em' },
      {
        opacity: 1,
        scale: 1,
        filter: 'blur(0px)',
        letterSpacing: '-0.04em',
        duration: 0.8,
        ease: 'power4.out',
      },
      26.0
    );
    tl.to('#text-make-noise', { opacity: 0, scale: 1.2, duration: 0.3 }, 26.8);

    // ============ 27-30s: HUMAN + MACHINE ============
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          setMode(9, this.targets()[0].p as number);
        },
      },
      27
    );
    tl.to(
      { z: 28 },
      {
        z: 18,
        duration: 3,
        ease: 'sine.inOut',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) camControlRef.current.position.set(0, 0, t.z);
        },
      },
      27
    );

    // Split screen UI
    tl.add(() => {
      const el = document.getElementById('ui-split');
      if (el) el.style.opacity = '1';
    }, 27.0);
    tl.fromTo('#split-left', { opacity: 0, x: -200 }, { opacity: 1, x: 0, duration: 0.7, ease: 'power3.out' }, 27.2);
    tl.fromTo('#split-right', { opacity: 0, x: 200 }, { opacity: 1, x: 0, duration: 0.7, ease: 'power3.out' }, 27.2);
    // Connecting lines emerge from both sides
    tl.fromTo(
      '.split-line',
      { scaleX: 0 },
      { scaleX: 1, duration: 0.6, stagger: 0.04, ease: 'power2.out' },
      28.0
    );
    // Center lime point
    tl.fromTo(
      '#split-center-dot',
      { scale: 0, opacity: 0 },
      { scale: 1, opacity: 1, duration: 0.4, ease: 'back.out(3)' },
      28.6
    );
    tl.to('#split-center-dot', {
      scale: 1.8,
      duration: 0.2,
      yoyo: true,
      repeat: 1,
      ease: 'power2.inOut',
    }, 29.0);

    tl.fromTo(
      '#text-human-intent',
      { opacity: 0 },
      { opacity: 1, duration: 0.5 },
      27.4
    );
    tl.fromTo(
      '#text-machine-speed',
      { opacity: 0 },
      { opacity: 1, duration: 0.5 },
      28.2
    );
    // Merge the two phrases visually
    tl.to('#text-human-intent', { x: 40, duration: 0.8, ease: 'power2.inOut' }, 29.0);
    tl.to('#text-machine-speed', { x: -40, duration: 0.8, ease: 'power2.inOut' }, 29.0);
    tl.to(['#text-human-intent', '#text-machine-speed', '#ui-split'], {
      opacity: 0,
      duration: 0.4,
    }, 29.7);

    // ============ 30-33s: BUILD WHAT'S NEXT ============
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          setMode(10, this.targets()[0].p as number);
        },
      },
      30
    );
    // Fly through city/environment
    tl.to(
      { z: 18, x: 0 },
      {
        z: -5,
        x: -4,
        y: -1,
        duration: 3,
        ease: 'power2.inOut',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) camControlRef.current.position.set(t.x, t.y, t.z);
        },
      },
      30
    );

    // City HTML overlay (simplified: grid of emerging blocks)
    tl.add(() => {
      const el = document.getElementById('ui-city');
      if (el) el.style.opacity = '1';
    }, 30.0);
    tl.fromTo(
      '.city-block',
      { opacity: 0, scaleY: 0, transformOrigin: 'bottom' },
      {
        opacity: 1,
        scaleY: 1,
        duration: 0.4,
        stagger: { amount: 2.0, from: 'center', grid: 'auto' },
        ease: 'power2.out',
      },
      30.1
    );

    tl.fromTo(
      '#text-build-next',
      { opacity: 0, y: 50, filter: 'blur(20px)' },
      { opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.7 },
      30.4
    );
    tl.to('#text-build-next', { opacity: 0, y: -20, duration: 0.3 }, 31.4);
    tl.fromTo(
      '#text-whats-next',
      { opacity: 0, y: 50, filter: 'blur(20px)' },
      { opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.8 },
      31.5
    );
    tl.to(['#text-whats-next', '#ui-city'], { opacity: 0, duration: 0.4 }, 32.8);

    // ============ 33-36s: BRAND REVEAL ============
    tl.to(
      { p: 0 },
      {
        p: 1,
        duration: 3,
        ease: 'none',
        onUpdate: function () {
          setMode(11, this.targets()[0].p as number);
        },
      },
      33
    );
    // Rapid collapse to center
    tl.to(
      { z: -5 },
      {
        z: 5,
        x: 0,
        y: 0,
        duration: 1.0,
        ease: 'power3.in',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) camControlRef.current.position.set(0, 0, t.z);
        },
      },
      33
    );
    tl.to(
      { z: 5 },
      {
        z: 10,
        duration: 2,
        ease: 'sine.inOut',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) camControlRef.current.position.set(0, 0, t.z);
        },
      },
      34
    );

    // Black screen
    tl.fromTo(
      '#reveal-black',
      { opacity: 0 },
      { opacity: 1, duration: 0.6, ease: 'power2.in' },
      33.8
    );

    // Thin lime line that draws the logo mark
    tl.fromTo(
      '#logo-line-h',
      { scaleX: 0 },
      { scaleX: 1, duration: 0.25, ease: 'power2.out' },
      34.3
    );
    // Then draw mark strokes one by one
    tl.fromTo(
      '#logo-mark line',
      { scale: 0, transformOrigin: 'center' },
      { scale: 1, duration: 0.15, stagger: 0.04, ease: 'power2.out' },
      34.5
    );
    // Center square
    tl.fromTo('#logo-mark rect', { opacity: 0 }, { opacity: 1, duration: 0.1 }, 34.9);

    // Wordmark CUPRIC
    tl.fromTo(
      '#logo-wordmark',
      { opacity: 0, y: 20, letterSpacing: '0.3em', filter: 'blur(12px)' },
      {
        opacity: 1,
        y: 0,
        letterSpacing: '-0.04em',
        filter: 'blur(0px)',
        duration: 0.7,
        ease: 'power3.out',
      },
      35.0
    );

    // ============ 36-38s: BRAND STATEMENT ============
    tl.to('#reveal-black', { opacity: 0.6, duration: 0.5 }, 36.0);
    // Fade out the big CUPRIC AI, show statement
    tl.to('#logo-wordmark', { scale: 0.55, y: -180, duration: 0.8, ease: 'power2.inOut' }, 36.0);
    tl.to('#logo-mark', { scale: 0.35, y: -180, duration: 0.8, ease: 'power2.inOut' }, 36.0);
    tl.fromTo(
      '#text-tagline',
      { opacity: 0, y: 20, letterSpacing: '0.1em' },
      {
        opacity: 1,
        y: 0,
        letterSpacing: '-0.02em',
        duration: 0.8,
        ease: 'power2.out',
      },
      36.3
    );

    // Very slow camera push
    tl.to(
      { z: 10 },
      {
        z: 8,
        duration: 4,
        ease: 'none',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) camControlRef.current.position.set(0, 0, t.z);
        },
      },
      36
    );

    // ============ 38-40s: FINAL END CARD ============
    tl.to('#text-tagline', { opacity: 0, y: -20, duration: 0.3 }, 38.0);
    tl.to(['#logo-mark', '#logo-wordmark'], { opacity: 0, duration: 0.3 }, 38.0);
    tl.to('#reveal-black', { opacity: 1, duration: 0.5 }, 38.0);

    // Final clean card
    tl.fromTo(
      '#final-card',
      { opacity: 0 },
      { opacity: 1, duration: 0.8, ease: 'power2.out' },
      38.4
    );
    tl.fromTo(
      '#final-logo',
      { opacity: 0, scale: 0.9, filter: 'blur(8px)' },
      { opacity: 1, scale: 1, filter: 'blur(0px)', duration: 0.8 },
      38.5
    );
    tl.fromTo(
      '#final-tagline',
      { opacity: 0, y: 10 },
      { opacity: 1, y: 0, duration: 0.5 },
      39.1
    );
    tl.fromTo(
      '#final-cta',
      { opacity: 0 },
      { opacity: 1, duration: 0.5 },
      39.5
    );
    // Slow push to end
    tl.to(
      { z: 8 },
      {
        z: 6,
        duration: 2,
        ease: 'none',
        onUpdate: function () {
          const t = this.targets()[0] as any;
          if (camControlRef.current) camControlRef.current.position.set(0, 0, t.z);
        },
      },
      38
    );

    tlRef.current = tl;
    tl.play(0);
  }, [started]);

  return (
    <div
      ref={containerRef}
      className="film-container"
      style={{ ['--scale' as any]: scale }}
    >
      {/* Three.js background */}
      <div style={{ position: 'absolute', inset: 0, background: '#050505' }}>
        <Canvas
          camera={{ position: [0, 0, 80], fov: 50, near: 0.1, far: 500 }}
          gl={{ antialias: true, alpha: false, powerPreference: 'high-performance' }}
          dpr={[1, 2]}
        >
          <color attach="background" args={['#050505']} />
          <fog attach="fog" args={['#050505', 60, 220]} />
          <ambientLight intensity={0.3} />
          <ParticleField uniformsRef={particleUniformsRef} />
          <LineLayer uniformsRef={lineUniformsRef} />
          <CameraController camRef={camControlRef} />
        </Canvas>
      </div>

      {/* Vignette, grain and scanlines */}
      <div className="vignette" />
      <div className="scanlines" />
      <svg className="grain-overlay" viewBox="0 0 1920 1080" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" stitchTiles="stitch" seed="1"/>
          <feColorMatrix type="saturate" values="0"/>
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)"/>
      </svg>

      {/* ======== TYPOGRAPHY OVERLAYS ======== */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          pointerEvents: 'none',
          zIndex: 10,
        }}
      >
        {/* 0-3s */}
        <div
          id="text-create"
          className="scene-text"
          style={{
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            fontSize: 220,
            fontWeight: 800,
            letterSpacing: '-0.05em',
            textShadow: '0 0 60px rgba(170,255,68,0.25)',
          }}
        >
          CREATE<span className="lime-accent">.</span>
        </div>
        <div
          id="text-with-intel"
          className="scene-text"
          style={{
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            fontSize: 130,
            fontWeight: 700,
            letterSpacing: '-0.04em',
          }}
        >
          WITH INTELLIGENCE<span className="lime-accent">.</span>
        </div>

        {/* 3-6s */}
        <div
          id="text-one-idea"
          className="scene-text"
          style={{
            left: 200,
            top: 300,
            fontSize: 170,
            fontWeight: 800,
          }}
        >
          ONE IDEA<span className="lime-accent">.</span>
        </div>
        <div
          id="text-infinite-wrapper"
          style={{
            position: 'absolute',
            left: 200,
            top: 520,
            opacity: 0,
          }}
        >
          <div
            id="text-infinite"
            style={{
              fontSize: 110,
              fontWeight: 700,
              letterSpacing: '-0.03em',
              display: 'flex',
              alignItems: 'baseline',
              gap: 30,
            }}
          >
            <span>INFINITE</span>
            <div id="text-directions-split" style={{ position: 'relative', opacity: 1 }}>
              {[-2, -1, 0, 1, 2].map((offset) => (
                <span
                  key={offset}
                  className="dir-split"
                  style={{
                    position: offset === 0 ? 'relative' : 'absolute',
                    left: '50%',
                    top: '50%',
                    transform: `translate(-50%, -50%) translateX(${offset * 0}px)`,
                    fontSize: 110,
                    fontWeight: 700,
                    letterSpacing: '-0.03em',
                    whiteSpace: 'nowrap',
                    color: offset === 0 ? 'white' : 'rgba(170,255,68,0.6)',
                  }}
                >
                  DIRECTIONS
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* 6-9s */}
        <div
          id="text-intel"
          className="scene-text"
          style={{
            left: '50%',
            top: '42%',
            transform: 'translate(-50%, -50%)',
            fontSize: 180,
            fontWeight: 800,
            letterSpacing: '-0.05em',
          }}
        >
          INTELLIGENCE
        </div>
        <div
          id="text-in-motion"
          className="scene-text"
          style={{
            left: '50%',
            top: '62%',
            transform: 'translate(-50%, -50%)',
            fontSize: 120,
            fontWeight: 700,
            color: 'var(--lime)',
            textShadow: '0 0 40px rgba(170,255,68,0.5)',
          }}
        >
          IN MOTION<span className="lime-accent">.</span>
        </div>

        {/* 9-12s BUILD FASTER */}
        <div
          id="text-build"
          className="scene-text"
          style={{
            left: 200,
            top: 220,
            fontSize: 140,
            fontWeight: 800,
            textShadow: '0 0 40px rgba(0,0,0,0.8)',
          }}
        >
          BUILD
        </div>
        <div
          id="text-faster"
          className="scene-text"
          style={{
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            fontSize: 380,
            fontWeight: 900,
            letterSpacing: '-0.06em',
            color: 'var(--lime)',
            textShadow:
              '0 0 80px rgba(170,255,68,0.5), 0 0 160px rgba(170,255,68,0.2)',
            mixBlendMode: 'screen',
          }}
        >
          FASTER<span style={{ color: 'white' }}>.</span>
        </div>

        {/* 12-15s */}
        <div
          id="text-from-prompt"
          className="scene-text"
          style={{
            left: 120,
            top: 120,
            fontSize: 72,
            fontWeight: 700,
            letterSpacing: '-0.02em',
          }}
        >
          FROM PROMPT
        </div>
        <div
          id="text-to-product"
          className="scene-text"
          style={{
            left: 120,
            top: 120,
            fontSize: 72,
            fontWeight: 700,
            letterSpacing: '-0.02em',
          }}
        >
          TO PRODUCT<span className="lime-accent">.</span>
        </div>

        {/* 15-18s */}
        <div
          id="text-less-rep"
          className="scene-text"
          style={{
            left: '50%',
            top: 200,
            transform: 'translateX(-50%)',
            fontSize: 96,
            fontWeight: 700,
          }}
        >
          LESS REPETITION<span className="lime-accent">.</span>
        </div>
        <div
          id="text-more-creation"
          className="scene-text"
          style={{
            left: '50%',
            top: 780,
            transform: 'translateX(-50%)',
            fontSize: 96,
            fontWeight: 800,
            color: 'var(--lime)',
          }}
        >
          MORE CREATION<span style={{ color: 'white' }}>.</span>
        </div>

        {/* 18-21s */}
        <div
          id="text-10x"
          className="scene-text"
          style={{
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            fontSize: 560,
            fontWeight: 900,
            letterSpacing: '-0.08em',
            lineHeight: 1,
            textShadow:
              '0 0 100px rgba(170,255,68,0.4), 0 0 200px rgba(170,255,68,0.15)',
          }}
        >
          <span style={{ color: 'white' }}>10</span>
          <span className="lime-accent">×</span>
        </div>

        {/* 21-24s */}
        <div
          id="text-ideas"
          className="scene-text"
          style={{
            left: 200,
            top: 300,
            fontSize: 180,
            fontWeight: 800,
          }}
        >
          IDEAS
        </div>
        <div
          id="text-connect"
          className="scene-text"
          style={{
            left: 200,
            top: 520,
            fontSize: 200,
            fontWeight: 800,
            color: 'var(--lime)',
            textShadow: '0 0 60px rgba(170,255,68,0.4)',
          }}
        >
          CONNECT<span style={{ color: 'white' }}>.</span>
        </div>

        {/* 24-27s Kinetic words */}
        <div
          style={{
            position: 'absolute',
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
          }}
        >
          {['THINK', 'BUILD', 'TEST', 'CREATE', 'ITERATE', 'LAUNCH'].map((w, i) => (
            <div
              key={w}
              id={`word-${i}`}
              className="kinetic-word scene-text"
              style={{
                position: 'absolute',
                left: 0,
                top: 0,
                fontSize: i === 4 ? 80 : 110,
                fontWeight: 800,
                letterSpacing: '-0.04em',
                whiteSpace: 'nowrap',
                transform: 'translate(-50%, -50%)',
                color: i % 2 === 0 ? 'white' : 'var(--lime)',
                textShadow:
                  i % 2 === 1
                    ? '0 0 30px rgba(170,255,68,0.4)'
                    : 'none',
              }}
            >
              {w}
            </div>
          ))}
        </div>
        <div
          id="text-make-noise"
          className="scene-text"
          style={{
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            fontSize: 230,
            fontWeight: 900,
            letterSpacing: '-0.05em',
            color: 'white',
            textShadow:
              '0 0 80px rgba(170,255,68,0.35), 0 0 160px rgba(170,255,68,0.15)',
          }}
        >
          MAKE <span className="lime-accent">NOISE</span>
          <span className="lime-accent">.</span>
        </div>

        {/* 27-30s split screen text */}
        <div
          id="text-human-intent"
          className="scene-text"
          style={{
            left: 480 - 280,
            top: 160,
            fontSize: 80,
            fontWeight: 700,
            letterSpacing: '-0.03em',
            whiteSpace: 'nowrap',
            textAlign: 'center',
            width: 560,
          }}
        >
          HUMAN<br />INTENT<span className="lime-accent">.</span>
        </div>
        <div
          id="text-machine-speed"
          className="scene-text"
          style={{
            right: 480 - 280,
            top: 160,
            fontSize: 80,
            fontWeight: 700,
            letterSpacing: '-0.03em',
            whiteSpace: 'nowrap',
            textAlign: 'center',
            width: 560,
            color: 'var(--lime)',
          }}
        >
          MACHINE<br />SPEED<span style={{ color: 'white' }}>.</span>
        </div>

        {/* 30-33s */}
        <div
          id="text-build-next"
          className="scene-text"
          style={{
            left: 200,
            top: 240,
            fontSize: 150,
            fontWeight: 800,
            textShadow: '0 0 40px rgba(0,0,0,0.8)',
          }}
        >
          BUILD
        </div>
        <div
          id="text-whats-next"
          className="scene-text"
          style={{
            left: 200,
            top: 430,
            fontSize: 170,
            fontWeight: 800,
            color: 'var(--lime)',
            textShadow:
              '0 0 50px rgba(170,255,68,0.4), 0 0 100px rgba(170,255,68,0.2)',
          }}
        >
          WHAT'S NEXT<span style={{ color: 'white' }}>.</span>
        </div>

        {/* 36-38s Tagline */}
        <div
          id="text-tagline"
          className="scene-text"
          style={{
            left: '50%',
            top: '58%',
            transform: 'translate(-50%, -50%)',
            fontSize: 78,
            fontWeight: 600,
            letterSpacing: '-0.02em',
            whiteSpace: 'nowrap',
            textAlign: 'center',
            color: 'rgba(255,255,255,0.95)',
          }}
        >
          INTELLIGENCE FOR PEOPLE WHO <span className="lime-accent">BUILD</span>.
        </div>
      </div>

      {/* ======== UI OVERLAYS ======== */}

      {/* 9-12s: Build grid */}
      <div
        id="ui-build-grid"
        style={{
          position: 'absolute',
          inset: 0,
          opacity: 0,
          zIndex: 5,
          pointerEvents: 'none',
        }}
      >
        <div
          style={{
            position: 'absolute',
            top: 180,
            left: 140,
            right: 140,
            bottom: 180,
            display: 'grid',
            gridTemplateColumns: 'repeat(6, 1fr)',
            gridTemplateRows: 'repeat(4, 1fr)',
            gap: 20,
          }}
        >
          {Array.from({ length: 24 }).map((_, i) => {
            const isGraph = i % 7 === 0;
            const isCode = i % 5 === 0;
            return (
              <div
                key={i}
                className="build-card ui-card ui-card-glow"
                style={{
                  padding: 24,
                  transformOrigin: 'center',
                  position: 'relative',
                }}
              >
                <div
                  style={{
                    width: '100%',
                    height: 4,
                    background: 'rgba(255,255,255,0.15)',
                    borderRadius: 2,
                    marginBottom: 12,
                  }}
                />
                <div
                  style={{
                    width: '60%',
                    height: 4,
                    background: 'rgba(170,255,68,0.5)',
                    borderRadius: 2,
                    marginBottom: 20,
                  }}
                />
                {isGraph ? (
                  <svg viewBox="0 0 100 50" style={{ width: '100%', height: '55%' }}>
                    <polyline
                      points="0,40 20,30 40,35 60,15 80,20 100,5"
                      fill="none"
                      stroke="rgba(170,255,68,0.7)"
                      strokeWidth="1.5"
                    />
                    <polyline
                      points="0,45 20,42 40,38 60,30 80,25 100,20"
                      fill="none"
                      stroke="rgba(255,255,255,0.3)"
                      strokeWidth="1"
                    />
                  </svg>
                ) : isCode ? (
                  <div style={{ fontFamily: 'JetBrains Mono', fontSize: 11, lineHeight: 1.7, color: 'rgba(255,255,255,0.5)' }}>
                    <div><span style={{ color: 'rgba(170,255,68,0.8)' }}>const</span> idea = await cupric.<span style={{ color: 'rgba(170,255,68,0.8)' }}>generate</span>()</div>
                    <div>  .run(prompt)</div>
                    <div>  .output(product)</div>
                  </div>
                ) : (
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 6, height: '55%' }}>
                    {Array.from({ length: 9 }).map((__, j) => (
                      <div
                        key={j}
                        style={{
                          background: `rgba(255,255,255,${0.03 + (j % 3) * 0.02})`,
                          borderRadius: 4,
                        }}
                      />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* 12-15s: Prompt and product */}
      <div
        id="ui-prompt"
        style={{
          position: 'absolute',
          inset: 0,
          opacity: 0,
          zIndex: 5,
          pointerEvents: 'none',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div
          id="prompt-box"
          className="ui-card ui-card-glow"
          style={{
            width: 1100,
            padding: 36,
            position: 'relative',
          }}
        >
          <div
            style={{
              display: 'flex',
              gap: 16,
              alignItems: 'center',
              marginBottom: 20,
            }}
          >
            <div
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                background: 'rgba(170,255,68,0.15)',
                border: '1px solid rgba(170,255,68,0.4)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <div
                style={{
                  width: 10,
                  height: 10,
                  borderRadius: '50%',
                  background: 'var(--lime)',
                  boxShadow: '0 0 8px var(--lime)',
                }}
              />
            </div>
            <div style={{ fontSize: 14, letterSpacing: '0.2em', color: 'rgba(255,255,255,0.5)', fontFamily: 'JetBrains Mono' }}>
              CUPRIC / PROMPT
            </div>
            <div style={{ flex: 1 }} />
            <div
              className="mono"
              style={{ fontSize: 13, color: 'rgba(255,255,255,0.4)' }}
            >
              v2.4
            </div>
          </div>
          <div
            style={{
              fontSize: 32,
              fontWeight: 500,
              lineHeight: 1.4,
              color: 'white',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
            }}
          >
            <span id="prompt-text" style={{ display: 'inline-block', width: 0 }}>
              "Build something people will remember."
              <span
                style={{
                  display: 'inline-block',
                  width: 2,
                  height: 32,
                  background: 'var(--lime)',
                  marginLeft: 4,
                  verticalAlign: 'middle',
                  animation: 'none',
                }}
              />
            </span>
          </div>
          <div
            style={{
              height: 2,
              background: 'rgba(255,255,255,0.08)',
              marginTop: 24,
              borderRadius: 2,
              overflow: 'hidden',
            }}
          >
            <div
              id="prompt-progress"
              style={{
                height: '100%',
                background: 'var(--lime)',
                width: '100%',
                transformOrigin: 'left',
                boxShadow: '0 0 10px rgba(170,255,68,0.6)',
              }}
            />
          </div>
        </div>
      </div>

      <div
        id="ui-product"
        style={{
          position: 'absolute',
          inset: 0,
          opacity: 0,
          zIndex: 5,
          pointerEvents: 'none',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div
          id="product-dashboard"
          style={{
            width: 1500,
            height: 780,
            position: 'relative',
            display: 'grid',
            gridTemplateColumns: '240px 1fr 320px',
            gap: 20,
          }}
        >
          {/* Sidebar */}
          <div className="ui-card" style={{ padding: 24 }}>
            <div className="mono" style={{ fontSize: 12, color: 'var(--lime)', marginBottom: 24, letterSpacing: '0.2em' }}>
              WORKSPACE
            </div>
            {['Overview', 'Projects', 'Components', 'Analytics', 'Deploy', 'Team'].map((x, i) => (
              <div
                key={x}
                style={{
                  padding: '12px 14px',
                  marginBottom: 4,
                  borderRadius: 8,
                  background: i === 0 ? 'rgba(170,255,68,0.1)' : 'transparent',
                  color: i === 0 ? 'var(--lime)' : 'rgba(255,255,255,0.6)',
                  fontSize: 15,
                  fontWeight: i === 0 ? 600 : 400,
                  borderLeft: i === 0 ? '2px solid var(--lime)' : '2px solid transparent',
                }}
              >
                {x}
              </div>
            ))}
          </div>
          {/* Main */}
          <div style={{ display: 'grid', gridTemplateRows: '1fr 1fr', gap: 20 }}>
            <div className="ui-card ui-card-glow" style={{ padding: 28 }}>
              <div style={{ fontSize: 13, letterSpacing: '0.2em', color: 'rgba(255,255,255,0.4)', marginBottom: 16 }} className="mono">
                LIVE PRODUCT
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
                {[
                  { v: '12.4K', l: 'Active users' },
                  { v: '98.7%', l: 'Uptime' },
                  { v: '0.3s', l: 'Avg response' },
                ].map((m, i) => (
                  <div key={i} style={{ padding: 16, background: 'rgba(255,255,255,0.03)', borderRadius: 8 }}>
                    <div style={{ fontSize: 36, fontWeight: 700, letterSpacing: '-0.03em' }}>{m.v}</div>
                    <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)', marginTop: 6 }}>{m.l}</div>
                  </div>
                ))}
              </div>
              <svg viewBox="0 0 300 80" style={{ width: '100%', height: 120, marginTop: 20 }}>
                <defs>
                  <linearGradient id="g1" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0" stopColor="rgba(170,255,68,0.4)" />
                    <stop offset="1" stopColor="rgba(170,255,68,0)" />
                  </linearGradient>
                </defs>
                <path
                  d="M0,60 C40,50 60,70 90,45 C120,20 150,55 180,35 C210,20 240,40 270,15 L300,10 L300,80 L0,80 Z"
                  fill="url(#g1)"
                />
                <path
                  d="M0,60 C40,50 60,70 90,45 C120,20 150,55 180,35 C210,20 240,40 270,15 L300,10"
                  fill="none"
                  stroke="var(--lime)"
                  strokeWidth="2"
                />
              </svg>
            </div>
            <div className="ui-card" style={{ padding: 24, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
              {['UI Components', 'Data Models', 'API Routes', 'Deployments'].map((t) => (
                <div key={t} style={{ padding: 18, background: 'rgba(255,255,255,0.02)', borderRadius: 8, border: '1px solid rgba(255,255,255,0.05)' }}>
                  <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 10, color: 'white' }}>{t}</div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    {Array.from({ length: 6 }).map((_, j) => (
                      <div key={j} style={{ flex: 1, height: 30, background: `rgba(170,255,68,${0.05 + (1 - j * 0.12) * 0.15})`, borderRadius: 4 }} />
                    ))}
                  </div>
                  <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', marginTop: 8 }}>
                    {Math.floor(Math.random() * 200 + 50)} generated
                  </div>
                </div>
              ))}
            </div>
          </div>
          {/* Right panel */}
          <div className="ui-card" style={{ padding: 24 }}>
            <div className="mono" style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', marginBottom: 20, letterSpacing: '0.2em' }}>
              ACTIVITY
            </div>
            {['Build complete', 'v2.4 deployed', '3 PRs merged', 'Tests passed', 'New component', 'Analytics sync'].map((x, i) => (
              <div key={x} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', marginBottom: 18 }}>
                <div
                  style={{
                    width: 8,
                    height: 8,
                    borderRadius: '50%',
                    background: i === 0 ? 'var(--lime)' : 'rgba(255,255,255,0.2)',
                    marginTop: 5,
                    boxShadow: i === 0 ? '0 0 8px var(--lime)' : 'none',
                  }}
                />
                <div>
                  <div style={{ fontSize: 14, color: i === 0 ? 'white' : 'rgba(255,255,255,0.7)' }}>{x}</div>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', marginTop: 2, fontFamily: 'JetBrains Mono' }}>
                    {String(i * 3 + 2).padStart(2, '0')}:{String(i * 7 + 12).padStart(2, '0')}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 15-18s: Repetition windows */}
      <div
        id="ui-repetition"
        style={{
          position: 'absolute',
          inset: 0,
          opacity: 0,
          zIndex: 5,
          pointerEvents: 'none',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={i}
            className="rep-window ui-card"
            style={{
              position: 'absolute',
              left: '50%',
              top: '50%',
              width: 280,
              height: 200,
              padding: 20,
              marginLeft: -140,
              marginTop: -100,
              background: 'rgba(20,20,22,0.9)',
            }}
          >
            <div className="mono" style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', marginBottom: 12, letterSpacing: '0.2em' }}>
              TASK_{String(i + 1).padStart(2, '0')}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, height: 130 }}>
              {Array.from({ length: 6 }).map((__, j) => (
                <div key={j} style={{ background: 'rgba(255,255,255,0.05)', borderRadius: 4, height: 28 }} />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* 27-30s: Split screen */}
      <div
        id="ui-split"
        style={{
          position: 'absolute',
          inset: 0,
          opacity: 0,
          zIndex: 4,
          pointerEvents: 'none',
        }}
      >
        <div
          id="split-left"
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            bottom: 0,
            width: '50%',
            borderRight: '1px solid rgba(255,255,255,0.04)',
            background: 'linear-gradient(to right, rgba(255,255,255,0.02), transparent)',
            padding: '120px 80px',
          }}
        >
          <div className="mono" style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', letterSpacing: '0.3em', marginBottom: 40 }}>
            INTENT
          </div>
          <svg viewBox="0 0 400 400" style={{ width: 500, height: 500, position: 'absolute', right: 80, bottom: 120, opacity: 0.6 }}>
            <circle cx="200" cy="200" r="120" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="1" />
            <circle cx="200" cy="200" r="80" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
            <path
              d="M200,80 C280,100 320,200 200,320 C80,200 120,100 200,80 Z"
              fill="none"
              stroke="white"
              strokeWidth="1.5"
              opacity="0.8"
            />
          </svg>
        </div>
        <div
          id="split-right"
          style={{
            position: 'absolute',
            right: 0,
            top: 0,
            bottom: 0,
            width: '50%',
            borderLeft: '1px solid rgba(170,255,68,0.08)',
            background: 'linear-gradient(to left, rgba(170,255,68,0.04), transparent)',
            padding: '120px 80px',
          }}
        >
          <div className="mono" style={{ fontSize: 12, color: 'var(--lime)', letterSpacing: '0.3em', marginBottom: 40, textAlign: 'right' }}>
            COMPUTE
          </div>
          <div style={{ position: 'absolute', left: 40, bottom: 120, display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 6, width: 700 }}>
            {Array.from({ length: 64 }).map((_, i) => (
              <div
                key={i}
                style={{
                  height: 20,
                  background: i % 3 === 0 ? 'rgba(170,255,68,0.5)' : 'rgba(255,255,255,0.06)',
                  borderRadius: 2,
                }}
              />
            ))}
          </div>
        </div>
        {/* Connecting lines */}
        <div
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 1400,
            height: 200,
          }}
        >
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className="split-line"
              style={{
                position: 'absolute',
                top: `${(i / 11) * 100}%`,
                left: 0,
                width: '100%',
                height: 1,
                background: i === 6 ? 'var(--lime)' : 'rgba(255,255,255,0.12)',
                transform: 'scaleX(0)',
                transformOrigin: 'center',
                boxShadow: i === 6 ? '0 0 12px var(--lime)' : 'none',
              }}
            />
          ))}
        </div>
        <div
          id="split-center-dot"
          style={{
            position: 'absolute',
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%) scale(0)',
            width: 24,
            height: 24,
            borderRadius: '50%',
            background: 'var(--lime)',
            opacity: 0,
            boxShadow:
              '0 0 40px rgba(170,255,68,0.8), 0 0 80px rgba(170,255,68,0.4), 0 0 120px rgba(170,255,68,0.2)',
          }}
        />
      </div>

      {/* 30-33s: City / ecosystem */}
      <div
        id="ui-city"
        style={{
          position: 'absolute',
          inset: 0,
          opacity: 0,
          zIndex: 4,
          pointerEvents: 'none',
          perspective: 1200,
        }}
      >
        <div
          style={{
            position: 'absolute',
            left: 300,
            bottom: 0,
            right: 200,
            top: 160,
            display: 'grid',
            gridTemplateColumns: 'repeat(12, 1fr)',
            gap: 8,
            alignItems: 'end',
            transform: 'rotateX(12deg)',
            transformOrigin: 'bottom',
          }}
        >
          {Array.from({ length: 60 }).map((_, i) => {
            const h = 40 + ((i * 37) % 400);
            const isLime = i % 11 === 0;
            return (
              <div
                key={i}
                className="city-block"
                style={{
                  height: h,
                  background: isLime
                    ? 'linear-gradient(to top, rgba(170,255,68,0.25), rgba(170,255,68,0.05))'
                    : 'linear-gradient(to top, rgba(255,255,255,0.08), rgba(255,255,255,0.02))',
                  borderTop: `1px solid ${isLime ? 'var(--lime)' : 'rgba(255,255,255,0.2)'}`,
                  borderRadius: '2px 2px 0 0',
                  boxShadow: isLime ? '0 -10px 30px rgba(170,255,68,0.2)' : 'none',
                  position: 'relative',
                }}
              >
                {Array.from({ length: Math.floor(h / 30) }).map((__, floor) => (
                  <div
                    key={floor}
                    style={{
                      position: 'absolute',
                      bottom: floor * 30 + 5,
                      left: 3,
                      right: 3,
                      height: 2,
                      background: isLime
                        ? 'rgba(170,255,68,0.4)'
                        : 'rgba(255,255,255,0.06)',
                    }}
                  />
                ))}
              </div>
            );
          })}
        </div>
      </div>

      {/* Brand reveal elements */}
      <div
        id="reveal-black"
        style={{
          position: 'absolute',
          inset: 0,
          background: '#050505',
          opacity: 0,
          zIndex: 20,
          pointerEvents: 'none',
        }}
      />
      <div
        id="logo-reveal"
        style={{
          position: 'absolute',
          inset: 0,
          zIndex: 25,
          pointerEvents: 'none',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div
          id="logo-mark"
          style={{
            width: 120,
            height: 120,
            marginBottom: 40,
            position: 'relative',
            opacity: 0,
          }}
        >
          <div
            id="logo-line-h"
            style={{
              position: 'absolute',
              top: '50%',
              left: 0,
              right: 0,
              height: 2,
              background: 'var(--lime)',
              transformOrigin: 'center',
              boxShadow: '0 0 16px var(--lime)',
            }}
          />
          <svg viewBox="0 0 120 120" style={{ position: 'absolute', inset: 0 }}>
            <g stroke="var(--lime)" strokeWidth="6" strokeLinecap="round">
              <line x1="60" y1="10" x2="60" y2="45" />
              <line x1="60" y1="75" x2="60" y2="110" />
              <line x1="10" y1="60" x2="45" y2="60" />
              <line x1="75" y1="60" x2="110" y2="60" />
              <line x1="25" y1="25" x2="48" y2="48" />
              <line x1="72" y1="72" x2="95" y2="95" />
              <line x1="95" y1="25" x2="72" y2="48" />
              <line x1="48" y1="72" x2="25" y2="95" />
            </g>
            <rect
              x="48"
              y="48"
              width="24"
              height="24"
              fill="none"
              stroke="var(--lime)"
              strokeWidth="2"
              rx="2"
            />
          </svg>
        </div>
        <div
          id="logo-wordmark"
          style={{
            fontSize: 160,
            fontWeight: 700,
            letterSpacing: '-0.05em',
            lineHeight: 1,
            opacity: 0,
          }}
        >
          CUPRIC <span className="lime-accent" style={{ fontStyle: 'italic' }}>AI</span>
        </div>
      </div>

      {/* Final card */}
      <div
        id="final-card"
        style={{
          position: 'absolute',
          inset: 0,
          zIndex: 30,
          pointerEvents: 'none',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          opacity: 0,
        }}
      >
        <div id="final-logo" style={{ marginBottom: 60, width: 480 }}>
          <CupricLogo />
        </div>
        <div
          id="final-tagline"
          style={{
            fontSize: 44,
            fontWeight: 500,
            letterSpacing: '-0.02em',
            marginBottom: 80,
            color: 'rgba(255,255,255,0.85)',
          }}
        >
          INTELLIGENCE FOR PEOPLE WHO <span className="lime-accent">BUILD</span>.
        </div>
        <div
          id="final-cta"
          style={{
            fontSize: 22,
            letterSpacing: '0.3em',
            color: 'rgba(170,255,68,0.8)',
            textTransform: 'uppercase',
            fontFamily: 'JetBrains Mono',
            textShadow: '0 0 20px rgba(170,255,68,0.3)',
          }}
        >
          CREATE WITHOUT LIMITS.
        </div>
      </div>

      {/* Progress bar */}
      {started && (
        <div
          className="progress-bar"
          style={{
            animation: 'progressFill 40s linear forwards',
          }}
        />
      )}

      <style>{`
        @keyframes progressFill {
          from { transform: scaleX(0); }
          to { transform: scaleX(1); }
        }
        @keyframes blink {
          0%, 50% { opacity: 1; }
          51%, 100% { opacity: 0; }
        }
      `}</style>

      {/* Start overlay */}
      {!started && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: '#050505',
            zIndex: 500,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column',
            gap: 30,
          }}
        >
          <div style={{ width: 160 }}>
            <CupricLogo />
          </div>
          <div
            style={{
              fontSize: 24,
              color: 'rgba(255,255,255,0.6)',
              letterSpacing: '0.3em',
              textTransform: 'uppercase',
              fontFamily: 'JetBrains Mono',
            }}
          >
            Brand Film · 40s
          </div>
          <button
            onClick={() => setStarted(true)}
            style={{
              marginTop: 40,
              padding: '18px 48px',
              background: 'var(--lime)',
              color: '#050505',
              border: 'none',
              borderRadius: 100,
              fontSize: 18,
              fontWeight: 700,
              cursor: 'pointer',
              letterSpacing: '-0.01em',
              boxShadow:
                '0 0 40px rgba(170,255,68,0.4), 0 0 80px rgba(170,255,68,0.2)',
              fontFamily: 'Inter, sans-serif',
            }}
          >
            Play Film
          </button>
          <div
            style={{
              fontSize: 13,
              color: 'rgba(255,255,255,0.3)',
              marginTop: 20,
              fontFamily: 'JetBrains Mono',
            }}
          >
            INTELLIGENCE FOR PEOPLE WHO BUILD.
          </div>
        </div>
      )}
    </div>
  );
}

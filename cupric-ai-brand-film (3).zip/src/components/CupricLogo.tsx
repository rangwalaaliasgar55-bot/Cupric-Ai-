import { forwardRef } from 'react';

export const CupricLogo = forwardRef<SVGSVGElement, { animated?: boolean }>(
  ({ animated = false }, ref) => {
    return (
      <svg
        ref={ref}
        viewBox="0 0 600 160"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        style={{ width: '100%', height: '100%' }}
      >
        {/* Symbol: 8-pointed asterisk with small center square */}
        <g id="cupric-mark">
          {/* 4 long arms */}
          <rect
            x="89"
            y="20"
            width="22"
            height="120"
            fill={animated ? '#aaff44' : '#aaff44'}
            style={{ transformOrigin: '100px 80px' }}
          />
          <rect
            x="40"
            y="69"
            width="120"
            height="22"
            fill="#aaff44"
            style={{ transformOrigin: '100px 80px' }}
          />
          <rect
            x="62"
            y="41"
            width="22"
            height="78"
            fill="#aaff44"
            transform="rotate(45 100 80)"
            style={{ transformOrigin: '100px 80px' }}
          />
          <rect
            x="62"
            y="41"
            width="22"
            height="78"
            fill="#aaff44"
            transform="rotate(-45 100 80)"
            style={{ transformOrigin: '100px 80px' }}
          />
          {/* Center square cutout - we overlay black/dark square */}
          <rect x="88" y="68" width="24" height="24" fill="#0f1a05" rx="2" />
          {/* Thin white/light edges for depth */}
        </g>

        {/* CUPRIC text */}
        <g id="cupric-word">
          <text
            x="185"
            y="112"
            fill="white"
            fontFamily="Inter, sans-serif"
            fontSize="110"
            fontWeight="700"
            letterSpacing="-4"
          >
            Cupric
          </text>
        </g>
        {/* AI text */}
        <g id="cupric-ai">
          <text
            x="495"
            y="112"
            fill="#aaff44"
            fontFamily="Inter, sans-serif"
            fontSize="110"
            fontWeight="700"
            letterSpacing="-4"
          >
            AI
          </text>
        </g>
      </svg>
    );
  }
);

CupricLogo.displayName = 'CupricLogo';

// Line-drawn version for the reveal
export function CupricLogoOutline() {
  return (
    <svg
      viewBox="0 0 600 160"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width: '100%', height: '100%' }}
    >
      {/* Symbol paths */}
      <g stroke="#aaff44" strokeWidth="2" strokeLinecap="round">
        {/* vertical */}
        <line x1="100" y1="20" x2="100" y2="68" />
        <line x1="100" y1="92" x2="100" y2="140" />
        {/* horizontal */}
        <line x1="40" y1="80" x2="88" y2="80" />
        <line x1="112" y1="80" x2="160" y2="80" />
        {/* diagonal 45 */}
        <line x1="57" y1="37" x2="79" y2="59" />
        <line x1="121" y1="101" x2="143" y2="123" />
        {/* diagonal -45 */}
        <line x1="143" y1="37" x2="121" y2="59" />
        <line x1="79" y1="101" x2="57" y2="123" />
        {/* center square */}
        <rect x="88" y="68" width="24" height="24" stroke="#aaff44" strokeWidth="1.5" />
      </g>
      {/* Text outlines will be drawn with CSS stroke-dashoffset */}
    </svg>
  );
}

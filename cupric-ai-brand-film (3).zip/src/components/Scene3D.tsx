import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame, useThree } from '@react-three/fiber';
import {
  particleVertexShader,
  particleFragmentShader,
} from '../shaders/particleShader';

const PARTICLE_COUNT = 6000;

// Pre-compute logo target positions for mode 11
function generateLogoTargets(count: number): Float32Array {
  const targets = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const r = i / count;
    let x = 0, y = 0, z = 0;
    if (r < 0.15) {
      // Symbol (asterisk)
      const sub = r / 0.15;
      const arm = Math.floor(sub * 8);
      const localR = (sub * 8) % 1;
      const len = localR * 0.85;
      const ang = (arm / 8) * Math.PI * 2;
      x = Math.cos(ang) * len * 1.2;
      y = Math.sin(ang) * len * 1.2;
      if (Math.abs(x) < 0.12 && Math.abs(y) < 0.12) {
        const edge = Math.floor(localR * 4);
        const l = localR * 4 - edge;
        if (edge === 0) { x = -0.12 + l * 0.24; y = -0.12; }
        else if (edge === 1) { x = 0.12; y = -0.12 + l * 0.24; }
        else if (edge === 2) { x = 0.12 - l * 0.24; y = 0.12; }
        else { x = -0.12; y = 0.12 - l * 0.24; }
      }
      z = (Math.random() - 0.5) * 0.05;
    } else if (r < 0.75) {
      // CUPRIC word
      const lr = (r - 0.15) / 0.6;
      x = -2.4 + lr * 4.5;
      const charPos = lr * 6;
      const charIdx = Math.floor(charPos);
      const h = [1.0, 1.0, 1.0, 1.0, 0.9, 1.0][Math.min(charIdx, 5)] * 0.7;
      y = (Math.random() - 0.5) * h;
      z = (Math.random() - 0.5) * 0.05;
      if (charIdx === 4) {
        x = -2.4 + lr * 4.5 + (Math.random() - 0.5) * 0.04;
      }
    } else {
      // AI
      const lr = (r - 0.75) / 0.25;
      x = 2.6 + lr * 1.2;
      y = (Math.random() - 0.5) * 0.7;
      z = (Math.random() - 0.5) * 0.05;
    }
    targets[i * 3] = x;
    targets[i * 3 + 1] = y;
    targets[i * 3 + 2] = z;
  }
  return targets;
}

export function ParticleField({
  uniformsRef,
}: {
  uniformsRef: React.MutableRefObject<{
    uTime: { value: number };
    uMode: { value: number };
    uProgress: { value: number };
    uGlobalTime: { value: number };
    uExplode: { value: number };
    uScale: { value: number };
    uPointSize: { value: number };
    uCameraPos: { value: THREE.Vector3 };
  } | null>;
}) {
  const pointsRef = useRef<THREE.Points>(null);
  const { camera } = useThree();

  const { positions, targetPositions, colors, sizes, randoms, groups } = useMemo(() => {
    const positions = new Float32Array(PARTICLE_COUNT * 3);
    const targetPositions = new Float32Array(PARTICLE_COUNT * 3);
    const colors = new Float32Array(PARTICLE_COUNT * 3);
    const sizes = new Float32Array(PARTICLE_COUNT);
    const randoms = new Float32Array(PARTICLE_COUNT);
    const groups = new Float32Array(PARTICLE_COUNT);

    const logoTargets = generateLogoTargets(PARTICLE_COUNT);

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const radius = 0.1 + Math.random() * 0.2;
      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = radius * Math.cos(phi);

      targetPositions[i * 3] = logoTargets[i * 3];
      targetPositions[i * 3 + 1] = logoTargets[i * 3 + 1];
      targetPositions[i * 3 + 2] = logoTargets[i * 3 + 2];

      randoms[i] = Math.random();
      groups[i] = Math.random();

      if (Math.random() < 0.22) {
        colors[i * 3] = 0.67;
        colors[i * 3 + 1] = 1.0;
        colors[i * 3 + 2] = 0.27;
      } else {
        const shade = 0.75 + Math.random() * 0.25;
        colors[i * 3] = shade;
        colors[i * 3 + 1] = shade;
        colors[i * 3 + 2] = shade;
      }

      sizes[i] = 0.8 + Math.random() * 1.5;
    }

    return { positions, targetPositions, colors, sizes, randoms, groups };
  }, []);

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uMode: { value: 0 },
      uProgress: { value: 0 },
      uGlobalTime: { value: 0 },
      uExplode: { value: 0 },
      uScale: { value: 1.0 },
      uPointSize: { value: 1.2 },
      uCameraPos: { value: new THREE.Vector3() },
    }),
    []
  );

  uniformsRef.current = uniforms;

  useFrame((_, delta) => {
    uniforms.uGlobalTime.value += delta;
    uniforms.uTime.value += delta;
    uniforms.uCameraPos.value.copy(camera.position);
  });

  return (
    <points ref={pointsRef} frustumCulled={false}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
          count={PARTICLE_COUNT}
        />
        <bufferAttribute
          attach="attributes-aPositionTarget"
          args={[targetPositions, 3]}
          count={PARTICLE_COUNT}
        />
        <bufferAttribute
          attach="attributes-aColor"
          args={[colors, 3]}
          count={PARTICLE_COUNT}
        />
        <bufferAttribute
          attach="attributes-aSize"
          args={[sizes, 1]}
          count={PARTICLE_COUNT}
        />
        <bufferAttribute
          attach="attributes-aRandom"
          args={[randoms, 1]}
          count={PARTICLE_COUNT}
        />
        <bufferAttribute
          attach="attributes-aGroup"
          args={[groups, 1]}
          count={PARTICLE_COUNT}
        />
      </bufferGeometry>
      <shaderMaterial
        vertexShader={particleVertexShader}
        fragmentShader={particleFragmentShader}
        uniforms={uniforms}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

// Line layer for connections
export function LineLayer({
  uniformsRef,
}: {
  uniformsRef: React.MutableRefObject<{
    uTime: { value: number };
    uMode: { value: number };
    uProgress: { value: number };
    uColor: { value: THREE.Color };
  } | null>;
}) {
  const lineRef = useRef<THREE.LineSegments>(null);
  const LINE_COUNT = 400;

  const { linePositions, lineTargets, lineRandoms } = useMemo(() => {
    const positions = new Float32Array(LINE_COUNT * 2 * 3);
    const targets = new Float32Array(LINE_COUNT * 2 * 3);
    const randoms = new Float32Array(LINE_COUNT * 2);
    for (let i = 0; i < LINE_COUNT; i++) {
      for (let j = 0; j < 2; j++) {
        const idx = (i * 2 + j) * 3;
        positions[idx] = (Math.random() - 0.5) * 80;
        positions[idx + 1] = (Math.random() - 0.5) * 40;
        positions[idx + 2] = (Math.random() - 0.5) * 80;
        targets[idx] = (Math.random() - 0.5) * 40;
        targets[idx + 1] = (Math.random() - 0.5) * 20;
        targets[idx + 2] = (Math.random() - 0.5) * 40;
      }
      randoms[i * 2] = Math.random();
      randoms[i * 2 + 1] = Math.random();
    }
    return { linePositions: positions, lineTargets: targets, lineRandoms: randoms };
  }, []);

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uMode: { value: 0 },
      uProgress: { value: 0 },
      uColor: { value: new THREE.Color(0xffffff) },
    }),
    []
  );

  uniformsRef.current = uniforms;

  useFrame((_, delta) => {
    uniforms.uTime.value += delta;
  });

  return (
    <lineSegments ref={lineRef} frustumCulled={false}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[linePositions, 3]}
          count={LINE_COUNT * 2}
        />
        <bufferAttribute
          attach="attributes-aTarget"
          args={[lineTargets, 3]}
          count={LINE_COUNT * 2}
        />
        <bufferAttribute
          attach="attributes-aRandom"
          args={[lineRandoms, 1]}
          count={LINE_COUNT * 2}
        />
      </bufferGeometry>
      <shaderMaterial
        vertexShader={`
          attribute vec3 aTarget;
          attribute float aRandom;
          uniform float uTime;
          uniform float uMode;
          uniform float uProgress;
          varying float vAlpha;
          void main() {
            vec3 pos = position;
            float networkMode = smoothstep(5.8, 6.2, uMode) - smoothstep(8.8, 9.2, uMode);
            float connectMode = smoothstep(20.8, 21.2, uMode) - smoothstep(23.8, 24.2, uMode);
            float splitMode = smoothstep(26.8, 27.2, uMode) - smoothstep(29.8, 30.2, uMode);
            float cityMode = smoothstep(29.8, 30.2, uMode) - smoothstep(32.8, 33.2, uMode);
            float active = max(max(networkMode, connectMode), max(splitMode, cityMode));
            float flow = fract(uTime * 0.15 + aRandom * 3.0);
            vec3 base = mix(position, aTarget, flow);
            if (splitMode > 0.0) {
              float pull = smoothstep(0.4, 1.0, uProgress);
              base.x = mix(base.x, 0.0, pull * 0.9);
              base.y *= 0.8;
              base.z *= 0.3;
            }
            if (cityMode > 0.0) {
              base.y *= 0.3;
              base.z *= 0.6;
            }
            if (connectMode > 0.0) {
              base *= 0.5;
            }
            pos = mix(pos * 80.0, base, active);
            vec4 mv = modelViewMatrix * vec4(pos, 1.0);
            gl_Position = projectionMatrix * mv;
            vAlpha = active * smoothstep(200.0, 50.0, -mv.z);
          }
        `}
        fragmentShader={`
          uniform vec3 uColor;
          varying float vAlpha;
          void main() {
            gl_FragColor = vec4(uColor, vAlpha * 0.35);
          }
        `}
        uniforms={uniforms}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </lineSegments>
  );
}

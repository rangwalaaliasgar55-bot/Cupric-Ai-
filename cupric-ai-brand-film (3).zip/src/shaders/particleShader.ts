// Custom particle shader for Cupric AI brand film
// Supports multiple modes through uniform 'uMode' 0-11

export const particleVertexShader = /* glsl */ `
uniform float uTime;
uniform float uMode;       // Drives particle configuration
uniform float uProgress;   // Generic progress within mode
uniform float uGlobalTime;
uniform float uExplode;    // Explosion amount
uniform float uScale;      // Global scale
uniform vec3 uCameraPos;
uniform float uPointSize;

attribute vec3 aPositionTarget; // Alternative position
attribute vec3 aColor;
attribute float aSize;
attribute float aRandom;
attribute float aGroup; // which group particle belongs to

varying vec3 vColor;
varying float vAlpha;
varying float vRandom;

//
// Description : Array and textureless GLSL 2D/3D/4D simplex 
//               noise functions.
//      Author : Ian McEwan, Ashima Arts.
//
vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 mod289(vec4 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 permute(vec4 x) { return mod289(((x*34.0)+1.0)*x); }
vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }

float snoise(vec3 v){ 
  const vec2 C = vec2(1.0/6.0, 1.0/3.0);
  const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
  vec3 i  = floor(v + dot(v, C.yyy));
  vec3 x0 = v - i + dot(i, C.xxx);
  vec3 g = step(x0.yzx, x0.xyz);
  vec3 l = 1.0 - g;
  vec3 i1 = min(g.xyz, l.zxy);
  vec3 i2 = max(g.xyz, l.zxy);
  vec3 x1 = x0 - i1 + C.xxx;
  vec3 x2 = x0 - i2 + C.yyy;
  vec3 x3 = x0 - D.yyy;
  i = mod289(i);
  vec4 p = permute(permute(permute(
    i.z + vec4(0.0, i1.z, i2.z, 1.0))
  + i.y + vec4(0.0, i1.y, i2.y, 1.0))
  + i.x + vec4(0.0, i1.x, i2.x, 1.0));
  float n_ = 0.142857142857;
  vec3 ns = n_ * D.wyz - D.xzx;
  vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
  vec4 x_ = floor(j * ns.z);
  vec4 y_ = floor(j - 7.0 * x_);
  vec4 x = x_ * ns.x + ns.yyyy;
  vec4 y = y_ * ns.x + ns.yyyy;
  vec4 h = 1.0 - abs(x) - abs(y);
  vec4 b0 = vec4(x.xy, y.xy);
  vec4 b1 = vec4(x.zw, y.zw);
  vec4 s0 = floor(b0)*2.0 + 1.0;
  vec4 s1 = floor(b1)*2.0 + 1.0;
  vec4 sh = -step(h, vec4(0.0));
  vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
  vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;
  vec3 p0 = vec3(a0.xy, h.x);
  vec3 p1 = vec3(a0.zw, h.y);
  vec3 p2 = vec3(a1.xy, h.z);
  vec3 p3 = vec3(a1.zw, h.w);
  vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
  p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
  vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
  m = m * m;
  return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
}

void main() {
  vec3 pos = position;
  float t = uTime;
  float r = aRandom;
  
  // Mode 0: expand from center (0-3s)
  // Mode 1: branching lines (3-6s)
  // Mode 2: network / data viz (6-9s)
  // Mode 3: collapse to point → UI assembly (9-12s)
  // Mode 4: prompt-to-product UI (12-15s)
  // Mode 5: repetition/automation (15-18s)
  // Mode 6: 10x explosion (18-21s)
  // Mode 7: ideas connect (21-24s)
  // Mode 8: kinetic words field (24-27s)
  // Mode 9: human+machine split (27-30s)
  // Mode 10: build what's next / city (30-33s)
  // Mode 11: collapse to logo (33-40s)
  
  float mode0 = 1.0 - smoothstep(2.8, 3.2, uMode);
  float mode1 = smoothstep(2.8, 3.2, uMode) - smoothstep(5.8, 6.2, uMode);
  float mode2 = smoothstep(5.8, 6.2, uMode) - smoothstep(8.8, 9.2, uMode);
  float mode3 = smoothstep(8.8, 9.2, uMode) - smoothstep(11.8, 12.2, uMode);
  float mode4 = smoothstep(11.8, 12.2, uMode) - smoothstep(14.8, 15.2, uMode);
  float mode5 = smoothstep(14.8, 15.2, uMode) - smoothstep(17.8, 18.2, uMode);
  float mode6 = smoothstep(17.8, 18.2, uMode) - smoothstep(20.8, 21.2, uMode);
  float mode7 = smoothstep(20.8, 21.2, uMode) - smoothstep(23.8, 24.2, uMode);
  float mode8 = smoothstep(23.8, 24.2, uMode) - smoothstep(26.8, 27.2, uMode);
  float mode9 = smoothstep(26.8, 27.2, uMode) - smoothstep(29.8, 30.2, uMode);
  float mode10 = smoothstep(29.8, 30.2, uMode) - smoothstep(32.8, 33.2, uMode);
  float mode11 = smoothstep(32.8, 33.2, uMode);
  
  // Compute position for each mode
  vec3 p = vec3(0.0);
  
  // MODE 0: Expanding field from center — spherical distribution, push out
  // For each particle a start and end position along a ray
  {
    // Target is on a procedural 3D lattice expanding
    vec3 target = normalize(pos + vec3(r*0.2, r*0.3-0.15, r*0.25)) * mix(8.0, 55.0, uProgress);
    // Add noise for structure
    float n = snoise(pos * 0.3 + t * 0.05);
    target += vec3(n, snoise(pos*0.3+5.0), snoise(pos*0.3+10.0)) * 2.5;
    p += target * mode0;
  }
  
  // MODE 1: Branching paths — particles form lines branching outward
  {
    // Place along radial lines with branches
    float branchAngle = floor(aGroup * 8.0) * (3.14159 * 2.0 / 8.0);
    float depth = fract(aGroup * 13.37) * 50.0;
    float branchSplit = step(0.5, fract(aGroup * 7.7)) * 15.0;
    float yJitter = (r - 0.5) * 2.0;
    vec3 target = vec3(
      cos(branchAngle) * depth + cos(branchAngle*2.0) * branchSplit,
      yJitter * 0.8,
      sin(branchAngle) * depth + sin(branchAngle*2.0) * branchSplit
    );
    // animate flow along branches
    float flow = fract(depth * 0.02 + t * 0.08);
    target *= mix(0.8, 1.15, flow);
    p += target * mode1;
  }
  
  // MODE 2: Network - nodes with connecting structures
  {
    // Place nodes in a rough 3D cloud; some form connection lines
    vec3 nodePos = pos * 25.0;
    float n1 = snoise(nodePos * 0.08 + vec3(0.0, t*0.03, 0.0));
    nodePos += vec3(n1*3.0, snoise(nodePos*0.1)*2.0, snoise(nodePos*0.1+10.0)*2.0);
    // Connection line particles snap to line between their node and nearest neighbor
    p += nodePos * mode2;
  }
  
  // MODE 3: Collapse to center then expand to UI grid
  {
    // Early part: collapse toward origin; late: form grid
    float collapseAmt = sin(clamp(uProgress, 0.0, 0.5) * 3.14159);
    vec3 collapsed = pos * (1.0 - collapseAmt);
    float uiAmt = smoothstep(0.5, 1.0, uProgress);
    // Grid of points representing UI panels
    float gridIdx = r * 2000.0;
    float gx = mod(gridIdx, 40.0) - 20.0;
    float gy = floor(gridIdx / 40.0) * 0.5 - 12.0;
    vec3 uiPos = vec3(gx * 4.5, gy, (r-0.5) * 2.0);
    vec3 target = mix(collapsed * 0.1, uiPos, uiAmt);
    p += target * mode3;
  }
  
  // MODE 4: UI assembly - particles form UI card edges
  {
    // Place on rectangular card outlines positioned around the screen
    float pIdx = floor(r * 60.0);
    float cardPerRow = 6.0;
    float cx = mod(pIdx, cardPerRow) - (cardPerRow-1.0)/2.0;
    float cy = floor(pIdx / cardPerRow) - 4.0;
    float edgeR = fract(r * 199.0);
    float side = floor(edgeR * 4.0);
    float along = fract(edgeR * 4.0);
    float cw = 6.0 + fract(aGroup*9.0) * 3.0;
    float ch = 3.5 + fract(aGroup*11.0) * 1.5;
    vec3 cardPos = vec3(cx * 8.0, cy * 6.0, (r-0.5)*0.5);
    // assemble with progressive delay per card
    float delay = fract(aGroup*3.7) * 0.5;
    float appear = smoothstep(delay, delay + 0.3, uProgress);
    if (side < 0.5) cardPos += vec3(mix(-cw, cw, along) * appear, -ch*appear, 0);
    else if (side < 1.5) cardPos += vec3(cw*appear, mix(-ch, ch, along)*appear, 0);
    else if (side < 2.5) cardPos += vec3(mix(cw, -cw, along)*appear, ch*appear, 0);
    else cardPos += vec3(-cw*appear, mix(ch, -ch, along)*appear, 0);
    p += cardPos * mode4;
  }
  
  // MODE 5: Repetition - multiple windows move mechanically, then collapse
  {
    float nWindows = 8.0;
    float wIdx = floor(aGroup * nWindows);
    float localR = r;
    // Positions: grid of windows that jitter mechanically then compress
    float row = floor(wIdx / 4.0);
    float col = mod(wIdx, 4.0);
    vec3 winPos = vec3(
      (col - 1.5) * (8.0 + sin(t*2.0 + wIdx)*0.3),
      (row - 0.5) * (8.0 + cos(t*2.5 + wIdx)*0.2),
      (wIdx - 4.0) * 0.3
    );
    // After uProgress 0.5 they collapse into one flow
    float collapseP = smoothstep(0.4, 0.8, uProgress);
    winPos = mix(winPos, vec3(0,0, -wIdx * 0.5 + localR * 2.0), collapseP);
    p += winPos * mode5;
  }
  
  // MODE 6: 10X explosion - freeze then burst
  {
    // Before burst: form a tight rectangular block (like a solid "block" of the numerals), after explode outward
    float burst = smoothstep(0.3, 0.55, uProgress);
    // Arrange particles into a big rectangular slab
    float bx = (fract(r * 137.0) - 0.5) * 18.0;
    float by = (fract(r * 251.0) - 0.5) * 10.0;
    float bz = (fract(r * 91.0) - 0.5) * 0.6;
    vec3 shapePos = vec3(bx, by, bz);
    // Explode outward radially
    float ang = t * 0.4 + r * 6.28;
    float rad = mix(0.0, 70.0, burst) + r * 20.0;
    vec3 expPos = vec3(cos(ang)*rad, (r-0.5)*25.0 + sin(ang)*rad*0.35, sin(ang*0.8)*rad);
    vec3 target = mix(shapePos, expPos, burst);
    p += target * mode6;
  }
  
  // MODE 7: Ideas connect - clusters form and connect
  {
    float clusterId = floor(aGroup * 6.0);
    float angC = clusterId * 1.1;
    float radC = 15.0 + sin(clusterId * 2.1) * 8.0;
    vec3 clusterCenter = vec3(cos(angC)*radC, sin(angC*0.7)*5.0, sin(angC)*radC);
    // particles orbiting cluster
    float localR = r;
    float orbAng = t * (0.3 + clusterId*0.1) + localR * 6.28;
    float orbR = 1.0 + localR * 4.0;
    vec3 orb = vec3(cos(orbAng)*orbR, sin(orbAng*1.3)*orbR, sin(orbAng)*orbR);
    vec3 target = clusterCenter + orb;
    // Connection: uProgress pulls clusters together
    float pull = smoothstep(0.3, 1.0, uProgress);
    target = mix(target, target * 0.3 + vec3(0, sin(clusterId)*2.0, 0), pull);
    p += target * mode7;
  }
  
  // MODE 8: Kinetic typography field - words spread then compress
  {
    // 6 words: THINK BUILD TEST CREATE ITERATE LAUNCH
    float wordId = floor(aGroup * 6.0);
    float wAng = wordId * 1.047 + t * 0.15 * (mod(wordId, 2.0) - 0.5);
    float wR = 12.0 + sin(wordId*1.3 + t*0.4) * 8.0;
    vec3 wordCenter = vec3(cos(wAng)*wR, sin(wAng*0.8)*wR*0.3, (wordId-3.0)*2.0);
    // particles scattered around each word center
    vec3 scatter = vec3(
      (fract(r*23.0) - 0.5) * 18.0,
      (fract(r*31.0) - 0.5) * 6.0,
      (fract(r*17.0) - 0.5) * 6.0
    );
    vec3 target = wordCenter + scatter;
    // Compress into center at the end
    float compress = smoothstep(0.6, 1.0, uProgress);
    target = mix(target, vec3(0,0, wordId*0.1) + scatter * (1.0 - compress) * 0.4, compress);
    p += target * mode8;
  }
  
  // MODE 9: Human + Machine split screen
  {
    float side = step(0.5, aGroup); // 0 = left (human), 1 = right (machine)
    float dir = side - 0.5;
    vec3 target;
    if (side < 0.5) {
      // Human side: soft, organic cloud, a few elegant curves
      float ang = r * 31.4 + t * 0.1;
      float rr = 6.0 + sin(ang*1.3 + aRandom*6.28) * 4.0;
      target = vec3(-18.0 + cos(ang)*rr, sin(ang)*rr*0.5, sin(ang*0.7)*rr*0.4);
    } else {
      // Machine side: grid, precise rows
      float gx = mod(floor(r*400.0), 15.0) - 7.0;
      float gy = floor(r*400.0 / 15.0) - 13.0;
      target = vec3(18.0 + gx*1.2, gy*0.8, (r-0.5)*2.0);
    }
    // Sync: lines meet at center
    float sync = smoothstep(0.4, 1.0, uProgress);
    target = mix(target, vec3(dir * 18.0 * (1.0 - sync), target.y * 0.5, target.z * 0.5), sync);
    p += target * mode9;
  }
  
  // MODE 10: Build what's next - procedural city/ecosystem
  {
    // Procedural city-like blocks arranged in a grid, building up
    float blockId = floor(r * 400.0);
    float bx = mod(blockId, 20.0) - 10.0;
    float bz = floor(blockId / 20.0) - 10.0;
    float dist = length(vec2(bx, bz));
    float maxDist = 14.0;
    float appear = smoothstep(maxDist, 1.0, dist) * uProgress;
    float noiseH = snoise(vec3(bx*0.4, bz*0.4, 0.0));
    float height = appear * (2.0 + noiseH * 7.0);
    // stack vertically based on aGroup (which level)
    float level = aGroup * 12.0;
    // Only show particles below the current height (growing effect)
    float show = step(level * 0.5, height);
    vec3 target = vec3(bx * 2.2, level * 0.7 - 10.0 + appear * 5.0, bz * 2.2);
    // fade out particles above current height by moving them down/invisible
    target.y *= show;
    target.y += appear * 8.0;
    p += target * mode10;
  }
  
  // MODE 11: Collapse to logo
  {
    float collapse = smoothstep(0.0, 0.3, uProgress);
    float form = smoothstep(0.3, 0.7, uProgress);
    // Start from wherever (use pos*10), collapse to center, then form logo shape via aPositionTarget
    vec3 startPos = pos * 40.0;
    vec3 collapsed = startPos * (1.0 - collapse);
    // After collapse, place into logo positions
    // aPositionTarget encoded logo layout (scaled down)
    vec3 logoPos = aPositionTarget * 4.0;
    vec3 target = mix(collapsed, logoPos, form);
    p += target * mode11;
  }
  
  // Global explode for transitions
  p += vec3(
    sin(r*6.28 + t*0.5),
    cos(r*6.28 + t*0.7),
    sin(r*6.28*1.3 + t*0.3)
  ) * uExplode;
  
  vec4 mvPos = modelViewMatrix * vec4(p, 1.0);
  gl_Position = projectionMatrix * mvPos;
  
  float size = aSize * uPointSize;
  // Depth-based size
  float depth = -mvPos.z;
  size *= 200.0 / max(depth, 1.0);
  gl_PointSize = size;
  
  // Color
  vec3 col = aColor;
  // Lime for group 0-ish, white otherwise
  vColor = col;
  
  // Alpha - fade near far clip, and fade during transitions
  float fadeStart = 180.0;
  float fadeEnd = 250.0;
  float alphaFade = smoothstep(fadeEnd, fadeStart, depth);
  vAlpha = alphaFade;
  vRandom = aRandom;
}
`;

export const particleFragmentShader = /* glsl */ `
uniform float uMode;
varying vec3 vColor;
varying float vAlpha;
varying float vRandom;

void main() {
  // Circular point
  vec2 uv = gl_PointCoord - 0.5;
  float d = length(uv);
  if (d > 0.5) discard;
  float a = smoothstep(0.5, 0.0, d);
  a = pow(a, 1.8);
  vec3 col = vColor;
  // Subtle inner glow
  col += vec3(0.1, 0.15, 0.05) * (1.0 - d) * step(0.5, vColor.g - vColor.r);
  gl_FragColor = vec4(col, a * vAlpha);
}
`;

// Line shader for glowing connections
export const lineVertexShader = /* glsl */ `
attribute vec3 aTarget;
attribute float aRandom;
uniform float uTime;
uniform float uMode;
uniform float uProgress;

void main() {
  vec3 pos = position;
  
  float mode2 = smoothstep(5.8, 6.2, uMode) - smoothstep(8.8, 9.2, uMode);
  float mode7 = smoothstep(20.8, 21.2, uMode) - smoothstep(23.8, 24.2, uMode);
  float mode9 = smoothstep(26.8, 27.2, uMode) - smoothstep(29.8, 30.2, uMode);
  
  // For network mode: lines connect between node positions (simplified - straight lines pulsing)
  vec3 target = aTarget;
  
  // Animated flow
  float flow = fract(uTime * 0.1 + aRandom);
  pos = mix(position, target, flow);
  
  vec4 mvPos = modelViewMatrix * vec4(pos, 1.0);
  gl_Position = projectionMatrix * mvPos;
}
`;

export const lineFragmentShader = /* glsl */ `
uniform vec3 uColor;
void main() {
  gl_FragColor = vec4(uColor, 0.12);
}
`;

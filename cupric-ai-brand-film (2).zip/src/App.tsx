import FilmPlayer from './film/FilmPlayer';

export default function App() {
  return <FilmPlayer />;
}

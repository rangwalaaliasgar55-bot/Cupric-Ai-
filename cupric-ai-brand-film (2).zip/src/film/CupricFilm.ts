import { VisualWorld } from './VisualWorld';

export const FILM_WIDTH = 1920;
export const FILM_HEIGHT = 1080;
export const FILM_DURATION = 40;
export const FILM_FPS = 30;

export const CHAPTERS = [
  { start: 0, end: 3, label: 'The hook' },
  { start: 3, end: 6, label: 'Infinite directions' },
  { start: 6, end: 9, label: 'Intelligence in motion' },
  { start: 9, end: 12, label: 'Build faster' },
  { start: 12, end: 15, label: 'Prompt to product' },
  { start: 15, end: 18, label: 'Less repetition' },
  { start: 18, end: 21, label: '10x' },
  { start: 21, end: 24, label: 'Ideas connect' },
  { start: 24, end: 27, label: 'Make noise' },
  { start: 27, end: 30, label: 'Human + machine' },
  { start: 30, end: 33, label: "Build what's next" },
  { start: 33, end: 36, label: 'Brand reveal' },
  { start: 36, end: 38, label: 'The statement' },
  { start: 38, end: 40, label: 'End card' },
];

const W = FILM_WIDTH;
const H = FILM_HEIGHT;
const LIME = '#b6fa82';
const WHITE = '#f2f4ef';
const DIM = '#89978a';
const DARK = '#060906';
const TAU = Math.PI * 2;
const clamp = (n: number, a = 0, b = 1) => Math.max(a, Math.min(b, n));
const mix = (a: number, b: number, p: number) => a + (b - a) * p;
const ease = (n: number) => {
  const v = clamp(n);
  return v * v * (3 - 2 * v);
};
const out = (n: number) => 1 - Math.pow(1 - clamp(n), 3);
const rand = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
const visibility = (t: number, start: number, end: number, enter = 0.35, exit = 0.28) =>
  ease((t - start) / enter) * (1 - ease((t - end) / exit));

type TextOptions = {
  size: number;
  weight?: number;
  color?: string;
  tracking?: number;
  align?: 'left' | 'center' | 'right';
  alpha?: number;
};

/** All typography and interface elements are drawn into the output canvas, not DOM overlays. */
export class CupricFilm {
  private ctx: CanvasRenderingContext2D;
  private world: VisualWorld | null = null;
  private grain: HTMLCanvasElement;
  private fallbackDots: { x: number; y: number; r: number }[] = [];

  constructor(canvas: HTMLCanvasElement) {
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Canvas 2D is unavailable.');
    this.ctx = ctx;
    try {
      this.world = new VisualWorld();
    } catch (error) {
      console.warn('WebGL unavailable; using the canvas film fallback.', error);
    }
    for (let i = 0; i < 440; i++) {
      this.fallbackDots.push({ x: rand(i * 3) * W, y: rand(i * 5) * H, r: 0.5 + rand(i * 7) * 1.6 });
    }
    this.grain = document.createElement('canvas');
    this.grain.width = 256;
    this.grain.height = 256;
    const g = this.grain.getContext('2d')!;
    const image = g.createImageData(256, 256);
    for (let i = 0; i < image.data.length; i += 4) {
      const value = rand(i * 0.741) > 0.5 ? 220 : 15;
      image.data[i] = value;
      image.data[i + 1] = value;
      image.data[i + 2] = value;
      image.data[i + 3] = 12 + Math.floor(rand(i) * 15);
    }
    g.putImageData(image, 0, 0);
  }

  dispose() {
    this.world?.dispose();
  }

  render(time: number) {
    const t = clamp(time, 0, FILM_DURATION);
    const c = this.ctx;
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.globalCompositeOperation = 'source-over';
    c.globalAlpha = 1;
    c.filter = 'none';
    c.fillStyle = '#050705';
    c.fillRect(0, 0, W, H);
    if (t >= FILM_DURATION) return;

    const chapter = CHAPTERS.findIndex((item) => t >= item.start && t < item.end);
    const scene = Math.max(0, chapter);
    const local = t - CHAPTERS[scene].start;

    const centerGlow = c.createRadialGradient(960, 520, 40, 960, 520, 980);
    const light = scene === 3 || scene === 4 ? 0.13 : scene === 6 || scene >= 11 ? 0.025 : 0.09;
    centerGlow.addColorStop(0, `rgba(70, 105, 52, ${light})`);
    centerGlow.addColorStop(0.53, 'rgba(20, 36, 21, 0.05)');
    centerGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
    c.fillStyle = centerGlow;
    c.fillRect(0, 0, W, H);

    if (this.world) {
      c.drawImage(this.world.render(t), 0, 0, W, H);
    } else {
      this.drawFallbackField(t, scene);
    }

    switch (scene) {
      case 0: this.hook(local); break;
      case 1: this.directions(local); break;
      case 2: this.intelligence(local, t); break;
      case 3: this.buildFaster(local); break;
      case 4: this.promptToProduct(local); break;
      case 5: this.lessRepetition(local); break;
      case 6: this.tenTimes(local); break;
      case 7: this.ideasConnect(local); break;
      case 8: this.makeNoise(local); break;
      case 9: this.humanMachine(local, t); break;
      case 10: this.buildNext(local); break;
      case 11: this.brandReveal(local); break;
      case 12: this.brandStatement(local); break;
      case 13: this.endCard(local); break;
    }

    const vignette = c.createRadialGradient(960, 520, 370, 960, 540, 1190);
    vignette.addColorStop(0, 'rgba(0, 0, 0, 0)');
    vignette.addColorStop(0.72, 'rgba(0, 0, 0, 0.1)');
    vignette.addColorStop(1, 'rgba(0, 0, 0, 0.72)');
    c.fillStyle = vignette;
    c.fillRect(0, 0, W, H);
    c.globalAlpha = 0.34;
    const pattern = c.createPattern(this.grain, 'repeat');
    if (pattern) {
      c.fillStyle = pattern;
      c.fillRect(0, 0, W, H);
    }
    c.globalAlpha = 1;
  }

  private drawFallbackField(t: number, scene: number) {
    const c = this.ctx;
    for (let i = 0; i < this.fallbackDots.length; i++) {
      const dot = this.fallbackDots[i];
      const x = (dot.x + t * (scene === 0 || scene === 1 ? 100 : 22)) % W;
      const y = dot.y + Math.sin(t * 0.8 + i) * 16;
      c.fillStyle = i % 11 === 0 ? 'rgba(182,250,130,.5)' : 'rgba(230,240,225,.22)';
      c.fillRect(x, y, dot.r, dot.r);
    }
  }

  private font(size: number, weight = 700) {
    this.ctx.font = `${weight} ${size}px Manrope, Inter, Arial, sans-serif`;
    this.ctx.textBaseline = 'alphabetic';
  }

  private textWidth(text: string, size: number, weight = 700, tracking = 0) {
    this.font(size, weight);
    return Array.from(text).reduce((width, letter) => width + this.ctx.measureText(letter).width + tracking, -tracking);
  }

  private text(text: string, x: number, y: number, options: TextOptions) {
    const c = this.ctx;
    const { size, weight = 700, color = WHITE, tracking = 0, align = 'left', alpha = 1 } = options;
    c.save();
    c.globalAlpha *= alpha;
    c.fillStyle = color;
    this.font(size, weight);
    const width = this.textWidth(text, size, weight, tracking);
    let cursor = x - (align === 'center' ? width / 2 : align === 'right' ? width : 0);
    for (const letter of text) {
      c.fillText(letter, cursor, y);
      cursor += c.measureText(letter).width + tracking;
    }
    c.restore();
    return width;
  }

  private kinetic(text: string, x: number, y: number, options: TextOptions, progress: number, travel = 72) {
    const c = this.ctx;
    const { size, weight = 800, color = WHITE, tracking = -2, align = 'left', alpha = 1 } = options;
    this.font(size, weight);
    const width = this.textWidth(text, size, weight, tracking);
    let cursor = x - (align === 'center' ? width / 2 : align === 'right' ? width : 0);
    const letters = Array.from(text);
    for (let i = 0; i < letters.length; i++) {
      const letter = letters[i];
      const p = out((progress - i / letters.length * 0.43) / 0.57);
      c.save();
      c.globalAlpha *= p * alpha;
      c.fillStyle = color;
      this.font(size, weight);
      c.translate(cursor + (1 - p) * -26, y + (1 - p) * travel);
      c.scale(0.94 + p * 0.06, 0.94 + p * 0.06);
      c.fillText(letter, 0, 0);
      c.restore();
      cursor += c.measureText(letter).width + tracking;
    }
  }

  private rule(x: number, y: number, width: number, alpha = 0.35, color = LIME) {
    const c = this.ctx;
    c.save();
    c.globalAlpha *= alpha;
    c.fillStyle = color;
    c.fillRect(x, y, Math.max(0, width), 1.5);
    c.restore();
  }

  private glow(x: number, y: number, radius: number, alpha = 0.6) {
    const c = this.ctx;
    const gradient = c.createRadialGradient(x, y, 0, x, y, radius);
    gradient.addColorStop(0, `rgba(185, 255, 133, ${alpha})`);
    gradient.addColorStop(0.08, `rgba(160, 240, 115, ${alpha * 0.37})`);
    gradient.addColorStop(0.42, `rgba(115, 205, 75, ${alpha * 0.08})`);
    gradient.addColorStop(1, 'rgba(115, 205, 75, 0)');
    c.fillStyle = gradient;
    c.fillRect(x - radius, y - radius, radius * 2, radius * 2);
  }

  private panel(x: number, y: number, w: number, h: number, fill = '#101510', stroke = '#303d31', radius = 12) {
    const c = this.ctx;
    c.beginPath();
    c.roundRect(x, y, w, h, radius);
    c.fillStyle = fill;
    c.fill();
    c.strokeStyle = stroke;
    c.lineWidth = 1.5;
    c.stroke();
  }

  private mark(x: number, y: number, size: number, progress = 1, glow = false) {
    const c = this.ctx;
    c.save();
    c.translate(x, y);
    if (glow) {
      c.shadowBlur = 33;
      c.shadowColor = 'rgba(176,255,117,.38)';
    }
    c.strokeStyle = LIME;
    c.lineWidth = size * 0.123;
    c.lineCap = 'butt';
    for (let i = 0; i < 8; i++) {
      const p = clamp((progress * 1.28 - i * 0.045) / 0.55);
      if (!p) continue;
      const a = (i / 8) * TAU;
      const inner = size * 0.14;
      const outer = inner + size * 0.39 * out(p);
      c.beginPath();
      c.moveTo(Math.cos(a) * inner, Math.sin(a) * inner);
      c.lineTo(Math.cos(a) * outer, Math.sin(a) * outer);
      c.stroke();
    }
    c.shadowBlur = 0;
    c.save();
    c.rotate(-0.19);
    c.fillStyle = DARK;
    c.fillRect(-size * 0.12, -size * 0.12, size * 0.24, size * 0.24);
    c.restore();
    c.restore();
  }

  private wordmark(centerX: number, centerY: number, size: number, progress = 1, markSize = size * 0.84) {
    const c = this.ctx;
    const tracking = -size * 0.055;
    const first = this.textWidth('CUPRIC', size, 800, tracking);
    const second = this.textWidth('AI', size, 800, tracking);
    const gap = size * 0.18;
    const markGap = size * 0.34;
    const total = markSize + markGap + first + gap + second;
    const left = centerX - total / 2;
    this.mark(left + markSize / 2, centerY - size * 0.36, markSize, progress, true);
    c.save();
    c.beginPath();
    c.rect(left + markSize + markGap, centerY - size * 1.17, (first + second + gap) * out((progress - 0.23) / 0.7), size * 1.55);
    c.clip();
    this.text('CUPRIC', left + markSize + markGap, centerY, { size, weight: 800, tracking });
    this.text('AI', left + markSize + markGap + first + gap, centerY, { size, weight: 800, tracking, color: LIME });
    c.restore();
  }

  private hook(t: number) {
    const c = this.ctx;
    this.glow(960, 540, 160 + out(t / 0.85) * 330, 0.24 * (1 - ease((t - 2.7) / 0.3)));
    if (t < 0.92) {
      c.beginPath();
      c.arc(960, 540, 2.5 + ease((t - 0.12) / 0.65) * 5.5, 0, TAU);
      c.fillStyle = LIME;
      c.fill();
    }
    const create = visibility(t, 0.82, 1.67, 0.42, 0.23);
    this.kinetic('CREATE.', 150, 642, { size: 260, weight: 800, tracking: -15, alpha: create }, (t - 0.79) / 0.78);
    const second = visibility(t, 1.66, 2.89, 0.28, 0.16);
    c.save();
    c.globalAlpha *= second;
    this.rule(153, 352, 96, 0.9);
    this.kinetic('WITH', 156, 430, { size: 70, weight: 700, tracking: 5 }, (t - 1.66) / 0.4, 26);
    this.kinetic('INTELLIGENCE.', 145, 633, { size: 169, weight: 800, tracking: -8 }, (t - 1.77) / 0.88);
    c.restore();
    if (t > 2.55) {
      const p = ease((t - 2.55) / 0.45);
      c.save();
      c.globalAlpha = p * 0.48;
      c.lineWidth = 1.5;
      for (let i = 0; i < 40; i++) {
        const a = i * 2.39996;
        const r = 60 + rand(i) * 250;
        c.strokeStyle = i % 8 === 0 ? LIME : 'rgba(220,240,218,.5)';
        c.beginPath();
        c.moveTo(960 + Math.cos(a) * r, 540 + Math.sin(a) * r);
        c.lineTo(960 + Math.cos(a) * (r + p * (380 + rand(i * 7) * 450)), 540 + Math.sin(a) * (r + p * (380 + rand(i * 7) * 450)));
        c.stroke();
      }
      c.restore();
    }
  }

  private directions(t: number) {
    const c = this.ctx;
    c.save();
    c.globalAlpha = 0.32;
    for (let i = 0; i < 19; i++) {
      const d = i - 9;
      c.beginPath();
      c.moveTo(-40, 540 + Math.sin(i) * 14);
      c.bezierCurveTo(490, 530 + d * 9, 980, 530 + d * 16, 1980, 540 + d * 65);
      c.strokeStyle = i % 5 === 0 ? 'rgba(182,250,130,.58)' : 'rgba(192,221,192,.24)';
      c.lineWidth = i % 5 === 0 ? 2 : 1;
      c.stroke();
    }
    c.restore();
    const first = visibility(t, 0.37, 1.35, 0.25, 0.24);
    this.kinetic('ONE IDEA.', 190, 615, { size: 205, tracking: -12, alpha: first }, (t - 0.33) / 0.72);
    const second = visibility(t, 1.43, 2.9, 0.3, 0.17);
    c.save();
    c.globalAlpha *= second;
    this.kinetic('INFINITE', 192, 442, { size: 111, weight: 700, tracking: 2 }, (t - 1.37) / 0.54, 44);
    this.kinetic('DIRECTIONS.', 175, 657, { size: 199, tracking: -12 }, (t - 1.52) / 0.88);
    if (t > 2.08) {
      const split = ease((t - 2.08) / 0.75);
      c.save();
      c.font = '800 199px Manrope, Arial, sans-serif';
      c.lineWidth = 1.5;
      c.strokeStyle = `rgba(182,250,130,${0.26 * (1 - split)})`;
      c.strokeText('DIRECTIONS.', 175 + split * 100, 657 - split * 108);
      c.strokeStyle = `rgba(210,230,208,${0.28 * (1 - split)})`;
      c.strokeText('DIRECTIONS.', 175 - split * 170, 657 + split * 119);
      c.restore();
    }
    c.restore();
  }

  private intelligence(t: number, globalTime: number) {
    const c = this.ctx;
    c.save();
    c.translate(960, 525);
    c.rotate(Math.sin(globalTime * 0.31) * 0.08);
    for (let i = 0; i < 4; i++) {
      c.beginPath();
      c.ellipse(0, 0, 470 + i * 42, 260 + i * 27, -0.32 + i * 0.36 + t * 0.08, 0, TAU);
      c.strokeStyle = i === 1 ? 'rgba(182,250,130,.18)' : 'rgba(201,226,204,.09)';
      c.lineWidth = 1.2;
      c.stroke();
    }
    c.restore();
    const first = visibility(t, 0.58, 1.72, 0.3, 0.24);
    this.kinetic('INTELLIGENCE', 960, 555, { size: 179, weight: 800, tracking: -9, align: 'center', alpha: first }, (t - 0.55) / 0.85);
    const second = visibility(t, 1.55, 2.92, 0.32, 0.2);
    this.kinetic('IN MOTION.', 960, 625, { size: 182, weight: 800, tracking: -9, align: 'center', alpha: second, color: LIME }, (t - 1.51) / 0.9);
    if (t > 1.15) {
      c.save();
      c.globalAlpha = Math.min(0.75, (t - 1.15) * 0.55);
      for (let i = 0; i < 14; i++) {
        const x = 230 + rand(i * 9) * 1460;
        const y = 150 + rand(i * 13) * 790;
        c.beginPath();
        c.moveTo(x, y);
        c.lineTo(960 + Math.sin(i * 3) * 420, 520 + Math.cos(i * 5) * 230);
        c.strokeStyle = i % 4 === 0 ? 'rgba(182,250,130,.14)' : 'rgba(210,230,210,.08)';
        c.stroke();
      }
      c.restore();
    }
  }

  private workspace(progress: number) {
    const c = this.ctx;
    const p = out(progress);
    c.save();
    c.globalAlpha *= p;
    c.translate(960, 540);
    c.scale(0.9 + p * 0.1, 0.9 + p * 0.1);
    c.translate(-960, -540);
    c.shadowColor = 'rgba(0,0,0,.7)';
    c.shadowBlur = 55;
    this.panel(118, 145, 1684, 796, '#0d120e', '#3c493c', 14);
    c.shadowBlur = 0;
    c.fillStyle = '#101711';
    c.fillRect(120, 147, 1680, 81);
    this.rule(120, 228, 1680, 0.46, '#4b594c');
    this.mark(167, 187, 42);
    this.text('CUPRIC / STUDIO', 205, 195, { size: 24, weight: 800, tracking: 1 });
    this.text('Canvas', 620, 194, { size: 22, weight: 700 });
    this.text('Versions', 748, 194, { size: 22, weight: 500, color: DIM });
    this.text('Assets', 884, 194, { size: 22, weight: 500, color: DIM });
    this.panel(1519, 165, 206, 43, '#b6fa82', '#b6fa82', 6);
    this.text('PUBLISH  ↗', 1622, 193, { size: 19, weight: 800, color: '#0a1308', align: 'center', tracking: 1 });
    this.rule(362, 228, 1, 0.5, '#5b6a5a');
    c.fillStyle = '#111811';
    c.fillRect(120, 230, 245, 709);
    this.text('WORKSPACE', 153, 284, { size: 16, weight: 700, color: '#8a9a88', tracking: 3 });
    this.text('Overview', 153, 343, { size: 22, weight: 700, color: LIME });
    this.text('Generate', 153, 402, { size: 22, weight: 500, color: DIM });
    this.text('Components', 153, 461, { size: 22, weight: 500, color: DIM });
    this.text('Library', 153, 520, { size: 22, weight: 500, color: DIM });
    this.rule(153, 557, 174, 0.18, '#d0e6cb');
    this.text('RECENT', 153, 606, { size: 15, weight: 700, color: '#7f907e', tracking: 3 });
    this.text('01 / New experience', 153, 660, { size: 17, weight: 600, color: '#d5dfd0' });
    this.text('02 / Brand system', 153, 706, { size: 17, weight: 500, color: DIM });

    this.panel(405, 264, 982, 583, '#090e0a', '#303e30', 8);
    this.text('LIVE CANVAS', 441, 309, { size: 15, weight: 800, color: '#8da28c', tracking: 2.5 });
    this.text('DESIGN SYSTEM / 01', 1160, 309, { size: 14, weight: 700, color: '#8da28c', tracking: 2, align: 'right' });
    this.rule(441, 331, 910, 0.19, '#b7cbb5');
    const preview = c.createLinearGradient(460, 375, 1260, 755);
    preview.addColorStop(0, '#172119');
    preview.addColorStop(0.65, '#0b100c');
    preview.addColorStop(1, '#263624');
    c.fillStyle = preview;
    c.fillRect(441, 356, 910, 407);
    c.save();
    c.translate(1080, 561);
    c.rotate(-0.37);
    for (let i = 0; i < 11; i++) {
      c.beginPath();
      c.ellipse(0, 0, 75 + i * 25, 125 + i * 20, 0, -1.7, 1.55);
      c.strokeStyle = `rgba(184,250,131,${0.49 - i * 0.034})`;
      c.lineWidth = 1.5;
      c.stroke();
    }
    c.restore();
    this.text('MAKE THE', 491, 487, { size: 81, weight: 800, tracking: -4 });
    this.text('UNEXPECTED.', 485, 580, { size: 78, weight: 800, tracking: -4 });
    this.text('An idea becomes an experience.', 491, 653, { size: 23, weight: 500, color: '#c3d0be' });
    this.rule(491, 700, 142, 0.8);
    this.text('EXPLORE  ↗', 491, 731, { size: 17, weight: 800, tracking: 2 });

    this.panel(1418, 264, 348, 583, '#111811', '#2a382a', 8);
    this.text('INSPECTOR', 1450, 310, { size: 16, weight: 800, color: '#c9d5c6', tracking: 2 });
    this.rule(1450, 333, 282, 0.22, '#c9d5c6');
    this.text('Appearance', 1450, 383, { size: 21, weight: 700 });
    this.text('Typography', 1450, 444, { size: 17, weight: 600, color: DIM });
    this.panel(1450, 463, 281, 54, '#171f18', '#344434', 5);
    this.text('Manrope / Semibold', 1467, 497, { size: 17, weight: 600, color: '#dce9d8' });
    this.text('Color system', 1450, 562, { size: 17, weight: 600, color: DIM });
    for (let i = 0; i < 5; i++) {
      c.fillStyle = ['#b6fa82', '#eff2ec', '#4f6450', '#263328', '#090e09'][i];
      c.fillRect(1450 + i * 58, 585, 48, 48);
    }
    this.text('Generation quality', 1450, 699, { size: 17, weight: 600, color: DIM });
    this.rule(1450, 732, 281, 0.25, '#d5eed1');
    this.rule(1450, 732, 205, 1);
    this.panel(405, 869, 1361, 51, '#171f17', '#3a4d3a', 7);
    this.text('✦', 433, 904, { size: 25, color: LIME });
    this.text('Ask Cupric to create anything...', 477, 902, { size: 21, weight: 500, color: '#9aa899' });
    this.text('↗', 1725, 903, { size: 26, weight: 700, color: LIME, align: 'right' });
    c.restore();
  }

  private buildFaster(t: number) {
    const c = this.ctx;
    if (t < 0.24) {
      c.fillStyle = `rgba(195,255,156,${0.16 * (1 - t / 0.24)})`;
      c.fillRect(0, 0, W, H);
      this.glow(960, 540, 600 * ease(t / 0.24), 0.82 * (1 - t / 0.24));
    }
    this.workspace((t - 0.08) / 1.35);
    c.save();
    const shade = c.createLinearGradient(0, 490, 0, 960);
    shade.addColorStop(0, 'rgba(3,7,3,0)');
    shade.addColorStop(0.5, 'rgba(3,7,3,.52)');
    shade.addColorStop(1, 'rgba(3,7,3,.34)');
    c.fillStyle = shade;
    c.fillRect(0, 430, W, 570);
    const build = visibility(t, 0.38, 1.32, 0.26, 0.23);
    this.kinetic('BUILD', 166, 665, { size: 275, weight: 800, tracking: -18, alpha: build }, (t - 0.37) / 0.7);
    const faster = visibility(t, 1.33, 2.55, 0.2, 0.38);
    c.save();
    c.globalAlpha *= faster;
    const acceleration = ease((t - 2.2) / 0.66);
    c.translate(132, 695);
    c.scale(1 + acceleration * 2.65, 1 + acceleration * 2.65);
    this.kinetic('FASTER.', 0, 0, { size: 286, weight: 800, tracking: -18 }, (t - 1.3) / 0.72);
    c.restore();
    c.restore();
  }

  private productPreview(progress: number) {
    const c = this.ctx;
    const p = ease(progress);
    c.save();
    c.globalAlpha *= p;
    this.panel(931, 213, 747, 620, '#0b100b', '#4a5d48', 10);
    this.text('FORMA', 970, 262, { size: 24, weight: 800, tracking: -1 });
    this.text('Objects', 1295, 259, { size: 15, weight: 600, color: DIM });
    this.text('Journal', 1390, 259, { size: 15, weight: 600, color: DIM });
    this.text('Explore  ↗', 1584, 259, { size: 15, weight: 700, color: LIME, align: 'right' });
    this.rule(970, 281, 667, 0.22, '#c5d6c0');
    const gradient = c.createLinearGradient(1000, 319, 1650, 748);
    gradient.addColorStop(0, '#17251a');
    gradient.addColorStop(0.5, '#0c130d');
    gradient.addColorStop(1, '#263b22');
    c.fillStyle = gradient;
    c.fillRect(970, 304, 668, 453);
    c.save();
    c.translate(1381, 525);
    c.rotate(-0.36);
    for (let i = 0; i < 13; i++) {
      c.beginPath();
      c.roundRect(-110 + i * 7.1, -136 + i * 8.2, 220 - i * 14.2, 272 - i * 16.4, 8);
      c.lineWidth = i === 0 ? 3 : 1.2;
      c.strokeStyle = i < 4 ? `rgba(185,251,133,${0.8 - i * 0.12})` : `rgba(202,234,190,${0.48 - i * 0.024})`;
      c.stroke();
    }
    c.restore();
    this.text('A NEW SHAPE', 1008, 415, { size: 49, weight: 800, tracking: -2 });
    this.text('OF POSSIBILITY.', 1005, 468, { size: 49, weight: 800, tracking: -2 });
    this.text('Thoughtful objects for a world in motion.', 1009, 520, { size: 17, weight: 500, color: '#c1d5bb' });
    this.panel(1008, 660, 158, 45, LIME, LIME, 4);
    this.text('DISCOVER  ↗', 1087, 688, { size: 14, weight: 800, color: '#10200e', align: 'center', tracking: 0.8 });
    this.text('01 / 04', 1574, 725, { size: 16, weight: 700, color: '#dae8d5', align: 'right' });
    c.restore();
  }

  private promptToProduct(t: number) {
    const c = this.ctx;
    const entrance = out(t / 0.6);
    c.save();
    c.globalAlpha *= entrance;
    this.panel(160, 214, 731, 620, '#0d130e', '#344434', 10);
    this.mark(210, 263, 42);
    this.text('CREATE WITH CUPRIC', 246, 271, { size: 21, weight: 800, tracking: 1 });
    this.rule(196, 297, 660, 0.3, '#d8ead4');
    this.text('YOUR PROMPT', 204, 361, { size: 17, weight: 800, color: DIM, tracking: 3 });
    this.panel(201, 391, 646, 192, '#131b14', '#475947', 8);
    const prompt = 'Build something people will remember.';
    const characters = Math.floor(clamp((t - 0.32) / 0.89) * prompt.length);
    this.text(prompt.slice(0, Math.min(characters, 24)), 230, 459, { size: 27, weight: 600, color: '#f4f7f0' });
    if (characters > 24) this.text(prompt.slice(24, characters), 230, 499, { size: 27, weight: 600, color: '#f4f7f0' });
    if (t < 1.25 && Math.floor(t * 5) % 2 === 0) {
      c.fillStyle = LIME;
      c.fillRect(231 + this.textWidth(prompt.slice(24, characters), 27, 600), 511, 3, 30);
    }
    this.text('STYLE', 204, 643, { size: 16, weight: 700, color: DIM, tracking: 2 });
    this.text('Editorial / Minimal / Responsive', 204, 685, { size: 21, weight: 600, color: '#e2eee0' });
    this.rule(204, 721, 643, 0.22, '#cfddcb');
    this.text(t > 1.26 ? 'GENERATING EXPERIENCE' : 'READY TO CREATE', 204, 779, { size: 16, weight: 800, color: LIME, tracking: 2 });
    this.text(t > 1.26 ? `${Math.floor(clamp((t - 1.2) / 1.2) * 100)}%` : '↗', 844, 779, { size: 20, weight: 800, color: LIME, align: 'right' });
    this.rule(204, 801, 644, 0.15, '#e2eee0');
    this.rule(204, 801, 644 * ease((t - 0.9) / 1.55), 1);
    c.restore();

    const generated = ease((t - 0.95) / 1.08);
    if (generated > 0) {
      c.save();
      c.globalAlpha = 0.5 * generated;
      for (let i = 0; i < 10; i++) {
        const y = 395 + i * 35;
        c.beginPath();
        c.moveTo(852, y);
        c.bezierCurveTo(920 + i * 2, y, 915 - i * 3, 500 + (i - 5) * 21, 976, 500 + (i - 5) * 21);
        c.strokeStyle = i % 3 === 0 ? LIME : '#839b80';
        c.lineWidth = 1;
        c.stroke();
      }
      c.restore();
    }
    this.productPreview((t - 0.94) / 1.16);

    const first = visibility(t, 0.32, 1.48, 0.28, 0.22);
    const second = visibility(t, 1.58, 2.94, 0.26, 0.13);
    c.save();
    const shade = c.createLinearGradient(0, 760, 0, 1080);
    shade.addColorStop(0, 'rgba(4,7,4,0)');
    shade.addColorStop(0.32, 'rgba(4,7,4,.9)');
    shade.addColorStop(1, 'rgba(4,7,4,.88)');
    c.fillStyle = shade;
    c.fillRect(0, 740, W, 340);
    this.kinetic('FROM PROMPT', 960, 975, { size: 167, tracking: -10, align: 'center', alpha: first }, (t - 0.3) / 0.78);
    this.kinetic('TO PRODUCT.', 960, 975, { size: 177, tracking: -10, align: 'center', alpha: second }, (t - 1.55) / 0.8);
    c.restore();
  }

  private lessRepetition(t: number) {
    const c = this.ctx;
    const collapse = ease((t - 1.17) / 0.95);
    c.save();
    for (let i = 0; i < 18; i++) {
      const col = i % 6;
      const row = Math.floor(i / 6);
      const x = mix(139 + col * 270, 900 + (col - 2.5) * 19, collapse);
      const y = mix(146 + row * 255, 515 + (row - 1) * 13, collapse);
      const w = mix(222, 125, collapse);
      const h = mix(189, 20, collapse);
      c.globalAlpha = (0.16 + (i % 6 === 0 ? 0.19 : 0)) * (1 - collapse * 0.9);
      this.panel(x, y, w, h, '#101811', i % 5 === 0 ? '#9ad36e' : '#758475', 4);
      this.rule(x + 21, y + 30, w * 0.66, 0.7, '#b6c6b1');
      this.rule(x + 21, y + 59, w * 0.47, 0.5, '#b6c6b1');
      this.rule(x + 21, y + 88, w * 0.56, 0.5, '#b6c6b1');
      c.fillStyle = LIME;
      c.fillRect(x + 21, y + h - 34, Math.max(4, w * 0.27), 4);
    }
    c.restore();
    if (collapse > 0.02) {
      c.save();
      c.globalAlpha = collapse;
      this.glow(960, 532, 395, 0.38);
      c.beginPath();
      c.moveTo(188, 790);
      c.bezierCurveTo(485, 790, 570, 531, 947, 531);
      c.bezierCurveTo(1270, 531, 1370, 266, 1741, 266);
      c.strokeStyle = LIME;
      c.lineWidth = 3;
      c.shadowColor = LIME;
      c.shadowBlur = 24;
      c.stroke();
      c.shadowBlur = 0;
      c.restore();
    }
    const first = visibility(t, 0.3, 1.53, 0.25, 0.22);
    c.save();
    c.globalAlpha = first;
    this.kinetic('LESS', 180, 461, { size: 110, tracking: -3 }, (t - 0.29) / 0.65);
    this.kinetic('REPETITION.', 169, 661, { size: 184, tracking: -13 }, (t - 0.42) / 0.85);
    c.restore();
    const second = visibility(t, 1.58, 2.96, 0.25, 0.13);
    c.save();
    c.globalAlpha = second;
    this.kinetic('MORE', 180, 461, { size: 110, tracking: -3, color: LIME }, (t - 1.55) / 0.6);
    this.kinetic('CREATION.', 170, 661, { size: 201, tracking: -13 }, (t - 1.66) / 0.87);
    c.restore();
  }

  private tenTimes(t: number) {
    const c = this.ctx;
    c.fillStyle = `rgba(2, 4, 2, ${0.75 * (1 - ease((t - 1.15) / 1.6))})`;
    c.fillRect(0, 0, W, H);
    const enter = out((t - 0.13) / 0.38);
    const fracture = ease((t - 1.13) / 1.35);
    if (enter > 0) {
      c.save();
      c.globalAlpha = enter * (1 - fracture);
      c.translate(960, 555);
      c.scale(0.73 + enter * 0.27 + fracture * 0.21, 0.73 + enter * 0.27 + fracture * 0.21);
      this.font(515, 800);
      const numberWidth = this.textWidth('10', 515, 800, -35);
      const crossWidth = this.textWidth('×', 515, 600, -14);
      const left = -(numberWidth + crossWidth + 18) / 2;
      this.text('10', left, 173, { size: 515, weight: 800, tracking: -35 });
      this.text('×', left + numberWidth + 18, 173, { size: 515, weight: 600, color: LIME, tracking: -14 });
      c.restore();
    }
    if (fracture > 0) {
      c.save();
      c.globalAlpha = fracture * (1 - ease((t - 2.53) / 0.44));
      for (let i = 0; i < 170; i++) {
        const angle = rand(i * 5) * TAU;
        const radius = 90 + rand(i * 7) * 420;
        const stretch = fracture * (170 + rand(i * 11) * 710);
        const x = 960 + Math.cos(angle) * (radius + stretch);
        const y = 540 + Math.sin(angle) * (radius * 0.65 + stretch);
        c.beginPath();
        c.moveTo(x - Math.cos(angle) * (18 + fracture * 150), y - Math.sin(angle) * (18 + fracture * 150));
        c.lineTo(x, y);
        c.strokeStyle = i % 8 === 0 ? 'rgba(182,250,130,.78)' : 'rgba(238,244,232,.38)';
        c.lineWidth = i % 8 === 0 ? 2 : 1;
        c.stroke();
      }
      c.restore();
    }
  }

  private ideasConnect(t: number) {
    const c = this.ctx;
    const join = ease((t - 0.52) / 1.48);
    const points = [
      [280, 350], [504, 233], [713, 401], [903, 280], [1136, 395], [1421, 252], [1661, 398],
      [270, 706], [520, 815], [763, 690], [991, 850], [1200, 686], [1490, 810], [1710, 668],
    ];
    c.save();
    c.globalAlpha = join * 0.6;
    for (let i = 0; i < points.length - 3; i++) {
      c.beginPath();
      c.moveTo(points[i][0], points[i][1]);
      c.lineTo(points[i + 3][0], points[i + 3][1]);
      c.strokeStyle = i % 4 === 0 ? 'rgba(182,250,130,.5)' : 'rgba(200,226,200,.23)';
      c.lineWidth = 1.5;
      c.stroke();
    }
    for (let i = 0; i < points.length; i++) {
      this.glow(points[i][0], points[i][1], i % 4 === 0 ? 49 : 22, i % 4 === 0 ? 0.42 : 0.15);
    }
    c.restore();
    const first = visibility(t, 0.28, 1.42, 0.28, 0.25);
    this.kinetic('IDEAS', 168, 632, { size: 248, tracking: -17, alpha: first }, (t - 0.25) / 0.74);
    const second = visibility(t, 1.36, 2.97, 0.27, 0.14);
    this.kinetic('CONNECT.', 165, 656, { size: 220, tracking: -15, alpha: second }, (t - 1.31) / 0.94);
    this.glow(965, 535, 70 + join * 110, 0.24 * join);
  }

  private makeNoise(t: number) {
    const c = this.ctx;
    const words = [
      { text: 'THINK', x: 124, y: 306, size: 169, angle: -0.07, color: WHITE },
      { text: 'BUILD', x: 973, y: 256, size: 159, angle: 0.08, color: LIME },
      { text: 'TEST', x: 532, y: 540, size: 216, angle: -0.14, color: WHITE },
      { text: 'CREATE', x: 1112, y: 611, size: 165, angle: 0.11, color: WHITE },
      { text: 'ITERATE', x: 115, y: 886, size: 151, angle: 0.06, color: '#a7b6a4' },
      { text: 'LAUNCH', x: 1025, y: 928, size: 169, angle: -0.075, color: LIME },
    ];
    const compressed = ease((t - 1.33) / 0.65);
    c.save();
    for (let i = 0; i < words.length; i++) {
      const item = words[i];
      const reveal = ease((t - i * 0.135) / 0.39) * (1 - compressed);
      if (reveal <= 0) continue;
      c.save();
      c.globalAlpha *= reveal;
      const x = mix(item.x, 960, compressed) + Math.sin(t * 4 + i) * 9;
      const y = mix(item.y, 545, compressed) + Math.cos(t * 3 + i) * 8;
      c.translate(x, y);
      c.rotate(item.angle * (1 - compressed) + (i % 2 ? 1 : -1) * compressed * 0.18);
      c.scale(0.88 + reveal * 0.12, 0.88 + reveal * 0.12);
      this.text(item.text, 0, 0, { size: item.size, weight: 800, tracking: -item.size * 0.053, color: item.color });
      c.restore();
    }
    c.restore();
    if (t > 1.77) {
      const p = visibility(t, 1.78, 2.99, 0.24, 0.14);
      c.save();
      c.globalAlpha *= p;
      this.kinetic('MAKE', 960, 464, { size: 222, weight: 800, tracking: -15, align: 'center' }, (t - 1.73) / 0.6);
      this.kinetic('NOISE.', 960, 708, { size: 248, weight: 800, tracking: -17, color: LIME, align: 'center' }, (t - 1.86) / 0.7);
      c.restore();
    }
  }

  private humanMachine(t: number, globalTime: number) {
    const c = this.ctx;
    const synchronize = ease((t - 0.91) / 1.45);
    c.save();
    c.strokeStyle = 'rgba(197,222,193,.18)';
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(960, 144);
    c.lineTo(960, 940);
    c.stroke();
    for (let i = 0; i < 16; i++) {
      const y = 180 + i * 47;
      c.beginPath();
      c.moveTo(90, y + Math.sin(i) * 17);
      c.bezierCurveTo(430, y - 135 + Math.sin(globalTime + i) * 40, 560, y + 143 - Math.cos(i) * 25, mix(772, 960, synchronize), y);
      c.strokeStyle = i % 5 === 0 ? 'rgba(226,242,220,.55)' : 'rgba(183,208,179,.17)';
      c.lineWidth = i % 5 === 0 ? 2 : 1;
      c.stroke();
      c.beginPath();
      c.moveTo(mix(1151, 960, synchronize), y);
      for (let j = 0; j < 12; j++) {
        const x = mix(1151, 960, synchronize) + j * 58;
        c.lineTo(x, y + Math.sin(j * 2.7 + i * 1.9 + globalTime * 1.5) * 15);
      }
      c.strokeStyle = i % 4 === 0 ? 'rgba(182,250,130,.56)' : 'rgba(152,213,126,.18)';
      c.stroke();
    }
    c.restore();
    this.glow(960, 540, 90 + synchronize * 220, 0.07 + synchronize * 0.42);
    c.fillStyle = LIME;
    c.beginPath();
    c.arc(960, 540, 3 + synchronize * 5, 0, TAU);
    c.fill();

    const first = visibility(t, 0.32, 1.76, 0.29, 0.28);
    const second = visibility(t, 1.18, 2.97, 0.28, 0.15);
    c.save();
    c.fillStyle = 'rgba(3,6,3,.55)';
    c.fillRect(0, 620, W, 190);
    this.kinetic('HUMAN INTENT.', 85, 743, { size: 92, tracking: -5, alpha: first }, (t - 0.27) / 0.78, 36);
    this.kinetic('MACHINE SPEED.', 1835, 743, { size: 88, tracking: -5, align: 'right', alpha: second, color: LIME }, (t - 1.15) / 0.84, 36);
    c.restore();
  }

  private buildNext(t: number) {
    const c = this.ctx;
    const emerge = ease(t / 1.2);
    this.glow(961, 522, 180 + emerge * 600, 0.28 * (1 - ease((t - 1.5) / 1.3)));
    c.save();
    c.globalAlpha = emerge * 0.64;
    const frames = [
      { x: 1350, y: 245, w: 209, h: 154 },
      { x: 1510, y: 521, w: 271, h: 195 },
      { x: 946, y: 331, w: 166, h: 123 },
    ];
    for (let i = 0; i < frames.length; i++) {
      const f = frames[i];
      c.save();
      c.translate(f.x, f.y + (1 - emerge) * 90);
      c.transform(1, -0.16, -0.12, 1, 0, 0);
      this.panel(0, 0, f.w, f.h, 'rgba(14,23,15,.8)', 'rgba(177,245,132,.49)', 5);
      this.rule(19, 22, f.w * 0.52, 0.8);
      for (let k = 0; k < 5; k++) this.rule(20, 52 + k * 19, f.w * (0.23 + rand(k + i * 4) * 0.48), 0.32, '#d4e5cf');
      c.restore();
    }
    c.restore();
    const first = visibility(t, 0.43, 1.47, 0.29, 0.25);
    const second = visibility(t, 1.32, 2.98, 0.26, 0.14);
    c.save();
    const shade = c.createLinearGradient(0, 240, 1150, 240);
    shade.addColorStop(0, 'rgba(3,7,3,.78)');
    shade.addColorStop(0.75, 'rgba(3,7,3,.2)');
    shade.addColorStop(1, 'rgba(3,7,3,0)');
    c.fillStyle = shade;
    c.fillRect(0, 200, 1350, 690);
    this.kinetic('BUILD', 141, 554, { size: 229, tracking: -13, alpha: first }, (t - 0.41) / 0.75);
    this.kinetic("WHAT'S NEXT.", 138, 639, { size: 181, tracking: -11, alpha: second }, (t - 1.29) / 0.89);
    c.restore();
  }

  private brandReveal(t: number) {
    const c = this.ctx;
    c.fillStyle = `rgba(3,6,3,${0.58 + ease(t / 0.85) * 0.4})`;
    c.fillRect(0, 0, W, H);
    const compression = 1 - ease(t / 0.55);
    if (compression > 0) this.glow(960, 540, 550 * compression + 40, compression * 0.7);
    const line = ease((t - 0.32) / 0.78) * (1 - ease((t - 1.55) / 0.45));
    this.rule(960 - line * 440, 540, line * 880, 0.86);
    this.glow(960, 540, 80 + line * 110, 0.24 * line);
    c.save();
    c.globalAlpha = ease((t - 0.72) / 0.75);
    const settle = ease((t - 1.84) / 1.14);
    this.wordmark(960, mix(600, 464, settle), mix(185, 148, settle), (t - 0.69) / 1.3, mix(167, 135, settle));
    c.restore();
  }

  private brandStatement(t: number) {
    const c = this.ctx;
    c.fillStyle = 'rgba(3,6,3,.85)';
    c.fillRect(0, 0, W, H);
    c.save();
    c.translate(960, 485);
    c.scale(1 + t * 0.006, 1 + t * 0.006);
    c.translate(-960, -485);
    this.wordmark(960, mix(464, 511, ease((t - 1.53) / 0.47)), 148, 1, 135);
    c.restore();
    this.rule(799, 551, 322, 0.4, '#73896b');
    const statement = ease(t / 0.58) * (1 - ease((t - 1.8) / 0.2));
    this.kinetic('INTELLIGENCE FOR PEOPLE WHO BUILD.', 960, 664, { size: 68, weight: 700, tracking: -1, align: 'center', alpha: statement }, t / 0.77, 28);
  }

  private endCard(t: number) {
    const c = this.ctx;
    c.fillStyle = `rgba(3,6,3,${0.94 + ease(t / 0.7) * 0.06})`;
    c.fillRect(0, 0, W, H);
    const fade = 1 - ease((t - 1.63) / 0.37);
    const enter = ease(t / 0.58);
    c.save();
    c.globalAlpha = fade * enter;
    c.translate(960, 510);
    c.scale(1 + t * 0.018, 1 + t * 0.018);
    c.translate(-960, -510);
    this.wordmark(960, 511, 147, 1, 131);
    this.text('INTELLIGENCE FOR PEOPLE WHO BUILD.', 960, 637, { size: 38, weight: 700, tracking: 1.4, align: 'center', alpha: ease((t - 0.24) / 0.55) });
    this.rule(802, 677, 316, 0.55 * ease((t - 0.52) / 0.5));
    this.text('CREATE WITHOUT LIMITS.', 960, 749, { size: 31, weight: 700, color: LIME, tracking: 6, align: 'center', alpha: ease((t - 0.64) / 0.56) });
    c.restore();
  }
}
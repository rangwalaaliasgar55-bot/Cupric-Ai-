import { useCallback, useEffect, useRef, useState } from 'react';
import { CHAPTERS, CupricFilm, FILM_DURATION, FILM_FPS } from './CupricFilm';
import { FilmSound } from './FilmSound';
import '../index.css';

const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));

function timecode(seconds: number) {
  const frames = Math.min(1200, Math.floor(seconds * FILM_FPS + 0.0001));
  const whole = Math.floor(frames / FILM_FPS);
  return `${String(Math.floor(whole / 60)).padStart(2, '0')}:${String(whole % 60).padStart(2, '0')}:${String(frames % FILM_FPS).padStart(2, '0')}`;
}

function BrandMark({ size = 34 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="13" strokeLinecap="square">
        <path d="M50 7V93M7 50H93M20 20L80 80M80 20L20 80" />
      </g>
      <path d="M39 38L59 39L61 60L40 61Z" fill="#080b08" />
    </svg>
  );
}

function PlayIcon({ paused }: { paused: boolean }) {
  return paused ? (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M8 5.5L18 12L8 18.5V5.5Z" fill="currentColor" /></svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M8 5V19M16 5V19" stroke="currentColor" strokeWidth="2.5" strokeLinecap="square" /></svg>
  );
}

function SpeakerIcon({ enabled }: { enabled: boolean }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M4 9V15H8L13 19V5L8 9H4Z" stroke="currentColor" strokeWidth="1.65" strokeLinejoin="round" />
      {enabled ? <path d="M16 8C17.2 9 17.8 10.4 17.8 12C17.8 13.6 17.2 15 16 16M18.7 5.5C20.6 7.2 21.6 9.4 21.6 12C21.6 14.6 20.6 16.8 18.7 18.5" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" /> : <path d="M17 9L22 15M22 9L17 15" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />}
    </svg>
  );
}

export default function FilmPlayer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const filmRef = useRef<CupricFilm | null>(null);
  const soundRef = useRef<FilmSound | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const timeRef = useRef(0);
  const playingRef = useRef(true);
  const exportingRef = useRef(false);
  const soundEnabledRef = useRef(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [soundOn, setSoundOn] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [ready, setReady] = useState(false);
  const [message, setMessage] = useState('');

  const seekTo = useCallback((rawTime: number) => {
    if (exportingRef.current) return;
    const time = Math.round(clamp(rawTime, 0, FILM_DURATION) * FILM_FPS) / FILM_FPS;
    timeRef.current = time;
    setCurrentTime(time);
    filmRef.current?.render(time);
    soundRef.current?.seek(time);
    if (time >= FILM_DURATION) {
      playingRef.current = false;
      setIsPlaying(false);
      soundRef.current?.setPlaying(false);
    }
  }, []);

  const togglePlayback = useCallback(() => {
    if (exportingRef.current || !filmRef.current) return;
    if (timeRef.current >= FILM_DURATION) {
      timeRef.current = 0;
      setCurrentTime(0);
      filmRef.current.render(0);
      soundRef.current?.seek(0);
    }
    const next = !playingRef.current;
    playingRef.current = next;
    setIsPlaying(next);
    soundRef.current?.setPlaying(next && soundEnabledRef.current);
  }, []);

  const toggleSound = useCallback(async () => {
    const sound = soundRef.current;
    if (!sound) return;
    if (soundOn) {
      soundEnabledRef.current = false;
      sound.setPlaying(false);
      setSoundOn(false);
      return;
    }
    try {
      await sound.enable();
      sound.seek(timeRef.current);
      soundEnabledRef.current = true;
      sound.setPlaying(playingRef.current);
      setSoundOn(true);
      setMessage('');
    } catch {
      setMessage('Audio is unavailable in this browser.');
    }
  }, [soundOn]);

  const toggleFullscreen = useCallback(() => {
    if (document.fullscreenElement) {
      void document.exitFullscreen();
    } else {
      void stageRef.current?.requestFullscreen();
    }
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const film = new CupricFilm(canvas);
    const sound = new FilmSound();
    filmRef.current = film;
    soundRef.current = sound;
    film.render(0);
    setReady(true);

    let animationFrame = 0;
    let cancelled = false;
    let lastTime = performance.now();
    let renderedFrame = -1;
    const animate = (now: number) => {
      const delta = Math.min((now - lastTime) / 1000, 0.12);
      lastTime = now;
      if (playingRef.current) {
        timeRef.current = Math.min(FILM_DURATION, timeRef.current + delta);
        const frame = Math.min(1200, Math.floor(timeRef.current * FILM_FPS));
        if (frame !== renderedFrame) {
          film.render(frame / FILM_FPS);
          renderedFrame = frame;
          setCurrentTime(frame / FILM_FPS);
        }
        sound.update(timeRef.current);
        if (timeRef.current >= FILM_DURATION) {
          playingRef.current = false;
          setIsPlaying(false);
          sound.setPlaying(false);
          if (exportingRef.current && recorderRef.current?.state === 'recording') {
            window.setTimeout(() => {
              if (recorderRef.current?.state === 'recording') recorderRef.current.stop();
            }, 180);
          }
        }
      } else {
        renderedFrame = Math.floor(timeRef.current * FILM_FPS);
      }
      animationFrame = requestAnimationFrame(animate);
    };
    animationFrame = requestAnimationFrame(animate);

    void document.fonts.load('800 180px Manrope').then(() => {
      if (!cancelled) film.render(Math.floor(timeRef.current * FILM_FPS) / FILM_FPS);
    }).catch(() => {});

    return () => {
      cancelled = true;
      cancelAnimationFrame(animationFrame);
      if (recorderRef.current?.state === 'recording') recorderRef.current.stop();
      film.dispose();
      void sound.dispose();
      filmRef.current = null;
      soundRef.current = null;
    };
  }, []);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (event.target instanceof HTMLInputElement || event.metaKey || event.ctrlKey || event.altKey) return;
      if (event.code === 'Space') {
        event.preventDefault();
        togglePlayback();
      } else if (event.code === 'ArrowRight') {
        event.preventDefault();
        seekTo(timeRef.current + 5);
      } else if (event.code === 'ArrowLeft') {
        event.preventDefault();
        seekTo(timeRef.current - 5);
      } else if (event.code === 'KeyM') {
        void toggleSound();
      } else if (event.code === 'KeyF') {
        toggleFullscreen();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [seekTo, togglePlayback, toggleSound, toggleFullscreen]);

  const exportFilm = async () => {
    if (exportingRef.current || !canvasRef.current || !filmRef.current) return;
    if (!('MediaRecorder' in window) || !canvasRef.current.captureStream) {
      setMessage('This browser cannot record canvas video. Try Chrome or Edge.');
      return;
    }
    try {
      const sound = soundRef.current;
      if (sound) {
        try {
          await sound.enable();
          soundEnabledRef.current = true;
          setSoundOn(true);
        } catch {
          // Video remains exportable when audio is not supported.
        }
      }
      const canvas = canvasRef.current;
      timeRef.current = 0;
      setCurrentTime(0);
      filmRef.current.render(0);
      sound?.seek(0);
      const videoStream = canvas.captureStream(FILM_FPS);
      const tracks = [...videoStream.getVideoTracks(), ...(sound?.stream?.getAudioTracks() ?? [])];
      const stream = new MediaStream(tracks);
      const candidates = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
      const mimeType = candidates.find((type) => MediaRecorder.isTypeSupported(type));
      const recorder = new MediaRecorder(stream, {
        ...(mimeType ? { mimeType } : {}),
        videoBitsPerSecond: 18_000_000,
        audioBitsPerSecond: 192_000,
      });
      recorderRef.current = recorder;
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size) chunks.push(event.data);
      };
      recorder.onstop = () => {
        videoStream.getTracks().forEach((track) => track.stop());
        exportingRef.current = false;
        setIsExporting(false);
        if (!chunks.length) {
          setMessage('The recording was empty. Please try exporting again.');
          return;
        }
        const blob = new Blob(chunks, { type: recorder.mimeType || 'video/webm' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'CUPRIC-AI_Brand-Film_1920x1080_30fps.webm';
        document.body.append(link);
        link.click();
        link.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
        setMessage('Film exported. Your WebM download is ready.');
      };
      recorder.onerror = () => {
        exportingRef.current = false;
        setIsExporting(false);
        setMessage('Recording failed. Please try again in Chrome or Edge.');
      };
      recorder.start(1000);
      exportingRef.current = true;
      setIsExporting(true);
      setMessage('');
      playingRef.current = true;
      setIsPlaying(true);
      sound?.setPlaying(soundEnabledRef.current);
    } catch (error) {
      exportingRef.current = false;
      setIsExporting(false);
      setMessage(error instanceof Error ? error.message : 'Export could not be started.');
    }
  };

  const chapterIndex = currentTime >= FILM_DURATION
    ? CHAPTERS.length - 1
    : Math.max(0, CHAPTERS.findIndex((chapter) => currentTime >= chapter.start && currentTime < chapter.end));
  const chapter = CHAPTERS[chapterIndex];
  const progress = currentTime / FILM_DURATION * 100;

  return (
    <main className="app-shell">
      <header className="site-header">
        <div className="header-brand" aria-label="Cupric AI">
          <span className="header-mark"><BrandMark /></span>
          <span className="header-wordmark">CUPRIC <span>AI</span></span>
        </div>
        <div className="header-statement">INTELLIGENCE FOR PEOPLE WHO BUILD.</div>
        <div className="header-edition"><span className="edition-line" /> A BRAND FILM <span className="edition-no">/ 001</span></div>
      </header>

      <section className="film-shell" aria-label="Cupric AI cinematic brand film">
        <div className="frame-heading">
          <span>THE FUTURE IS BUILT.</span>
          <span className="frame-heading-right"><span className="status-light" /> {isExporting ? 'RECORDING MASTER' : isPlaying ? 'NOW PLAYING' : currentTime >= FILM_DURATION ? 'FILM COMPLETE' : 'PAUSED'} <span className="heading-divider">/</span> 40 SECOND FILM</span>
        </div>

        <div className="stage" ref={stageRef}>
          <canvas ref={canvasRef} aria-label="Cupric AI 40-second animated brand film" />
          {!ready && <div className="stage-loading">INITIALIZING FILM ENGINE</div>}
        </div>

        <div className="player-controls">
          <button className="play-button" type="button" onClick={togglePlayback} disabled={!ready || isExporting} aria-label={isPlaying ? 'Pause film' : currentTime >= FILM_DURATION ? 'Replay film' : 'Play film'} title="Play / pause (Space)">
            <PlayIcon paused={!isPlaying} />
          </button>

          <div className="timecode" aria-label="Current film time">{timecode(currentTime)} <span>/ {timecode(FILM_DURATION)}</span></div>

          <div className="timeline-area">
            <div className="timeline-track">
              <div className="timeline-fill" style={{ width: `${progress}%` }} />
              {CHAPTERS.slice(1).map((item) => <span className="timeline-tick" key={item.start} style={{ left: `${item.start / FILM_DURATION * 100}%` }} />)}
              <span className="timeline-handle" style={{ left: `${progress}%` }} />
              <input type="range" min="0" max={FILM_DURATION * FILM_FPS} step="1" value={Math.round(currentTime * FILM_FPS)} onChange={(event) => seekTo(Number(event.target.value) / FILM_FPS)} disabled={isExporting} aria-label="Seek through the film" />
            </div>
            <div className="timeline-meta"><span>{String(chapterIndex + 1).padStart(2, '0')} / {chapter.label.toUpperCase()}</span><span>14 CHAPTERS</span></div>
          </div>

          <div className="control-actions">
            <button className={`icon-button ${soundOn ? 'active' : ''}`} type="button" onClick={() => void toggleSound()} aria-label={soundOn ? 'Mute sound' : 'Enable sound'} title="Sound (M)"><SpeakerIcon enabled={soundOn} /></button>
            <button className="icon-button fullscreen-button" type="button" onClick={toggleFullscreen} aria-label="Toggle fullscreen" title="Fullscreen (F)">
              <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 9V4H9M15 4H20V9M20 15V20H15M9 20H4V15" stroke="currentColor" strokeWidth="1.8" strokeLinecap="square" /></svg>
            </button>
            <button className="export-button" type="button" onClick={() => void exportFilm()} disabled={!ready || isExporting} title="Record and download the complete 1920x1080 film">
              {isExporting ? <><span className="recording-dot" /> EXPORTING {Math.floor(progress)}%</> : <><span>EXPORT FILM</span><svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M10 2V13M10 13L5.5 8.5M10 13L14.5 8.5M3 15.5V18H17V15.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="square" /></svg></>}
            </button>
          </div>
        </div>

        <div className="film-footer">
          <span>01&nbsp; / &nbsp;AN EXPERIMENT IN POSSIBILITY</span>
          <span className="film-footer-center">CREATE WITHOUT LIMITS.</span>
          <span>1920 × 1080&nbsp;&nbsp; / &nbsp;&nbsp;30 FPS&nbsp;&nbsp; / &nbsp;&nbsp;16:9</span>
        </div>
        {message && <div className="status-message" role="status">{message}</div>}
      </section>
    </main>
  );
}
import * as THREE from 'three';

const POINT_COUNT = 2600;
const MAX_LINES = 3000;
const TAU = Math.PI * 2;

const hash = (n: number) => {
  const x = Math.sin(n * 127.1 + 78.233) * 43758.5453;
  return x - Math.floor(x);
};
const clamp = (n: number, a = 0, b = 1) => Math.max(a, Math.min(b, n));
const ease = (n: number) => {
  const x = clamp(n);
  return x * x * (3 - 2 * x);
};
const mix = (a: number, b: number, k: number) => a + (b - a) * k;

const BOUNDARIES = [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 38, 40];

function sceneAt(t: number) {
  for (let i = BOUNDARIES.length - 2; i >= 0; i--) {
    if (t >= BOUNDARIES[i]) return i;
  }
  return 0;
}

/** A single morphing 3D world persists under every typographic and interface scene. */
export class VisualWorld {
  readonly canvas: HTMLCanvasElement;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(53, 16 / 9, 0.1, 120);
  private targets: Float32Array[] = [];
  private positions = new Float32Array(POINT_COUNT * 3);
  private pointGeometry = new THREE.BufferGeometry();
  private pointMaterial: THREE.ShaderMaterial;
  private linePositions = new Float32Array(MAX_LINES * 6);
  private lineColors = new Float32Array(MAX_LINES * 6);
  private lineGeometry = new THREE.BufferGeometry();
  private lineCount = 0;
  private lines: THREE.LineSegments;
  private architecture: THREE.Group;
  private city: THREE.InstancedMesh;
  private cityData: { x: number; z: number; h: number; w: number; d: number }[] = [];
  private dummy = new THREE.Object3D();

  constructor() {
    this.canvas = document.createElement('canvas');
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    this.renderer.setPixelRatio(1);
    this.renderer.setSize(1920, 1080, false);
    this.renderer.setClearColor(0x050705, 0);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.35;

    this.targets = this.createTargets();
    this.pointGeometry.setAttribute('position', new THREE.BufferAttribute(this.positions, 3).setUsage(THREE.DynamicDrawUsage));
    const colors = new Float32Array(POINT_COUNT * 3);
    const sizes = new Float32Array(POINT_COUNT);
    for (let i = 0; i < POINT_COUNT; i++) {
      const lime = i % 11 === 0 || i % 31 === 0;
      colors[i * 3] = lime ? 0.68 : 0.55 + hash(i * 3) * 0.35;
      colors[i * 3 + 1] = lime ? 1 : 0.61 + hash(i * 5) * 0.29;
      colors[i * 3 + 2] = lime ? 0.36 : 0.56 + hash(i * 7) * 0.3;
      sizes[i] = 0.7 + hash(i * 13) * 1.7;
    }
    this.pointGeometry.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));
    this.pointGeometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
    this.pointMaterial = new THREE.ShaderMaterial({
      uniforms: { uOpacity: { value: 1 } },
      vertexShader: `
        attribute vec3 aColor;
        attribute float aSize;
        varying vec3 vColor;
        void main() {
          vColor = aColor;
          vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
          gl_Position = projectionMatrix * mvPosition;
          gl_PointSize = min(16.0, (2.7 + aSize * 2.8) * (22.0 / -mvPosition.z));
        }
      `,
      fragmentShader: `
        uniform float uOpacity;
        varying vec3 vColor;
        void main() {
          float r = length(gl_PointCoord - vec2(0.5));
          float core = 1.0 - smoothstep(0.07, 0.49, r);
          float glow = (1.0 - smoothstep(0.0, 0.5, r)) * 0.32;
          gl_FragColor = vec4(vColor * (core + glow), (core * 0.75 + glow) * uOpacity);
        }
      `,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.scene.add(new THREE.Points(this.pointGeometry, this.pointMaterial));

    this.lineGeometry.setAttribute('position', new THREE.BufferAttribute(this.linePositions, 3).setUsage(THREE.DynamicDrawUsage));
    this.lineGeometry.setAttribute('color', new THREE.BufferAttribute(this.lineColors, 3).setUsage(THREE.DynamicDrawUsage));
    this.lineGeometry.setDrawRange(0, 0);
    this.lines = new THREE.LineSegments(
      this.lineGeometry,
      new THREE.LineBasicMaterial({
        vertexColors: true,
        transparent: true,
        opacity: 0.75,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    );
    this.scene.add(this.lines);

    this.architecture = new THREE.Group();
    for (let i = 0; i < 3; i++) {
      const shape = new THREE.IcosahedronGeometry(i === 0 ? 3.05 : 1.6, i === 0 ? 2 : 1);
      const edges = new THREE.EdgesGeometry(shape, 18);
      const mesh = new THREE.LineSegments(
        edges,
        new THREE.LineBasicMaterial({
          color: i === 1 ? 0xb7fa7e : 0x94ac98,
          transparent: true,
          opacity: i === 0 ? 0.27 : 0.4,
          blending: THREE.AdditiveBlending,
        }),
      );
      this.architecture.add(mesh);
    }
    this.scene.add(this.architecture);

    const cityMaterial = new THREE.MeshStandardMaterial({
      color: 0x283228,
      roughness: 0.4,
      metalness: 0.6,
      emissive: 0x061006,
      flatShading: true,
    });
    this.city = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), cityMaterial, 168);
    this.city.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    for (let i = 0; i < 168; i++) {
      const col = i % 14;
      const row = Math.floor(i / 14);
      const x = (col - 6.5) * 1.5 + (hash(i * 8) - 0.5) * 0.28;
      const z = (row - 5.5) * 1.6;
      const h = 0.25 + Math.pow(hash(i * 21 + 2), 2.1) * 5.2;
      const w = 0.36 + hash(i * 17 + 3) * 0.47;
      const d = 0.38 + hash(i * 25 + 4) * 0.55;
      this.cityData.push({ x, z, h, w, d });
      this.city.setColorAt(i, new THREE.Color(i % 13 === 0 ? 0x9dda76 : i % 4 === 0 ? 0x697b68 : 0x2b352d));
    }
    this.city.visible = false;
    this.scene.add(this.city);
    this.scene.add(new THREE.AmbientLight(0xcddccc, 1.1));
    const key = new THREE.DirectionalLight(0xf0fff0, 2.5);
    key.position.set(-8, 12, 6);
    this.scene.add(key);
    const rim = new THREE.PointLight(0xa9fa72, 50, 35);
    rim.position.set(5, 3, 1);
    this.scene.add(rim);
  }

  private createTargets() {
    const states = Array.from({ length: 14 }, () => new Float32Array(POINT_COUNT * 3));
    const mask = document.createElement('canvas');
    mask.width = 1400;
    mask.height = 500;
    const m = mask.getContext('2d')!;
    m.fillStyle = '#fff';
    m.font = '900 475px Arial, sans-serif';
    m.textAlign = 'center';
    m.textBaseline = 'middle';
    m.fillText('10×', 700, 255);
    const pixels = m.getImageData(0, 0, mask.width, mask.height).data;
    const glyph: { x: number; y: number }[] = [];
    for (let y = 18; y < 490; y += 5) {
      for (let x = 20; x < 1380; x += 5) {
        if (pixels[(y * mask.width + x) * 4 + 3] > 150) glyph.push({ x, y });
      }
    }

    for (let i = 0; i < POINT_COUNT; i++) {
      const a = hash(i * 1.17 + 1);
      const b = hash(i * 2.79 + 2);
      const c = hash(i * 4.33 + 3);
      const theta = i * 2.39996323;
      const ring = Math.floor(i / 52);
      const spoke = i % 52;
      const angle = (spoke / 52) * TAU + ring * 0.095;
      const radius = 3.3 + Math.sin(angle * 5 + ring * 0.2) * 0.5;
      const branch = i % 24;
      const u = Math.floor(i / 24) / Math.ceil(POINT_COUNT / 24);
      const sphereY = 1 - (i / (POINT_COUNT - 1)) * 2;
      const sphereRadius = Math.sqrt(1 - sphereY * sphereY);
      const cluster = i % 4;
      const cx = [-5, 4.8, -1.2, 2.8][cluster];
      const cy = [1.7, 1.9, -2, -1.4][cluster];
      const maskPoint = glyph[Math.floor(hash(i * 7.91 + 12) * glyph.length)] || { x: 700, y: 250 };
      const targets: [number, number, number][] = [
        [Math.cos(angle) * radius, Math.sin(angle) * radius * 0.85, -10 + ring * 0.39],
        [-10 + u * 20, (branch - 11.5) * 0.39 * Math.pow(u, 1.35) + Math.sin(u * 6 + branch) * 0.35, (branch % 8 - 4) * 0.65 + Math.sin(u * 8 + branch) * 0.4],
        [Math.cos(theta) * sphereRadius * 5.6, sphereY * 5.1, Math.sin(theta) * sphereRadius * 5.2],
        [(a - 0.5) * 18, (b - 0.5) * 9.6, -6 + c * 6],
        [(Math.floor(i % 28) / 27 - 0.5) * 16, (Math.floor(i / 28) % 76 / 75 - 0.5) * 8.3, -4 + c * 3],
        [((i % 9) - 4) * 1.85 + (a - 0.5) * 1.4, (Math.floor(i / 9) % 6 - 2.5) * 1.45 + (b - 0.5) * 0.8, -3 + c * 4],
        [(maskPoint.x / 1400 - 0.5) * 15.2, (0.5 - maskPoint.y / 500) * 6.3, (c - 0.5) * 0.7],
        [cx + (a - 0.5) * 3, cy + (b - 0.5) * 3, (c - 0.5) * 4],
        [(a - 0.5) * 19, (b - 0.5) * 11, (c - 0.5) * 12],
        [i % 2 ? 2.4 + a * 5.2 : -2.4 - a * 5.2, (b - 0.5) * 8.4, (c - 0.5) * 5],
        [((i % 28) - 13.5) * 0.71, -3.9 + b * 5.4, (Math.floor(i / 28) % 17 - 8) * 0.8],
        [(a - 0.5) * 0.4, (b - 0.5) * 0.4, (c - 0.5) * 0.4],
        [Math.cos(theta) * (4.7 + a * 2.2), Math.sin(theta) * (2.8 + b * 1.1), (c - 0.5) * 10],
        [Math.cos(theta) * (5 + a * 4), Math.sin(theta) * (3 + b * 3), -5 + c * 9],
      ];
      for (let s = 0; s < states.length; s++) {
        const p = targets[s];
        states[s][i * 3] = p[0];
        states[s][i * 3 + 1] = p[1];
        states[s][i * 3 + 2] = p[2];
      }
    }
    return states;
  }

  private line(a: [number, number, number], b: [number, number, number], strength = 1, lime = false) {
    if (this.lineCount >= MAX_LINES) return;
    const j = this.lineCount++ * 6;
    this.linePositions.set([...a, ...b], j);
    const color = lime ? [0.48, 0.98, 0.29] : [0.48, 0.59, 0.5];
    for (let k = 0; k < 2; k++) {
      this.lineColors[j + k * 3] = color[0] * strength;
      this.lineColors[j + k * 3 + 1] = color[1] * strength;
      this.lineColors[j + k * 3 + 2] = color[2] * strength;
    }
  }

  private buildLines(s: number, local: number, opacity: number, t: number) {
    if (opacity <= 0.01) return;
    if (s === 0) {
      const grown = ease((local - 0.12) / 0.9);
      for (let ring = 0; ring < 18; ring++) {
        const z = -9 + ring * 1.05 + local * 1.4;
        for (let k = 0; k < 36; k++) {
          const a = (k / 36) * TAU + ring * 0.08;
          const b = ((k + 1) / 36) * TAU + ring * 0.08;
          const r = (3.35 + Math.sin(a * 5 + ring * 0.25) * 0.32) * grown;
          const rn = (3.35 + Math.sin(b * 5 + ring * 0.25) * 0.32) * grown;
          this.line([Math.cos(a) * r, Math.sin(a) * r * 0.84, z], [Math.cos(b) * rn, Math.sin(b) * rn * 0.84, z], opacity * (ring % 4 === 0 ? 0.35 : 0.12), ring % 5 === 0);
          if (ring < 17 && k % 2 === 0) this.line([Math.cos(a) * r, Math.sin(a) * r * 0.84, z], [Math.cos(a + 0.08) * r, Math.sin(a + 0.08) * r * 0.84, z + 1.05], opacity * 0.16);
        }
      }
    } else if (s === 1) {
      for (let branch = 0; branch < 29; branch++) {
        const lane = branch - 14;
        for (let k = 0; k < 27; k++) {
          const u = k / 27;
          const v = (k + 1) / 27;
          const point = (q: number): [number, number, number] => [
            -10 + q * 21,
            lane * 0.29 * Math.pow(q, 1.6) + Math.sin(q * 7 + branch * 0.55) * 0.29,
            (branch % 7 - 3) * 0.78 + Math.cos(q * 7 + branch) * 0.38,
          ];
          this.line(point(u), point(v), opacity * (branch % 7 === 0 ? 0.78 : 0.21), branch % 7 === 0);
        }
      }
    } else if (s === 2) {
      const nodes: [number, number, number][] = [];
      for (let i = 0; i < 100; i++) {
        const y = 1 - (i / 99) * 2;
        const r = Math.sqrt(1 - y * y);
        const a = i * 2.39996323 + t * 0.23;
        nodes.push([Math.cos(a) * r * 5.3, y * 4.75, Math.sin(a) * r * 5.3]);
      }
      for (let i = 0; i < 100; i++) {
        for (const step of [1, 2, 3, 5]) {
          const j = (i + step) % 100;
          const a = nodes[i];
          const b = nodes[j];
          const distance = Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
          if (distance < 2.9) this.line(a, b, opacity * (step === 1 ? 0.55 : 0.22), i % 13 === 0);
        }
      }
    } else if (s >= 3 && s <= 5) {
      for (let x = -10; x <= 10; x += 0.7) {
        this.line([x, -5.3, -7], [x, 5.3, -7], opacity * 0.13, x === 0);
      }
      for (let y = -5; y <= 5; y += 0.7) this.line([-10, y, -7], [10, y, -7], opacity * 0.13);
      for (let i = 0; i < 33; i++) {
        const x = -9 + ((i * 3) % 18);
        const y = -4.4 + ((i * 7) % 9);
        const w = 0.3 + (i % 5) * 0.21;
        this.line([x, y, -4], [x + w, y, -4], opacity * 0.28, i % 5 === 0);
      }
    } else if (s === 6) {
      const burst = ease((local - 1.1) / 1.5);
      for (let i = 0; i < 250; i++) {
        const a = hash(i * 11) * TAU;
        const r = 0.6 + hash(i * 4) * 2.4;
        this.line([Math.cos(a) * r, Math.sin(a) * r, 0], [Math.cos(a) * (r + burst * (3 + hash(i * 8) * 10)), Math.sin(a) * (r + burst * (3 + hash(i * 8) * 10)), (hash(i * 9) - 0.5) * 5], opacity * burst * 0.55, i % 6 === 0);
      }
    } else if (s === 7) {
      const join = ease((local - 0.4) / 1.6);
      const vertices: [number, number, number][] = [];
      for (let z = 0; z < 4; z++) {
        for (let y = 0; y < 5; y++) {
          for (let x = 0; x < 6; x++) {
            const cluster = (x + y + z) % 4;
            const offsetX = [-5, 5, -2, 3][cluster] * (1 - join);
            const offsetY = [2, 2, -2, -1][cluster] * (1 - join);
            vertices.push([(x - 2.5) * 1.5 + offsetX, (y - 2) * 1.43 + offsetY, (z - 1.5) * 1.5]);
          }
        }
      }
      for (let z = 0; z < 4; z++) for (let y = 0; y < 5; y++) for (let x = 0; x < 6; x++) {
        const i = z * 30 + y * 6 + x;
        if (x < 5) this.line(vertices[i], vertices[i + 1], opacity * (0.28 + join * 0.32), (x + y + z) % 9 === 0);
        if (y < 4) this.line(vertices[i], vertices[i + 6], opacity * 0.35, i % 12 === 0);
        if (z < 3 && i % 2 === 0) this.line(vertices[i], vertices[i + 30], opacity * 0.25);
      }
    } else if (s === 8) {
      for (let i = 0; i < 240; i++) {
        const x = (hash(i * 3) - 0.5) * 24;
        const y = (hash(i * 7) - 0.5) * 12;
        const z = (hash(i * 13) - 0.5) * 10;
        this.line([x, y, z], [x + 0.8 + local * 0.65, y - 0.4, z], opacity * (i % 12 === 0 ? 0.6 : 0.15), i % 12 === 0);
      }
    } else if (s === 9) {
      for (let j = 0; j < 18; j++) {
        for (let k = 0; k < 32; k++) {
          const u = k / 32;
          const v = (k + 1) / 32;
          const curve = (p: number): [number, number, number] => [-9 + p * 9, Math.sin(p * 7 + j * 0.29 + t * 0.65) * (0.8 + j * 0.11) + (j - 9) * 0.2, -2 + j * 0.17];
          this.line(curve(u), curve(v), opacity * 0.25, j % 7 === 0);
        }
      }
      for (let x = 0; x < 15; x++) for (let y = 0; y < 13; y++) {
        const p: [number, number, number] = [0.4 + x * 0.68, (y - 6) * 0.64, -2];
        if (x < 14) this.line(p, [p[0] + 0.68, p[1], -2], opacity * 0.29, y % 5 === 0);
        if (y < 12 && (x + y) % 3 === 0) this.line(p, [p[0], p[1] + 0.64, -2], opacity * 0.2);
      }
    } else if (s === 10) {
      for (let x = -12; x <= 12; x += 1.5) this.line([x, -4.05, -11], [x, -4.05, 10], opacity * 0.32, x === 0);
      for (let z = -11; z <= 10; z += 1.6) this.line([-12, -4.05, z], [12, -4.05, z], opacity * 0.32, z === 0);
      for (let i = 0; i < 168; i += 4) {
        const b = this.cityData[i];
        const h = b.h * ease((local - i * 0.006) / 1.6);
        if (h < 0.1) continue;
        this.line([b.x, -4 + h, b.z], [b.x, -4 + h + 0.13, b.z], opacity * 0.72, i % 16 === 0);
      }
    } else if (s >= 11) {
      const count = s === 11 ? 56 : 24;
      for (let i = 0; i < count; i++) {
        const a = (i / count) * TAU;
        const r = s === 11 ? (1 - ease(local / 1.5)) * 8 : 5.5;
        const p: [number, number, number] = [Math.cos(a) * r, Math.sin(a) * r * 0.6, -5];
        const q: [number, number, number] = [Math.cos(a + 0.04) * r, Math.sin(a + 0.04) * r * 0.6, -5];
        this.line(p, q, opacity * (s === 11 ? 0.5 : 0.09), i % 9 === 0);
      }
    }
  }

  render(time: number) {
    const t = Math.max(0, Math.min(40, time));
    const s = sceneAt(Math.min(t, 39.999));
    const local = t - BOUNDARIES[s];
    const transition = [3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 38].includes(BOUNDARIES[s]) ? (s === 3 || s === 6 || s === 8 || s === 9 || s === 11 ? 0.23 : 0.65) : 0.65;
    const morph = s === 0 ? 1 : ease(local / transition);
    const prev = this.targets[Math.max(0, s - 1)];
    const next = this.targets[s];
    const birth = s === 0 ? ease((t - 0.06) / 1.02) : 1;

    for (let i = 0; i < POINT_COUNT; i++) {
      const j = i * 3;
      let x = mix(prev[j], next[j], morph) * birth;
      let y = mix(prev[j + 1], next[j + 1], morph) * birth;
      let z = mix(prev[j + 2], next[j + 2], morph) * birth;
      const sway = Math.sin(t * 1.4 + i * 0.117) * 0.055;
      x += sway;
      y += Math.cos(t * 1.1 + i * 0.097) * 0.04;
      if (s === 0) z += local * 1.2;
      if (s === 1) x -= local * 0.9;
      if (s === 2) {
        const a = local * 0.21;
        const oldX = x;
        x = x * Math.cos(a) - z * Math.sin(a);
        z = oldX * Math.sin(a) + z * Math.cos(a);
      }
      if (s === 6 && local > 1.05) {
        const burst = Math.pow(clamp((local - 1.05) / 1.7), 1.5);
        const direction = Math.atan2(y, x) + (hash(i * 7) - 0.5) * 1.2;
        const speed = 3 + hash(i * 17) * 14;
        x += Math.cos(direction) * speed * burst;
        y += Math.sin(direction) * speed * burst;
        z += (hash(i * 4) - 0.5) * 16 * burst;
      }
      if (s === 7) {
        const connect = ease((local - 0.6) / 1.6);
        x = mix(x, (hash(i * 11) - 0.5) * 11, connect * 0.6);
        y = mix(y, (hash(i * 13) - 0.5) * 7.5, connect * 0.6);
      }
      if (s === 11) {
        const collapse = ease(local / 1.4);
        x *= 1 - collapse * 0.93;
        y *= 1 - collapse * 0.93;
        z *= 1 - collapse * 0.9;
      }
      this.positions[j] = x;
      this.positions[j + 1] = y;
      this.positions[j + 2] = z;
    }
    this.pointGeometry.attributes.position.needsUpdate = true;
    const opacity = [0.85, 0.91, 0.88, 0.24, 0.3, 0.35, 1, 0.82, 0.55, 0.46, 0.82, 0.4, 0.15, 0.12][s];
    this.pointMaterial.uniforms.uOpacity.value = opacity * (s === 0 ? birth : 1) * (t > 39.5 ? 1 - ease((t - 39.5) / 0.5) : 1);

    this.lineCount = 0;
    if (s > 0 && local < transition) this.buildLines(s - 1, BOUNDARIES[s] - BOUNDARIES[s - 1], 1 - morph, t);
    this.buildLines(s, local, s >= 3 && s <= 5 ? 0.5 * morph : morph, t);
    this.lineGeometry.setDrawRange(0, this.lineCount * 2);
    this.lineGeometry.attributes.position.needsUpdate = true;
    this.lineGeometry.attributes.color.needsUpdate = true;

    this.architecture.visible = s === 2 || s === 7;
    if (this.architecture.visible) {
      const join = s === 7 ? ease((local - 0.55) / 1.6) : 1;
      this.architecture.children[0].position.set(0, 0, -1);
      this.architecture.children[1].position.set((s === 7 ? -4 * (1 - join) : -1.3), s === 7 ? 1.2 * (1 - join) : 0.5, 0.7);
      this.architecture.children[2].position.set((s === 7 ? 4 * (1 - join) : 1.4), s === 7 ? -1.1 * (1 - join) : -0.6, -0.5);
      this.architecture.rotation.set(t * 0.09, t * 0.16, t * 0.035);
      this.architecture.scale.setScalar(s === 7 ? 0.9 + join * 0.18 : 1);
    }

    this.city.visible = s === 10;
    if (this.city.visible) {
      for (let i = 0; i < this.cityData.length; i++) {
        const b = this.cityData[i];
        const assembled = ease((local - i * 0.006) / 1.48);
        const h = Math.max(0.005, b.h * assembled);
        this.dummy.position.set(b.x, -4 + h / 2, b.z);
        this.dummy.scale.set(b.w, h, b.d);
        this.dummy.updateMatrix();
        this.city.setMatrixAt(i, this.dummy.matrix);
      }
      this.city.instanceMatrix.needsUpdate = true;
    }

    if (s === 10) {
      this.camera.position.set(2.5 - local * 0.8, 4.6 - local * 0.26, 17.5 - local * 2.5);
      this.camera.lookAt(0, -0.9, -2);
    } else {
      this.camera.position.set(
        s === 2 || s === 7 ? Math.sin(t * 0.32) * 2.3 : Math.sin(t * 0.22) * 0.5,
        s === 0 ? 0.5 : s === 2 ? 0.9 : 0,
        s === 0 ? 22 - local * 2.2 : s === 1 ? 22 - local * 1.1 : 22,
      );
      this.camera.lookAt(0, 0, 0);
    }
    this.renderer.render(this.scene, this.camera);
    return this.canvas;
  }

  dispose() {
    this.pointGeometry.dispose();
    this.pointMaterial.dispose();
    this.lineGeometry.dispose();
    (this.lines.material as THREE.Material).dispose();
    this.city.geometry.dispose();
    (this.city.material as THREE.Material).dispose();
    this.renderer.dispose();
  }
}
type Cue = { at: number; kind: 'impact' | 'pulse' | 'click' | 'resolve'; strength?: number };

const CUES: Cue[] = [
  { at: 0.23, kind: 'pulse', strength: 0.55 },
  { at: 0.91, kind: 'impact', strength: 0.72 },
  { at: 1.76, kind: 'pulse', strength: 0.65 },
  { at: 2.77, kind: 'impact', strength: 0.78 },
  { at: 3.05, kind: 'pulse', strength: 0.45 },
  { at: 4.52, kind: 'click', strength: 0.9 },
  { at: 5.72, kind: 'impact', strength: 0.48 },
  { at: 6.03, kind: 'pulse', strength: 0.54 },
  { at: 7.57, kind: 'pulse', strength: 0.57 },
  { at: 9.02, kind: 'impact', strength: 0.95 },
  { at: 10.32, kind: 'click', strength: 0.75 },
  { at: 11.05, kind: 'impact', strength: 0.87 },
  { at: 12.04, kind: 'click', strength: 0.62 },
  { at: 13.41, kind: 'pulse', strength: 0.52 },
  { at: 14.02, kind: 'impact', strength: 0.65 },
  { at: 15.03, kind: 'impact', strength: 0.58 },
  { at: 16.43, kind: 'pulse', strength: 0.63 },
  { at: 17.07, kind: 'impact', strength: 0.65 },
  { at: 18.29, kind: 'impact', strength: 1.25 },
  { at: 19.19, kind: 'impact', strength: 0.95 },
  { at: 20.63, kind: 'pulse', strength: 0.85 },
  { at: 21.47, kind: 'click', strength: 0.8 },
  { at: 22.57, kind: 'impact', strength: 0.7 },
  { at: 24.04, kind: 'impact', strength: 0.83 },
  { at: 25.9, kind: 'impact', strength: 0.94 },
  { at: 27.03, kind: 'pulse', strength: 0.42 },
  { at: 28.35, kind: 'click', strength: 0.65 },
  { at: 29.5, kind: 'impact', strength: 0.7 },
  { at: 30.07, kind: 'impact', strength: 0.9 },
  { at: 31.61, kind: 'pulse', strength: 0.75 },
  { at: 32.88, kind: 'impact', strength: 0.9 },
  { at: 33.53, kind: 'pulse', strength: 0.56 },
  { at: 34.31, kind: 'resolve', strength: 0.9 },
  { at: 36.11, kind: 'resolve', strength: 0.55 },
  { at: 38.15, kind: 'resolve', strength: 0.58 },
];

/** Restrained procedural score; the same output bus is used for speakers and recording. */
export class FilmSound {
  private context: AudioContext | null = null;
  private master: GainNode | null = null;
  private bed: GainNode | null = null;
  private destination: MediaStreamAudioDestinationNode | null = null;
  private oscillators: OscillatorNode[] = [];
  private noise: AudioBuffer | null = null;
  private lastTime = 0;
  private playing = false;

  get enabled() {
    return this.context !== null;
  }

  get stream() {
    return this.destination?.stream ?? null;
  }

  async enable() {
    if (this.context) {
      await this.context.resume();
      return;
    }
    const AudioContextClass = window.AudioContext;
    if (!AudioContextClass) throw new Error('Web Audio is not supported in this browser.');
    const ctx = new AudioContextClass();
    this.context = ctx;
    const destination = ctx.createMediaStreamDestination();
    const master = ctx.createGain();
    master.gain.value = 0;
    master.connect(ctx.destination);
    master.connect(destination);
    this.master = master;
    this.destination = destination;

    const bed = ctx.createGain();
    bed.gain.value = 0.12;
    const lowpass = ctx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 230;
    lowpass.Q.value = 0.5;
    bed.connect(lowpass);
    lowpass.connect(master);
    this.bed = bed;
    for (const [frequency, type, level] of [
      [43.65, 'sine', 0.48],
      [65.41, 'triangle', 0.12],
      [87.31, 'sine', 0.13],
    ] as const) {
      const oscillator = ctx.createOscillator();
      oscillator.type = type;
      oscillator.frequency.value = frequency;
      const gain = ctx.createGain();
      gain.gain.value = level;
      oscillator.connect(gain);
      gain.connect(bed);
      oscillator.start();
      this.oscillators.push(oscillator);
    }

    const noise = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 1.5), ctx.sampleRate);
    const samples = noise.getChannelData(0);
    let state = 5741;
    for (let i = 0; i < samples.length; i++) {
      state = (state * 1664525 + 1013904223) >>> 0;
      samples[i] = (state / 2147483648 - 1) * 0.75;
    }
    this.noise = noise;
    await ctx.resume();
    this.setPlaying(this.playing);
  }

  setPlaying(playing: boolean) {
    this.playing = playing;
    if (this.context && this.master) {
      this.master.gain.setTargetAtTime(playing ? 0.52 : 0.0001, this.context.currentTime, playing ? 0.28 : 0.12);
    }
  }

  seek(time: number) {
    this.lastTime = time;
  }

  update(time: number) {
    const ctx = this.context;
    if (!ctx || !this.playing) {
      this.lastTime = time;
      return;
    }
    if (time < this.lastTime) this.lastTime = time;
    for (const cue of CUES) {
      if (cue.at > this.lastTime && cue.at <= time) this.playCue(cue);
    }
    if (this.bed) {
      const hush = time >= 18 && time < 18.27 ? 0.002 : time > 33 ? 0.07 : 0.105 + Math.sin(time * 0.24) * 0.018;
      this.bed.gain.setTargetAtTime(hush, ctx.currentTime, 0.2);
    }
    this.lastTime = time;
  }

  private playCue(cue: Cue) {
    const ctx = this.context!;
    const master = this.master!;
    const now = ctx.currentTime;
    const strength = cue.strength ?? 1;

    if (cue.kind === 'click') {
      if (!this.noise) return;
      const source = ctx.createBufferSource();
      source.buffer = this.noise;
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 1350;
      filter.Q.value = 1.6;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.12 * strength, now + 0.004);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.085);
      source.connect(filter);
      filter.connect(gain);
      gain.connect(master);
      source.start(now);
      source.stop(now + 0.09);
      return;
    }

    const oscillator = ctx.createOscillator();
    oscillator.type = cue.kind === 'resolve' ? 'sine' : 'triangle';
    const gain = ctx.createGain();
    const duration = cue.kind === 'resolve' ? 1.8 : cue.kind === 'pulse' ? 0.7 : 1.08;
    const startFrequency = cue.kind === 'resolve' ? 130.81 : cue.kind === 'pulse' ? 109 : 83;
    oscillator.frequency.setValueAtTime(startFrequency, now);
    oscillator.frequency.exponentialRampToValueAtTime(cue.kind === 'resolve' ? 65.41 : 38, now + duration);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime((cue.kind === 'resolve' ? 0.19 : 0.29) * strength, now + 0.018);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    oscillator.connect(gain);
    gain.connect(master);
    oscillator.start(now);
    oscillator.stop(now + duration + 0.01);

    if (cue.kind !== 'resolve' && this.noise) {
      const texture = ctx.createBufferSource();
      texture.buffer = this.noise;
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(cue.kind === 'pulse' ? 900 : 1900, now);
      filter.frequency.exponentialRampToValueAtTime(130, now + 0.62);
      const textureGain = ctx.createGain();
      textureGain.gain.setValueAtTime(0.0001, now);
      textureGain.gain.exponentialRampToValueAtTime(0.055 * strength, now + 0.022);
      textureGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.56);
      texture.connect(filter);
      filter.connect(textureGain);
      textureGain.connect(master);
      texture.start(now);
      texture.stop(now + 0.59);
    }
  }

  async dispose() {
    this.oscillators.forEach((oscillator) => oscillator.stop());
    await this.context?.close();
    this.context = null;
  }
}
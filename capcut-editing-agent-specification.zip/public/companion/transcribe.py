#!/usr/bin/env python3
"""Local word-timestamp transcription helper for Cutroom.

Install once on the computer with the original footage:
  py -3.11 -m pip install faster-whisper

Transcribe a folder (audio is extracted locally by faster-whisper):
  py transcribe.py --media-dir "C:/MyFilm/Footage" --output transcript.json

Paste the resulting JSON into Cutroom's Dialogue & transcript field. It contains
word-level timestamps and source_file names for caption timing. Model weights may
be downloaded the first time you choose a model; inference itself runs locally.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

SUPPORTED = {".mp4", ".mov", ".m4v", ".webm", ".mkv", ".mp3", ".wav", ".m4a", ".aac", ".ogg"}


def main() -> int:
    parser = argparse.ArgumentParser(description="Transcribe local footage with word-level timestamps.")
    parser.add_argument("--media-dir", required=True, help="Folder with original video and audio files")
    parser.add_argument("--output", default="cutroom-transcript.json", help="Output JSON file")
    parser.add_argument("--model", default="base", help="faster-whisper model size (default: base)")
    parser.add_argument("--language", help="Optional language code, for example en")
    args = parser.parse_args()

    media_dir = Path(args.media_dir).expanduser().resolve()
    if not media_dir.is_dir():
        parser.error(f"Media folder not found: {media_dir}")
    files = sorted(path for path in media_dir.iterdir() if path.is_file() and path.suffix.lower() in SUPPORTED)
    if not files:
        parser.error("No supported video or audio files were found in this folder.")

    try:
        from faster_whisper import WhisperModel
    except ImportError:
        parser.error("faster-whisper is not installed. Run: py -3.11 -m pip install faster-whisper")

    model = WhisperModel(args.model, device="auto", compute_type="int8")
    transcriptions: list[dict[str, Any]] = []
    for index, media_path in enumerate(files, start=1):
        print(f"[{index}/{len(files)}] Transcribing {media_path.name} …", file=sys.stderr)
        segments, info = model.transcribe(
            str(media_path),
            word_timestamps=True,
            vad_filter=True,
            language=args.language or None,
        )
        words: list[dict[str, Any]] = []
        for segment in segments:
            for word in segment.words or []:
                text = str(word.word).strip()
                if not text or word.start is None or word.end is None:
                    continue
                words.append({
                    "word": text,
                    "start_s": round(float(word.start), 3),
                    "end_s": round(float(word.end), 3),
                })
        transcriptions.append({
            "source_file": media_path.name,
            "language": info.language,
            "duration_s": round(float(info.duration), 3),
            "words": words,
        })

    output_path = Path(args.output).expanduser().resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps({"files": transcriptions}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Saved {sum(len(item['words']) for item in transcriptions)} word timestamps to {output_path}")
    print("Paste this JSON into Cutroom's Dialogue & transcript field for synchronized captions.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit("Cancelled.")

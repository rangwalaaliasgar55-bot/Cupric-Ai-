#!/usr/bin/env python3
"""Build a CapCut/Jianying draft from a Cutroom EDL manifest.

Install on the desktop that owns the footage and CapCut drafts folder:
  py -3.11 -m pip install pyJianYingDraft

Keep the original files named as listed in clip_inventory, then run:
  py build_capcut_draft.py --manifest my-edit-manifest.json \
    --media-dir "C:/MyFilm/Footage" --drafts-dir "C:/Users/me/CapCut Drafts"

This bridge writes a local editable draft. It does not automate CapCut or export a
render. Review the result in CapCut and export manually. It uses pyJianYingDraft
for all project, track, segment, transition, text, filter and keyframe operations.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import pyJianYingDraft as draft
from pyJianYingDraft import (
    AudioMaterial,
    ClipSettings,
    FilterType,
    FontType,
    KeyframeProperty,
    TextIntro,
    TextOutro,
    TextStyle,
    TransitionType,
    trange,
)

TRANSITIONS = {
    "dissolve": "叠化",
    "whip_pan": "向左流动",
    "zoom_cut": "吸入",
}
GRADE_HINTS = {
    "warm_premium": ("暖", "夕阳", "琥珀", "金色", "原生肤"),
    "cool_tech": ("蓝", "青", "冷", "冰雪"),
    "high_contrast_punchy": ("对比", "鲜艳", "浓郁", "高饱和", "原生肤"),
    "neutral": (),
}


def seconds(value: float) -> str:
    return f"{max(0.0, float(value)):.6f}s"


def safe_project_name(value: str) -> str:
    name = "".join(character if character.isalnum() or character in " -_" else "-" for character in value)
    name = " ".join(name.split()).strip(" -_")[:72]
    return name or "Cutroom draft"


def resolve_media(media_dir: Path, source_file: str) -> Path:
    candidate = Path(source_file)
    if not candidate.is_absolute():
        candidate = media_dir / candidate
    resolved = candidate.resolve()
    base = media_dir.resolve()
    try:
        resolved.relative_to(base)
    except ValueError as exc:
        raise ValueError(f"Source path must remain inside --media-dir: {source_file}") from exc
    if not resolved.is_file():
        raise FileNotFoundError(f"Missing source file: {resolved}\nPut the original file in --media-dir; the web upload is not your CapCut source folder.")
    return resolved


def backup_existing_draft(project_path: Path) -> Path | None:
    if not project_path.exists():
        return None
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = project_path.with_name(f"{project_path.name}.backup-{timestamp}")
    suffix = 1
    while backup.exists():
        backup = project_path.with_name(f"{project_path.name}.backup-{timestamp}-{suffix}")
        suffix += 1
    shutil.copytree(project_path, backup)
    return backup


def find_grade_filter(mood: str) -> Any | None:
    hints = GRADE_HINTS.get(mood, ())
    if not hints:
        return None
    try:
        members = list(FilterType)
    except TypeError:
        members = []
    for hint in hints:
        for member in members:
            label = str(getattr(getattr(member, "value", None), "name", member))
            if hint in label:
                return member
    return None


def add_eased_zoom(segment: Any, duration: float, start_scale: float, end_scale: float) -> None:
    """Approximate an ease-in/out curve with smoothstep-spaced linear keyframes.

    pyJianYingDraft currently exports linear interpolation only. Several carefully
    placed keyframes make this subtle move read as eased without editing its JSON.
    """
    if abs(start_scale - end_scale) <= 0.001:
        return
    segment.uniform_scale = False
    for fraction in (0.0, 0.25, 0.5, 0.75, 1.0):
        eased = fraction * fraction * (3.0 - 2.0 * fraction)
        scale = start_scale + (end_scale - start_scale) * eased
        offset = seconds(duration * fraction)
        segment.add_keyframe(KeyframeProperty.scale_x, offset, scale)
        segment.add_keyframe(KeyframeProperty.scale_y, offset, scale)


def find_sfx(sfx_dir: Path, tag: str) -> Path | None:
    extensions = {".mp3", ".wav", ".m4a", ".aac", ".ogg"}
    wanted = re.sub(r"[^a-z0-9]", "", tag.lower())
    for path in sorted(sfx_dir.iterdir()):
        if path.is_file() and path.suffix.lower() in extensions:
            candidate = re.sub(r"[^a-z0-9]", "", path.stem.lower())
            if candidate == wanted or (wanted and wanted in candidate):
                return path
    return None


def align_to_music_beats(clips: list[dict[str, Any]], assets: dict[str, dict[str, Any]], media_dir: Path) -> int:
    music_asset = next((asset for asset in assets.values() if asset.get("kind") == "audio"), None)
    if music_asset is None:
        print("Note: beat alignment requested, but the project has no music-bed file.")
        return 0
    music_path = resolve_media(media_dir, str(music_asset.get("source_file", "")))
    try:
        import librosa
    except ImportError as exc:
        raise RuntimeError("Beat alignment needs librosa. Install it with: py -3.11 -m pip install librosa") from exc

    target_duration = sum(float(clip["out_s"]) - float(clip["in_s"]) for clip in clips)
    audio, sample_rate = librosa.load(str(music_path), sr=22050, mono=True, duration=target_duration)
    _, beat_frames = librosa.beat.beat_track(y=audio, sr=sample_rate)
    beat_times = [float(value) for value in librosa.frames_to_time(beat_frames, sr=sample_rate)]
    if not beat_times:
        print("Note: no beats were detected; original cut timing was kept.")
        return 0

    adjusted = 0
    boundary = 0.0
    for clip in clips[:-1]:
        duration = float(clip["out_s"]) - float(clip["in_s"])
        boundary += duration
        nearest = min(beat_times, key=lambda beat: abs(beat - boundary))
        delta = nearest - boundary
        asset = assets.get(str(clip.get("source_file", "")), {})
        proposed_out = float(clip["out_s"]) + delta
        source_limit = float(asset.get("duration_s") or 0)
        if abs(delta) <= 0.18 and float(clip["in_s"]) + 0.4 < proposed_out and (not source_limit or proposed_out <= source_limit):
            clip["out_s"] = round(proposed_out, 3)
            boundary += delta
            adjusted += 1
    print(f"Beat alignment adjusted {adjusted} of {max(0, len(clips) - 1)} nearby cuts.")
    return adjusted


def add_audio_track(script: Any, media_path: Path, source_start: float, duration: float, target_start: float, track: str, volume: float, fade_in: float = 0.0, fade_out: float = 0.0) -> None:
    if duration <= 0.04:
        return
    try:
        audio = draft.AudioSegment(
            str(media_path),
            trange(seconds(target_start), seconds(duration)),
            source_timerange=trange(seconds(source_start), seconds(duration)),
            volume=volume,
        )
        fade_in = min(fade_in, duration / 3)
        fade_out = min(fade_out, duration / 3)
        if fade_in > 0.01 or fade_out > 0.01:
            audio.add_fade(seconds(fade_in), seconds(fade_out))
        script.add_segment(audio, track)
    except Exception as exc:  # Some camera clips do not contain an audio stream.
        print(f"Note: embedded audio was not added for {media_path.name}: {exc}", file=sys.stderr)


def main() -> int:
    parser = argparse.ArgumentParser(description="Create an editable CapCut/Jianying draft using pyJianYingDraft.")
    parser.add_argument("--manifest", required=True, help="Cutroom edit manifest JSON")
    parser.add_argument("--media-dir", required=True, help="Folder containing the original source files")
    parser.add_argument("--drafts-dir", required=True, help="Existing CapCut/Jianying drafts folder")
    parser.add_argument("--project-name", help="Draft name (defaults to the project name in the manifest)")
    parser.add_argument("--sfx-dir", help="Optional folder of tag-named sound effects, e.g. soft-impact.wav")
    parser.add_argument("--beat-align", action="store_true", help="Optionally align nearby cut points to the selected music bed with librosa")
    parser.add_argument("--fps", type=int, default=30, help="Timeline frame rate (default: 30)")
    args = parser.parse_args()

    manifest_path = Path(args.manifest).expanduser().resolve()
    media_dir = Path(args.media_dir).expanduser().resolve()
    drafts_dir = Path(args.drafts_dir).expanduser().resolve()
    sfx_dir = Path(args.sfx_dir).expanduser().resolve() if args.sfx_dir else None
    if not manifest_path.is_file():
        parser.error(f"Manifest not found: {manifest_path}")
    if not media_dir.is_dir():
        parser.error(f"Media folder not found: {media_dir}")
    if not drafts_dir.is_dir():
        parser.error(f"Drafts folder must already exist: {drafts_dir}")
    if sfx_dir is not None and not sfx_dir.is_dir():
        parser.error(f"SFX folder not found: {sfx_dir}")
    if args.fps < 1 or args.fps > 120:
        parser.error("--fps must be between 1 and 120")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    edl = manifest.get("edl")
    if not isinstance(edl, dict) or not isinstance(edl.get("sections"), list):
        parser.error("Manifest has no valid EDL. Generate an edit before downloading it.")
    clips = [clip for section in edl["sections"] for clip in section.get("clips", [])]
    if not clips:
        parser.error("EDL contains no video clips.")

    assets = {asset.get("source_file"): asset for asset in manifest.get("clip_inventory", []) if isinstance(asset, dict)}
    for clip in clips:
        source_file = str(clip.get("source_file", ""))
        asset = assets.get(source_file)
        if not asset:
            parser.error(f"The EDL references a file missing from clip_inventory: {source_file}")
        resolve_media(media_dir, source_file)
        in_s, out_s = float(clip["in_s"]), float(clip["out_s"])
        source_duration = float(asset.get("duration_s") or 0)
        if in_s < 0 or out_s <= in_s or (source_duration and out_s > source_duration + 0.25):
            parser.error(f"Invalid or out-of-range source segment for {source_file}: {in_s}–{out_s}")
    if args.beat_align:
        align_to_music_beats(clips, assets, media_dir)

    ratio = manifest.get("aspect_ratio", "9:16")
    if ratio == "16:9":
        width, height = 1920, 1080
    elif ratio == "1:1":
        width, height = 1080, 1080
    else:
        width, height = 1080, 1920

    project_name = safe_project_name(args.project_name or manifest.get("project_name", "Cutroom draft"))
    project_path = drafts_dir / project_name
    backup_path = backup_existing_draft(project_path)
    if backup_path:
        print(f"Backed up existing draft first: {backup_path}")

    folder = draft.DraftFolder(str(drafts_dir))
    script = folder.create_draft(project_name, width, height, fps=args.fps, allow_replace=backup_path is not None)
    script.append_tracks([
        draft.TrackSpec(draft.TrackType.audio, "dialogue"),
        draft.TrackSpec(draft.TrackType.audio, "music"),
        draft.TrackSpec(draft.TrackType.audio, "sfx"),
        draft.TrackSpec(draft.TrackType.video, "main"),
        draft.TrackSpec(draft.TrackType.text, "captions"),
    ])

    prepared: list[tuple[dict[str, Any], Path, float, Any]] = []
    for clip in clips:
        source_file = str(clip.get("source_file", ""))
        asset = assets.get(source_file)
        if not asset:
            raise ValueError(f"The EDL references a file missing from clip_inventory: {source_file}")
        media_path = resolve_media(media_dir, source_file)
        in_s, out_s = float(clip["in_s"]), float(clip["out_s"])
        duration = out_s - in_s
        if in_s < 0 or duration <= 0:
            raise ValueError(f"Invalid source range for {source_file}: {in_s}–{out_s}")
        segment = draft.VideoSegment(
            str(media_path),
            trange("0s", seconds(duration)),
            source_timerange=trange(seconds(in_s), seconds(duration)),
            volume=0.0,
        )
        zoom = clip.get("keyframe_zoom")
        if isinstance(zoom, dict):
            add_eased_zoom(segment, duration, float(zoom.get("start_scale", 1.0)), float(zoom.get("end_scale", 1.0)))
        prepared.append((clip, media_path, duration, segment))

    music_assets = [asset for asset in manifest.get("clip_inventory", []) if isinstance(asset, dict) and asset.get("kind") == "audio"]
    if music_assets:
        music = music_assets[0]
        music_path = resolve_media(media_dir, str(music.get("source_file", "")))
        timeline_duration = sum(duration for _, _, duration, _ in prepared)
        music_duration = min(timeline_duration, float(music.get("duration_s") or timeline_duration))
        add_audio_track(script, music_path, 0.0, music_duration, 0.0, "music", 0.24, 0.35, min(1.0, music_duration / 4))

    filter_type = find_grade_filter(str(edl.get("color_grade_mood", "neutral")))
    if filter_type is None and edl.get("color_grade_mood") != "neutral":
        print(f"Note: no matching installed filter was found for grade '{edl.get('color_grade_mood')}'. The EDL's consistent grade mood remains available for manual review.")

    timeline = 0.0
    previous_segment = None
    for clip, media_path, duration, segment in prepared:
        transition_name = clip.get("transition_in", "hard_cut")
        if previous_segment is not None and transition_name in TRANSITIONS:
            try:
                transition = getattr(TransitionType, TRANSITIONS[transition_name])
                previous_segment.add_transition(transition)
            except (AttributeError, ValueError) as exc:
                print(f"Note: transition '{transition_name}' is unavailable in this pyJianYingDraft build: {exc}")
        if filter_type is not None:
            try:
                segment.add_filter(filter_type, 12)
            except (AttributeError, ValueError) as exc:
                print(f"Note: the selected grade filter could not be applied: {exc}")

        segment.target_timerange = trange(seconds(timeline), seconds(duration))
        script.add_segment(segment, "main")

        # Keep camera/dialogue audio on its own lane so the source picture stays silent.
        source_start = float(clip["in_s"])
        offset = clip.get("audio_offset", "none")
        if offset == "j_cut":
            lead = min(0.25, source_start, timeline)
            add_audio_track(script, media_path, source_start - lead, duration + lead, timeline - lead, "dialogue", 1.0)
        elif offset == "l_cut":
            source_duration = float(assets[clip["source_file"]].get("duration_s") or (float(clip["out_s"]) + 0.25))
            tail = min(0.25, max(0.0, source_duration - float(clip["out_s"])))
            add_audio_track(script, media_path, source_start, duration + tail, timeline, "dialogue", 1.0)
        else:
            add_audio_track(script, media_path, source_start, duration, timeline, "dialogue", 1.0)

        if sfx_dir is not None:
            for cue in clip.get("sfx", []):
                tag = str(cue.get("tag", "")).strip()
                sfx_path = find_sfx(sfx_dir, tag) if tag else None
                if sfx_path is None:
                    if tag:
                        print(f"Note: no local SFX file matched tag '{tag}'.")
                    continue
                try:
                    sfx_material = AudioMaterial(str(sfx_path))
                    sfx_duration = min(1.8, sfx_material.duration / draft.SEC)
                    cue_start = min(duration, max(0.0, float(cue.get("at_s", 0))))
                    sfx_length = min(sfx_duration, max(0.06, duration - cue_start))
                    sfx_segment = draft.AudioSegment(
                        sfx_material,
                        trange(seconds(timeline + cue_start), seconds(sfx_length)),
                        volume=0.42,
                    )
                    script.add_segment(sfx_segment, "sfx")
                except Exception as exc:
                    print(f"Note: could not add SFX tag '{tag}': {exc}", file=sys.stderr)

        for caption in clip.get("captions", []):
            text = str(caption.get("word", "")).strip()
            if not text:
                continue
            start = max(0.0, min(duration, float(caption.get("start_s", 0))))
            end = max(start + 0.06, min(duration, float(caption.get("end_s", start + 0.28))))
            if end <= start:
                continue
            color = (0.82, 0.96, 0.53) if caption.get("emphasis") else (1.0, 1.0, 1.0)
            title = draft.TextSegment(
                text,
                trange(seconds(timeline + start), seconds(end - start)),
                font=FontType.文轩体,
                style=TextStyle(size=8.0, color=color, align=1, auto_wrapping=True, max_line_width=0.8),
                clip_settings=ClipSettings(transform_y=-0.75),
            )
            title.add_animation(TextIntro.弹簧).add_animation(TextOutro.弹簧)
            script.add_segment(title, "captions")

        previous_segment = segment
        timeline += duration

    output = script.save()
    print(f"Draft ready: {project_path}")
    print(f"Saved project file: {output if output else project_path / 'draft_content.json'}")
    print("Open this draft in CapCut, review the edit, then export manually from the app.")
    print("Audio offsets are short 0.25s J/L cuts where source handles allow; music bed is reduced to 24% gain.")
    print("Eased zooms are approximated with smoothstep keyframes; keyframes in this library are linear-only.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit("Cancelled.")

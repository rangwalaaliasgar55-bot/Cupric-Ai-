import { sql } from "drizzle-orm";
import { boolean, integer, jsonb, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import type { ClipAsset, EditDecisionList, AspectRatio } from "../lib/edl";

export const editingProjects = pgTable("editing_projects", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull().default("Untitled film"),
  stylePrompt: text("style_prompt").notNull().default(""),
  targetDuration: integer("target_duration_s").notNull().default(30),
  aspectRatio: text("aspect_ratio").$type<AspectRatio>().notNull().default("9:16"),
  status: text("status").$type<"draft" | "ready">().notNull().default("draft"),
  clips: jsonb("clips").$type<ClipAsset[]>().notNull().default(sql`'[]'::jsonb`),
  transcript: text("transcript").notNull().default(""),
  edl: jsonb("edl").$type<EditDecisionList | null>(),
  isExample: boolean("is_example").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

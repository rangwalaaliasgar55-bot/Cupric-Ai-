"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { demoProject } from "@/lib/demo-project";
import { flattenEDL, type ClipAsset, type EditDecisionList, type EditRole, type EDLClip, type StudioProject } from "@/lib/edl";

type StudioProps = { initialProjects: StudioProject[] };
type GlyphName = "mark" | "home" | "film" | "guide" | "settings" | "plus" | "spark" | "upload" | "play" | "pause" | "chevron" | "close" | "download" | "clock" | "scissors" | "wave" | "caption" | "check" | "arrow" | "folder" | "trash" | "lock" | "external" | "music" | "video" | "image" | "cloud";
type ModalName = "settings" | "guide" | null;

function Glyph({ name, size = 18, stroke = 1.8 }: { name: GlyphName; size?: number; stroke?: number }) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: stroke, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true as const };
  const paths: Record<GlyphName, ReactNode> = {
    mark: <><path d="M4 4h7v7H4z" /><path d="M13 4h7v4h-7z" /><path d="M13 10h7v10h-7z" /><path d="M4 13h7v7H4z" /></>,
    home: <><path d="m3 10 9-7 9 7" /><path d="M5 9v11h14V9" /><path d="M9 20v-6h6v6" /></>,
    film: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M7 5v14M17 5v14M3 9h4M3 15h4M17 9h4M17 15h4" /></>,
    guide: <><path d="M5 4.5A2.5 2.5 0 0 1 7.5 2H20v18H7.5A2.5 2.5 0 0 0 5 22z" /><path d="M5 5v17M9 7h7M9 11h7" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.6a7.8 7.8 0 0 1-1.4.8l-.3 1.8h-2.8l-.3-1.8a7.8 7.8 0 0 1-1.4-.8l-1.7.6-1.4-2.4 1.4-1.1a7.4 7.4 0 0 1 0-1.6l-1.4-1.1 1.4-2.4 1.7.6a7.8 7.8 0 0 1 1.4-.8l.3-1.8h2.8l.3 1.8a7.8 7.8 0 0 1 1.4.8l1.7-.6 1.4 2.4-1.4 1.1a7.4 7.4 0 0 1 0 1.6Z" transform="translate(-1 -1) scale(.98)" /></>,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    spark: <><path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z" /><path d="m19 16 .9 2.1L22 19l-2.1.9L19 22l-.9-2.1L16 19l2.1-.9L19 16Z" /></>,
    upload: <><path d="M12 16V4m0 0L7 9m5-5 5 5" /><path d="M5 14v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5" /></>,
    play: <path d="m8 5 11 7-11 7V5Z" fill="currentColor" stroke="none" />,
    pause: <><path d="M8 5v14M16 5v14" strokeWidth="2.5" /></>,
    chevron: <path d="m9 18 6-6-6-6" />,
    close: <><path d="m18 6-12 12M6 6l12 12" /></>,
    download: <><path d="M12 3v12m0 0 5-5m-5 5-5-5" /><path d="M5 17v4h14v-4" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3.5 2" /></>,
    scissors: <><circle cx="6" cy="6" r="2.5" /><circle cx="6" cy="18" r="2.5" /><path d="m8 8 12 12M8 16l12-12" /></>,
    wave: <path d="M2 12h2l2-6 4 12 4-12 3 12 2-6h3" />,
    caption: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M7 10h10M7 14h6" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    arrow: <><path d="M5 12h14M13 6l6 6-6 6" /></>,
    folder: <><path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /></>,
    trash: <><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v5M14 11v5" /></>,
    lock: <><rect x="4" y="10" width="16" height="11" rx="2" /><path d="M8 10V7a4 4 0 1 1 8 0v3" /></>,
    external: <><path d="M14 4h6v6M20 4l-9 9" /><path d="M18 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5" /></>,
    music: <><path d="M9 18V5l12-2v13" /><circle cx="6" cy="18" r="3" /><circle cx="18" cy="16" r="3" /></>,
    video: <><rect x="3" y="5" width="13" height="14" rx="2" /><path d="m16 10 5-3v10l-5-3" /></>,
    image: <><rect x="3" y="4" width="18" height="16" rx="2" /><circle cx="8.5" cy="9" r="1.5" /><path d="m21 15-5-5L5 20" /></>,
    cloud: <><path d="M20 16.5A4.5 4.5 0 0 0 18 8h-1a6 6 0 1 0-11 3.5A4 4 0 0 0 7 19h11a3.5 3.5 0 0 0 2-2.5Z" /></>,
  };
  return <svg {...common}>{paths[name]}</svg>;
}

const roleTitles: Record<EditRole, string> = { hook: "Hook", problem: "Agitate", solution: "Solution", proof: "Proof", cta: "CTA", body: "Story" };
const roleColors: Record<EditRole, string> = { hook: "#d7f177", problem: "#efba9a", solution: "#bdd2e9", proof: "#d5c6ec", cta: "#f0c969", body: "#c9cbc1" };
const stylePresets = [
  { label: "Warm & considered", prompt: "A premium, sun-warmed film. Tactile grain, natural movement, and a confident, unhurried pace." },
  { label: "Punchy & alive", prompt: "Energetic short-form with a bold opening, varied 1.5–3 second cuts, visual resets, and crisp sound accents." },
  { label: "Quiet & human", prompt: "An intimate documentary feel. Let the natural moments breathe; prioritize honest dialogue and restrained transitions." },
  { label: "Cool & precise", prompt: "A clean, modern product film with a cool editorial grade, purposeful zooms, clear proof points, and a decisive CTA." },
];

function formatTime(seconds: number) {
  const safe = Math.max(0, Math.floor(seconds));
  return `${String(Math.floor(safe / 60)).padStart(2, "0")}:${String(safe % 60).padStart(2, "0")}`;
}

function formatBytes(bytes: number) {
  if (bytes <= 0) return "STORYBOARD";
  return bytes > 1024 * 1024 ? `${(bytes / (1024 * 1024)).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function makeBlankProject(): Omit<StudioProject, "id" | "createdAt" | "updatedAt"> {
  return { name: "Untitled film", stylePrompt: "", targetDuration: 30, aspectRatio: "9:16", status: "draft", clips: [], transcript: "", edl: null };
}

function payloadForProject(project: StudioProject) {
  return {
    name: project.name,
    stylePrompt: project.stylePrompt,
    targetDuration: project.targetDuration,
    aspectRatio: project.aspectRatio,
    status: project.status,
    clips: project.clips,
    transcript: project.transcript,
    edl: project.edl,
  };
}

function Modal({ modal, onClose, apiKey, onSaveKey, onRemoveKey }: {
  modal: Exclude<ModalName, null>;
  onClose: () => void;
  apiKey: string;
  onSaveKey: (value: string) => void;
  onRemoveKey: () => void;
}) {
  const [keyDraft, setKeyDraft] = useState(apiKey);
  const [showKey, setShowKey] = useState(false);
  useEffect(() => setKeyDraft(apiKey), [apiKey]);
  return (
    <div className="modal-scrim" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <button className="icon-button modal-close" onClick={onClose} aria-label="Close dialog"><Glyph name="close" /></button>
        {modal === "settings" ? <>
          <div className="modal-icon"><Glyph name="spark" size={21} /></div>
          <p className="eyebrow">DIRECTOR SETTINGS</p>
          <h2 id="modal-title">Bring your own Gemini key.</h2>
          <p className="modal-lede">The key lives only in this browser’s local storage. It is sent over HTTPS in a request header and is never saved to a project, database, or application log.</p>
          <label className="field-label" htmlFor="gemini-key">Google AI Studio API key</label>
          <div className="key-field">
            <input id="gemini-key" type={showKey ? "text" : "password"} autoComplete="off" value={keyDraft} onChange={(event) => setKeyDraft(event.target.value)} placeholder="Paste your API key" />
            <button type="button" className="text-button" onClick={() => setShowKey((value) => !value)}>{showKey ? "Hide" : "Show"}</button>
          </div>
          <div className="privacy-note"><Glyph name="lock" size={16} /><span>No key? The local craft planner still creates a deterministic cut outline without calling an external AI.</span></div>
          <div className="modal-actions">
            <button className="button button-quiet" onClick={onRemoveKey}>Remove key</button>
            <button className="button button-dark" onClick={() => { onSaveKey(keyDraft.trim()); onClose(); }}>Save locally <Glyph name="check" size={16} /></button>
          </div>
        </> : <>
          <div className="modal-icon"><Glyph name="guide" size={21} /></div>
          <p className="eyebrow">FROM EDL TO CAPCUT</p>
          <h2 id="modal-title">A thoughtful first cut. Then your call.</h2>
          <p className="modal-lede">Cutroom writes an Edit Decision List, not CapCut’s private project JSON. The included Python bridge uses pyJianYingDraft on your machine to turn a downloaded manifest into a real local draft.</p>
          <div className="guide-steps">
            <div><span>01</span><section><b>Generate the EDL</b><small>Upload source clips, set a direction, then generate or refine the cut.</small></section></div>
            <div><span>02</span><section><b>Download the manifest + bridge</b><small>Install pyJianYingDraft locally. Keep the original source files together in a folder on your computer.</small></section></div>
            <div><span>03</span><section><b>Build locally, review in CapCut</b><small>Run the bridge with your CapCut drafts folder. Open the new project, check it, and export manually.</small></section></div>
          </div>
          <pre className="command-example"><code>py -3.11 -m pip install pyJianYingDraft</code><code>py build_capcut_draft.py --manifest edit.json --media-dir ./Footage --drafts-dir "C:/CapCut Drafts"</code></pre>
          <div className="notice-note"><strong>Manual export is intentional.</strong> Current CapCut versions hide the controls used by old Windows UI automation. Open the generated draft and click Export yourself.</div>
          <div className="notice-note notice-warm"><strong>Draft backups are made before overwrite.</strong> Masks are not included because pyJianYingDraft reports them broken on newer builds. CapCut is officially banned in India; check local availability and rules before use.</div>
          <div className="modal-actions"><a className="button button-quiet" href="/companion/transcribe.py" download>Whisper helper <Glyph name="download" size={15} /></a><button className="button button-dark" onClick={onClose}>Got it <Glyph name="check" size={16} /></button></div>
        </>}
      </section>
    </div>
  );
}

export default function Studio({ initialProjects }: StudioProps) {
  const [projects, setProjects] = useState(initialProjects);
  const [sample, setSample] = useState<StudioProject>(demoProject);
  const [activeId, setActiveId] = useState(initialProjects[0]?.id ?? demoProject.id);
  const [activeTab, setActiveTab] = useState<"studio" | "guide">("studio");
  const [modal, setModal] = useState<ModalName>(null);
  const [apiKey, setApiKey] = useState("");
  const [saveState, setSaveState] = useState<"saved" | "saving" | "error">("saved");
  const [provider, setProvider] = useState<"gemini" | "local" | null>(null);
  const [generating, setGenerating] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [transcriptOpen, setTranscriptOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [selectedClipIndex, setSelectedClipIndex] = useState(0);
  const [previewPlaying, setPreviewPlaying] = useState(false);
  const [notice, setNotice] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const saveQueueRef = useRef<Promise<void>>(Promise.resolve());

  const project = activeId === demoProject.id ? sample : projects.find((item) => item.id === activeId) ?? sample;
  const isSample = project.id === demoProject.id;
  const flattened = useMemo(() => project.edl ? flattenEDL(project.edl) : [], [project.edl]);
  const playSequence = flattened.length ? flattened : project.clips.filter((clip) => clip.kind === "video").map((clip, index) => ({
    source_file: clip.source_file, in_s: 0, out_s: clip.duration_s, transition_in: "hard_cut" as const, audio_offset: "none" as const, keyframe_zoom: null, captions: [], sfx: [], role: "body" as const, timeline_start_s: index * clip.duration_s,
  }));
  const safeSelectedIndex = playSequence.length ? selectedClipIndex % playSequence.length : 0;
  const selectedSegment = playSequence[safeSelectedIndex];
  const selectedAsset = selectedSegment ? project.clips.find((clip) => clip.source_file === selectedSegment.source_file) : project.clips.find((clip) => clip.kind === "video");
  const timelineDuration = flattened.reduce((sum, clip) => sum + clip.out_s - clip.in_s, 0);
  const videoCount = project.clips.filter((clip) => clip.kind === "video").length;
  const audioCount = project.clips.filter((clip) => clip.kind === "audio").length;
  const completedSteps = Number(videoCount > 0) + Number(project.stylePrompt.trim().length > 0) + Number(Boolean(project.edl));

  useEffect(() => {
    const storedKey = window.localStorage.getItem("cutroom-gemini-key");
    if (storedKey) setApiKey(storedKey);
  }, []);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(""), 3600);
    return () => window.clearTimeout(timer);
  }, [notice]);

  useEffect(() => {
    if (!previewPlaying || playSequence.length < 2) return;
    const timer = window.setInterval(() => setSelectedClipIndex((index) => (index + 1) % playSequence.length), 2600);
    return () => window.clearInterval(timer);
  }, [previewPlaying, playSequence.length]);

  const applySavedProject = useCallback((updated: StudioProject) => {
    setProjects((current) => current.map((item) => item.id === updated.id ? updated : item));
  }, []);

  const persistProject = useCallback(async (candidate: StudioProject) => {
    const response = await fetch(`/api/projects/${candidate.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payloadForProject(candidate)),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error ?? "Could not save this project.");
    applySavedProject(result.project as StudioProject);
    setSaveState("saved");
  }, [applySavedProject]);

  const queueSave = useCallback((candidate: StudioProject) => {
    if (candidate.id === demoProject.id) return;
    setSaveState("saving");
    saveQueueRef.current = saveQueueRef.current.then(() => persistProject(candidate)).catch((error: unknown) => {
      setSaveState("error");
      setNotice(error instanceof Error ? error.message : "Your changes could not be saved.");
    });
  }, [persistProject]);

  const saveNow = useCallback(async (candidate: StudioProject) => {
    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current);
      saveTimerRef.current = null;
    }
    if (candidate.id === demoProject.id) return;
    setSaveState("saving");
    saveQueueRef.current = saveQueueRef.current.then(() => persistProject(candidate)).catch((error: unknown) => {
      setSaveState("error");
      throw error;
    });
    await saveQueueRef.current;
  }, [persistProject]);

  const updateProject = useCallback((patch: Partial<StudioProject>, invalidate = true) => {
    const current = activeId === demoProject.id ? sample : projects.find((item) => item.id === activeId) ?? sample;
    const shouldInvalidate = invalidate && (patch.stylePrompt !== undefined || patch.transcript !== undefined || patch.clips !== undefined || patch.aspectRatio !== undefined || patch.targetDuration !== undefined);
    const next: StudioProject = {
      ...current,
      ...patch,
      ...(shouldInvalidate ? { edl: null, status: "draft" as const } : {}),
      updatedAt: new Date().toISOString(),
    };
    if (current.id === demoProject.id) setSample(next);
    else {
      setProjects((items) => items.map((item) => item.id === next.id ? next : item));
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
      saveTimerRef.current = setTimeout(() => queueSave(next), 650);
    }
    return next;
  }, [activeId, projects, sample, queueSave]);

  const createProject = useCallback(async (name = "Untitled film") => {
    const blank = makeBlankProject();
    const response = await fetch("/api/projects", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ...blank, name }),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error ?? "Could not create a project.");
    const created = result.project as StudioProject;
    setProjects((items) => [created, ...items]);
    setActiveId(created.id);
    setActiveTab("studio");
    setProvider(null);
    setSelectedClipIndex(0);
    setSaveState("saved");
    setNotice("Your new edit is ready for footage.");
    return created;
  }, []);

  const handleNewProject = async () => {
    try {
      await createProject();
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Could not create a project.");
    }
  };

  const getDuration = (file: File, kind: "video" | "audio") => new Promise<number>((resolve) => {
    const element = document.createElement(kind === "audio" ? "audio" : "video");
    const objectUrl = URL.createObjectURL(file);
    const finish = (duration: number) => {
      URL.revokeObjectURL(objectUrl);
      resolve(Number.isFinite(duration) && duration > 0 ? duration : 0);
    };
    element.preload = "metadata";
    element.onloadedmetadata = () => finish(element.duration);
    element.onerror = () => finish(0);
    window.setTimeout(() => finish(0), 12000);
    element.src = objectUrl;
  });

  const uploadFiles = async (fileList: FileList | File[]) => {
    const files = Array.from(fileList).filter((file) => file.size > 0);
    if (!files.length) return;
    setUploading(true);
    try {
      let target = project;
      if (isSample) target = await createProject(files.find((file) => file.type.startsWith("video/"))?.name.replace(/\.[^.]+$/, "") || "New film");
      const incomingNames = files.map((file) => file.name.split(/[\\/]/).pop() ?? file.name);
      const existingNames = new Set(target.clips.filter((clip) => !clip.is_sample).map((clip) => clip.source_file));
      if (new Set(incomingNames).size !== incomingNames.length || incomingNames.some((name) => existingNames.has(name))) {
        throw new Error("A file with that name is already in this project. Rename duplicate sources before adding them.");
      }
      const uploaded: ClipAsset[] = [];
      for (const file of files) {
        const extension = file.name.split(".").pop()?.toLowerCase() ?? "";
        const kind = file.type.startsWith("audio/") || ["mp3", "wav", "m4a", "aac", "ogg"].includes(extension) ? "audio" : "video";
        const duration = await getDuration(file, kind);
        const data = new FormData();
        data.append("file", file);
        data.append("duration_s", String(duration));
        const response = await fetch("/api/media", { method: "POST", body: data });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(result.error ?? `Could not upload ${file.name}.`);
        uploaded.push(result.clip as ClipAsset);
      }
      const next = { ...target, clips: [...target.clips.filter((clip) => !clip.is_sample), ...uploaded], edl: null, status: "draft" as const, updatedAt: new Date().toISOString() };
      setProjects((current) => current.map((item) => item.id === next.id ? next : item));
      setSelectedClipIndex(0);
      await saveNow(next);
      setNotice(`${uploaded.length} ${uploaded.length === 1 ? "file" : "files"} added to your project.`);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Upload failed.");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleGenerate = async () => {
    if (isSample) {
      setNotice("Start a new project and add your own footage to build a CapCut draft.");
      return;
    }
    if (!videoCount) {
      setNotice("Add at least one video clip before generating an edit.");
      return;
    }
    setGenerating(true);
    setProvider(null);
    try {
      await saveNow(project);
      const response = await fetch(`/api/projects/${project.id}/generate`, {
        method: "POST",
        headers: apiKey ? { "x-gemini-api-key": apiKey } : {},
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error ?? "The director could not finish this cut.");
      applySavedProject(result.project as StudioProject);
      setProvider(result.provider === "gemini" ? "gemini" : "local");
      setSelectedClipIndex(0);
      setNotice(result.provider === "gemini" ? "Director’s cut is ready to review." : "Offline cut outline is ready. Add a Gemini key for an AI-directed EDL.");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "The director could not finish this cut.");
    } finally {
      setGenerating(false);
    }
  };

  const saveApiKey = (value: string) => {
    setApiKey(value);
    if (value) window.localStorage.setItem("cutroom-gemini-key", value);
    else window.localStorage.removeItem("cutroom-gemini-key");
    setNotice(value ? "Gemini key saved in this browser only." : "The key was removed from this browser.");
  };

  const removeApiKey = () => {
    setApiKey("");
    window.localStorage.removeItem("cutroom-gemini-key");
    setNotice("The key was removed from this browser.");
  };

  const downloadEDL = async () => {
    if (isSample) {
      const blob = new Blob([JSON.stringify({ project_name: project.name, target_duration_s: project.targetDuration, aspect_ratio: project.aspectRatio, transcript: project.transcript, clip_inventory: project.clips, edl: project.edl }, null, 2)], { type: "application/json" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "sample-edit-manifest.json";
      link.click();
      URL.revokeObjectURL(link.href);
      return;
    }
    const response = await fetch(`/api/projects/${project.id}/export`);
    if (!response.ok) {
      const result = await response.json().catch(() => ({}));
      setNotice(result.error ?? "Could not download the edit manifest.");
      return;
    }
    const blob = await response.blob();
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${project.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "edit"}-edit-manifest.json`;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  const deleteProject = async () => {
    if (isSample || !window.confirm(`Delete “${project.name}” from your project list?`)) return;
    const response = await fetch(`/api/projects/${project.id}`, { method: "DELETE" });
    if (!response.ok) {
      setNotice("Could not delete this project.");
      return;
    }
    const remaining = projects.filter((item) => item.id !== project.id);
    setProjects(remaining);
    setActiveId(remaining[0]?.id ?? demoProject.id);
    setSample(demoProject);
    setNotice("Project deleted.");
  };

  const togglePreview = async () => {
    if (videoRef.current && !videoRef.current.paused) {
      videoRef.current.pause();
      setPreviewPlaying(false);
      return;
    }
    if (videoRef.current) {
      try { await videoRef.current.play(); } catch { /* Browser autoplay policy; the preview is still selectable from the timeline. */ }
    }
    setPreviewPlaying(true);
  };

  const mainCaption = (selectedSegment as (EDLClip & { role: EditRole; timeline_start_s: number }) | undefined)?.captions ?? [];
  const captionLine = mainCaption.slice(0, 6).map((word) => word.word).join(" ");
  const aspectClass = project.aspectRatio === "16:9" ? "aspect-landscape" : project.aspectRatio === "1:1" ? "aspect-square" : "aspect-portrait";
  const sourcePercent = Math.max(12, Math.min(100, Math.round((videoCount / 8) * 100)));

  return (
    <div className="studio-shell">
      <aside className="sidebar">
        <button className="brand-lockup" onClick={() => setActiveTab("studio")} aria-label="Cutroom home">
          <span className="brand-mark"><Glyph name="mark" size={20} stroke={2.4} /></span>
          <span className="brand-word">cutroom<span>®</span></span>
        </button>
        <div className="workspace-switcher">
          <span className="workspace-avatar">S</span>
          <span><b>Studio North</b><small>Personal workspace</small></span>
          <span className="switch-chevron">⌄</span>
        </div>
        <p className="side-label">WORKSPACE</p>
        <button className={`nav-link ${activeTab === "studio" ? "nav-active" : ""}`} onClick={() => setActiveTab("studio")}><Glyph name="film" size={17} /><span>Editor</span><span className="nav-shortcut">⌘1</span></button>
        <button className={`nav-link ${activeTab === "guide" ? "nav-active" : ""}`} onClick={() => { setActiveTab("guide"); setModal("guide"); }}><Glyph name="guide" size={17} /><span>Build guide</span><Glyph name="external" size={14} /></button>
        <div className="side-section-title"><p className="side-label">RECENT CUTS</p><button onClick={handleNewProject} aria-label="Create a new project"><Glyph name="plus" size={16} /></button></div>
        <div className="project-nav-list">
          {projects.slice(0, 6).map((item, index) => (
            <button key={item.id} className={`project-nav-item ${activeId === item.id ? "project-nav-active" : ""}`} onClick={() => { setActiveId(item.id); setActiveTab("studio"); setSelectedClipIndex(0); }}>
              <span className={`project-nav-thumb thumb-${index % 4}`} style={item.clips[0]?.url ? { backgroundImage: `linear-gradient(180deg,rgba(20,24,22,.05),rgba(20,24,22,.26)), url("${item.clips[0].url}")` } : undefined}><Glyph name="film" size={13} /></span>
              <span className="project-nav-copy"><b>{item.name}</b><small>{item.edl ? "Ready to review" : item.clips.length ? `${item.clips.length} source files` : "New project"}</small></span>
              {activeId === item.id && <span className="nav-dot" />}
            </button>
          ))}
          {!projects.length && <p className="empty-recent">Your next great cut starts here.</p>}
          <button className={`project-nav-item ${isSample ? "project-nav-active" : ""}`} onClick={() => { setActiveId(demoProject.id); setSample(demoProject); setSelectedClipIndex(0); }}>
            <span className="project-nav-thumb sample-thumb"><Glyph name="play" size={13} /></span>
            <span className="project-nav-copy"><b>The shape of a slower day</b><small>Sample storyboard</small></span>
            {isSample && <span className="nav-dot" />}
          </button>
        </div>
        <div className="sidebar-spacer" />
        <div className="plan-card">
          <div className="plan-icon"><Glyph name="spark" size={16} /></div>
          <div><b>{apiKey ? "Gemini director" : "Local director"}</b><small>{apiKey ? "Key saved in this browser" : "Ready · no key needed"}</small></div>
          <span className={`plan-status ${apiKey ? "plan-status-live" : ""}`} />
        </div>
        <button className="sidebar-settings" onClick={() => setModal("settings")}><span className="profile-avatar">A</span><span><b>Alex Morgan</b><small>Settings & API key</small></span><Glyph name="settings" size={17} /></button>
        <p className="sidebar-footnote">MADE FOR THE MOMENT, NOT THE METRONOME.</p>
      </aside>

      <main className="studio-main">
        <header className="topbar">
          <div className="breadcrumbs"><span>Studio</span><Glyph name="chevron" size={14} /><span className="crumb-current">{activeTab === "studio" ? project.name : "Build guide"}</span></div>
          <div className="topbar-right">
            <span className={`save-indicator save-${saveState}`}><span />{saveState === "saving" ? "Saving" : saveState === "error" ? "Not saved" : "All changes saved"}</span>
            <span className="topbar-divider" />
            <button className="icon-button top-settings" onClick={() => setModal("settings")} aria-label="Director settings"><Glyph name="settings" size={17} /></button>
            <button className="button button-small button-outline top-new" onClick={handleNewProject}><Glyph name="plus" size={15} />New project</button>
          </div>
        </header>

        <div className="workspace-scroll">
          <div className="workspace-content">
            <section className="intro-row">
              <div>
                <p className="eyebrow intro-eyebrow"><span className="eyebrow-line" /> THE AI EDITING STUDIO</p>
                <h1>Make it <em>mean</em> something.</h1>
                <p className="intro-copy">Your footage has a story. Give it a point of view, then let the craft follow.</p>
              </div>
              <div className="intro-right">
                <div className="step-progress" aria-label={`${completedSteps} of 3 workflow steps complete`}>
                  <span className="step-progress-label">YOUR CUT</span>
                  <span className="step-progress-count">0{completedSteps}<i> / 03</i></span>
                  <div className="step-track"><span style={{ width: `${(completedSteps / 3) * 100}%` }} /></div>
                  <small>{completedSteps === 3 ? "Ready for your review" : "A few thoughtful steps"}</small>
                </div>
              </div>
            </section>

            <div className="workspace-meta-row">
              <div className="project-title-wrap">
                <span className={`project-status-dot ${project.status === "ready" ? "is-ready" : ""}`} />
                <input className="project-title-input" aria-label="Project title" maxLength={100} value={project.name} onChange={(event) => updateProject({ name: event.target.value }, false)} />
                {isSample ? <span className="sample-pill">EXAMPLE</span> : <span className="cloud-sync"><Glyph name="cloud" size={14} /> {saveState === "saving" ? "Syncing" : "Saved"}</span>}
              </div>
              <div className="project-actions">
                {project.edl && <span className={`director-chip ${provider === "gemini" ? "director-chip-gemini" : ""}`}><Glyph name="spark" size={13} />{provider === "gemini" ? "GEMINI DIRECTOR" : isSample ? "SAMPLE CUT" : "LOCAL CUT PLAN"}</span>}
                <button className="button button-small button-outline" onClick={downloadEDL} disabled={!project.edl}><Glyph name="download" size={15} /> Download EDL</button>
                <a className="button button-small button-lime" href="/companion/build_capcut_draft.py" download><Glyph name="film" size={15} /> CapCut bridge</a>
                {!isSample && <button className="icon-button delete-project" onClick={deleteProject} aria-label="Delete project" title="Delete project"><Glyph name="trash" size={16} /></button>}
              </div>
            </div>

            <section className="editor-grid">
              <div className="direction-card panel-card">
                <div className="panel-heading">
                  <div className="panel-step">01</div>
                  <div><p className="eyebrow">SOURCE + DIRECTION</p><h2>Start with what you have.</h2></div>
                </div>

                <button className={`upload-zone ${isDragging ? "upload-dragging" : ""} ${isSample ? "upload-zone-sample" : ""}`} onClick={() => fileInputRef.current?.click()} onDragOver={(event) => { event.preventDefault(); setIsDragging(true); }} onDragLeave={() => setIsDragging(false)} onDrop={(event) => { event.preventDefault(); setIsDragging(false); void uploadFiles(event.dataTransfer.files); }} disabled={uploading}>
                  <input ref={fileInputRef} type="file" accept="video/*,audio/*,.mkv,.mov,.m4a" multiple hidden onChange={(event) => { if (event.target.files) void uploadFiles(event.target.files); }} />
                  <span className="upload-icon"><Glyph name={uploading ? "wave" : "upload"} size={18} /></span>
                  <span className="upload-copy"><b>{uploading ? "Adding your footage…" : isSample ? "Add your own footage" : "Drop your footage here"}</b><small>{uploading ? "Files stay with this local workspace" : "Video + music · MP4, MOV, WAV, MP3"}</small></span>
                  <span className="upload-action">{uploading ? <span className="mini-spinner" /> : <Glyph name="plus" size={16} />}</span>
                </button>

                {project.clips.length > 0 ? <div className="source-list">
                  {project.clips.map((clip, index) => <div className="source-row" key={clip.id}>
                    <span className={`source-thumb source-thumb-${index % 4}`} style={clip.url ? { backgroundImage: `linear-gradient(0deg,rgba(16,22,20,.34),transparent), url("${clip.url}")` } : undefined}><Glyph name={clip.kind === "audio" ? "music" : "video"} size={15} /></span>
                    <span className="source-name"><b>{clip.name}</b>{clip.kind === "audio" ? <small>MUSIC BED · MIXED BELOW DIALOGUE</small> : clip.is_sample ? <small>{clip.description ?? "STORYBOARD SOURCE"}</small> : <input className="source-description" aria-label={`Describe ${clip.name}`} maxLength={240} value={clip.description ?? ""} placeholder="What happens in this shot?" onChange={(event) => updateProject({ clips: project.clips.map((item) => item.id === clip.id ? { ...item, description: event.target.value } : item) })} />}</span>
                    <span className="source-duration">{clip.duration_s ? formatTime(clip.duration_s) : "—"}</span>
                    {!clip.is_sample && <button className="source-remove" aria-label={`Remove ${clip.name}`} onClick={() => updateProject({ clips: project.clips.filter((item) => item.id !== clip.id) })}><Glyph name="close" size={14} /></button>}
                  </div>)}
                  {project.clips.filter((clip) => clip.kind === "video").length > 4 && <div className="inventory-bar"><span><span style={{ width: `${sourcePercent}%` }} /></span><small>{videoCount} VIDEO{videoCount === 1 ? "" : "S"} IN THE BIN{audioCount > 0 ? ` · ${audioCount} MUSIC BED` : ""}</small></div>}
                </div> : <div className="empty-source"><Glyph name="film" size={16} /><span>No source media yet</span><small>Your footage stays yours.</small></div>}

                <div className="direction-divider"><span>THEN, SET THE TONE</span><span className="divider-line" /></div>
                <label className="field-label" htmlFor="style-prompt">Your direction</label>
                <textarea id="style-prompt" className="direction-input" rows={3} maxLength={5000} placeholder="What should this feel like? Call out the audience, energy, moments to protect…" value={project.stylePrompt} onChange={(event) => updateProject({ stylePrompt: event.target.value })} />
                <div className="style-presets">
                  {stylePresets.map((preset, index) => <button key={preset.label} className={`style-chip style-chip-${index}`} onClick={() => updateProject({ stylePrompt: preset.prompt })}>{preset.label}</button>)}
                </div>

                <div className="format-row">
                  <div className="format-control"><label className="field-label" htmlFor="target-duration">LENGTH</label><div className="duration-control"><Glyph name="clock" size={15} /><input id="target-duration" type="number" min={5} max={180} step={5} value={project.targetDuration} onChange={(event) => { const value = Number(event.target.value); if (Number.isInteger(value) && value >= 5 && value <= 180) updateProject({ targetDuration: value }); }} /><span>sec</span><span className="duration-arrow">⌄</span></div></div>
                  <div className="format-control format-ratio-control"><span className="field-label">FRAME</span><div className="ratio-switch" role="group" aria-label="Aspect ratio">
                    {(["9:16", "16:9", "1:1"] as const).map((ratio) => <button key={ratio} className={project.aspectRatio === ratio ? "ratio-active" : ""} onClick={() => updateProject({ aspectRatio: ratio })} aria-pressed={project.aspectRatio === ratio}><span className={`ratio-icon ratio-${ratio.replace(":", "-")}`} />{ratio}</button>)}
                  </div></div>
                </div>

                <div className="transcript-toggle-row">
                  <button className="transcript-toggle" onClick={() => setTranscriptOpen((current) => !current)} aria-expanded={transcriptOpen}><span className="transcript-icon"><Glyph name="caption" size={15} /></span><span><b>Dialogue & transcript</b><small>{project.transcript ? `${project.transcript.split(/\s+/).filter(Boolean).length} words · timing can be refined` : "Optional · powers word-synced captions"}</small></span><span className={`toggle-chevron ${transcriptOpen ? "toggle-open" : ""}`}>⌄</span></button>
                  {transcriptOpen && <div className="transcript-field-wrap"><textarea className="transcript-input" rows={4} maxLength={30000} placeholder="Paste dialogue, a transcript, or word-level JSON from the Whisper helper. The director will only caption words it can source here." value={project.transcript} onChange={(event) => updateProject({ transcript: event.target.value })} /><a href="/companion/transcribe.py" className="whisper-link" download><Glyph name="download" size={13} /> Get local Faster Whisper helper</a></div>}
                </div>

                <button className="button button-generate" onClick={handleGenerate} disabled={generating || uploading || !videoCount || isSample}>
                  <span className="generate-orb"><Glyph name="spark" size={18} /></span>
                  <span>{generating ? "Finding the story…" : project.edl ? "Regenerate the cut" : "Generate my first cut"}<small>{generating ? "Reading your brief & shaping a sequence" : apiKey ? "Gemini director · your key stays local" : "Local craft plan · add a Gemini key for AI direction"}</small></span>
                  {generating ? <span className="button-spinner" /> : <Glyph name="arrow" size={17} />}
                </button>
                {isSample && <div className="sample-footnote"><Glyph name="spark" size={13} /> This is a storyboard example. Add your footage to generate a real cut.</div>}
              </div>

              <div className="preview-column">
                <div className="preview-card panel-card">
                  <div className="preview-card-header">
                    <div><p className="eyebrow">THE DIRECTOR’S VIEW</p><h2>{selectedSegment ? roleTitles[selectedSegment.role] : "Your first frame"}<span className="header-separator">/</span>{selectedAsset?.name.replace(/\.[^.]+$/, "") ?? "waiting for footage"}</h2></div>
                    <div className="preview-tools"><span className="preview-timecode">{selectedSegment ? formatTime((selectedSegment as EDLClip & { timeline_start_s: number }).timeline_start_s) : "00:00"}<i> / {formatTime(timelineDuration || project.targetDuration)}</i></span><button className="preview-play" onClick={togglePreview} disabled={!playSequence.length} aria-label={previewPlaying ? "Pause preview" : "Play preview"}><Glyph name={previewPlaying ? "pause" : "play"} size={16} /></button></div>
                  </div>
                  <div className={`preview-stage ${aspectClass}`}>
                    {selectedAsset && !selectedAsset.is_sample && selectedAsset.kind === "video" ? <video key={selectedAsset.id} ref={videoRef} className="preview-media" src={selectedAsset.url} poster="/images/cinematic-still.jpg" playsInline controls onPlay={() => setPreviewPlaying(true)} onPause={() => setPreviewPlaying(false)} /> : <img className="preview-media preview-poster" src={selectedAsset?.url || "/images/cinematic-still.jpg"} alt="Cinematic coastal sample frame" />}
                    <div className="preview-shade" />
                    <div className="preview-topline"><span className="preview-rec"><i /> {isSample ? "STORYBOARD" : "CUTROOM PREVIEW"}</span><span className="preview-ratio-label">{project.aspectRatio}</span></div>
                    <div className="preview-caption-wrap">
                      <span className="caption-kicker">{selectedSegment ? roleTitles[selectedSegment.role].toUpperCase() : "OPENING FRAME"}</span>
                      {captionLine ? <p className="preview-caption">{captionLine}</p> : <p className="preview-caption preview-caption-placeholder">A better first cut starts with intention.</p>}
                    </div>
                    <div className="preview-bottomline"><span>{selectedAsset?.name ?? "Add source media to begin"}</span><span>{selectedSegment ? `${(selectedSegment.out_s - selectedSegment.in_s).toFixed(1)}s` : `${project.targetDuration}s target`}</span></div>
                    {previewPlaying && isSample && <span className="storyboard-playing"><i /> STORYBOARD REEL</span>}
                  </div>
                  <div className="preview-footer">
                    <div className="preview-footer-copy"><span className="tiny-spark"><Glyph name="spark" size={13} /></span><span><b>{project.edl ? `${project.edl.color_grade_mood.replaceAll("_", " ")} grade` : "The shape of your story"}</b><small>{project.edl ? project.edl.music_mood : "Hook → heart → something worth remembering"}</small></span></div>
                    <span className="preview-footer-count"><b>{flattened.length || project.clips.filter((clip) => clip.kind === "video").length}</b><small>SCENES</small></span>
                  </div>
                </div>

                <div className="craft-note">
                  <span className="craft-note-mark">✳</span>
                  <div><span className="eyebrow">A NOTE ON THE CRAFT</span><p>{project.edl ? craftSummary(project.edl) : "The strongest opening isn't always the first clip. Your director will look for the moment that earns the next three seconds."}</p></div>
                </div>
              </div>
            </section>

            <section className="timeline-section panel-card">
              <div className="timeline-header">
                <div className="timeline-heading"><span className="timeline-icon"><Glyph name="scissors" size={17} /></span><div><p className="eyebrow">EDIT DECISION LIST</p><h2>{project.edl ? "The first assembly" : "Your edit will live here"}<span>{project.edl ? `${flattened.length} cuts` : "PREVIEW"}</span></h2></div></div>
                <div className="timeline-header-right"><span className="timeline-status"><span />{project.edl ? "READY FOR REVIEW" : "WAITING FOR FOOTAGE"}</span><span className="timeline-total">{formatTime(timelineDuration || 0)} <i>/ {formatTime(project.targetDuration)}</i></span></div>
              </div>
              <div className="timeline-ruler"><div className="ruler-label">TIME</div><div className="ruler-ticks"><span>00:00</span><span>00:05</span><span>00:10</span><span>00:15</span><span>00:20</span><span>{formatTime(project.targetDuration)}</span></div></div>
              <div className="timeline-lanes">
                <div className="lane-label"><Glyph name="video" size={14} /><span>VIDEO</span></div>
                <div className="lane-track video-track">
                  {flattened.length ? flattened.map((segment, index) => {
                    const duration = segment.out_s - segment.in_s;
                    const width = Math.max(8, duration / Math.max(project.targetDuration, timelineDuration) * 100);
                    const asset = project.clips.find((item) => item.source_file === segment.source_file);
                    return <button key={`${segment.source_file}-${index}`} className={`timeline-clip ${safeSelectedIndex === index ? "timeline-clip-selected" : ""}`} style={{ width: `${width}%`, borderColor: roleColors[segment.role], backgroundImage: asset?.url ? `linear-gradient(90deg,rgba(30,39,35,.26),rgba(30,39,35,.1)),url("${asset.url}")` : undefined }} onClick={() => { setSelectedClipIndex(index); setPreviewPlaying(false); }} title={`${roleTitles[segment.role]} · ${segment.source_file} · ${duration.toFixed(1)}s`}><span className="timeline-clip-role" style={{ backgroundColor: roleColors[segment.role] }} /><span className="timeline-clip-name">{segment.source_file.replace(/\.[^.]+$/, "")}</span><span className="timeline-clip-time">{duration.toFixed(1)}s</span>{segment.keyframe_zoom && <span className="zoom-badge">↗</span>}</button>;
                  }) : project.clips.filter((clip) => clip.kind === "video").length ? project.clips.filter((clip) => clip.kind === "video").map((clip, index) => <button key={clip.id} className="timeline-clip timeline-clip-unplanned" style={{ width: `${Math.max(12, (Math.min(clip.duration_s || 3, project.targetDuration) / project.targetDuration) * 100)}%`, backgroundImage: `linear-gradient(90deg,rgba(30,39,35,.32),rgba(30,39,35,.08)),url("${clip.url}")` }} onClick={() => setSelectedClipIndex(index)}><span className="timeline-clip-name">{clip.name.replace(/\.[^.]+$/, "")}</span><span className="timeline-clip-time">{clip.duration_s ? `${clip.duration_s.toFixed(1)}s` : "source"}</span></button>) : <div className="lane-empty">Your first source clip will appear here</div>}
                  <div className="playhead" style={{ left: flattened.length && timelineDuration ? `${Math.min(100, (selectedSegment ? selectedSegment.timeline_start_s / timelineDuration : 0) * 100)}%` : "8%" }}><i /></div>
                </div>
                <div className="lane-label"><Glyph name="caption" size={14} /><span>CAPTIONS</span></div>
                <div className="lane-track caption-track">
                  {flattened.length ? flattened.map((segment, index) => {
                    const width = Math.max(8, (segment.out_s - segment.in_s) / Math.max(project.targetDuration, timelineDuration) * 100);
                    return <button key={`caption-${index}`} className={`caption-block ${safeSelectedIndex === index ? "caption-block-active" : ""}`} style={{ width: `${width}%` }} onClick={() => setSelectedClipIndex(index)}>{segment.captions.length ? segment.captions.slice(0, 3).map((word) => word.word).join(" ") : "SILENT BEAT"}</button>;
                  }) : <div className="lane-empty caption-empty">Word-synced captions appear when a transcript is available</div>}
                </div>
                <div className="lane-label"><Glyph name="wave" size={14} /><span>SOUND</span></div>
                <div className="lane-track sound-track">
                  <div className="soundwave-graphic" aria-hidden="true">{Array.from({ length: 74 }, (_, i) => <i key={i} style={{ height: `${18 + ((i * 17 + i * i * 7) % 68)}%`, opacity: project.edl ? 0.36 + ((i % 5) * 0.1) : 0.19 }} />)}</div>
                  <span className="sound-track-label"><Glyph name="music" size={12} /> {audioCount ? `${audioCount} BED${audioCount > 1 ? "S" : ""} · DIALOGUE STAYS ON TOP` : project.edl?.music_mood ?? "MUSIC BED · SOFTLY DUCKED UNDER DIALOGUE"}</span>
                </div>
              </div>
              <div className="timeline-footer"><span>HARD CUTS LEAD. J / L CUTS KEEP THE CONVERSATION MOVING.</span><span>SAFE MARGINS · ONE CONSISTENT GRADE · HUMAN REVIEW</span></div>
            </section>

            <section className="workflow-strip">
              <div className={`workflow-step ${videoCount ? "workflow-done" : ""}`}><span className="workflow-number">01</span><span className="workflow-icon"><Glyph name={videoCount ? "check" : "upload"} size={16} /></span><span><b>Bring in the footage</b><small>{videoCount ? `${videoCount} video${videoCount === 1 ? "" : "s"} in the bin` : "Drop a folder of clips"}</small></span></div>
              <span className="workflow-connector" />
              <div className={`workflow-step ${project.stylePrompt.trim() ? "workflow-done" : ""}`}><span className="workflow-number">02</span><span className="workflow-icon"><Glyph name={project.stylePrompt.trim() ? "check" : "spark"} size={16} /></span><span><b>Set the intention</b><small>{project.stylePrompt.trim() ? "Direction added" : "A feeling, not a filter"}</small></span></div>
              <span className="workflow-connector" />
              <div className={`workflow-step ${project.edl ? "workflow-done" : ""}`}><span className="workflow-number">03</span><span className="workflow-icon"><Glyph name={project.edl ? "check" : "film"} size={16} /></span><span><b>Review in CapCut</b><small>{project.edl ? "Build locally · export by hand" : "Your final say stays yours"}</small></span></div>
              <a className="workflow-doc-link" href="/companion/build_capcut_draft.py" download><Glyph name="download" size={14} /> Get the local bridge</a>
            </section>
            <footer className="page-footer"><span>CAPCUT HAS NO OFFICIAL PUBLIC API. THIS STUDIO BUILDS A REVIEWABLE EDIT PLAN, THEN A LOCAL PYTHON BRIDGE.</span><span>OPEN IN CAPCUT <b>→</b> EXPORT MANUALLY</span></footer>
          </div>
        </div>
      </main>

      {notice && <div className="toast" role="status"><span className="toast-mark"><Glyph name="check" size={15} /></span>{notice}<button onClick={() => setNotice("")} aria-label="Dismiss notice"><Glyph name="close" size={14} /></button></div>}
      {modal && <Modal modal={modal} onClose={() => setModal(null)} apiKey={apiKey} onSaveKey={saveApiKey} onRemoveKey={removeApiKey} />}
    </div>
  );
}

function craftSummary(edl: EditDecisionList) {
  const transitionCount = edl.sections.flatMap((section) => section.clips).filter((clip) => clip.transition_in !== "hard_cut").length;
  const zoomCount = edl.sections.flatMap((section) => section.clips).filter((clip) => clip.keyframe_zoom).length;
  return `${transitionCount ? `${transitionCount} deliberate transition${transitionCount === 1 ? "" : "s"}` : "Hard cuts keep the pace honest"}. ${zoomCount ? `${zoomCount} quiet punch-in${zoomCount === 1 ? "" : "s"} for a little movement` : "Let stillness do its job"}. One ${edl.color_grade_mood.replaceAll("_", " ")} grade, all the way through.`;
}

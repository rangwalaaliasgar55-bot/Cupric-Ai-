import { desc } from "drizzle-orm";
import { db } from "@/db";
import { editingProjects } from "@/db/schema";
import type { AspectRatio, StudioProject } from "@/lib/edl";
import Studio from "./studio";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const rows = await db.select().from(editingProjects).orderBy(desc(editingProjects.updatedAt)).limit(40);
  const projects: StudioProject[] = rows.map((row) => ({
    ...row,
    aspectRatio: (row.aspectRatio === "16:9" || row.aspectRatio === "1:1" ? row.aspectRatio : "9:16") as AspectRatio,
    clips: Array.isArray(row.clips) ? row.clips : [],
    edl: row.edl ?? null,
    transcript: row.transcript ?? "",
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  }));

  return <Studio initialProjects={projects} />;
}

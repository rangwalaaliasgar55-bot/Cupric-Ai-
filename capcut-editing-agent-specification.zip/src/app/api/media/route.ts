import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import type { ClipAsset } from "@/lib/edl";

export const runtime = "nodejs";
export const maxDuration = 60;

const MAX_FILE_SIZE = 180 * 1024 * 1024;
const VIDEO_EXTENSIONS = new Set([".mp4", ".mov", ".m4v", ".webm", ".mkv"]);
const AUDIO_EXTENSIONS = new Set([".mp3", ".wav", ".m4a", ".aac", ".ogg"]);

export async function POST(request: Request) {
  const formData = await request.formData().catch(() => null);
  const file = formData?.get("file");
  if (!(file instanceof File)) return Response.json({ error: "Choose a video or audio file to upload." }, { status: 400 });
  if (file.size < 1 || file.size > MAX_FILE_SIZE) return Response.json({ error: "Files must be between 1 byte and 180 MB." }, { status: 413 });

  const extension = path.extname(file.name).toLowerCase();
  const kind = VIDEO_EXTENSIONS.has(extension) ? "video" : AUDIO_EXTENSIONS.has(extension) ? "audio" : null;
  if (!kind) return Response.json({ error: "Use MP4, MOV, WebM, MKV, MP3, WAV, M4A, AAC, or OGG media." }, { status: 415 });

  const safeName = file.name.normalize("NFKC").replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 100) || `clip${extension}`;
  const storedName = `${randomUUID()}-${safeName}`;
  const uploadDirectory = path.join(process.cwd(), "data", "uploads");
  await mkdir(uploadDirectory, { recursive: true });
  await writeFile(path.join(uploadDirectory, storedName), Buffer.from(await file.arrayBuffer()), { flag: "wx" });

  const durationValue = Number(formData?.get("duration_s"));
  const clip: ClipAsset = {
    id: randomUUID(),
    name: file.name.slice(0, 160),
    source_file: file.name.split(/[\\/]/).pop() || safeName,
    url: `/api/media/${storedName}`,
    kind,
    duration_s: Number.isFinite(durationValue) && durationValue > 0 ? Math.round(durationValue * 100) / 100 : 0,
    size_bytes: file.size,
  };
  return Response.json({ clip }, { status: 201 });
}

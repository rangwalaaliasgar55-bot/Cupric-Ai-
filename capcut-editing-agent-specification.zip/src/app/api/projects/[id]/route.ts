import { eq } from "drizzle-orm";
import { db } from "@/db";
import { editingProjects } from "@/db/schema";
import { validateEditDecisionList, type AspectRatio, type ClipAsset, type StudioProject } from "@/lib/edl";

export const dynamic = "force-dynamic";
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ratios: AspectRatio[] = ["9:16", "16:9", "1:1"];

function serializeProject(row: typeof editingProjects.$inferSelect): StudioProject {
  return {
    ...row,
    aspectRatio: ratios.includes(row.aspectRatio) ? row.aspectRatio : "9:16",
    clips: Array.isArray(row.clips) ? row.clips : [],
    edl: row.edl ?? null,
    transcript: row.transcript ?? "",
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

async function getId(context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  return UUID_PATTERN.test(id) ? id : null;
}

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const id = await getId(context);
  if (!id) return Response.json({ error: "Project not found." }, { status: 404 });
  const [row] = await db.select().from(editingProjects).where(eq(editingProjects.id, id)).limit(1);
  if (!row) return Response.json({ error: "Project not found." }, { status: 404 });
  return Response.json({ project: serializeProject(row) });
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const id = await getId(context);
  if (!id) return Response.json({ error: "Project not found." }, { status: 404 });
  const [existing] = await db.select().from(editingProjects).where(eq(editingProjects.id, id)).limit(1);
  if (!existing) return Response.json({ error: "Project not found." }, { status: 404 });
  const value: unknown = await request.json().catch(() => null);
  if (!value || typeof value !== "object") return Response.json({ error: "Invalid update payload." }, { status: 400 });
  const body = value as Record<string, unknown>;
  const update: Partial<typeof editingProjects.$inferInsert> = { updatedAt: new Date() };

  if (body.name !== undefined) {
    if (typeof body.name !== "string" || !body.name.trim() || body.name.length > 100) return Response.json({ error: "Project name must be 1–100 characters." }, { status: 400 });
    update.name = body.name.trim();
  }
  if (body.stylePrompt !== undefined) {
    if (typeof body.stylePrompt !== "string" || body.stylePrompt.length > 5000) return Response.json({ error: "Style prompt is too long." }, { status: 400 });
    update.stylePrompt = body.stylePrompt;
  }
  if (body.transcript !== undefined) {
    if (typeof body.transcript !== "string" || body.transcript.length > 30000) return Response.json({ error: "Transcript is too long." }, { status: 400 });
    update.transcript = body.transcript;
  }
  if (body.targetDuration !== undefined) {
    if (typeof body.targetDuration !== "number" || !Number.isInteger(body.targetDuration) || body.targetDuration < 5 || body.targetDuration > 180) return Response.json({ error: "Duration must be between 5 and 180 seconds." }, { status: 400 });
    update.targetDuration = body.targetDuration;
  }
  if (body.aspectRatio !== undefined) {
    if (typeof body.aspectRatio !== "string" || !ratios.includes(body.aspectRatio as AspectRatio)) return Response.json({ error: "Aspect ratio is invalid." }, { status: 400 });
    update.aspectRatio = body.aspectRatio as AspectRatio;
  }
  if (body.clips !== undefined) {
    if (!Array.isArray(body.clips) || body.clips.length > 100 || !body.clips.every((item) => {
      if (!item || typeof item !== "object") return false;
      const clip = item as Partial<ClipAsset>;
      return typeof clip.id === "string" && typeof clip.name === "string" && typeof clip.source_file === "string" && typeof clip.url === "string" && (clip.kind === "video" || clip.kind === "audio") && typeof clip.duration_s === "number" && Number.isFinite(clip.duration_s) && typeof clip.size_bytes === "number";
    })) return Response.json({ error: "Clip inventory is invalid." }, { status: 400 });
    update.clips = body.clips as ClipAsset[];
  }
  if (body.edl !== undefined) {
    if (body.edl === null) update.edl = null;
    else {
      try {
        const clips = (update.clips as ClipAsset[] | undefined) ?? existing.clips;
        const targetDuration = (update.targetDuration as number | undefined) ?? existing.targetDuration;
        update.edl = validateEditDecisionList(body.edl, clips, targetDuration);
      } catch (error) {
        return Response.json({ error: error instanceof Error ? error.message : "Invalid EDL." }, { status: 400 });
      }
    }
  }
  if (body.status !== undefined) {
    if (body.status !== "draft" && body.status !== "ready") return Response.json({ error: "Project status is invalid." }, { status: 400 });
    update.status = body.status;
  }
  if ((body.clips !== undefined || body.stylePrompt !== undefined || body.transcript !== undefined || body.targetDuration !== undefined || body.aspectRatio !== undefined) && body.edl === undefined) {
    update.edl = null;
    update.status = "draft";
  }

  const [row] = await db.update(editingProjects).set(update).where(eq(editingProjects.id, id)).returning();
  return Response.json({ project: serializeProject(row) });
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const id = await getId(context);
  if (!id) return Response.json({ error: "Project not found." }, { status: 404 });
  const [row] = await db.delete(editingProjects).where(eq(editingProjects.id, id)).returning({ id: editingProjects.id });
  if (!row) return Response.json({ error: "Project not found." }, { status: 404 });
  return Response.json({ ok: true });
}

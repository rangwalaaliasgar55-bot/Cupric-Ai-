import { eq } from "drizzle-orm";
import { db } from "@/db";
import { editingProjects } from "@/db/schema";

export const dynamic = "force-dynamic";
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!UUID_PATTERN.test(id)) return Response.json({ error: "Project not found." }, { status: 404 });
  const [project] = await db.select().from(editingProjects).where(eq(editingProjects.id, id)).limit(1);
  if (!project) return Response.json({ error: "Project not found." }, { status: 404 });
  if (!project.edl) return Response.json({ error: "Generate an edit before exporting the EDL." }, { status: 409 });
  const safeName = project.name.replace(/[^a-zA-Z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60) || "edit";
  const manifest = {
    project_name: project.name,
    target_duration_s: project.targetDuration,
    aspect_ratio: project.aspectRatio,
    transcript: project.transcript,
    clip_inventory: project.clips,
    edl: project.edl,
    generated_at: project.updatedAt.toISOString(),
  };
  return new Response(JSON.stringify(manifest, null, 2), {
    headers: {
      "content-type": "application/json; charset=utf-8",
      "content-disposition": `attachment; filename="${safeName}-edit-manifest.json"`,
      "cache-control": "private, no-store",
    },
  });
}

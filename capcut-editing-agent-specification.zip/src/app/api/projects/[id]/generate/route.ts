import { eq } from "drizzle-orm";
import { db } from "@/db";
import { editingProjects } from "@/db/schema";
import { DIRECTOR_SYSTEM_PROMPT } from "@/lib/director-prompt";
import { createLocalEDL, validateEditDecisionList, type StudioProject } from "@/lib/edl";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const schema = {
  type: "object",
  properties: {
    target_duration_s: { type: "number" },
    sections: {
      type: "array",
      items: {
        type: "object",
        properties: {
          role: { type: "string", enum: ["hook", "problem", "solution", "proof", "cta", "body"] },
          clips: {
            type: "array",
            items: {
              type: "object",
              properties: {
                source_file: { type: "string" },
                in_s: { type: "number" },
                out_s: { type: "number" },
                transition_in: { type: "string", enum: ["hard_cut", "dissolve", "whip_pan", "zoom_cut"] },
                audio_offset: { type: "string", enum: ["none", "j_cut", "l_cut"] },
                keyframe_zoom: {
                  type: "object",
                  nullable: true,
                  properties: { start_scale: { type: "number" }, end_scale: { type: "number" } },
                  required: ["start_scale", "end_scale"],
                },
                captions: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      word: { type: "string" },
                      start_s: { type: "number" },
                      end_s: { type: "number" },
                      emphasis: { type: "boolean" },
                    },
                    required: ["word", "start_s", "end_s", "emphasis"],
                  },
                },
                sfx: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: { tag: { type: "string" }, at_s: { type: "number" } },
                    required: ["tag", "at_s"],
                  },
                },
              },
              required: ["source_file", "in_s", "out_s", "transition_in", "audio_offset", "keyframe_zoom", "captions", "sfx"],
            },
          },
        },
        required: ["role", "clips"],
      },
    },
    color_grade_mood: { type: "string", enum: ["warm_premium", "cool_tech", "high_contrast_punchy", "neutral"] },
    music_mood: { type: "string" },
  },
  required: ["target_duration_s", "sections", "color_grade_mood", "music_mood"],
};

function serializeProject(row: typeof editingProjects.$inferSelect): StudioProject {
  return {
    ...row,
    aspectRatio: row.aspectRatio === "16:9" || row.aspectRatio === "1:1" ? row.aspectRatio : "9:16",
    clips: Array.isArray(row.clips) ? row.clips : [],
    edl: row.edl ?? null,
    transcript: row.transcript ?? "",
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function getText(payload: unknown): string {
  if (!payload || typeof payload !== "object") return "";
  const candidates = (payload as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> }).candidates;
  return candidates?.[0]?.content?.parts?.map((part) => part.text ?? "").join("").trim() ?? "";
}

async function generateWithGemini(project: typeof editingProjects.$inferSelect, apiKey: string) {
  const transcript = project.transcript.slice(0, 24000);
  const userBrief = {
    transcript,
    style_prompt: project.stylePrompt,
    clip_inventory: project.clips.filter((clip) => clip.kind === "video" && !clip.is_sample).map((clip) => ({ source_file: clip.source_file, duration_s: clip.duration_s, description: clip.description ?? "" })),
    constraints: { target_duration_s: project.targetDuration, aspect_ratio: project.aspectRatio, must_keep_moments: [] },
  };
  let previousError = "";
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${process.env.GEMINI_MODEL || "gemini-3.1-flash-lite"}:generateContent`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: DIRECTOR_SYSTEM_PROMPT }] },
        contents: [{ role: "user", parts: [{ text: `${JSON.stringify(userBrief)}${previousError ? `\n\nThe previous EDL failed validation: ${previousError}. Return a corrected complete EDL object only.` : ""}` }] }],
        generationConfig: { temperature: 0.55, maxOutputTokens: 8192, responseMimeType: "application/json", responseSchema: schema },
      }),
      signal: AbortSignal.timeout(45000),
    });
    const payload: unknown = await response.json().catch(() => null);
    if (!response.ok) {
      const message = payload && typeof payload === "object" && "error" in payload && typeof payload.error === "object" && payload.error && "message" in payload.error && typeof payload.error.message === "string" ? payload.error.message : "Gemini could not generate an edit.";
      throw new Error(message.slice(0, 300));
    }
    const text = getText(payload);
    try {
      const parsed = JSON.parse(text) as unknown;
      return validateEditDecisionList(parsed, project.clips, project.targetDuration);
    } catch (error) {
      previousError = error instanceof Error ? error.message : "Malformed JSON";
      if (attempt === 1) throw new Error(`The director returned an invalid EDL after a retry: ${previousError}`);
    }
  }
  throw new Error("The director could not create a valid EDL.");
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!UUID_PATTERN.test(id)) return Response.json({ error: "Project not found." }, { status: 404 });
  const [project] = await db.select().from(editingProjects).where(eq(editingProjects.id, id)).limit(1);
  if (!project) return Response.json({ error: "Project not found." }, { status: 404 });
  if (project.clips.filter((clip) => clip.kind === "video" && !clip.is_sample).length === 0) {
    return Response.json({ error: "Add at least one video clip before generating an edit." }, { status: 400 });
  }

  const apiKey = request.headers.get("x-gemini-api-key")?.trim() || process.env.GEMINI_API_KEY?.trim() || "";
  let provider: "gemini" | "local" = apiKey ? "gemini" : "local";
  try {
    const edl = apiKey
      ? await generateWithGemini(project, apiKey)
      : createLocalEDL(project.clips, project.targetDuration, project.stylePrompt, project.transcript);
    const [updated] = await db.update(editingProjects).set({ edl, status: "ready", updatedAt: new Date() }).where(eq(editingProjects.id, id)).returning();
    return Response.json({ project: serializeProject(updated), provider });
  } catch (error) {
    if (!apiKey) provider = "local";
    const message = error instanceof Error ? error.message : "Could not generate an edit.";
    return Response.json({ error: message, provider }, { status: apiKey ? 502 : 400 });
  }
}

import { desc } from "drizzle-orm";
import { db } from "@/db";
import { editingProjects } from "@/db/schema";
import type { AspectRatio, ClipAsset, StudioProject } from "@/lib/edl";

export const dynamic = "force-dynamic";

const ratios: AspectRatio[] = ["9:16", "16:9", "1:1"];
const safeClips = (value: unknown): value is ClipAsset[] =>
  Array.isArray(value) && value.length <= 100 && value.every((item) => {
    if (!item || typeof item !== "object") return false;
    const clip = item as Partial<ClipAsset>;
    return typeof clip.id === "string" && typeof clip.name === "string" && typeof clip.source_file === "string" && typeof clip.url === "string" && (clip.kind === "video" || clip.kind === "audio") && typeof clip.duration_s === "number" && Number.isFinite(clip.duration_s) && typeof clip.size_bytes === "number";
  });

function serializeProject(row: typeof editingProjects.$inferSelect): StudioProject {
  return {
    ...row,
    aspectRatio: ratios.includes(row.aspectRatio) ? row.aspectRatio : "9:16",
    clips: Array.isArray(row.clips) ? row.clips : [],
    edl: row.edl ?? null,
    transcript: row.transcript ?? "",
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export async function GET() {
  const rows = await db.select().from(editingProjects).orderBy(desc(editingProjects.updatedAt)).limit(50);
  return Response.json({ projects: rows.map(serializeProject) });
}

export async function POST(request: Request) {
  const value: unknown = await request.json().catch(() => null);
  if (!value || typeof value !== "object") return Response.json({ error: "Invalid project payload." }, { status: 400 });
  const body = value as Record<string, unknown>;
  const name = typeof body.name === "string" ? body.name.trim().slice(0, 100) : "Untitled film";
  const stylePrompt = typeof body.stylePrompt === "string" ? body.stylePrompt.slice(0, 5000) : "";
  const transcript = typeof body.transcript === "string" ? body.transcript.slice(0, 30000) : "";
  const targetDuration = typeof body.targetDuration === "number" ? body.targetDuration : 30;
  const aspectRatio = body.aspectRatio;
  const clips = body.clips ?? [];

  if (!name || !Number.isInteger(targetDuration) || targetDuration < 5 || targetDuration > 180) {
    return Response.json({ error: "Give the film a name and choose a duration between 5 and 180 seconds." }, { status: 400 });
  }
  if (typeof aspectRatio !== "string" || !ratios.includes(aspectRatio as AspectRatio) || !safeClips(clips)) {
    return Response.json({ error: "The aspect ratio or clip inventory is invalid." }, { status: 400 });
  }

  const [row] = await db.insert(editingProjects).values({
    name,
    stylePrompt,
    transcript,
    targetDuration,
    aspectRatio: aspectRatio as AspectRatio,
    clips,
    status: "draft",
  }).returning();
  return Response.json({ project: serializeProject(row) }, { status: 201 });
}

export const EDIT_ROLES = ["hook", "problem", "solution", "proof", "cta", "body"] as const;
export const TRANSITIONS = ["hard_cut", "dissolve", "whip_pan", "zoom_cut"] as const;
export const AUDIO_OFFSETS = ["none", "j_cut", "l_cut"] as const;
export const COLOR_GRADES = ["warm_premium", "cool_tech", "high_contrast_punchy", "neutral"] as const;
export const ASPECT_RATIOS = ["9:16", "16:9", "1:1"] as const;

export type EditRole = (typeof EDIT_ROLES)[number];
export type TransitionKind = (typeof TRANSITIONS)[number];
export type AudioOffset = (typeof AUDIO_OFFSETS)[number];
export type ColorGradeMood = (typeof COLOR_GRADES)[number];
export type AspectRatio = (typeof ASPECT_RATIOS)[number];

export type TranscriptWord = {
  word: string;
  start_s: number;
  end_s: number;
};

export type CaptionWord = TranscriptWord & { emphasis: boolean };

export type SfxCue = {
  tag: string;
  at_s: number;
};

export type ZoomKeyframe = {
  start_scale: number;
  end_scale: number;
};

export type EDLClip = {
  source_file: string;
  in_s: number;
  out_s: number;
  transition_in: TransitionKind;
  audio_offset: AudioOffset;
  keyframe_zoom: ZoomKeyframe | null;
  captions: CaptionWord[];
  sfx: SfxCue[];
};

export type EDLSection = {
  role: EditRole;
  clips: EDLClip[];
};

export type EditDecisionList = {
  target_duration_s: number;
  sections: EDLSection[];
  color_grade_mood: ColorGradeMood;
  music_mood: string;
};

export type ClipAsset = {
  id: string;
  name: string;
  source_file: string;
  url: string;
  kind: "video" | "audio";
  duration_s: number;
  size_bytes: number;
  description?: string;
  is_sample?: boolean;
};

export type StudioProject = {
  id: string;
  name: string;
  stylePrompt: string;
  targetDuration: number;
  aspectRatio: AspectRatio;
  status: "draft" | "ready";
  clips: ClipAsset[];
  transcript: string;
  edl: EditDecisionList | null;
  createdAt: string;
  updatedAt: string;
};

export type GenerateResult = {
  project: StudioProject;
  provider: "gemini" | "local";
};

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const isFiniteNumber = (value: unknown): value is number =>
  typeof value === "number" && Number.isFinite(value);

const isMember = <T extends readonly string[]>(value: unknown, choices: T): value is T[number] =>
  typeof value === "string" && choices.includes(value as T[number]);

export function validateEditDecisionList(
  value: unknown,
  inventory: ClipAsset[],
  requestedDuration: number,
): EditDecisionList {
  if (!isRecord(value) || !Array.isArray(value.sections)) {
    throw new Error("The director response is not an EDL object.");
  }

  if (!isFiniteNumber(value.target_duration_s) || Math.abs(value.target_duration_s - requestedDuration) > 0.5) {
    throw new Error("EDL target_duration_s does not match the requested project duration.");
  }

  if (!isMember(value.color_grade_mood, COLOR_GRADES)) {
    throw new Error("EDL color_grade_mood is not supported.");
  }

  if (typeof value.music_mood !== "string" || value.music_mood.length > 140) {
    throw new Error("EDL music_mood must be a short text value.");
  }

  const available = new Map(inventory.filter((clip) => clip.kind === "video").map((clip) => [clip.source_file, clip]));
  const sections: EDLSection[] = [];
  let clipCount = 0;

  for (const sectionValue of value.sections) {
    if (!isRecord(sectionValue) || !isMember(sectionValue.role, EDIT_ROLES) || !Array.isArray(sectionValue.clips)) {
      throw new Error("EDL sections must have a supported role and clip array.");
    }

    const clips: EDLClip[] = [];
    for (const clipValue of sectionValue.clips) {
      if (!isRecord(clipValue) || typeof clipValue.source_file !== "string") {
        throw new Error("An EDL clip is missing a source_file.");
      }
      const asset = available.get(clipValue.source_file);
      if (!asset) throw new Error(`EDL references footage that is not in the project: ${clipValue.source_file}`);
      if (!isFiniteNumber(clipValue.in_s) || !isFiniteNumber(clipValue.out_s) || clipValue.in_s < 0 || clipValue.out_s <= clipValue.in_s) {
        throw new Error(`EDL has an invalid source range for ${clipValue.source_file}.`);
      }
      if (asset.duration_s > 0 && clipValue.out_s > asset.duration_s + 0.25) {
        throw new Error(`EDL source range exceeds ${clipValue.source_file}'s ${asset.duration_s.toFixed(1)}s duration.`);
      }
      if (!isMember(clipValue.transition_in, TRANSITIONS) || !isMember(clipValue.audio_offset, AUDIO_OFFSETS)) {
        throw new Error("EDL uses an unsupported transition or audio offset.");
      }

      let zoom: ZoomKeyframe | null = null;
      if (clipValue.keyframe_zoom !== null) {
        if (!isRecord(clipValue.keyframe_zoom) || !isFiniteNumber(clipValue.keyframe_zoom.start_scale) || !isFiniteNumber(clipValue.keyframe_zoom.end_scale)) {
          throw new Error("EDL keyframe_zoom must be a scale pair or null.");
        }
        if (clipValue.keyframe_zoom.start_scale < 0.95 || clipValue.keyframe_zoom.start_scale > 1.1 || clipValue.keyframe_zoom.end_scale < 0.95 || clipValue.keyframe_zoom.end_scale > 1.1) {
          throw new Error("EDL zoom keyframes must remain subtle (0.95–1.10 scale).");
        }
        zoom = {
          start_scale: clipValue.keyframe_zoom.start_scale,
          end_scale: clipValue.keyframe_zoom.end_scale,
        };
      }

      if (!Array.isArray(clipValue.captions) || !Array.isArray(clipValue.sfx)) {
        throw new Error("EDL captions and sfx must be arrays.");
      }
      const duration = clipValue.out_s - clipValue.in_s;
      const captions: CaptionWord[] = clipValue.captions.map((caption) => {
        if (!isRecord(caption) || typeof caption.word !== "string" || caption.word.length > 80 || !isFiniteNumber(caption.start_s) || !isFiniteNumber(caption.end_s) || typeof caption.emphasis !== "boolean") {
          throw new Error("An EDL caption is not a valid timed word.");
        }
        if (caption.start_s < 0 || caption.end_s <= caption.start_s || caption.end_s > duration + 0.2) {
          throw new Error(`Caption timing for ${clipValue.source_file} must be relative to its clip and within its duration.`);
        }
        return { word: caption.word, start_s: caption.start_s, end_s: caption.end_s, emphasis: caption.emphasis };
      });
      const sfx: SfxCue[] = clipValue.sfx.map((cue) => {
        if (!isRecord(cue) || typeof cue.tag !== "string" || cue.tag.length > 50 || !isFiniteNumber(cue.at_s) || cue.at_s < 0 || cue.at_s > duration) {
          throw new Error(`An EDL sound cue for ${clipValue.source_file} has invalid timing.`);
        }
        return { tag: cue.tag, at_s: cue.at_s };
      });

      clips.push({
        source_file: asset.source_file,
        in_s: clipValue.in_s,
        out_s: clipValue.out_s,
        transition_in: clipValue.transition_in,
        audio_offset: clipValue.audio_offset,
        keyframe_zoom: zoom,
        captions,
        sfx,
      });
      clipCount += 1;
    }
    if (clips.length > 0) sections.push({ role: sectionValue.role, clips });
  }

  if (clipCount === 0 || clipCount > 100) throw new Error("The EDL must contain between 1 and 100 clips.");

  return {
    target_duration_s: requestedDuration,
    sections,
    color_grade_mood: value.color_grade_mood,
    music_mood: value.music_mood,
  };
}

export function flattenEDL(edl: EditDecisionList): Array<EDLClip & { role: EditRole; timeline_start_s: number }> {
  const clips: Array<EDLClip & { role: EditRole; timeline_start_s: number }> = [];
  let timeline = 0;
  for (const section of edl.sections) {
    for (const clip of section.clips) {
      clips.push({ ...clip, role: section.role, timeline_start_s: timeline });
      timeline += clip.out_s - clip.in_s;
    }
  }
  return clips;
}

function parseTranscriptWords(transcript: string): {
  timed: Array<{ word: string; start_s: number; end_s: number; source_file?: string }>;
  plain: string[];
} {
  const raw = transcript.trim();
  if (!raw) return { timed: [], plain: [] };
  try {
    const parsed: unknown = JSON.parse(raw);
    const timed: Array<{ word: string; start_s: number; end_s: number; source_file?: string }> = [];
    const visit = (value: unknown, inheritedFile?: string): void => {
      if (Array.isArray(value)) {
        for (const child of value) visit(child, inheritedFile);
        return;
      }
      if (!isRecord(value)) return;
      const sourceFile = typeof value.source_file === "string" ? value.source_file : inheritedFile;
      if (typeof value.word === "string" && isFiniteNumber(value.start_s) && isFiniteNumber(value.end_s)) {
        timed.push({ word: value.word.trim(), start_s: value.start_s, end_s: value.end_s, source_file: sourceFile });
        return;
      }
      for (const [key, child] of Object.entries(value)) visit(child, key === "words" || key === "files" ? sourceFile : sourceFile);
    };
    visit(parsed);
    if (timed.length) return { timed, plain: [] };
  } catch {
    // A plain transcript is also a useful caption source.
  }
  return { timed: [], plain: raw.split(/\s+/).map((word) => word.replace(/[.,!?;:]+$/g, "")).filter(Boolean) };
}

export function createLocalEDL(
  inventory: ClipAsset[],
  targetDuration: number,
  stylePrompt: string,
  transcript: string,
): EditDecisionList {
  const videos = inventory.filter((clip) => clip.kind === "video" && !clip.is_sample);
  if (videos.length === 0) throw new Error("Add at least one real video clip before generating an edit.");

  const keywords = /hook|reveal|wide|drone|coast|ocean|sunset|opening|hero|close|detail/i;
  const ordered = [...videos].sort((a, b) => Number(keywords.test(b.name + " " + (b.description ?? ""))) - Number(keywords.test(a.name + " " + (a.description ?? ""))));
  const roles: EditRole[] = ["hook", "problem", "solution", "solution", "proof", "cta"];
  const transcriptWords = parseTranscriptWords(transcript);
  const plainWords = transcriptWords.timed.length ? [] : transcriptWords.plain;
  const pieces: Array<{ role: EditRole; clip: EDLClip }> = [];
  let remaining = targetDuration;
  let wordIndex = 0;
  let cutIndex = 0;

  while (remaining > 0.15 && cutIndex < 100) {
    const asset = ordered[cutIndex % ordered.length];
    const sourceDuration = Math.max(0.5, asset.duration_s || Math.min(4, remaining));
    const segmentDuration = Math.min(remaining, sourceDuration, videos.length === 1 ? 4 : (cutIndex % 3 === 1 ? 2.8 : 3.6));
    const sourceStart = cutIndex < ordered.length ? 0 : Math.max(0, Math.min(sourceDuration - segmentDuration, (cutIndex * 1.7) % Math.max(0.5, sourceDuration - segmentDuration)));
    const captions: CaptionWord[] = [];
    if (transcriptWords.timed.length) {
      for (const timedWord of transcriptWords.timed) {
        if (timedWord.source_file && timedWord.source_file !== asset.source_file) continue;
        if (timedWord.start_s < sourceStart || timedWord.start_s >= sourceStart + segmentDuration) continue;
        const start = Math.max(0, timedWord.start_s - sourceStart);
        const end = Math.min(segmentDuration, Math.max(start + 0.06, timedWord.end_s - sourceStart));
        if (end > start) captions.push({ word: timedWord.word, start_s: start, end_s: end, emphasis: /\d|!/.test(timedWord.word) });
        if (captions.length >= 6) break;
      }
    } else {
      const wordSlots = Math.min(plainWords.length - wordIndex, 5);
      for (let index = 0; index < wordSlots; index += 1) {
        const start = (segmentDuration / Math.max(1, wordSlots)) * index;
        const word = plainWords[wordIndex++];
        captions.push({ word, start_s: start, end_s: Math.min(segmentDuration, start + Math.min(0.48, segmentDuration / wordSlots)), emphasis: index === 0 || /\d|!/.test(word) });
      }
    }
    const transition: TransitionKind = cutIndex === 0 ? "hard_cut" : (cutIndex % 5 === 3 ? "dissolve" : "hard_cut");
    pieces.push({
      role: roles[Math.min(roles.length - 1, Math.floor((cutIndex / Math.max(1, Math.ceil(targetDuration / 3.4))) * roles.length))],
      clip: {
        source_file: asset.source_file,
        in_s: sourceStart,
        out_s: sourceStart + segmentDuration,
        transition_in: transition,
        audio_offset: cutIndex > 0 && cutIndex % 3 === 1 ? "j_cut" : "none",
        keyframe_zoom: cutIndex > 0 && cutIndex % 4 === 1 ? { start_scale: 1, end_scale: 1.04 } : null,
        captions,
        sfx: cutIndex === 0 ? [{ tag: "soft-impact", at_s: 0.05 }] : [],
      },
    });
    remaining -= segmentDuration;
    cutIndex += 1;
  }

  const sections: EDLSection[] = [];
  for (const piece of pieces) {
    const last = sections[sections.length - 1];
    if (last?.role === piece.role) last.clips.push(piece.clip);
    else sections.push({ role: piece.role, clips: [piece.clip] });
  }

  const prompt = stylePrompt.toLowerCase();
  const color_grade_mood: ColorGradeMood = /warm|premium|travel|lifestyle|golden/.test(prompt)
    ? "warm_premium"
    : /tech|software|saas|product|clean/.test(prompt)
      ? "cool_tech"
      : /punchy|bold|high contrast|energetic/.test(prompt)
        ? "high_contrast_punchy"
        : "neutral";

  return {
    target_duration_s: targetDuration,
    sections,
    color_grade_mood,
    music_mood: "Subtle cinematic bed · dialogue-forward, ducked beneath speech",
  };
}

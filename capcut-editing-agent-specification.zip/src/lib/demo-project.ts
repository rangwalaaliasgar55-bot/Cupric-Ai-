import type { EditDecisionList, StudioProject } from "./edl";

const demoEDL: EditDecisionList = {
  target_duration_s: 24,
  color_grade_mood: "warm_premium",
  music_mood: "Airy piano · warm analog texture · dialogue-forward",
  sections: [
    {
      role: "hook",
      clips: [
        {
          source_file: "coastline-dawn.mp4",
          in_s: 1.2,
          out_s: 4.2,
          transition_in: "hard_cut",
          audio_offset: "none",
          keyframe_zoom: { start_scale: 1, end_scale: 1.04 },
          captions: [
            { word: "Find", start_s: 0.38, end_s: 0.74, emphasis: false },
            { word: "your", start_s: 0.76, end_s: 1.04, emphasis: false },
            { word: "own", start_s: 1.05, end_s: 1.38, emphasis: true },
            { word: "horizon.", start_s: 1.4, end_s: 2.05, emphasis: true },
          ],
          sfx: [{ tag: "soft-impact", at_s: 0.1 }],
        },
      ],
    },
    {
      role: "problem",
      clips: [
        {
          source_file: "last-light.mp4",
          in_s: 0,
          out_s: 3.3,
          transition_in: "dissolve",
          audio_offset: "l_cut",
          keyframe_zoom: null,
          captions: [
            { word: "Leave", start_s: 0.34, end_s: 0.72, emphasis: false },
            { word: "the", start_s: 0.73, end_s: 0.92, emphasis: false },
            { word: "noise", start_s: 0.94, end_s: 1.42, emphasis: true },
            { word: "behind.", start_s: 1.43, end_s: 2.08, emphasis: true },
          ],
          sfx: [],
        },
      ],
    },
    {
      role: "solution",
      clips: [
        {
          source_file: "open-water.mp4",
          in_s: 2,
          out_s: 5.6,
          transition_in: "hard_cut",
          audio_offset: "j_cut",
          keyframe_zoom: null,
          captions: [
            { word: "Nothing", start_s: 0.4, end_s: 0.9, emphasis: false },
            { word: "but", start_s: 0.91, end_s: 1.1, emphasis: false },
            { word: "room", start_s: 1.12, end_s: 1.54, emphasis: true },
            { word: "to", start_s: 1.56, end_s: 1.76, emphasis: false },
            { word: "breathe.", start_s: 1.78, end_s: 2.5, emphasis: true },
          ],
          sfx: [],
        },
        {
          source_file: "last-light.mp4",
          in_s: 4,
          out_s: 7.2,
          transition_in: "hard_cut",
          audio_offset: "none",
          keyframe_zoom: { start_scale: 1, end_scale: 1.035 },
          captions: [
            { word: "The", start_s: 0.4, end_s: 0.62, emphasis: false },
            { word: "weekend", start_s: 0.64, end_s: 1.28, emphasis: true },
            { word: "starts", start_s: 1.3, end_s: 1.75, emphasis: false },
            { word: "here.", start_s: 1.77, end_s: 2.3, emphasis: true },
          ],
          sfx: [{ tag: "airy-whoosh", at_s: 0.05 }],
        },
      ],
    },
    {
      role: "cta",
      clips: [
        {
          source_file: "coastline-dawn.mp4",
          in_s: 5,
          out_s: 7.3,
          transition_in: "dissolve",
          audio_offset: "none",
          keyframe_zoom: null,
          captions: [
            { word: "Take", start_s: 0.28, end_s: 0.55, emphasis: false },
            { word: "the", start_s: 0.57, end_s: 0.76, emphasis: false },
            { word: "long", start_s: 0.78, end_s: 1.13, emphasis: true },
            { word: "way.", start_s: 1.15, end_s: 1.8, emphasis: true },
          ],
          sfx: [],
        },
      ],
    },
  ],
};

export const demoProject: StudioProject = {
  id: "example-project",
  name: "The shape of a slower day",
  stylePrompt: "A premium, sun-warmed travel film. Let the landscape lead. Intimate, considered cuts; tactile grain; keep it human.",
  targetDuration: 24,
  aspectRatio: "9:16",
  status: "ready",
  clips: [
    { id: "example-1", name: "coastline-dawn.mp4", source_file: "coastline-dawn.mp4", url: "/images/cinematic-still.jpg", kind: "video", duration_s: 9.4, size_bytes: 0, description: "First light over the coast", is_sample: true },
    { id: "example-2", name: "last-light.mp4", source_file: "last-light.mp4", url: "/images/cinematic-still.jpg", kind: "video", duration_s: 8.2, size_bytes: 0, description: "Wind in the grass at golden hour", is_sample: true },
    { id: "example-3", name: "open-water.mp4", source_file: "open-water.mp4", url: "/images/cinematic-still.jpg", kind: "video", duration_s: 7.6, size_bytes: 0, description: "Wide horizon and open water", is_sample: true },
  ],
  transcript: "Find your own horizon. Leave the noise behind. Nothing but room to breathe. The weekend starts here. Take the long way.",
  edl: demoEDL,
  createdAt: "2026-06-01T09:00:00.000Z",
  updatedAt: "2026-06-01T09:12:00.000Z",
};

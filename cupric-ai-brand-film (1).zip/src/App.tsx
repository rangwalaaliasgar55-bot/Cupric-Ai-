import { useCallback, useEffect, useRef, useState } from "react";
import { Engine } from "./film/engine";
import { FilmAudio } from "./film/audio";
import { DURATION, FPS, W, H, LIME, hash } from "./film/ease";
import { Hook, Directions, Intelligence, TenX, Connect } from "./film/ScenesA";
import { Workspace, PromptProduct, Repetition } from "./film/UIScenes";
import { Noise, HumanMachine, BuildNext, Brand } from "./film/ScenesB";
import { Logo } from "./film/Kinetic";

const CHAPTERS = [
  "Hook", "Infinite Directions", "Intelligence in Motion", "Build Faster", "Prompt to Product", "Less Repetition",
  "10×", "Ideas Connect", "Make Noise", "Human + Machine", "Build What's Next", "Brand Reveal", "Statement", "End Card",
];
const CH_T = [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 38];

function tc(t: number) {
  const s = Math.floor(t);
  const f = Math.floor((t - s) * FPS + 1e-6);
  return `00:${String(s).padStart(2, "0")}:${String(f).padStart(2, "0")}`;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const audioRef = useRef(new FilmAudio());
  const clock = useRef({ base: 0, wall: 0, playing: false, lastFrame: -1 });
  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [started, setStarted] = useState(false);
  const [ready, setReady] = useState(false);
  const [muted, setMuted] = useState(false);
  const [scale, setScale] = useState(1);
  const [uiVisible, setUiVisible] = useState(true);
  const [glError, setGlError] = useState(false);
  const hideTimer = useRef<number | undefined>(undefined);

  // engine init
  useEffect(() => {
    let eng: Engine | null = null;
    try {
      eng = new Engine(canvasRef.current!);
      engineRef.current = eng;
    } catch (e) {
      console.error(e);
      setGlError(true);
    }
    const params = new URLSearchParams(location.search);
    const t0 = Math.min(DURATION, Math.max(0, parseFloat(params.get("t") || "0") || 0));
    clock.current.base = t0;
    if (params.has("still")) { setStarted(true); setUiVisible(false); }
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      try { eng?.setText10(); } catch (e) { console.error(e); }
      setReady(true);
    };
    Promise.all([
      document.fonts.load('700 640px "Inter Tight"'),
      document.fonts.load('600 100px "Inter Tight"'),
      document.fonts.load('400 20px "JetBrains Mono"'),
    ]).then(() => document.fonts.ready).then(finish, finish);
    const to = window.setTimeout(finish, 3000);
    return () => { window.clearTimeout(to); eng?.dispose(); };
  }, []);

  // resize
  useEffect(() => {
    const fit = () => setScale(Math.min(window.innerWidth / W, window.innerHeight / H));
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, []);

  const now = () => performance.now();
  const current = () => {
    const c = clock.current;
    return c.playing ? c.base + (now() - c.wall) / 1000 : c.base;
  };

  // main loop (fixed 30fps sampling)
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      let tt = current();
      if (tt >= DURATION) {
        tt = DURATION - 1e-4;
        if (clock.current.playing) {
          clock.current.playing = false;
          clock.current.base = DURATION - 1e-4;
          setPlaying(false);
          setUiVisible(true);
        }
      }
      const frame = Math.floor(tt * FPS);
      if (frame !== clock.current.lastFrame) {
        clock.current.lastFrame = frame;
        const ft = frame / FPS;
        try { engineRef.current?.update(ft); } catch (e) { console.error(e); }
        setT(ft);
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const play = useCallback(() => {
    const c = clock.current;
    if (c.base >= DURATION - 0.05) c.base = 0;
    c.wall = now();
    c.playing = true;
    c.lastFrame = -1;
    setPlaying(true);
    setStarted(true);
    try { audioRef.current.play(c.base); } catch (e) { console.error(e); }
  }, []);
  const pause = useCallback(() => {
    const c = clock.current;
    c.base = current();
    c.playing = false;
    setPlaying(false);
    audioRef.current.stop();
  }, []);
  const seek = useCallback((v: number) => {
    const c = clock.current;
    c.base = Math.max(0, Math.min(DURATION - 1e-4, v));
    c.wall = now();
    c.lastFrame = -1;
    if (c.playing) audioRef.current.play(c.base);
  }, []);
  const toggle = useCallback(() => (clock.current.playing ? pause() : play()), [play, pause]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Space") { e.preventDefault(); toggle(); }
      else if (e.code === "ArrowRight") seek(current() + (e.shiftKey ? 3 : 1));
      else if (e.code === "ArrowLeft") seek(current() - (e.shiftKey ? 3 : 1));
      else if (e.key === "r") { seek(0); if (!clock.current.playing) play(); }
      else if (e.key === "m") setMuted((m) => { audioRef.current.setMuted(!m); return !m; });
      else if (e.key === "f") document.documentElement.requestFullscreen?.();
      else if (e.key === ".") { if (!clock.current.playing) seek(current() + 1 / FPS); }
      else if (e.key === ",") { if (!clock.current.playing) seek(current() - 1 / FPS); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle, seek, play]);

  const poke = () => {
    setUiVisible(true);
    window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => clock.current.playing && setUiVisible(false), 2200);
  };

  const labels = engineRef.current?.labels ?? [];
  const frame = Math.round(t * FPS);
  const chapter = CH_T.reduce((a, ct, i) => (t >= ct ? i : a), 0);

  return (
    <div className="fixed inset-0 bg-black select-none" onMouseMove={poke} style={{ cursor: uiVisible ? "default" : "none" }}>
      {/* stage */}
      <div
        className="stage"
        style={{ position: "absolute", left: "50%", top: "50%", width: W, height: H, transform: `translate(-50%,-50%) scale(${scale})`, overflow: "hidden", background: "#050505" }}
        onClick={() => started && toggle()}
      >
        <canvas ref={canvasRef} width={W} height={H} style={{ position: "absolute", inset: 0, width: W, height: H }} />
        <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
          <Hook t={t} />
          <Directions t={t} />
          <Intelligence t={t} />
          <Workspace t={t} />
          <PromptProduct t={t} />
          <Repetition t={t} />
          <TenX t={t} />
          <Connect t={t} />
          <Noise t={t} />
          <HumanMachine t={t} />
          <BuildNext t={t} labels={labels} />
          <Brand t={t} />
        </div>
        {/* grain + vignette */}
        <div className="grain" style={{ position: "absolute", inset: -60, pointerEvents: "none", opacity: 0.075, mixBlendMode: "overlay", transform: `translate(${(hash(frame) - 0.5) * 60}px, ${(hash(frame + 99) - 0.5) * 60}px)` }} />
        <div style={{ position: "absolute", inset: 0, pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.55) 100%)" }} />
        {t > 39.9 && <div style={{ position: "absolute", inset: 0, background: "#000" }} />}
        {glError && (
          <div style={{ position: "absolute", left: 40, bottom: 40, fontSize: 18, color: "rgba(255,255,255,0.6)" }}>WebGL unavailable — 3D layers disabled.</div>
        )}
      </div>

      {/* start screen */}
      {!started && (
        <div className="absolute inset-0 flex flex-col items-center justify-center" style={{ background: "radial-gradient(ellipse at center, rgba(20,22,18,0.6), #000 70%)" }}>
          <div className="flex items-center gap-4 mb-8">
            <Logo size={46} />
            <span style={{ fontSize: 44, fontWeight: 700, letterSpacing: "-0.04em" }}>Cupric <span style={{ color: LIME }}>AI</span></span>
          </div>
          <div className="mono text-xs tracking-[0.3em] text-white/45 mb-10">BRAND FILM · 00:40 · 1920×1080 · 30FPS</div>
          <button
            onClick={play}
            disabled={!ready}
            className="group flex items-center gap-3 rounded-full pl-5 pr-7 py-4 text-black font-semibold transition-transform hover:scale-[1.04] active:scale-95 disabled:opacity-40"
            style={{ background: LIME, boxShadow: "0 0 60px rgba(182,255,59,0.35)" }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24"><path d="M6 4l14 8-14 8z" fill="#000" /></svg>
            {ready ? "Play film — sound on" : "Loading…"}
          </button>
          <div className="mono text-[11px] tracking-[0.2em] text-white/30 mt-8">SPACE play/pause · ← → seek · M mute · F fullscreen</div>
        </div>
      )}

      {/* controls */}
      {started && (
        <div className="absolute left-0 right-0 bottom-0 px-6 pb-5 pt-16 transition-opacity duration-500" style={{ opacity: uiVisible ? 1 : 0, background: "linear-gradient(transparent, rgba(0,0,0,0.75))" }}>
          <div className="relative h-5 flex items-center cursor-pointer group" onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); seek(((e.clientX - r.left) / r.width) * DURATION); }}>
            <div className="absolute left-0 right-0 h-[3px] rounded bg-white/15" />
            <div className="absolute left-0 h-[3px] rounded" style={{ width: `${(t / DURATION) * 100}%`, background: LIME }} />
            {CH_T.map((ct, i) => <div key={i} className="absolute w-px h-2 bg-white/40" style={{ left: `${(ct / DURATION) * 100}%` }} />)}
            <div className="absolute w-3 h-3 rounded-full bg-white -translate-x-1/2" style={{ left: `${(t / DURATION) * 100}%` }} />
          </div>
          <div className="flex items-center gap-5 mt-2 text-sm">
            <button onClick={toggle} className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center">
              {playing ? (
                <svg width="14" height="14" viewBox="0 0 24 24"><rect x="5" y="4" width="5" height="16" fill="#fff" /><rect x="14" y="4" width="5" height="16" fill="#fff" /></svg>
              ) : (
                <svg width="14" height="14" viewBox="0 0 24 24"><path d="M6 4l14 8-14 8z" fill="#fff" /></svg>
              )}
            </button>
            <button onClick={() => { seek(0); if (!clock.current.playing) play(); }} className="text-white/60 hover:text-white">Restart</button>
            <button onClick={() => setMuted((m) => { audioRef.current.setMuted(!m); return !m; })} className="text-white/60 hover:text-white">{muted ? "Unmute" : "Mute"}</button>
            <span className="mono text-white/70">{tc(t)} <span className="text-white/30">/ 00:40:00</span></span>
            <span className="mono text-white/40 text-xs tracking-widest uppercase">{String(chapter + 1).padStart(2, "0")} · {CHAPTERS[chapter]}</span>
            <button onClick={() => document.documentElement.requestFullscreen?.()} className="ml-auto text-white/60 hover:text-white">Fullscreen</button>
          </div>
        </div>
      )}
    </div>
  );
}

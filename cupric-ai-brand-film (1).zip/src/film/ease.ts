export const DURATION = 40;
export const FPS = 30;
export const W = 1920;
export const H = 1080;
export const LIME = "#B6FF3B";
export const LIME_RGB = "182,255,59";

export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const prog = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
export const eo3 = (x: number) => 1 - Math.pow(1 - x, 3);
export const ei3 = (x: number) => x * x * x;
export const eio3 = (x: number) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
export const eoExpo = (x: number) => (x >= 1 ? 1 : 1 - Math.pow(2, -10 * x));
export const eiExpo = (x: number) => (x <= 0 ? 0 : Math.pow(2, 10 * x - 10));
export const eioExpo = (x: number) =>
  x <= 0 ? 0 : x >= 1 ? 1 : x < 0.5 ? Math.pow(2, 20 * x - 10) / 2 : (2 - Math.pow(2, -20 * x + 10)) / 2;
export const eoBack = (x: number, s = 1.70158) => 1 + (s + 1) * Math.pow(x - 1, 3) + s * Math.pow(x - 1, 2);
export const eo5 = (x: number) => 1 - Math.pow(1 - x, 5);

/** fade in over [a, a+fi], hold, fade out over [b-fo, b] */
export const win = (t: number, a: number, b: number, fi = 0.25, fo = 0.25) =>
  Math.min(prog(t, a, a + fi), 1 - prog(t, b - fo, b));

export const inRange = (t: number, a: number, b: number) => t >= a && t < b;

export function hash(n: number) {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
}

export function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

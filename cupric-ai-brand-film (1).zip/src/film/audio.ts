type Ev = { t: number; f: (c: AudioContext, out: AudioNode, when: number) => void };

export class FilmAudio {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  bus: GainNode | null = null;
  noise: AudioBuffer | null = null;
  verb: ConvolverNode | null = null;
  verbSend: GainNode | null = null;
  muted = false;
  private events: Ev[] = [];
  private nodes: AudioScheduledSourceNode[] = [];

  ensure() {
    if (this.ctx) return;
    const C = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new C();
    this.ctx = ctx;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.ratio.value = 4;
    this.master = ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.85;
    comp.connect(this.master).connect(ctx.destination);
    this.bus = ctx.createGain();
    this.bus.connect(comp);
    // noise
    const len = ctx.sampleRate * 2;
    this.noise = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noise.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    // reverb impulse
    const il = ctx.sampleRate * 3;
    const ir = ctx.createBuffer(2, il, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const c = ir.getChannelData(ch);
      for (let i = 0; i < il; i++) c[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / il, 3.2);
    }
    this.verb = ctx.createConvolver();
    this.verb.buffer = ir;
    this.verbSend = ctx.createGain();
    this.verbSend.gain.value = 0.35;
    this.verbSend.connect(this.verb).connect(comp);
    this.buildEvents();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.85, this.ctx.currentTime, 0.05);
  }

  // ---------------- instruments
  private reg(n: AudioScheduledSourceNode) {
    this.nodes.push(n);
    return n;
  }
  private out(dry = 1, wet = 0.4) {
    const c = this.ctx!;
    const g = c.createGain();
    g.gain.value = dry;
    g.connect(this.bus!);
    if (wet > 0) {
      const s = c.createGain();
      s.gain.value = wet;
      g.connect(s).connect(this.verbSend!);
    }
    return g;
  }
  private noiseSrc(when: number, dur: number) {
    const c = this.ctx!;
    const s = c.createBufferSource();
    s.buffer = this.noise;
    s.loop = true;
    this.reg(s);
    s.start(when, Math.random());
    s.stop(when + dur + 0.05);
    return s;
  }
  impact(when: number, amt = 1) {
    const c = this.ctx!;
    const o = c.createOscillator();
    o.type = "sine";
    o.frequency.setValueAtTime(110, when);
    o.frequency.exponentialRampToValueAtTime(32, when + 0.7);
    const g = c.createGain();
    g.gain.setValueAtTime(0, when);
    g.gain.linearRampToValueAtTime(0.9 * amt, when + 0.008);
    g.gain.exponentialRampToValueAtTime(0.001, when + 1.8);
    o.connect(g).connect(this.out(1, 0.5));
    this.reg(o).start(when);
    o.stop(when + 2);
    const n = this.noiseSrc(when, 0.9);
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(2400, when);
    f.frequency.exponentialRampToValueAtTime(120, when + 0.6);
    const ng = c.createGain();
    ng.gain.setValueAtTime(0.45 * amt, when);
    ng.gain.exponentialRampToValueAtTime(0.001, when + 0.8);
    n.connect(f).connect(ng).connect(this.out(1, 0.8));
  }
  hit(when: number, amt = 1) {
    const c = this.ctx!;
    const o = c.createOscillator();
    o.frequency.setValueAtTime(180, when);
    o.frequency.exponentialRampToValueAtTime(55, when + 0.18);
    const g = c.createGain();
    g.gain.setValueAtTime(0.5 * amt, when);
    g.gain.exponentialRampToValueAtTime(0.001, when + 0.45);
    o.connect(g).connect(this.out(1, 0.3));
    this.reg(o).start(when);
    o.stop(when + 0.5);
    const n = this.noiseSrc(when, 0.06);
    const f = c.createBiquadFilter();
    f.type = "highpass";
    f.frequency.value = 3000;
    const ng = c.createGain();
    ng.gain.setValueAtTime(0.15 * amt, when);
    ng.gain.exponentialRampToValueAtTime(0.001, when + 0.05);
    n.connect(f).connect(ng).connect(this.out(1, 0.2));
  }
  click(when: number, freq = 2600, amt = 1) {
    const c = this.ctx!;
    const o = c.createOscillator();
    o.type = "triangle";
    o.frequency.setValueAtTime(freq, when);
    o.frequency.exponentialRampToValueAtTime(freq * 0.6, when + 0.03);
    const g = c.createGain();
    g.gain.setValueAtTime(0.07 * amt, when);
    g.gain.exponentialRampToValueAtTime(0.0005, when + 0.04);
    o.connect(g).connect(this.out(1, 0.15));
    this.reg(o).start(when);
    o.stop(when + 0.06);
  }
  tick(when: number, amt = 1) {
    const c = this.ctx!;
    const n = this.noiseSrc(when, 0.03);
    const f = c.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = 1800;
    f.Q.value = 8;
    const g = c.createGain();
    g.gain.setValueAtTime(0.5 * amt, when);
    g.gain.exponentialRampToValueAtTime(0.001, when + 0.025);
    n.connect(f).connect(g).connect(this.out(1, 0.05));
  }
  whoosh(when: number, dur: number, up = true, amt = 1) {
    const c = this.ctx!;
    const n = this.noiseSrc(when, dur);
    const f = c.createBiquadFilter();
    f.type = "bandpass";
    f.Q.value = 1.4;
    f.frequency.setValueAtTime(up ? 250 : 5000, when);
    f.frequency.exponentialRampToValueAtTime(up ? 5000 : 200, when + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.001, when);
    g.gain.exponentialRampToValueAtTime(0.35 * amt, when + dur * (up ? 0.92 : 0.15));
    g.gain.exponentialRampToValueAtTime(0.001, when + dur);
    n.connect(f).connect(g).connect(this.out(1, 0.5));
  }
  riser(when: number, dur: number, amt = 1) {
    this.whoosh(when, dur, true, amt);
    const c = this.ctx!;
    const o = c.createOscillator();
    o.type = "sawtooth";
    o.frequency.setValueAtTime(90, when);
    o.frequency.exponentialRampToValueAtTime(360, when + dur);
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(300, when);
    f.frequency.exponentialRampToValueAtTime(2400, when + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.001, when);
    g.gain.exponentialRampToValueAtTime(0.08 * amt, when + dur * 0.95);
    g.gain.linearRampToValueAtTime(0, when + dur);
    o.connect(f).connect(g).connect(this.out(1, 0.4));
    this.reg(o).start(when);
    o.stop(when + dur + 0.02);
  }
  bell(when: number, freq: number, dur = 1.5, amt = 1) {
    const c = this.ctx!;
    [1, 2.01, 3.0].forEach((m, i) => {
      const o = c.createOscillator();
      o.type = "sine";
      o.frequency.value = freq * m;
      const g = c.createGain();
      g.gain.setValueAtTime(0, when);
      g.gain.linearRampToValueAtTime((0.12 / (i + 1)) * amt, when + 0.005);
      g.gain.exponentialRampToValueAtTime(0.0005, when + dur / (i + 1));
      o.connect(g).connect(this.out(1, 0.7));
      this.reg(o).start(when);
      o.stop(when + dur + 0.1);
    });
  }
  pad(when: number, freqs: number[], dur: number, amt = 1, attack = 0.6) {
    const c = this.ctx!;
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(400, when);
    f.frequency.linearRampToValueAtTime(1600, when + dur * 0.5);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(0.05 * amt, when + attack);
    g.gain.setValueAtTime(0.05 * amt, when + dur - 0.8);
    g.gain.linearRampToValueAtTime(0.0001, when + dur);
    f.connect(g).connect(this.out(1, 0.6));
    freqs.forEach((fr) => {
      [-6, 6].forEach((det) => {
        const o = c.createOscillator();
        o.type = "sawtooth";
        o.frequency.value = fr;
        o.detune.value = det;
        o.connect(f);
        this.reg(o).start(when);
        o.stop(when + dur + 0.05);
      });
    });
  }
  kick(when: number, amt = 1) {
    const c = this.ctx!;
    const o = c.createOscillator();
    o.frequency.setValueAtTime(160, when);
    o.frequency.exponentialRampToValueAtTime(42, when + 0.12);
    const g = c.createGain();
    g.gain.setValueAtTime(0.7 * amt, when);
    g.gain.exponentialRampToValueAtTime(0.001, when + 0.3);
    o.connect(g).connect(this.out(1, 0.1));
    this.reg(o).start(when);
    o.stop(when + 0.32);
  }
  drone(when: number, from: number, to: number, freqs: number[], amt = 1) {
    const c = this.ctx!;
    const dur = to - from;
    if (dur <= 0) return;
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 260;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(0.06 * amt, when + Math.min(0.8, dur / 3));
    g.gain.setValueAtTime(0.06 * amt, when + dur - Math.min(0.15, dur / 4));
    g.gain.linearRampToValueAtTime(0.0001, when + dur);
    f.connect(g).connect(this.out(1, 0.3));
    freqs.forEach((fr, i) => {
      const o = c.createOscillator();
      o.type = i === 0 ? "sine" : "sawtooth";
      o.frequency.value = fr;
      o.connect(f);
      this.reg(o).start(when);
      o.stop(when + dur + 0.05);
    });
  }

  private buildEvents() {
    const E: Ev[] = [];
    const add = (t: number, f: Ev["f"]) => E.push({ t, f });
    const A = this;
    // Drones (as timed segments)
    const drones: [number, number, number[], number][] = [
      [0.2, 9.0, [36.7, 55, 73.4], 1],
      [9.3, 17.85, [41.2, 61.7, 82.4], 0.9],
      [19.3, 26.2, [36.7, 55, 110], 1.1],
      [27.0, 30.0, [55, 82.4], 0.5],
      [30.0, 33.2, [36.7, 55, 73.4, 110], 1.2],
      [34.0, 39.9, [36.7, 55], 0.8],
    ];
    drones.forEach(([a, b, fr, amt]) => E.push({ t: a, f: (_c, _o, w) => A.drone(w, a, b, fr, amt) }));
    // 0–3
    add(0.05, (_c, _o, w) => A.bell(w, 1318, 0.8, 0.4));
    add(0.25, (_c, _o, w) => A.impact(w, 1));
    add(0.9, (_c, _o, w) => A.hit(w, 0.9));
    add(1.8, (_c, _o, w) => A.hit(w, 0.9));
    add(2.35, (_c, _o, w) => A.riser(w, 0.65, 1));
    // 3–6
    add(3.0, (_c, _o, w) => A.impact(w, 0.9));
    add(3.35, (_c, _o, w) => A.hit(w, 0.6));
    add(4.4, (_c, _o, w) => A.hit(w, 0.7));
    [5.0, 5.08, 5.16, 5.24].forEach((t) => add(t, (_c, _o, w) => A.whoosh(w, 0.5, false, 0.5)));
    add(5.55, (_c, _o, w) => A.whoosh(w, 0.45, true, 0.6));
    // 6–9
    for (let i = 0; i < 18; i++) add(6.2 + i * 0.13, (_c, _o, w) => A.click(w, 1800 + (i % 5) * 400, 0.6));
    add(6.3, (_c, _o, w) => A.hit(w, 0.5));
    add(7.5, (_c, _o, w) => A.hit(w, 0.6));
    add(8.5, (_c, _o, w) => A.whoosh(w, 0.5, true, 0.8));
    // 9–12
    add(9.0, (_c, _o, w) => A.impact(w, 1.1));
    for (let i = 0; i < 22; i++) add(9.5 + i * 0.07, (_c, _o, w) => A.click(w, 2200 + (i % 3) * 600, 0.8));
    add(10.05, (_c, _o, w) => A.hit(w, 0.9));
    add(10.85, (_c, _o, w) => A.hit(w, 1));
    add(11.3, (_c, _o, w) => A.riser(w, 0.7, 1.1));
    // 12–15
    add(12.0, (_c, _o, w) => A.whoosh(w, 0.4, false, 0.7));
    for (let i = 0; i < 37; i++) add(12.35 + i * 0.019, (_c, _o, w) => A.tick(w, 0.35));
    add(13.05, (_c, _o, w) => A.click(w, 1200, 1.6));
    [13.15, 13.25, 13.35, 13.45].forEach((t, i) => add(t, (_c, _o, w) => A.bell(w, 880 * (1 + i * 0.12), 0.4, 0.4)));
    for (let i = 0; i < 12; i++) add(13.55 + i * 0.09, (_c, _o, w) => A.click(w, 1500 + i * 90, 0.8));
    add(13.75, (_c, _o, w) => A.hit(w, 0.8));
    add(14.65, (_c, _o, w) => A.bell(w, 1760, 0.8, 0.5));
    // 15–18
    for (let i = 0; i < 10; i++) add(15.0 + i * 0.125, (_c, _o, w) => A.tick(w, 0.8));
    add(15.35, (_c, _o, w) => A.hit(w, 0.6));
    add(16.25, (_c, _o, w) => A.whoosh(w, 0.4, true, 0.7));
    add(16.6, (_c, _o, w) => A.pad(w, [220, 277, 330], 1.3, 0.8, 0.2));
    // 18–21
    add(18.25, (_c, _o, w) => A.impact(w, 1.4));
    add(18.25, (_c, _o, w) => A.bell(w, 110, 1.2, 0.8));
    add(19.3, (_c, _o, w) => A.impact(w, 1.2));
    add(19.3, (_c, _o, w) => A.whoosh(w, 1.2, false, 1));
    // 21–24
    add(21.2, (_c, _o, w) => A.pad(w, [110, 165, 247], 2.8, 0.8, 1.2));
    add(22.9, (_c, _o, w) => A.impact(w, 0.9));
    add(22.9, (_c, _o, w) => A.bell(w, 660, 1.4, 0.6));
    add(23.6, (_c, _o, w) => A.riser(w, 0.4, 0.9));
    // 24–27 energetic
    for (let i = 0; i < 9; i++) add(24.0 + i * 0.25, (_c, _o, w) => A.kick(w, 0.9));
    for (let i = 0; i < 18; i++) add(24.12 + i * 0.125, (_c, _o, w) => A.tick(w, 0.6));
    add(25.4, (_c, _o, w) => A.whoosh(w, 0.3, false, 0.6));
    add(25.8, (_c, _o, w) => A.riser(w, 0.4, 1));
    add(26.2, (_c, _o, w) => A.impact(w, 1.3));
    // 27–30
    add(27.4, (_c, _o, w) => A.bell(w, 440, 1.6, 0.5));
    add(28.0, (_c, _o, w) => A.bell(w, 660, 1.6, 0.4));
    add(28.4, (_c, _o, w) => A.bell(w, 880, 2.2, 0.8));
    add(29.2, (_c, _o, w) => A.riser(w, 0.8, 1.1));
    // 30–33
    add(30.0, (_c, _o, w) => A.impact(w, 1.2));
    add(30.0, (_c, _o, w) => A.pad(w, [110, 165, 220, 277], 3.2, 1, 0.8));
    add(30.55, (_c, _o, w) => A.hit(w, 0.7));
    add(31.35, (_c, _o, w) => A.hit(w, 0.8));
    // 33–40
    add(33.0, (_c, _o, w) => A.whoosh(w, 0.65, false, 1));
    add(33.7, (_c, _o, w) => A.tick(w, 0.6));
    add(34.2, (_c, _o, w) => A.bell(w, 1320, 1.2, 0.35));
    add(35.2, (_c, _o, w) => A.impact(w, 1.1));
    add(35.2, (_c, _o, w) => A.pad(w, [146.8, 220, 277, 370], 4.6, 1.1, 0.4));
    add(36.3, (_c, _o, w) => A.bell(w, 1760, 1.4, 0.3));
    add(38.0, (_c, _o, w) => A.pad(w, [110, 165, 220, 330], 1.9, 0.8, 0.5));
    add(38.6, (_c, _o, w) => A.bell(w, 2640, 1.2, 0.25));
    this.events = E;
  }

  play(offset: number) {
    this.ensure();
    const c = this.ctx!;
    if (c.state === "suspended") c.resume();
    this.stop();
    const now = c.currentTime + 0.05;
    for (const e of this.events) {
      if (e.t >= offset - 0.02) {
        try { e.f(c, this.bus!, now + (e.t - offset)); } catch { /* ignore */ }
      }
    }
  }

  stop() {
    this.nodes.forEach((n) => { try { n.stop(); } catch { /* noop */ } });
    this.nodes = [];
  }
}

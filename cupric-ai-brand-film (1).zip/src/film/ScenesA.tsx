import { KText, Center } from "./Kinetic";
import { clamp, prog, eo3, eoExpo, ei3, eio3, hash, LIME, LIME_RGB, mulberry32 } from "./ease";
import { textInfo } from "./engine";

const mono: React.CSSProperties = { fontFamily: '"JetBrains Mono", monospace' };

export function HudLabel({ x, y, text, o = 1, align = "left" }: { x: number; y: number; text: string; o?: number; align?: "left" | "right" }) {
  return (
    <div style={{ position: "absolute", left: x, top: y, ...mono, fontSize: 13, letterSpacing: "0.16em", color: `rgba(255,255,255,${0.42 * o})`, transform: align === "right" ? "translateX(-100%)" : undefined, whiteSpace: "nowrap" }}>
      {text}
    </div>
  );
}

// 0–3 -------------------------------------------------------------------------
export function Hook({ t }: { t: number }) {
  if (t > 3.1) return null;
  const dot = eo3(prog(t, 0.02, 0.18));
  const flash = prog(t, 0.22, 1.0);
  const trails = Array.from({ length: 9 });
  const tr = Math.min(prog(t, 0.9, 1.2), 1 - prog(t, 2.6, 2.9));
  return (
    <>
      {t < 0.6 && (
        <div style={{ position: "absolute", left: 960, top: 540, width: 6 + dot * 4, height: 6 + dot * 4, borderRadius: 99, background: "#eaffc4", transform: `translate(-50%,-50%) scale(${1 + ei3(prog(t, 0.15, 0.3)) * 3})`, boxShadow: `0 0 ${20 + dot * 30}px ${6 + dot * 8}px rgba(${LIME_RGB},0.8)`, opacity: 1 - prog(t, 0.28, 0.5) }} />
      )}
      {t > 0.2 && t < 1.05 && (
        <div style={{ position: "absolute", left: 960, top: 540, width: 60, height: 60, borderRadius: 999, transform: `translate(-50%,-50%) scale(${1 + eoExpo(flash) * 45})`, background: `radial-gradient(circle, rgba(${LIME_RGB},0.0) 40%, rgba(${LIME_RGB},0.55) 62%, transparent 70%)`, opacity: (1 - flash) * 0.9 }} />
      )}
      {tr > 0 &&
        trails.map((_, i) => {
          const y = 200 + hash(i) * 680;
          const sp = 900 + hash(i + 9) * 1600;
          const x = ((t * sp + hash(i + 3) * 2400) % 2600) - 400;
          return <div key={i} style={{ position: "absolute", left: x, top: y, width: 240 + hash(i + 5) * 300, height: 1, background: `linear-gradient(90deg, transparent, rgba(${i % 3 === 0 ? LIME_RGB : "255,255,255"},0.8), transparent)`, opacity: tr * 0.7 }} />;
        })}
      <Center>
        <div style={{ transform: `perspective(1400px) rotateY(${Math.sin(t * 0.9) * -6}deg) rotateX(${Math.cos(t * 0.7) * 3}deg) scale(${1 + clamp(t - 0.85) * 0.12})` }}>
          <KText text="CREATE." t={t} at={0.85} out={1.62} inDur={0.8} outDur={0.3} variant="depth" exit="blur" size={320} weight={700} stagger={0.045} glow />
        </div>
      </Center>
      <Center>
        <div style={{ transform: `perspective(1400px) rotateY(${Math.sin(t * 0.9) * -4}deg) scale(${1 + clamp(t - 1.8) * 0.08})` }}>
          <KText text="WITH INTELLIGENCE." t={t} at={1.78} out={2.62} inDur={0.6} outDur={0.4} variant="blur" exit="zoom" size={150} weight={600} trackFrom={0.35} stagger={0.02} />
        </div>
      </Center>
      <HudLabel x={80} y={70} text="CUPRIC / 001 — GENESIS" o={win2(t, 0.6, 2.8)} />
      <HudLabel x={1840} y={70} align="right" text={`FIELD ${Math.floor(clamp(t / 1.5) * 14000).toLocaleString()} PTS`} o={win2(t, 0.6, 2.8)} />
    </>
  );
}
const win2 = (t: number, a: number, b: number) => Math.min(prog(t, a, a + 0.3), 1 - prog(t, b - 0.3, b));

// 3–6 -------------------------------------------------------------------------
export function Directions({ t }: { t: number }) {
  if (t < 3.2 || t > 6.1) return null;
  const copies = 8;
  return (
    <>
      <Center>
        <KText text="ONE IDEA." t={t} at={3.3} out={4.2} inDur={0.6} outDur={0.35} size={230} weight={700} stagger={0.04} />
      </Center>
      <Center y={-92}>
        <KText text="INFINITE" t={t} at={4.3} out={5.7} inDur={0.55} outDur={0.35} size={176} weight={700} stagger={0.03} />
      </Center>
      {t > 4.95 &&
        Array.from({ length: copies }).map((_, k) => {
          const a = (k / copies) * Math.PI * 2 + 0.3;
          const p = eo3(prog(t, 4.98 + k * 0.035, 5.95));
          const d = 1100 * p;
          return (
            <Center key={k} y={82}>
              <div style={{ fontSize: 176, fontWeight: 700, letterSpacing: "-0.045em", lineHeight: 0.92, color: "transparent", WebkitTextStroke: `1.4px ${k % 3 === 0 ? LIME : "rgba(255,255,255,0.7)"}`, transform: `translate(${Math.cos(a) * d}px, ${Math.sin(a) * d * 0.6}px) scale(${1 + p * 0.4}) rotate(${Math.cos(a) * p * 8}deg)`, opacity: (1 - p) * clamp((t - 4.98) * 8), filter: `blur(${p * 6}px)` }}>
                DIRECTIONS.
              </div>
            </Center>
          );
        })}
      <Center y={82}>
        <KText text="DIRECTIONS." t={t} at={4.45} out={5.7} inDur={0.55} outDur={0.35} size={176} weight={700} stagger={0.03} />
      </Center>
      <HudLabel x={80} y={70} text="002 — BRANCHING" o={win2(t, 3.3, 5.9)} />
      <HudLabel x={1840} y={70} align="right" text={`PATHS ${Math.floor(eo3(prog(t, 3, 5.6)) * 1458)}`} o={win2(t, 3.3, 5.9)} />
    </>
  );
}

// 6–9 -------------------------------------------------------------------------
export function Intelligence({ t }: { t: number }) {
  if (t < 6.1 || t > 9.1) return null;
  const word = "INTELLIGENCE";
  const n = word.length;
  const act = Math.floor(t * 14) % (n + 4);
  const col = ei3(prog(t, 8.65, 9.0));
  const nodeY = (i: number) => -46 + Math.sin(t * 2.4 + i * 0.8) * 12;
  return (
    <>
      <Center style={{ transform: `scale(${Math.max(0.001, 1 - col)})`, opacity: 1 - prog(t, 8.9, 9.0) }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 36 }}>
          <KText
            text={word}
            t={t}
            at={6.25}
            inDur={0.9}
            stagger={0.04}
            variant="depth"
            exit="none"
            size={196}
            weight={600}
            tracking={-0.03}
            charStyle={(i) => ({ color: i === act ? LIME : "#fff", transition: "none" })}
            decorate={(i, e) => {
              const y0 = nodeY(i), y1 = nodeY(i + 1);
              const on = i === act;
              return (
                <svg style={{ position: "absolute", left: 0, top: 0, width: "100%", height: "100%", overflow: "visible", opacity: e }}>
                  {i < n - 1 && <line x1="50%" y1={y0} x2="150%" y2={y1} stroke="rgba(255,255,255,0.35)" strokeWidth={1} />}
                  {i % 3 === 0 && <line x1="50%" y1={y0} x2="50%" y2={-180 - hash(i) * 120} stroke="rgba(255,255,255,0.12)" strokeWidth={1} strokeDasharray="2 6" />}
                  <circle cx="50%" cy={y0} r={on ? 6 : 3.2} fill={on ? LIME : "#fff"} />
                  {on && <circle cx="50%" cy={y0} r={16} fill="none" stroke={LIME} strokeOpacity={0.5} />}
                </svg>
              );
            }}
          />
          <KText text="IN MOTION." t={t} at={7.4} inDur={0.55} stagger={0.035} variant="slide" exit="none" size={120} weight={500} tracking={0.02} charTransform={(i) => `translateX(${Math.sin(t * 3 + i * 0.7) * 3}px)`} />
        </div>
      </Center>
      <HudLabel x={80} y={70} text="003 — LIVE NETWORK" o={win2(t, 6.3, 8.8)} />
      <HudLabel x={1840} y={70} align="right" text={`72 NODES · 219 EDGES · ${(1.2 + Math.sin(t * 5) * 0.2).toFixed(2)} TFLOP/s`} o={win2(t, 6.3, 8.8)} />
      {t > 8.85 && <div style={{ position: "absolute", left: 960, top: 540, width: 14, height: 14, borderRadius: 99, background: "#f4ffe0", transform: "translate(-50%,-50%)", boxShadow: `0 0 50px 20px rgba(${LIME_RGB},0.9)`, opacity: 1 - prog(t, 9.0, 9.1) }} />}
    </>
  );
}

// 18–21 -----------------------------------------------------------------------
const shardRng = mulberry32(99);
const SHARDS: { pts: [number, number][]; c: [number, number]; r: number }[] = (() => {
  const cols = 7, rows = 4, x0 = 300, x1 = 1620, y0 = 230, y1 = 850;
  const gp: [number, number][][] = [];
  for (let j = 0; j <= rows; j++) {
    gp.push([]);
    for (let i = 0; i <= cols; i++) {
      const jx = i > 0 && i < cols ? (shardRng() - 0.5) * 110 : 0;
      const jy = j > 0 && j < rows ? (shardRng() - 0.5) * 90 : 0;
      gp[j].push([x0 + ((x1 - x0) * i) / cols + jx, y0 + ((y1 - y0) * j) / rows + jy]);
    }
  }
  const out: { pts: [number, number][]; c: [number, number]; r: number }[] = [];
  for (let j = 0; j < rows; j++)
    for (let i = 0; i < cols; i++) {
      const a = gp[j][i], b = gp[j][i + 1], c = gp[j + 1][i + 1], d = gp[j + 1][i];
      const tris: [number, number][][] = shardRng() < 0.5 ? [[a, b, c], [a, c, d]] : [[a, b, d], [b, c, d]];
      tris.forEach((tri) => out.push({ pts: tri, c: [(tri[0][0] + tri[1][0] + tri[2][0]) / 3, (tri[0][1] + tri[1][1] + tri[2][1]) / 3], r: shardRng() }));
    }
  return out;
})();

function TenText() {
  return (
    <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0 }}>
      <text x={960} y={textInfo.baseline10} textAnchor="middle" fontSize={640} fontWeight={700} letterSpacing={-38} fill="#fff" style={{ fontFamily: '"Inter Tight", sans-serif' }}>
        10<tspan fill={LIME}>×</tspan>
      </text>
    </svg>
  );
}

export function TenX({ t }: { t: number }) {
  if (t < 18.2 || t > 20.0) return null;
  const inP = eoExpo(prog(t, 18.25, 18.65));
  const s = 1.22 - 0.22 * inP + Math.sin(prog(t, 18.65, 19.3) * Math.PI) * 0.02;
  const shattered = t >= 19.3;
  const hud = Math.min(prog(t, 18.55, 18.8), 1 - prog(t, 19.2, 19.3));
  return (
    <>
      {!shattered && (
        <div style={{ position: "absolute", inset: 0, transform: `scale(${s})`, opacity: prog(t, 18.25, 18.32), filter: inP < 0.98 ? `blur(${(1 - inP) * 18}px)` : undefined }}>
          <TenText />
        </div>
      )}
      {shattered &&
        SHARDS.map((sh, k) => {
          const p = eo3(prog(t, 19.3, 19.95));
          const dx = sh.c[0] - 960, dy = sh.c[1] - 540;
          const len = Math.hypot(dx, dy) || 1;
          const d = (260 + sh.r * 900) * p;
          const poly = sh.pts.map(([x, y]) => `${x}px ${y}px`).join(",");
          return (
            <div key={k} style={{ position: "absolute", inset: 0, clipPath: `polygon(${poly})`, transformOrigin: `${sh.c[0]}px ${sh.c[1]}px`, transform: `translate(${(dx / len) * d}px, ${(dy / len) * d}px) rotate(${(sh.r - 0.5) * 140 * p}deg) scale(${1 - p * 0.3})`, opacity: 1 - prog(t, 19.35, 19.8) }}>
              <TenText />
            </div>
          );
        })}
      {hud > 0 && (
        <>
          <div style={{ position: "absolute", left: 120, right: 120, top: 540, height: 1, background: "rgba(255,255,255,0.12)", opacity: hud }} />
          <div style={{ position: "absolute", top: 120, bottom: 120, left: 960, width: 1, background: "rgba(255,255,255,0.08)", opacity: hud }} />
          <HudLabel x={130} y={505} text="BASELINE 1.00" o={hud} />
          <HudLabel x={1790} y={505} align="right" text={`OUTPUT ${(1 + 9 * eo3(prog(t, 18.5, 19.1))).toFixed(2)}`} o={hud} />
          <HudLabel x={80} y={70} text="007 — MULTIPLIER" o={hud} />
        </>
      )}
    </>
  );
}

// 21–24 -----------------------------------------------------------------------
export function Connect({ t }: { t: number }) {
  if (t < 21.2 || t > 24.1) return null;
  const c = eio3(prog(t, 22.5, 22.92));
  const u = eoExpo(prog(t, 22.92, 23.35));
  return (
    <>
      <Center y={330}>
        <KText text="IDEAS" t={t} at={21.35} out={22.35} inDur={0.7} outDur={0.3} variant="blur" exit="blur" size={150} weight={600} trackFrom={0.6} stagger={0.04} />
      </Center>
      <Center y={330}>
        <div style={{ position: "relative" }}>
          <KText
            text="CONNECT."
            t={t}
            at={22.4}
            out={23.75}
            inDur={0.3}
            outDur={0.3}
            variant="blur"
            exit="blur"
            size={150}
            weight={700}
            stagger={0.01}
            charTransform={(i) => {
              const a = hash(i * 7.1) * Math.PI * 2;
              const r = 220 + hash(i * 3.3) * 260;
              return `translate(${Math.cos(a) * r * (1 - c)}px, ${Math.sin(a) * r * 0.5 * (1 - c)}px) rotate(${(hash(i) - 0.5) * 50 * (1 - c)}deg)`;
            }}
          />
          <div style={{ position: "absolute", left: 0, bottom: -26, height: 3, width: `${u * 100}%`, background: LIME, boxShadow: `0 0 24px rgba(${LIME_RGB},0.8)`, opacity: 1 - prog(t, 23.6, 23.9) }} />
        </div>
      </Center>
      <HudLabel x={80} y={70} text="008 — SYNTHESIS" o={win2(t, 21.4, 23.9)} />
      <HudLabel x={1840} y={70} align="right" text={t < 22.9 ? `LINKING ${Math.floor(eo3(prog(t, 21.5, 22.9)) * 15)}/15` : "UNIFIED"} o={win2(t, 21.4, 23.9)} />
    </>
  );
}

import React from "react";
import { KText, Center, Logo } from "./Kinetic";
import { HudLabel } from "./ScenesA";
import { clamp, prog, eo3, eoExpo, ei3, eio3, eioExpo, hash, lerp, LIME, LIME_RGB } from "./ease";

const MONO = '"JetBrains Mono", monospace';
const glass: React.CSSProperties = {
  background: "linear-gradient(180deg, rgba(24,26,28,0.94), rgba(13,14,15,0.94))",
  border: "1px solid rgba(255,255,255,0.08)",
  borderRadius: 14,
  boxShadow: "0 30px 80px rgba(0,0,0,0.55), inset 0 1px 0 rgba(255,255,255,0.05)",
};
const abs = (x: number, y: number, w: number, h: number): React.CSSProperties => ({ position: "absolute", left: x, top: y, width: w, height: h });

function fly(t: number, at: number, dur = 0.55, fromX = 0, fromY = 30, fromS = 0.94): React.CSSProperties {
  const p = eoExpo(prog(t, at, at + dur));
  return {
    opacity: clamp(prog(t, at, at + dur * 0.4)),
    transform: `translate(${fromX * (1 - p)}px, ${fromY * (1 - p)}px) scale(${lerp(fromS, 1, p)})`,
    filter: p < 0.97 ? `blur(${(1 - p) * 10}px)` : undefined,
  };
}

// ============================================================ 9–12 WORKSPACE
const CODE: [string, string][][] = [
  [["import", "#8a8f98"], [" { Hero, Metric, Chart } ", "#e8eaed"], ["from", "#8a8f98"], [' "@cupric/ui"', LIME]],
  [],
  [["export default ", "#8a8f98"], ["function ", "#8a8f98"], ["Launch", "#fff"], ["() {", "#e8eaed"]],
  [["  return ", "#8a8f98"], ["<Grid ", "#fff"], ["cols", "#8a8f98"], ["={6}>", "#e8eaed"]],
  [["    <Hero ", "#fff"], ["title", "#8a8f98"], ['="Launch faster"', LIME], [" />", "#fff"]],
  [["    <Metric ", "#fff"], ["label", "#8a8f98"], ['="Builders"', LIME], [" live />", "#fff"]],
  [["    <Chart ", "#fff"], ["data", "#8a8f98"], ["={usage} ", "#e8eaed"], ["smooth />", "#fff"]],
  [["    <Feed ", "#fff"], ["source", "#8a8f98"], ['="agents"', LIME], [" />", "#fff"]],
  [["    <Toggles ", "#fff"], ["flags", "#8a8f98"], ["={env} />", "#e8eaed"]],
  [["    <Deploy ", "#fff"], ["target", "#8a8f98"], ['="edge"', LIME], [" />", "#fff"]],
  [["  </Grid>", "#fff"]],
  [["}", "#e8eaed"]],
];
const COMPILE = [4, 5, 6, 7, 8, 9];

function Spark({ w, h, p, color = LIME, seed = 1, fill = true }: { w: number; h: number; p: number; color?: string; seed?: number; fill?: boolean }) {
  const pts: string[] = [];
  const n = 28;
  for (let i = 0; i <= n; i++) {
    const x = (i / n) * w;
    const y = h * 0.85 - (Math.sin(i * 0.45 + seed) * 0.18 + Math.sin(i * 0.17 + seed * 2) * 0.2 + (i / n) * 0.45) * h * 0.8;
    pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
  }
  const d = "M" + pts.join(" L");
  return (
    <svg width={w} height={h} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id={`g${seed}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={color} stopOpacity={0.35} />
          <stop offset="1" stopColor={color} stopOpacity={0} />
        </linearGradient>
        <clipPath id={`c${seed}`}>
          <rect x={0} y={-20} width={w * p} height={h + 40} />
        </clipPath>
      </defs>
      <g clipPath={`url(#c${seed})`}>
        {fill && <path d={`${d} L${w},${h} L0,${h} Z`} fill={`url(#g${seed})`} />}
        <path d={d} fill="none" stroke={color} strokeWidth={2} />
      </g>
    </svg>
  );
}

export function Workspace({ t }: { t: number }) {
  if (t < 9.28 || t > 12.05) return null;
  const o1 = eoExpo(prog(t, 9.3, 9.58));
  const o2 = eoExpo(prog(t, 9.52, 9.88));
  const e = eo3(prog(t, 9.3, 11.6));
  const zp = ei3(prog(t, 11.5, 12.0));
  const dim = 1 - 0.6 * eo3(prog(t, 10.75, 11.0));
  const navActive = lerp(0, 3, eioExpo(prog(t, 10.45, 10.8)));
  const nav = ["Home", "Projects", "Agents", "Components", "Data", "Deployments", "Analytics", "Settings"];
  const slots = [
    [0, 0, 870, 220], [0, 236, 280, 170], [295, 236, 575, 170], [0, 422, 425, 300], [440, 422, 430, 145], [440, 577, 430, 145],
  ];
  const cardIn = (k: number) => {
    const at = 10.2 + k * 0.12;
    const p = eoExpo(prog(t, at, at + 0.6));
    const line = COMPILE[k];
    const fromX = -520 - slots[k][0];
    const fromY = 60 + line * 22 - slots[k][1];
    return {
      opacity: clamp(prog(t, at, at + 0.15)),
      transform: `translate(${fromX * (1 - p)}px, ${fromY * (1 - p)}px) scale(${lerp(0.25, 1, p)})`,
      transformOrigin: "0 0",
      filter: p < 0.97 ? `blur(${(1 - p) * 8}px)` : undefined,
    } as React.CSSProperties;
  };
  const gen = Math.min(6, Math.floor(prog(t, 10.2, 11.0) * 6.99));
  return (
    <>
      {t < 9.9 && (
        <div style={{ position: "absolute", left: 960, top: 540, width: 1560 * o1, height: 2, background: LIME, transform: "translate(-50%,-50%)", boxShadow: `0 0 30px 4px rgba(${LIME_RGB},0.7)`, opacity: 1 - prog(t, 9.6, 9.85) }} />
      )}
      <div style={{ position: "absolute", inset: 0, perspective: 2200, opacity: 1 - prog(t, 11.75, 12.0) }}>
        <div
          style={{
            ...abs(180, 110, 1560, 860),
            ...glass,
            borderRadius: 18,
            overflow: "hidden",
            clipPath: `inset(${(1 - o2) * 50}% ${(1 - o1) * 50}% round 18px)`,
            transform: `rotateX(${16 - 11 * e}deg) rotateY(${-9 + 7 * e}deg) scale(${(0.9 + 0.07 * e) * (1 + zp * 0.9)})`,
            filter: `brightness(${dim})${zp > 0.01 ? ` blur(${zp * 12}px)` : ""}`,
          }}
        >
          {/* top bar */}
          <div style={{ ...abs(0, 0, 1560, 56), borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", alignItems: "center", padding: "0 20px", gap: 18, ...fly(t, 9.8, 0.5, 0, -20) }}>
            <div style={{ display: "flex", gap: 8 }}>{[0, 1, 2].map((i) => <div key={i} style={{ width: 11, height: 11, borderRadius: 9, background: "rgba(255,255,255,0.14)" }} />)}</div>
            <div style={{ fontSize: 14, color: "rgba(255,255,255,0.5)" }}>Cupric <span style={{ opacity: 0.4 }}>/</span> Workspace <span style={{ opacity: 0.4 }}>/</span> <span style={{ color: "#fff" }}>Launch</span> <span style={{ fontFamily: MONO, fontSize: 11, marginLeft: 8, padding: "2px 7px", borderRadius: 6, background: "rgba(255,255,255,0.06)" }}>v0.4</span></div>
            <div style={{ marginLeft: "auto", marginRight: "auto", width: 480, height: 34, borderRadius: 10, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", display: "flex", alignItems: "center", padding: "0 12px", gap: 10, fontSize: 14, color: "rgba(255,255,255,0.4)" }}>
              <span style={{ fontFamily: MONO, fontSize: 11, padding: "2px 6px", borderRadius: 5, background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.7)" }}>⌘K</span> Ask Cupric to build anything…
            </div>
            <div style={{ display: "flex" }}>{["#3a3f45", "#50565e", "#2a2e33"].map((c, i) => <div key={i} style={{ width: 28, height: 28, borderRadius: 99, background: c, border: "2px solid #151719", marginLeft: i ? -8 : 0 }} />)}</div>
            <div style={{ height: 32, padding: "0 14px", borderRadius: 9, background: LIME, color: "#0a0a0a", fontSize: 14, fontWeight: 600, display: "flex", alignItems: "center" }}>Deploy</div>
          </div>
          {/* sidebar */}
          <div style={{ ...abs(0, 56, 230, 804), borderRight: "1px solid rgba(255,255,255,0.06)", padding: 16 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 22, ...fly(t, 9.85) }}>
              <Logo size={22} />
              <span style={{ fontWeight: 600, fontSize: 16 }}>Cupric <span style={{ color: LIME }}>AI</span></span>
            </div>
            <div style={{ position: "relative" }}>
              <div style={{ position: "absolute", left: 0, right: 0, top: navActive * 40, height: 34, borderRadius: 9, background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.06)", opacity: prog(t, 9.95, 10.1) }} />
              {nav.map((n, i) => (
                <div key={n} style={{ position: "relative", height: 34, marginBottom: 6, display: "flex", alignItems: "center", gap: 12, padding: "0 10px", fontSize: 14.5, color: Math.round(navActive) === i ? "#fff" : "rgba(255,255,255,0.5)", ...fly(t, 9.88 + i * 0.04, 0.45, -24, 0) }}>
                  <div style={{ width: 14, height: 14, borderRadius: 4, border: `1.5px solid ${Math.round(navActive) === i ? LIME : "rgba(255,255,255,0.35)"}` }} />
                  {n}
                </div>
              ))}
            </div>
          </div>
          {/* code panel */}
          <div style={{ ...abs(230, 56, 420, 768), borderRight: "1px solid rgba(255,255,255,0.06)", background: "rgba(0,0,0,0.25)", ...fly(t, 9.9, 0.5, -30, 0) }}>
            <div style={{ height: 40, display: "flex", alignItems: "center", gap: 6, padding: "0 12px", borderBottom: "1px solid rgba(255,255,255,0.05)", fontSize: 12.5, fontFamily: MONO, color: "rgba(255,255,255,0.45)" }}>
              <span style={{ padding: "4px 10px", borderRadius: 6, background: "rgba(255,255,255,0.06)", color: "#fff" }}>launch.tsx</span>
              <span style={{ padding: "4px 10px" }}>theme.ts</span>
              <span style={{ marginLeft: "auto", color: LIME }}>● live</span>
            </div>
            <div style={{ padding: "16px 0", fontFamily: MONO, fontSize: 13, lineHeight: "22px" }}>
              {CODE.map((segs, i) => {
                const at = 9.95 + i * 0.055;
                const full = segs.map((s) => s[0]).join("");
                let vis = Math.floor(full.length * prog(t, at, at + 0.22));
                const ci = COMPILE.indexOf(i);
                const compiled = ci >= 0 && t > 10.2 + ci * 0.12;
                return (
                  <div key={i} style={{ display: "flex", whiteSpace: "pre", height: 22, background: compiled && t < 10.4 + ci * 0.12 ? `rgba(${LIME_RGB},0.08)` : undefined }}>
                    <span style={{ width: 38, textAlign: "right", paddingRight: 14, color: "rgba(255,255,255,0.2)" }}>{i + 1}</span>
                    <span>
                      {segs.map(([s, c], k) => {
                        const take = Math.max(0, Math.min(s.length, vis));
                        vis -= s.length;
                        return <span key={k} style={{ color: c }}>{s.slice(0, take)}</span>;
                      })}
                    </span>
                    {compiled && <span style={{ marginLeft: "auto", marginRight: 14, color: LIME, fontSize: 11 }}>✓</span>}
                  </div>
                );
              })}
            </div>
          </div>
          {/* canvas */}
          <div style={{ ...abs(670, 76, 870, 740) }}>
            {/* hero */}
            <div style={{ ...abs(slots[0][0], slots[0][1], slots[0][2], slots[0][3]), ...glass, overflow: "hidden", ...cardIn(0) }}>
              <div style={{ position: "absolute", right: -60, top: -80, width: 420, height: 420, borderRadius: 999, background: `radial-gradient(circle at 40% 40%, rgba(${LIME_RGB},0.55), rgba(${LIME_RGB},0.06) 45%, transparent 65%)`, transform: `rotate(${t * 40}deg)` }} />
              <div style={{ position: "absolute", left: 28, top: 26, fontFamily: MONO, fontSize: 11, letterSpacing: "0.14em", color: "rgba(255,255,255,0.45)" }}>HERO · GENERATED</div>
              <div style={{ position: "absolute", left: 28, top: 58, fontSize: 54, fontWeight: 600, letterSpacing: "-0.04em", lineHeight: 1 }}>Launch faster<span style={{ color: LIME }}>.</span></div>
              <div style={{ position: "absolute", left: 28, top: 124, fontSize: 15, color: "rgba(255,255,255,0.5)", width: 420 }}>Ship production-ready interfaces from a single sentence.</div>
              <div style={{ position: "absolute", left: 28, top: 162, display: "flex", gap: 10 }}>
                <div style={{ height: 34, padding: "0 16px", borderRadius: 9, background: "#fff", color: "#000", fontSize: 13.5, fontWeight: 600, display: "flex", alignItems: "center" }}>Start building</div>
                <div style={{ height: 34, padding: "0 16px", borderRadius: 9, border: "1px solid rgba(255,255,255,0.15)", fontSize: 13.5, display: "flex", alignItems: "center", color: "rgba(255,255,255,0.8)" }}>View docs</div>
              </div>
            </div>
            {/* metric */}
            <div style={{ ...abs(slots[1][0], slots[1][1], slots[1][2], slots[1][3]), ...glass, padding: 22, ...cardIn(1) }}>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)" }}>Active builders</div>
              <div style={{ fontSize: 48, fontWeight: 600, letterSpacing: "-0.04em", marginTop: 10 }}>{Math.floor(12480 * eo3(prog(t, 10.35, 11.2))).toLocaleString()}</div>
              <div style={{ display: "inline-flex", marginTop: 8, fontSize: 12.5, fontFamily: MONO, color: LIME, background: `rgba(${LIME_RGB},0.1)`, padding: "3px 8px", borderRadius: 6 }}>▲ 18.4%</div>
            </div>
            {/* chart */}
            <div style={{ ...abs(slots[2][0], slots[2][1], slots[2][2], slots[2][3]), ...glass, padding: 22, ...cardIn(2) }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: "rgba(255,255,255,0.5)" }}><span>Usage</span><span style={{ fontFamily: MONO, fontSize: 11 }}>7D · 30D · <span style={{ color: "#fff" }}>90D</span></span></div>
              <div style={{ marginTop: 18 }}><Spark w={530} h={92} p={eo3(prog(t, 10.5, 11.3))} seed={3} /></div>
            </div>
            {/* feed */}
            <div style={{ ...abs(slots[3][0], slots[3][1], slots[3][2], slots[3][3]), ...glass, padding: 20, ...cardIn(3) }}>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", marginBottom: 14 }}>Agent activity</div>
              {["Generated pricing layout", "Refactored checkout flow", "Wrote 42 unit tests", "Optimized hero assets", "Synced design tokens"].map((s, i) => (
                <div key={s} style={{ display: "flex", alignItems: "center", gap: 12, height: 44, borderTop: i ? "1px solid rgba(255,255,255,0.05)" : undefined, ...fly(t, 10.7 + i * 0.06, 0.4, 20, 0) }}>
                  <div style={{ width: 26, height: 26, borderRadius: 8, background: i === 0 ? `rgba(${LIME_RGB},0.15)` : "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center" }}><div style={{ width: 7, height: 7, borderRadius: 9, background: i === 0 ? LIME : "rgba(255,255,255,0.5)" }} /></div>
                  <span style={{ fontSize: 14 }}>{s}</span>
                  <span style={{ marginLeft: "auto", fontFamily: MONO, fontSize: 11, color: "rgba(255,255,255,0.35)" }}>{i * 2 + 1}s</span>
                </div>
              ))}
            </div>
            {/* toggles */}
            <div style={{ ...abs(slots[4][0], slots[4][1], slots[4][2], slots[4][3]), ...glass, padding: 20, ...cardIn(4) }}>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", marginBottom: 14 }}>Environment</div>
              {["Edge rendering", "Auto-optimize"].map((s, i) => {
                const on = t > 10.9 + i * 0.12;
                return (
                  <div key={s} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 38 }}>
                    <span style={{ fontSize: 14 }}>{s}</span>
                    <div style={{ width: 40, height: 22, borderRadius: 99, background: on ? LIME : "rgba(255,255,255,0.12)", position: "relative" }}>
                      <div style={{ position: "absolute", top: 3, left: on ? 21 : 3, width: 16, height: 16, borderRadius: 99, background: on ? "#0a0a0a" : "#fff" }} />
                    </div>
                  </div>
                );
              })}
            </div>
            {/* deploy ring */}
            <div style={{ ...abs(slots[5][0], slots[5][1], slots[5][2], slots[5][3]), ...glass, padding: 20, display: "flex", alignItems: "center", gap: 20, ...cardIn(5) }}>
              <svg width={92} height={92} viewBox="0 0 100 100">
                <circle cx={50} cy={50} r={40} stroke="rgba(255,255,255,0.08)" strokeWidth={8} fill="none" />
                <circle cx={50} cy={50} r={40} stroke={LIME} strokeWidth={8} fill="none" strokeLinecap="round" pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - eo3(prog(t, 10.85, 11.5)) * 0.94} transform="rotate(-90 50 50)" />
                <text x={50} y={56} textAnchor="middle" fill="#fff" fontSize={18} fontWeight={600}>{Math.round(eo3(prog(t, 10.85, 11.5)) * 94)}%</text>
              </svg>
              <div>
                <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)" }}>Deploying to edge</div>
                <div style={{ fontSize: 22, fontWeight: 600, marginTop: 4 }}>312 regions</div>
              </div>
            </div>
          </div>
          {/* status bar */}
          <div style={{ ...abs(230, 824, 1330, 36), borderTop: "1px solid rgba(255,255,255,0.06)", display: "flex", alignItems: "center", padding: "0 16px", gap: 10, fontFamily: MONO, fontSize: 12, color: "rgba(255,255,255,0.5)", ...fly(t, 9.95, 0.4, 0, 10) }}>
            <div style={{ width: 7, height: 7, borderRadius: 9, background: LIME, boxShadow: `0 0 10px ${LIME}` }} />
            {gen < 6 ? `Generating components ${gen}/6 …` : "6 components generated in 0.9s"}
            <span style={{ marginLeft: "auto" }}>cupric-2 · build</span>
          </div>
        </div>
      </div>
      {/* typography */}
      <div style={{ position: "absolute", left: 130, top: 790, textShadow: "0 20px 80px rgba(0,0,0,0.9)" }}>
        <KText text="BUILD" t={t} at={10.02} out={10.66} inDur={0.5} outDur={0.3} size={220} weight={700} stagger={0.04} />
      </div>
      <Center>
        <div style={{ textShadow: "0 30px 120px rgba(0,0,0,0.8)" }}>
          <KText text="FASTER." t={t} at={10.78} out={11.5} inDur={0.5} outDur={0.5} variant="scale" exit="zoom" size={400} weight={800} stagger={0.025} tracking={-0.055} />
        </div>
      </Center>
      {t > 11.4 && (
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, opacity: Math.min(prog(t, 11.4, 11.6), 1 - prog(t, 11.9, 12.05)) }}>
          {Array.from({ length: 48 }).map((_, i) => {
            const a = (i / 48) * Math.PI * 2 + hash(i) * 0.1;
            const p = ((t - 11.4) * (2 + hash(i + 2) * 2) + hash(i + 4)) % 1;
            const r0 = 100 + p * 900, r1 = r0 + 120 + p * 400;
            return <line key={i} x1={960 + Math.cos(a) * r0} y1={540 + Math.sin(a) * r0} x2={960 + Math.cos(a) * r1} y2={540 + Math.sin(a) * r1} stroke={i % 5 === 0 ? LIME : "#fff"} strokeOpacity={0.5 * p} strokeWidth={1.2} />;
          })}
        </svg>
      )}
      <HudLabel x={80} y={50} text="004 — WORKSPACE / ASSEMBLY" o={Math.min(prog(t, 9.8, 10), 1 - prog(t, 11.3, 11.5))} />
    </>
  );
}

// ============================================================ 12–15 PROMPT → PRODUCT
const PROMPT = "Build something people will remember.";
export function PromptProduct({ t }: { t: number }) {
  if (t < 11.9 || t > 15.1) return null;
  const pin = eoExpo(prog(t, 11.92, 12.4));
  const typed = Math.floor(PROMPT.length * prog(t, 12.35, 13.02));
  const press = t > 13.02 && t < 13.14;
  const m = eioExpo(prog(t, 13.1, 13.45)); // morph input → chip
  const proc = Math.min(prog(t, 13.12, 13.2), 1 - prog(t, 13.52, 13.62));
  const ex = eioExpo(prog(t, 14.8, 15.08));
  const PX = 820, PY = 150, PW = 960, PH = 780;
  const steps = ["Understanding intent", "Composing layout", "Generating assets", "Structuring data"];
  const chipsDef = [
    { w: "Build", to: [70, 240] },
    { w: "something", to: [640, 330] },
    { w: "people", to: [150, 520] },
    { w: "will", to: [120, 440] },
    { w: "remember.", to: [140, 330] },
  ];
  const caret = Math.floor(t * 3) % 2 === 0;
  return (
    <>
      <div
        style={{
          ...abs(PX, PY, PW, PH),
          ...glass,
          borderRadius: 22,
          overflow: "hidden",
          opacity: pin * (1 - ex),
          transform: `scale(${lerp(1.25, 1, pin) * lerp(1, 0.22, ex)}) translate(${ex * -1500}px, 0)`,
          transformOrigin: "50% 50%",
          filter: pin < 0.98 ? `blur(${(1 - pin) * 14}px)` : undefined,
          boxShadow: t > 14.55 ? `0 0 0 1px rgba(${LIME_RGB},${0.4 * (1 - prog(t, 14.6, 15))}), 0 40px 120px rgba(0,0,0,0.6)` : glass.boxShadow,
        }}
      >
        {/* header */}
        <div style={{ ...abs(0, 0, PW, 60), display: "flex", alignItems: "center", padding: "0 24px", gap: 12, borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <Logo size={20} />
          <span style={{ fontSize: 15, fontWeight: 600 }}>New project</span>
          <span style={{ marginLeft: 8, fontFamily: MONO, fontSize: 11.5, color: "rgba(255,255,255,0.6)", padding: "4px 9px", borderRadius: 7, background: "rgba(255,255,255,0.06)" }}>cupric-2 · build mode</span>
          <span style={{ marginLeft: "auto", fontFamily: MONO, fontSize: 11.5, color: t > 13.1 ? LIME : "rgba(255,255,255,0.35)" }}>{t < 13.1 ? "idle" : t < 13.55 ? "thinking…" : t < 14.55 ? "building…" : "ready"}</span>
        </div>
        {/* prompt box / chip */}
        <div
          style={{
            position: "absolute",
            left: lerp(50, 24, m),
            top: lerp(250, 78, m),
            width: lerp(860, 912, m),
            height: lerp(200, 50, m),
            borderRadius: lerp(18, 12, m),
            background: "rgba(255,255,255,0.035)",
            border: `1px solid ${t > 12.3 && t < 13.1 ? "rgba(255,255,255,0.16)" : "rgba(255,255,255,0.08)"}`,
            boxShadow: t > 12.3 && t < 13.1 ? `0 0 0 4px rgba(255,255,255,0.03)` : undefined,
          }}
        >
          <div style={{ position: "absolute", left: lerp(26, 16, m), top: lerp(24, 14, m), fontSize: lerp(30, 15, m), fontWeight: 500, letterSpacing: "-0.02em", color: "#fff", whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 10 }}>
            {m > 0.5 && <span style={{ fontFamily: MONO, fontSize: 11, color: LIME }}>PROMPT</span>}
            <span>
              {t < 12.35 ? <span style={{ color: "rgba(255,255,255,0.3)" }}>Describe what you want to build…</span> : PROMPT.slice(0, typed)}
              {t < 13.1 && t > 12.3 && <span style={{ display: "inline-block", width: 2, height: 32, background: LIME, marginLeft: 3, verticalAlign: "middle", opacity: caret || t < 13 ? 1 : 0 }} />}
            </span>
          </div>
          <div style={{ position: "absolute", left: 22, right: 22, bottom: 18, display: "flex", alignItems: "center", gap: 10, opacity: 1 - m }}>
            {["+ Attach", "◎ Brand kit", "⌘ Context · 12k"].map((s) => <span key={s} style={{ fontSize: 13, color: "rgba(255,255,255,0.55)", padding: "6px 11px", borderRadius: 8, border: "1px solid rgba(255,255,255,0.08)" }}>{s}</span>)}
            <div style={{ marginLeft: "auto", width: 44, height: 44, borderRadius: 99, background: typed >= PROMPT.length ? LIME : "rgba(255,255,255,0.1)", display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${press ? 0.86 : 1})`, boxShadow: press ? `0 0 0 8px rgba(${LIME_RGB},0.2), 0 0 40px rgba(${LIME_RGB},0.6)` : undefined, color: "#0a0a0a", fontSize: 20, fontWeight: 700 }}>↑</div>
          </div>
        </div>
        {/* processing steps */}
        {proc > 0 && (
          <div style={{ position: "absolute", left: 24, top: 160, width: 912, opacity: proc }}>
            {steps.map((s, i) => {
              const at = 13.14 + i * 0.09;
              const done = t > at + 0.08;
              return (
                <div key={s} style={{ height: 52, display: "flex", alignItems: "center", gap: 14, borderBottom: "1px solid rgba(255,255,255,0.05)", ...fly(t, at, 0.3, 0, 12) }}>
                  <div style={{ width: 20, height: 20, borderRadius: 99, border: `1.5px solid ${done ? LIME : "rgba(255,255,255,0.3)"}`, background: done ? LIME : "transparent", color: "#000", fontSize: 12, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800 }}>{done ? "✓" : ""}</div>
                  <span style={{ fontSize: 17, background: done ? undefined : `linear-gradient(90deg, rgba(255,255,255,0.4), #fff, rgba(255,255,255,0.4))`, WebkitBackgroundClip: done ? undefined : "text", color: done ? "#fff" : "transparent", backgroundSize: "200% 100%", backgroundPosition: `${-t * 400}% 0` }}>{s}</span>
                  <span style={{ marginLeft: "auto", fontFamily: MONO, fontSize: 12, color: "rgba(255,255,255,0.35)" }}>{done ? `${(40 + i * 23)}ms` : "…"}</span>
                </div>
              );
            })}
          </div>
        )}
        {/* product */}
        {t > 13.5 && (
          <div style={{ position: "absolute", left: 24, top: 148, width: 912, height: 606 }}>
            <div style={{ position: "absolute", inset: 0, borderRadius: 16, border: "1px solid rgba(255,255,255,0.08)", background: "#0b0c0d", overflow: "hidden", ...fly(t, 13.52, 0.5, 0, 20, 0.97) }}>
              {/* nav */}
              <div style={{ height: 54, display: "flex", alignItems: "center", padding: "0 26px", gap: 26, borderBottom: "1px solid rgba(255,255,255,0.05)", ...fly(t, 13.58, 0.4, 0, -10) }}>
                <span style={{ fontWeight: 700, fontSize: 17, letterSpacing: "-0.02em" }}>◆ Remember</span>
                {["Product", "Stories", "Pricing"].map((s) => <span key={s} style={{ fontSize: 13.5, color: "rgba(255,255,255,0.5)" }}>{s}</span>)}
                <span style={{ marginLeft: "auto", fontSize: 13, padding: "7px 14px", borderRadius: 99, background: "#fff", color: "#000", fontWeight: 600 }}>Get early access</span>
              </div>
              {/* hero */}
              <div style={{ position: "absolute", left: 30, top: 92 }}>
                <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.16em", color: LIME, ...fly(t, 13.66, 0.4) }}>NEW · MEMORY ENGINE</div>
                <div style={{ marginTop: 14, fontSize: 56, fontWeight: 600, letterSpacing: "-0.045em", lineHeight: 0.98 }}>
                  {["Made to be", "remembered."].map((l, i) => (
                    <div key={l} style={{ overflow: "hidden" }}>
                      <div style={{ transform: `translateY(${(1 - eoExpo(prog(t, 13.7 + i * 0.08, 14.2 + i * 0.08))) * 110}%)` }}>{l}</div>
                    </div>
                  ))}
                </div>
                <div style={{ marginTop: 16, width: 380, fontSize: 15, lineHeight: 1.5, color: "rgba(255,255,255,0.5)", ...fly(t, 13.85, 0.5) }}>Experiences people carry with them — designed, generated and shipped in minutes.</div>
                <div style={{ marginTop: 22, display: "flex", gap: 10, ...fly(t, 13.92, 0.5) }}>
                  <span style={{ padding: "11px 18px", borderRadius: 10, background: LIME, color: "#000", fontSize: 14, fontWeight: 600 }}>Start free</span>
                  <span style={{ padding: "11px 18px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.15)", fontSize: 14 }}>Watch film →</span>
                </div>
              </div>
              {/* orb asset */}
              <div style={{ position: "absolute", right: 40, top: 80, width: 300, height: 260, ...fly(t, 13.78, 0.7, 0, 0, 0.6) }}>
                <div style={{ position: "absolute", inset: 0, borderRadius: 20, background: "linear-gradient(135deg, #141618, #0c0d0e)", border: "1px solid rgba(255,255,255,0.06)", overflow: "hidden" }}>
                  <div style={{ position: "absolute", left: 40, top: 20, width: 220, height: 220, borderRadius: 999, background: `conic-gradient(from ${t * 120}deg, rgba(${LIME_RGB},0.9), #1a1d1f, #fff, rgba(${LIME_RGB},0.4), #1a1d1f, rgba(${LIME_RGB},0.9))`, filter: "blur(26px)", opacity: 0.85 }} />
                  <div style={{ position: "absolute", left: 80, top: 60, width: 140, height: 140, borderRadius: 999, background: "radial-gradient(circle at 35% 30%, #fff, rgba(255,255,255,0.1) 40%, transparent 70%)", mixBlendMode: "overlay" }} />
                  <div style={{ position: "absolute", left: 14, bottom: 12, fontFamily: MONO, fontSize: 10.5, color: "rgba(255,255,255,0.6)" }}>asset_01.png · generated</div>
                </div>
              </div>
              {/* stats */}
              {[["98%", "Recall after 30 days"], ["2.4M", "Moments created"], ["12ms", "Median render"]].map(([v, l], k) => (
                <div key={l} style={{ position: "absolute", left: 30 + k * 196, top: 420, width: 182, height: 150, borderRadius: 14, border: "1px solid rgba(255,255,255,0.07)", background: "rgba(255,255,255,0.025)", padding: 18, ...fly(t, 14.0 + k * 0.07, 0.5, 0, 30) }}>
                  <div style={{ fontSize: 36, fontWeight: 600, letterSpacing: "-0.04em", color: k === 0 ? LIME : "#fff" }}>{v}</div>
                  <div style={{ fontSize: 12.5, color: "rgba(255,255,255,0.5)", marginTop: 6 }}>{l}</div>
                  <div style={{ position: "absolute", left: 18, right: 18, bottom: 18, height: 4, borderRadius: 4, background: "rgba(255,255,255,0.06)" }}>
                    <div style={{ height: 4, borderRadius: 4, width: `${eo3(prog(t, 14.1 + k * 0.07, 14.7)) * (60 + k * 13)}%`, background: k === 0 ? LIME : "rgba(255,255,255,0.6)" }} />
                  </div>
                </div>
              ))}
              {/* bars */}
              <div style={{ position: "absolute", right: 40, top: 360, width: 300, height: 210, borderRadius: 14, border: "1px solid rgba(255,255,255,0.07)", background: "rgba(255,255,255,0.025)", padding: 18, ...fly(t, 14.15, 0.5, 30, 0) }}>
                <div style={{ fontSize: 12.5, color: "rgba(255,255,255,0.5)" }}>Engagement</div>
                <div style={{ display: "flex", alignItems: "flex-end", gap: 10, height: 130, marginTop: 20 }}>
                  {[0.4, 0.55, 0.45, 0.7, 0.62, 0.85, 1].map((h, i) => (
                    <div key={i} style={{ flex: 1, borderRadius: 5, height: `${h * 100 * eoExpo(prog(t, 14.2 + i * 0.04, 14.7 + i * 0.04))}%`, background: i === 6 ? LIME : "rgba(255,255,255,0.18)" }} />
                  ))}
                </div>
              </div>
            </div>
            {/* toast */}
            <div style={{ position: "absolute", right: 16, bottom: 16, padding: "10px 14px", borderRadius: 10, background: "rgba(20,22,24,0.95)", border: "1px solid rgba(255,255,255,0.1)", display: "flex", alignItems: "center", gap: 10, fontSize: 13, ...fly(t, 14.55, 0.4, 0, 16) }}>
              <div style={{ width: 8, height: 8, borderRadius: 9, background: LIME, boxShadow: `0 0 10px ${LIME}` }} />
              Deployed · <span style={{ fontFamily: MONO, fontSize: 12, color: "rgba(255,255,255,0.6)" }}>cupric.app/remember</span>
            </div>
          </div>
        )}
        {/* flying word chips */}
        {t > 13.42 && t < 14.1 &&
          chipsDef.map((c, k) => {
            const p = eioExpo(prog(t, 13.45 + k * 0.04, 13.9 + k * 0.04));
            const x0 = 90 + [0, 64, 190, 262, 306][k] * 1.0, y0 = 92;
            const x = lerp(x0, 24 + c.to[0], p), y = lerp(y0, 148 + c.to[1], p);
            return (
              <div key={k} style={{ position: "absolute", left: x, top: y, padding: "6px 12px", borderRadius: 99, border: `1px solid ${LIME}`, background: `rgba(${LIME_RGB},0.12)`, color: LIME, fontSize: 14, fontWeight: 500, whiteSpace: "nowrap", opacity: Math.min(prog(t, 13.45, 13.5), 1 - prog(t, 13.85 + k * 0.04, 14.0 + k * 0.04)), boxShadow: `0 0 24px rgba(${LIME_RGB},0.35)` }}>
                {c.w}
              </div>
            );
          })}
      </div>
      {/* left typography */}
      <div style={{ position: "absolute", left: 130, top: 330, opacity: 1 - ex }}>
        <KText text="FROM" t={t} at={12.2} out={13.5} inDur={0.55} outDur={0.3} size={150} weight={700} stagger={0.04} />
        <div style={{ height: 8 }} />
        <KText text="PROMPT" t={t} at={12.3} out={13.53} inDur={0.55} outDur={0.3} size={150} weight={700} stagger={0.04} />
      </div>
      <div style={{ position: "absolute", left: 130, top: 330, opacity: 1 - ex }}>
        <KText text="TO" t={t} at={13.72} out={14.72} inDur={0.55} outDur={0.3} size={150} weight={700} stagger={0.04} />
        <div style={{ height: 8 }} />
        <KText text="PRODUCT." t={t} at={13.8} out={14.75} inDur={0.55} outDur={0.3} size={150} weight={700} stagger={0.04} />
      </div>
      <HudLabel x={130} y={260} text="005 — PROMPT ⟶ PRODUCT" o={Math.min(prog(t, 12.2, 12.5), 1 - prog(t, 14.6, 14.8))} />
    </>
  );
}

// ============================================================ 15–18 REPETITION → CREATION
const TASKS = ["Resize asset", "Rename files", "Update row", "Export CSV", "Copy spec", "Sync tokens", "Crop image", "Fill form"];
export function Repetition({ t: tRaw }: { t: number }) {
  if (tRaw < 14.95 || tRaw > 18.1) return null;
  const t = Math.min(tRaw, 17.85);
  const fz = prog(tRaw, 17.86, 18.06);
  const cols = 6, rows = 4, ww = 270, wh = 180, g = 20, x0 = 100, y0 = 150;
  const scanX = 2000 * eio3(prog(t, 16.2, 16.6)) - 40;
  const nodes = [
    ["Intent", "prompt.md"], ["Understand", "context · 12k"], ["Generate", "42 components"], ["Refine", "3 passes"], ["Ship", "cupric.app"],
  ];
  const NW = 230, NG = 60, NX = (1920 - (5 * NW + 4 * NG)) / 2, NY = 640;
  const line = eo3(prog(t, 16.55, 17.15));
  const phase = Math.floor(t * 8);
  return (
    <div style={{ position: "absolute", inset: 0, filter: fz > 0 ? `grayscale(1) brightness(${1 - fz})` : undefined }}>
      {Array.from({ length: cols * rows }).map((_, i) => {
        const c = i % cols, r = Math.floor(i / cols);
        const cx = x0 + c * (ww + g), cy = y0 + r * (wh + g);
        const order = Math.hypot(c - 2.5, r - 1.5);
        const at = 15.0 + order * 0.07;
        if (t < at) return null;
        const pop = Math.floor(prog(t, at, at + 0.12) * 3) / 3;
        const jx = t < 16.2 ? (hash(i * 13 + phase) - 0.5) * 12 : 0;
        const jy = t < 16.2 ? Math.round((hash(i * 7 + phase) - 0.5) * 2) * 4 : 0;
        const ts = 16.2 + ((cx + ww / 2) / 1920) * 0.4;
        const col = eioExpo(prog(t, ts, ts + 0.45));
        const k = i % 5;
        const tx = NX + k * (NW + NG) + NW / 2 - (cx + ww / 2);
        const ty = NY + 52 - (cy + wh / 2);
        const pr = Math.floor(((t * 1.6 + hash(i)) % 1) * 6) / 6;
        if (col >= 1) return null;
        return (
          <div key={i} style={{ ...abs(cx, cy, ww, wh), ...glass, borderRadius: 10, opacity: (0.35 + 0.65 * pop) * (1 - col) * 0.8, transform: `translate(${jx + tx * col}px, ${jy + ty * col}px) scale(${(0.92 + 0.08 * pop) * (1 - col * 0.85)})`, overflow: "hidden" }}>
            <div style={{ height: 30, display: "flex", alignItems: "center", gap: 6, padding: "0 10px", borderBottom: "1px solid rgba(255,255,255,0.06)", fontFamily: MONO, fontSize: 10.5, color: "rgba(255,255,255,0.45)" }}>
              {[0, 1, 2].map((d) => <div key={d} style={{ width: 7, height: 7, borderRadius: 9, background: "rgba(255,255,255,0.15)" }} />)}
              <span style={{ marginLeft: 6 }}>{TASKS[i % TASKS.length]}</span>
              <span style={{ marginLeft: "auto" }}>#{(421 + i * 37 + phase) % 9999}</span>
            </div>
            <div style={{ padding: 14 }}>
              <div style={{ height: 8, width: `${50 + hash(i + 1) * 40}%`, borderRadius: 4, background: "rgba(255,255,255,0.12)", marginBottom: 8 }} />
              <div style={{ height: 8, width: `${30 + hash(i + 2) * 40}%`, borderRadius: 4, background: "rgba(255,255,255,0.07)", marginBottom: 22 }} />
              <div style={{ display: "flex", justifyContent: "space-between", fontFamily: MONO, fontSize: 10.5, color: "rgba(255,255,255,0.4)", marginBottom: 6 }}><span>repeat</span><span>{Math.round(pr * 100)}%</span></div>
              <div style={{ height: 6, borderRadius: 3, background: "rgba(255,255,255,0.06)" }}><div style={{ height: 6, width: `${pr * 100}%`, borderRadius: 3, background: "rgba(255,255,255,0.45)" }} /></div>
              <div style={{ marginTop: 14, display: "flex", gap: 6 }}>{[0, 1, 2, 3].map((q) => <div key={q} style={{ flex: 1, height: 18, borderRadius: 4, background: q === phase % 4 ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.05)" }} />)}</div>
            </div>
          </div>
        );
      })}
      {t > 16.15 && t < 16.75 && (
        <div style={{ position: "absolute", top: 0, bottom: 0, left: scanX, width: 3, background: LIME, boxShadow: `0 0 40px 10px rgba(${LIME_RGB},0.6), -120px 0 160px rgba(${LIME_RGB},0.12)` }} />
      )}
      {/* elegant flow */}
      {t > 16.4 && (
        <>
          <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
            <line x1={NX + NW / 2} y1={NY + 52} x2={NX + NW / 2 + (4 * (NW + NG)) * line} y2={NY + 52} stroke={LIME} strokeWidth={1.5} strokeOpacity={0.8} />
            {t > 17.0 && [0, 1, 2].map((k) => {
              const L = 4 * (NW + NG);
              const x = NX + NW / 2 + (((t - 17.0) * 700 + k * (L / 3)) % L);
              return <circle key={k} cx={x} cy={NY + 52} r={4} fill="#f2ffd6" style={{ filter: `drop-shadow(0 0 8px ${LIME})` }} />;
            })}
          </svg>
          {nodes.map(([n, s], k) => {
            const done = t > 16.95 + k * 0.12;
            return (
              <div key={n} style={{ ...abs(NX + k * (NW + NG), NY, NW, 104), ...glass, borderRadius: 16, padding: 18, border: `1px solid ${done ? `rgba(${LIME_RGB},0.45)` : "rgba(255,255,255,0.1)"}`, ...fly(t, 16.42 + k * 0.07, 0.55, 0, 24, 0.9) }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ width: 22, height: 22, borderRadius: 99, background: done ? LIME : "rgba(255,255,255,0.08)", color: "#000", fontSize: 12, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center" }}>{done ? "✓" : k + 1}</div>
                  <span style={{ fontSize: 19, fontWeight: 600, letterSpacing: "-0.02em" }}>{n}</span>
                </div>
                <div style={{ marginTop: 12, fontFamily: MONO, fontSize: 12, color: "rgba(255,255,255,0.45)" }}>{s}</div>
              </div>
            );
          })}
        </>
      )}
      <Center y={-10}>
        <div style={{ textShadow: "0 0 50px #000, 0 0 30px #000" }}>
          <KText text="LESS REPETITION." t={t} at={15.28} out={16.15} inDur={0.3} outDur={0.1} variant="step" exit="fade" size={146} weight={700} stagger={0.03} />
        </div>
      </Center>
      <Center y={-170}>
        <KText text="MORE CREATION." t={t} at={16.62} inDur={0.8} stagger={0.03} variant="blur" exit="none" size={146} weight={600} trackFrom={0.3} />
      </Center>
      <HudLabel x={80} y={70} text={t < 16.2 ? `006 — MANUAL · ${Math.floor(prog(t, 15, 16.2) * 1284).toLocaleString()} REPEATED TASKS` : "006 — AUTOMATED FLOW · 1 PIPELINE"} o={Math.min(prog(t, 15.1, 15.3), 1)} />
    </div>
  );
}

import * as THREE from "three";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { AfterimagePass } from "three/examples/jsm/postprocessing/AfterimagePass.js";
import { ShaderPass } from "three/examples/jsm/postprocessing/ShaderPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { clamp, prog, lerp, eio3, ei3, eo3, eoExpo, mulberry32, W, H } from "./ease";

const V3 = THREE.Vector3;
const N = 14000;
const LIME = new THREE.Color("#B6FF3B");
const WHITE = new THREE.Color("#e9ecef");
export const C2 = new V3(0, 0, -46);
export const C7 = new V3(0, 0, -45);

/** Shared info for the DOM layer (10× glyph baseline) */
export const textInfo = { baseline10: 540 + 230, ready: false };

type Keys = [number, number][];
function kf(t: number, keys: Keys) {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    const [t1, v1] = keys[i];
    if (t < t1) {
      const [t0, v0] = keys[i - 1];
      if (t1 === t0) return v1;
      const p = (t - t0) / (t1 - t0);
      return v0 + (v1 - v0) * (p * p * (3 - 2 * p));
    }
  }
  return keys[keys.length - 1][1];
}

// ---------- keyframed look parameters ----------
const K_OPACITY: Keys = [
  [0, 0], [0.22, 0], [0.5, 0.9], [2.0, 0.75], [3.0, 0.8], [6, 0.7], [8.6, 0.75], [8.95, 1], [9.3, 0], [9.6, 0], [10.4, 0.45], [11.5, 0.45], [11.9, 0.8], [12.4, 0.4],
  [17.84, 0.4], [17.86, 0], [19.28, 0], [19.3, 1], [19.8, 0.75], [24, 0.75], [26.8, 0.7], [27.2, 0.03], [29.9, 0.03], [30.3, 0.55],
  [33.0, 0.6], [33.5, 0.9], [33.9, 0], [34.3, 0], [35.6, 0.42], [37.8, 0.42], [39.2, 0.1], [39.9, 0],
];
const K_SIZE: Keys = [
  [0, 0.05], [3, 0.04], [6, 0.035], [9, 0.05], [9.4, 0.06], [18, 0.06], [18.2, 0.052], [21, 0.04], [24, 0.04], [27, 0.03],
  [30, 0.045], [33, 0.045], [34.2, 0.07], [40, 0.07],
];
const K_BLOOM: Keys = [
  [0, 1.6], [1, 1.1], [3, 1.3], [3.3, 0.8], [6, 0.75], [8.8, 1.2], [9.1, 2.2], [9.5, 0.7], [18, 0.7], [18.3, 0.9],
  [19.3, 1.8], [19.8, 1.0], [22.9, 1.5], [23.3, 1.0], [24, 1.0], [27, 0.9], [30, 1.4], [30.5, 0.65], [33, 0.7], [33.5, 1.4],
  [34, 0.9], [40, 0.9],
];
const K_DAMP: Keys = [
  [0, 0], [2.5, 0], [2.7, 0.75], [3.2, 0.75], [3.6, 0.3], [5.7, 0.3], [6.1, 0.6], [6.5, 0.2], [8.6, 0.2], [8.9, 0.8],
  [9.3, 0], [18, 0], [19.3, 0], [19.35, 0.86], [21, 0.6], [21.5, 0.25], [24, 0.3], [24.2, 0.9], [26.9, 0.85],
  [27.2, 0], [30, 0], [30.1, 0.6], [30.8, 0.3], [33, 0.3], [33.2, 0.85], [33.9, 0], [40, 0],
];
const K_CA: Keys = [
  [0, 0.0], [2.8, 0.002], [3.0, 0.02], [3.4, 0.003], [9.0, 0.003], [9.1, 0.03], [9.4, 0.002], [19.28, 0.002],
  [19.32, 0.05], [19.8, 0.004], [24, 0.004], [24.1, 0.03], [24.4, 0.008], [26.1, 0.008], [26.2, 0.05], [26.5, 0.006],
  [27, 0.002], [30, 0.002], [30.05, 0.025], [30.4, 0.003], [35.15, 0.003], [35.2, 0.012], [35.6, 0.002], [40, 0.002],
];
const K_FOCUS: Keys = [
  [0, 16], [2.5, 6], [3, 8], [6, 12], [9, 11], [9.4, 14], [18, 10], [19.3, 10], [21, 14], [24, 16], [30, 25], [33, 14],
  [34.2, 24], [40, 22],
];
const K_ACCENT: Keys = [
  [0, 0.14], [3, 0.1], [6, 0.12], [9, 0.08], [18, 0.1], [21, 0.12], [24, 0.14], [27, 0.1], [30, 0.08], [33.5, 0.1], [34, 0.2], [40, 0.2],
];
const K_FADE: Keys = [[0, 1], [39.4, 1], [39.93, 0], [40, 0]];

// morph transitions: [start, duration, shape, scatter]
const TRANS: [number, number, string, number][] = [
  [0, 0.01, "origin", 0],
  [0.22, 1.6, "lattice", 2.2],
  [3.0, 1.1, "branches", 4.5],
  [5.85, 1.05, "network", 2.5],
  [8.7, 0.32, "collapse2", 0],
  [9.35, 1.4, "grid", 1.5],
  [18.2, 0.4, "text10", 0],
  [19.3, 1.5, "vortex", 3.5],
  [21.0, 1.2, "clusters", 2],
  [22.4, 1.1, "structure", 1.2],
  [24.0, 0.55, "flow", 5],
  [27.0, 0.4, "origin", 0],
  [29.95, 1.2, "streams", 4],
  [33.05, 0.55, "origin", 0],
  [34.2, 2.0, "ring", 2],
];

// ---------- shaders ----------
const pointsVS = /* glsl */ `
attribute float aRand;
uniform float uSize; uniform float uScale; uniform float uFocus; uniform float uTime;
varying float vRand; varying float vAlpha;
void main(){
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_Position = projectionMatrix * mv;
  float depth = max(0.1, -mv.z);
  float blur = clamp(abs(depth - uFocus) / (uFocus * 0.9), 0.0, 1.0);
  float tw = 0.75 + 0.25 * sin(uTime * 3.0 + aRand * 60.0);
  float k = 1.0 + blur * 2.2;
  float s = uSize * (0.45 + aRand * 1.1) * k;
  float px = s * uScale / depth;
  gl_PointSize = clamp(px, 1.0, 48.0);
  vRand = aRand;
  vAlpha = tw / (k * k) * smoothstep(1.0, 4.0, depth) * clamp(px, 0.0, 1.0) * (48.0 / max(48.0, px)) * (1.0 - smoothstep(30.0, 75.0, depth));
}`;
const pointsFS = /* glsl */ `
uniform vec3 uColA; uniform vec3 uColB; uniform float uOpacity; uniform float uAccent;
varying float vRand; varying float vAlpha;
void main(){
  vec2 c = gl_PointCoord - 0.5; float d = length(c);
  if (d > 0.5) discard;
  float a = smoothstep(0.5, 0.0, d); a *= a;
  vec3 col = mix(uColA, uColB * 1.6, step(1.0 - uAccent, fract(vRand * 7.31)));
  gl_FragColor = vec4(col, a * vAlpha * uOpacity);
}`;
const linesVS = /* glsl */ `
attribute float aBirth; attribute float aTone;
varying float vBirth; varying float vTone; varying float vDepth;
void main(){
  vBirth = aBirth; vTone = aTone;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  vDepth = -mv.z;
  gl_Position = projectionMatrix * mv;
}`;
const linesFS = /* glsl */ `
uniform float uProgress; uniform float uOpacity; uniform float uFar; uniform vec3 uColA; uniform vec3 uColB; uniform float uBase;
varying float vBirth; varying float vTone; varying float vDepth;
void main(){
  float vis = 1.0 - smoothstep(uProgress - 0.015, uProgress, vBirth);
  float head = (1.0 - smoothstep(0.0, 0.07, uProgress - vBirth)) * vis;
  vec3 c = mix(uColA, uColB * 1.4, step(0.8, vTone));
  c += head * vec3(0.9, 1.2, 0.5) * 1.4;
  float fog = 1.0 - smoothstep(uFar * 0.35, uFar, vDepth);
  gl_FragColor = vec4(c, (uBase + head) * vis * uOpacity * fog);
}`;
const finalShader = {
  uniforms: {
    tDiffuse: { value: null },
    uCA: { value: 0 },
    uVig: { value: 0.55 },
    uFade: { value: 1 },
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0);} `,
  fragmentShader: `
    uniform sampler2D tDiffuse; uniform float uCA; uniform float uVig; uniform float uFade; varying vec2 vUv;
    void main(){
      vec2 d = vUv - 0.5; float r = length(d);
      vec2 off = d * uCA * (0.4 + r);
      vec3 c;
      c.r = texture2D(tDiffuse, vUv + off).r;
      c.g = texture2D(tDiffuse, vUv).g;
      c.b = texture2D(tDiffuse, vUv - off).b;
      c *= 1.0 - uVig * smoothstep(0.25, 0.85, r);
      gl_FragColor = vec4(c * uFade, 1.0);
    }`,
};

type LineObj = THREE.LineSegments<THREE.BufferGeometry, THREE.ShaderMaterial>;

function makeLineMat(far = 60, base = 0.35) {
  return new THREE.ShaderMaterial({
    vertexShader: linesVS,
    fragmentShader: linesFS,
    uniforms: {
      uProgress: { value: 0 },
      uOpacity: { value: 0 },
      uFar: { value: far },
      uBase: { value: base },
      uColA: { value: WHITE.clone() },
      uColB: { value: LIME.clone() },
    },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
}
function makeLines(pos: number[], birth: number[], tone: number[], far = 60, base = 0.35): LineObj {
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("aBirth", new THREE.Float32BufferAttribute(birth, 1));
  g.setAttribute("aTone", new THREE.Float32BufferAttribute(tone, 1));
  const l = new THREE.LineSegments(g, makeLineMat(far, base));
  l.frustumCulled = false;
  return l;
}
function edgePairs(geo: THREE.BufferGeometry): number[] {
  const e = new THREE.EdgesGeometry(geo, 1);
  return Array.from(e.attributes.position.array as Float32Array);
}

type Bld = { x: number; z: number; w: number; d: number; h: number; delay: number; cap: boolean };

export class Engine {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(55, W / H, 0.05, 400);
  composer: EffectComposer;
  bloom: UnrealBloomPass;
  after: AfterimagePass;
  final: ShaderPass;
  points: THREE.Points<THREE.BufferGeometry, THREE.ShaderMaterial>;
  pos = new Float32Array(N * 3);
  shapes: Record<string, Float32Array> = {};
  dyn: Record<string, (t: number, o: Float32Array) => void> = {};
  rand = new Float32Array(N);
  dir = new Float32Array(N * 3);
  seed = new Float32Array(N * 4);
  latticeLines!: LineObj;
  branchLines!: LineObj;
  netGroup = new THREE.Group();
  netLines!: LineObj;
  ringLines!: LineObj;
  structLines!: LineObj;
  clusterLines!: LineObj;
  city = new THREE.Group();
  blds: Bld[] = [];
  bMesh!: THREE.InstancedMesh;
  capMesh!: THREE.InstancedMesh;
  panels: THREE.Group[] = [];
  cityShader: { uniforms: Record<string, THREE.IUniform> } | null = null;
  labelAnchors: THREE.Vector3[] = [];
  labels: { x: number; y: number; vis: number }[] = [];
  private tmpM = new THREE.Matrix4();
  private tmpQ = new THREE.Quaternion();
  private tmpS = new V3();
  private tmpP = new V3();
  private lastFov = 0;
  netNodes: THREE.Vector3[] = [];
  netEdges: [number, number][] = [];
  clusterDirs: THREE.Vector3[] = [];
  clusterLocal = new Float32Array(N * 3);
  posCurve!: THREE.CatmullRomCurve3;
  lookCurve!: THREE.CatmullRomCurve3;

  constructor(canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(1);
    this.renderer.setSize(W, H, false);
    this.scene.background = new THREE.Color("#050505");

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

    const rt = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType, samples: 4 });
    this.composer = new EffectComposer(this.renderer, rt);
    this.composer.setPixelRatio(1);
    this.composer.setSize(W, H);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.after = new AfterimagePass(0);
    this.composer.addPass(this.after);
    this.bloom = new UnrealBloomPass(new THREE.Vector2(W, H), 1.0, 0.5, 0.22);
    this.composer.addPass(this.bloom);
    this.final = new ShaderPass(finalShader);
    this.composer.addPass(this.final);
    this.composer.addPass(new OutputPass());

    const rng = mulberry32(1337);
    for (let i = 0; i < N; i++) {
      this.rand[i] = rng();
      const u = rng() * 2 - 1, th = rng() * Math.PI * 2, s = Math.sqrt(1 - u * u);
      this.dir[i * 3] = s * Math.cos(th);
      this.dir[i * 3 + 1] = u;
      this.dir[i * 3 + 2] = s * Math.sin(th);
      for (let k = 0; k < 4; k++) this.seed[i * 4 + k] = rng();
    }

    this.buildShapes(rng);

    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute("aRand", new THREE.BufferAttribute(this.rand, 1));
    const mat = new THREE.ShaderMaterial({
      vertexShader: pointsVS,
      fragmentShader: pointsFS,
      uniforms: {
        uSize: { value: 0.05 },
        uScale: { value: 1000 },
        uFocus: { value: 10 },
        uTime: { value: 0 },
        uColA: { value: WHITE.clone() },
        uColB: { value: LIME.clone() },
        uOpacity: { value: 0 },
        uAccent: { value: 0.1 },
      },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.points = new THREE.Points(g, mat);
    this.points.frustumCulled = false;
    this.scene.add(this.points);

    this.buildLines(rng);
    this.buildCity(rng);
  }

  // ---------------------------------------------------------------- shapes
  private buildShapes(rng: () => number) {
    const S = (name: string) => (this.shapes[name] = new Float32Array(N * 3));
    const set = (a: Float32Array, i: number, x: number, y: number, z: number) => {
      a[i * 3] = x; a[i * 3 + 1] = y; a[i * 3 + 2] = z;
    };
    const sampler = (pairs: number[]) => {
      const ne = pairs.length / 6;
      return (out: THREE.Vector3) => {
        const e = Math.floor(rng() * ne) * 6, u = rng();
        out.set(
          lerp(pairs[e], pairs[e + 3], u),
          lerp(pairs[e + 1], pairs[e + 4], u),
          lerp(pairs[e + 2], pairs[e + 5], u),
        );
        return out;
      };
    };
    const v = new V3();

    // origin & collapse points
    const o = S("origin"), c2 = S("collapse2");
    for (let i = 0; i < N; i++) {
      const r = 0.03 * this.seed[i * 4];
      set(o, i, this.dir[i * 3] * r, this.dir[i * 3 + 1] * r, this.dir[i * 3 + 2] * r);
      set(c2, i, C2.x + this.dir[i * 3] * r, C2.y + this.dir[i * 3 + 1] * r, C2.z + this.dir[i * 3 + 2] * r);
    }

    // lattice: nested polyhedra + dust tunnel
    const ico = sampler(edgePairs(new THREE.IcosahedronGeometry(2.6, 1)));
    const dod = sampler(edgePairs(new THREE.DodecahedronGeometry(4.3, 0).rotateY(0.4).rotateX(0.3)));
    const oct = sampler(edgePairs(new THREE.OctahedronGeometry(1.2, 0)));
    const lat = S("lattice");
    for (let i = 0; i < N; i++) {
      const r = this.rand[i];
      if (r < 0.32) ico(v);
      else if (r < 0.52) dod(v);
      else if (r < 0.6) oct(v);
      else {
        const a = rng() * Math.PI * 2, rad = 1.8 + Math.pow(rng(), 0.7) * 11;
        v.set(Math.cos(a) * rad, Math.sin(a) * rad, 12 - rng() * 60);
      }
      set(lat, i, v.x, v.y, v.z);
    }

    // branches: recursive growth along -z
    const paths: { pts: THREE.Vector3[]; b0: number; b1: number }[] = [];
    const grow = (p: THREE.Vector3, d: THREE.Vector3, len: number, depth: number, b0: number) => {
      const pts = [p.clone()];
      const cur = p.clone(), dd = d.clone();
      const steps = 10;
      for (let s = 0; s < steps; s++) {
        dd.add(new V3((rng() - 0.5) * 0.12, (rng() - 0.5) * 0.12, 0)).normalize();
        cur.addScaledVector(dd, len / steps);
        pts.push(cur.clone());
      }
      const b1 = b0 + len;
      paths.push({ pts, b0, b1 });
      if (depth < 6) {
        const kids = rng() < 0.3 ? 3 : 2;
        for (let k = 0; k < kids; k++) {
          const nd = dd.clone().add(new V3((rng() - 0.5) * 0.9, (rng() - 0.5) * 0.9, 0)).normalize();
          grow(cur, nd, len * (0.72 + rng() * 0.15), depth + 1, b1);
        }
      }
    };
    for (let r = 0; r < 3; r++) {
      const a = (r / 3) * Math.PI * 2;
      grow(new V3(Math.cos(a) * 0.3, Math.sin(a) * 0.3, -2), new V3(Math.cos(a) * 0.25, Math.sin(a) * 0.25, -1).normalize(), 7, 0, 0);
    }
    const maxB = Math.max(...paths.map((p) => p.b1));
    const br = S("branches");
    const bl: number[] = [], bb: number[] = [], bt: number[] = [];
    paths.forEach((p) => {
      const tone = rng();
      for (let s = 0; s < p.pts.length - 1; s++) {
        const a = p.pts[s], b = p.pts[s + 1];
        bl.push(a.x, a.y, a.z, b.x, b.y, b.z);
        const f0 = lerp(p.b0, p.b1, s / (p.pts.length - 1)) / maxB;
        const f1 = lerp(p.b0, p.b1, (s + 1) / (p.pts.length - 1)) / maxB;
        bb.push(f0, f1);
        bt.push(tone, tone);
      }
    });
    for (let i = 0; i < N; i++) {
      const p = paths[Math.floor(rng() * paths.length)];
      const s = Math.floor(rng() * (p.pts.length - 1)), u = rng();
      v.copy(p.pts[s]).lerp(p.pts[s + 1], u);
      const j = this.seed[i * 4 + 1] < 0.8 ? 0.06 : 0.6;
      set(br, i, v.x + this.dir[i * 3] * j, v.y + this.dir[i * 3 + 1] * j, v.z + this.dir[i * 3 + 2] * j);
    }
    this.branchPairs = { bl, bb, bt };

    // network
    const nodes: THREE.Vector3[] = [];
    while (nodes.length < 72) {
      const p = new V3((rng() - 0.5) * 15, (rng() - 0.5) * 9, (rng() - 0.5) * 12);
      if (p.x * p.x / 56 + p.y * p.y / 20 + p.z * p.z / 36 > 1) continue;
      if (nodes.some((n) => n.distanceTo(p) < 1.5)) continue;
      nodes.push(p);
    }
    const edges: [number, number][] = [];
    nodes.forEach((n, i) => {
      const near = nodes.map((m, j) => [j, m.distanceTo(n)] as [number, number]).filter((x) => x[0] !== i).sort((a, b) => a[1] - b[1]);
      for (let k = 0; k < 3; k++) {
        const j = near[k][0];
        if (!edges.some((e) => (e[0] === i && e[1] === j) || (e[0] === j && e[1] === i))) edges.push([i, j]);
      }
    });
    this.netNodes = nodes;
    this.netEdges = edges;
    const net = S("network");
    for (let i = 0; i < N; i++) {
      const cls = i % 20;
      if (cls < 9) {
        const n = nodes[Math.floor(Math.pow(this.seed[i * 4], 1.6) * nodes.length)];
        const r = 0.08 + Math.pow(this.seed[i * 4 + 1], 3) * 0.45;
        set(net, i, C2.x + n.x + this.dir[i * 3] * r, C2.y + n.y + this.dir[i * 3 + 1] * r, C2.z + n.z + this.dir[i * 3 + 2] * r);
      } else if (cls >= 17) {
        const r = 9 + this.seed[i * 4 + 2] * 14;
        set(net, i, C2.x + this.dir[i * 3] * r, C2.y + this.dir[i * 3 + 1] * r * 0.6, C2.z + this.dir[i * 3 + 2] * r);
      }
    }
    this.dyn.network = (t, out) => {
      for (let i = 0; i < N; i++) {
        const cls = i % 20;
        if (cls < 9 || cls >= 17) continue;
        const e = edges[Math.floor(this.seed[i * 4] * edges.length)];
        const a = nodes[e[0]], b = nodes[e[1]];
        const u = (this.seed[i * 4 + 1] + t * (0.18 + this.seed[i * 4 + 2] * 0.3)) % 1;
        const j = 0.03;
        out[i * 3] = C2.x + lerp(a.x, b.x, u) + this.dir[i * 3] * j;
        out[i * 3 + 1] = C2.y + lerp(a.y, b.y, u) + this.dir[i * 3 + 1] * j;
        out[i * 3 + 2] = C2.z + lerp(a.z, b.z, u) + this.dir[i * 3 + 2] * j;
      }
    };
    // copy static into both (dyn overwrites the flow subset)
    // grid floor (UI backdrop)
    S("grid");
    this.dyn.grid = (tt, out) => {
      const t = Math.min(tt, 17.85);
      const cols = 140;
      for (let i = 0; i < N; i++) {
        const c = i % cols, r = Math.floor(i / cols);
        const x = (c / (cols - 1) - 0.5) * 90;
        const z = 8 - r * 0.72;
        const y = -3.4 + 0.45 * Math.sin(x * 0.22 + t * 1.1) * Math.cos(z * 0.18 + t * 0.7) + 0.25 * Math.sin(x * 0.05 - z * 0.08 + t * 0.5);
        out[i * 3] = x; out[i * 3 + 1] = y; out[i * 3 + 2] = z;
      }
    };
    // text10 filled later
    S("text10");
    // vortex
    S("vortex");
    this.dyn.vortex = (t, out) => {
      for (let i = 0; i < N; i++) {
        const r = 1.4 + Math.pow(this.seed[i * 4 + 1], 1.2) * 7;
        const a = this.seed[i * 4] * Math.PI * 2 + (t - 19.3) * (0.4 + 2.2 / r);
        out[i * 3] = Math.cos(a) * r;
        out[i * 3 + 1] = Math.sin(a) * r;
        out[i * 3 + 2] = 6 - this.seed[i * 4 + 2] * 62;
      }
    };
    // clusters
    const cDirs = [
      new V3(1, 0.3, 0.2), new V3(-1, -0.2, 0.3), new V3(0.2, 1, -0.3), new V3(-0.3, -1, -0.2), new V3(0.5, -0.4, 1), new V3(-0.4, 0.5, -1),
    ].map((d) => d.normalize());
    this.clusterDirs = cDirs;
    const cico = sampler(edgePairs(new THREE.IcosahedronGeometry(1.25, 1)));
    for (let i = 0; i < N; i++) {
      if (this.seed[i * 4 + 3] < 0.75) cico(v);
      else v.set(this.dir[i * 3], this.dir[i * 3 + 1], this.dir[i * 3 + 2]).multiplyScalar(0.35 * this.seed[i * 4]);
      set(this.clusterLocal, i, v.x, v.y, v.z);
    }
    S("clusters");
    this.dyn.clusters = (t, out) => {
      for (let i = 0; i < N; i++) {
        const k = i % 6;
        const c = this.clusterCenter(k, t);
        const lx = this.clusterLocal[i * 3], ly = this.clusterLocal[i * 3 + 1], lz = this.clusterLocal[i * 3 + 2];
        const a = t * (0.6 + k * 0.1) + k;
        const ca = Math.cos(a), sa = Math.sin(a);
        out[i * 3] = c.x + lx * ca - lz * sa;
        out[i * 3 + 1] = c.y + ly;
        out[i * 3 + 2] = c.z + lx * sa + lz * ca;
      }
    };
    // structure
    const sBig = sampler(edgePairs(new THREE.IcosahedronGeometry(4.8, 2)));
    const sMid = sampler(edgePairs(new THREE.IcosahedronGeometry(2.4, 1).rotateY(0.5)));
    const st = S("structure");
    for (let i = 0; i < N; i++) {
      const r = this.rand[i];
      if (r < 0.6) sBig(v);
      else if (r < 0.88) sMid(v);
      else v.set(this.dir[i * 3], this.dir[i * 3 + 1], this.dir[i * 3 + 2]).multiplyScalar(7 + this.seed[i * 4] * 10);
      set(st, i, v.x, v.y, v.z);
    }
    const stBase = st.slice();
    this.dyn.structure = (t, out) => {
      const a = (t - 22) * 0.18, ca = Math.cos(a), sa = Math.sin(a);
      for (let i = 0; i < N; i++) {
        const x = stBase[i * 3], y = stBase[i * 3 + 1], z = stBase[i * 3 + 2];
        out[i * 3] = C7.x + x * ca + z * sa;
        out[i * 3 + 1] = C7.y + y;
        out[i * 3 + 2] = C7.z - x * sa + z * ca;
      }
    };
    // flow (kinetic type field)
    S("flow");
    this.dyn.flow = (t, out) => {
      for (let i = 0; i < N; i++) {
        const sp = 8 + this.seed[i * 4] * 34;
        const x = ((this.seed[i * 4 + 1] * 80 + (t - 24) * sp) % 80) - 40;
        out[i * 3] = x;
        out[i * 3 + 1] = (this.seed[i * 4 + 2] - 0.5) * 26 + Math.sin(x * 0.1 + i) * 0.4;
        out[i * 3 + 2] = -28 + this.seed[i * 4 + 3] * 32;
      }
    };
    // streams (city data)
    S("streams");
    this.dyn.streams = (t, out) => {
      for (let i = 0; i < N; i++) {
        const s0 = this.seed[i * 4], s1 = this.seed[i * 4 + 1], s2 = this.seed[i * 4 + 2];
        const lane = (Math.floor(s0 * 11) - 5) * 5 * 2.4 + 1.2;
        if (i % 3 !== 2) {
          const zz = ((s1 * 70 + (t - 30) * (6 + s2 * 18)) % 70) - 50;
          const along = i % 2 === 0;
          out[i * 3] = along ? lane + (s2 - 0.5) * 0.5 : zz + 10;
          out[i * 3 + 1] = 0.12 + s2 * 0.3;
          out[i * 3 + 2] = along ? zz : lane + (s2 - 0.5) * 0.5;
        } else {
          const lane2 = (Math.floor(s2 * 11) - 5) * 5 * 2.4 + 1.2;
          out[i * 3] = lane + (s1 - 0.5) * 0.2;
          out[i * 3 + 1] = ((s1 * 30 + (t - 30) * (2 + s0 * 5)) % 30);
          out[i * 3 + 2] = lane2;
        }
      }
    };
    // ring
    S("ring");
    this.dyn.ring = (t, out) => {
      for (let i = 0; i < N; i++) {
        const r = 6 + Math.pow(this.seed[i * 4 + 1], 0.6) * 24;
        const a = this.seed[i * 4] * Math.PI * 2 + t * 0.35 / Math.sqrt(r);
        out[i * 3] = Math.cos(a) * r;
        out[i * 3 + 1] = (this.seed[i * 4 + 2] - 0.5) * 0.9 * (r / 12) - 1.5;
        out[i * 3 + 2] = Math.sin(a) * r - 6;
      }
    };
  }
  branchPairs = { bl: [] as number[], bb: [] as number[], bt: [] as number[] };

  clusterCenter(k: number, t: number) {
    const p = eio3(prog(t, 21.0, 22.5));
    const d = lerp(12, 3.2, p);
    const dir = this.clusterDirs[k];
    return this.tmpP.set(C7.x + dir.x * d, C7.y + dir.y * d * 0.8, C7.z + dir.z * d);
  }

  /** sample the "10×" glyphs into particle targets */
  setText10() {
    const cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    const ctx = cv.getContext("2d")!;
    ctx.fillStyle = "#fff";
    ctx.font = '700 640px "Inter Tight", Inter, system-ui, sans-serif';
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    try { (ctx as unknown as { letterSpacing: string }).letterSpacing = "-38px"; } catch { /* noop */ }
    const m = ctx.measureText("10×");
    const asc = m.actualBoundingBoxAscent, desc = m.actualBoundingBoxDescent;
    const base = H / 2 + (asc - desc) / 2;
    textInfo.baseline10 = base;
    ctx.fillText("10×", W / 2, base);
    const data = ctx.getImageData(0, 0, W, H).data;
    const px: number[] = [];
    for (let y = 0; y < H; y += 3) for (let x = 0; x < W; x += 3) if (data[(y * W + x) * 4 + 3] > 128) px.push(x, y);
    const vh = 2 * 10 * Math.tan(THREE.MathUtils.degToRad(25));
    const vw = vh * (W / H);
    const out = this.shapes.text10;
    const cnt = px.length / 2;
    for (let i = 0; i < N; i++) {
      const k = Math.floor(this.seed[i * 4 + 3] * cnt) * 2;
      out[i * 3] = ((px[k] + this.seed[i * 4] * 3) / W - 0.5) * vw;
      out[i * 3 + 1] = -((px[k + 1] + this.seed[i * 4 + 1] * 3) / H - 0.5) * vh;
      out[i * 3 + 2] = (this.seed[i * 4 + 2] - 0.5) * 0.15;
    }
    textInfo.ready = true;
  }

  // ---------------------------------------------------------------- lines
  private buildLines(rng: () => number) {
    // lattice
    const lp = [
      ...edgePairs(new THREE.IcosahedronGeometry(2.6, 1)),
      ...edgePairs(new THREE.DodecahedronGeometry(4.3, 0).rotateY(0.4).rotateX(0.3)),
      ...edgePairs(new THREE.OctahedronGeometry(1.2, 0)),
    ];
    const lb: number[] = [], lt: number[] = [];
    for (let i = 0; i < lp.length / 6; i++) {
      const b = clamp((lp[i * 6 + 1] + 4.5) / 9) * 0.8 + rng() * 0.2;
      lb.push(b, b);
      const tn = rng();
      lt.push(tn, tn);
    }
    this.latticeLines = makeLines(lp, lb, lt, 40, 0.3);
    this.scene.add(this.latticeLines);

    const { bl, bb, bt } = this.branchPairs;
    this.branchLines = makeLines(bl, bb, bt, 45, 0.4);
    this.scene.add(this.branchLines);

    // network
    const np: number[] = [], nb: number[] = [], nt: number[] = [];
    this.netEdges.forEach(([a, b]) => {
      const A = this.netNodes[a], B = this.netNodes[b];
      np.push(A.x, A.y, A.z, B.x, B.y, B.z);
      const r = rng() * 0.8;
      nb.push(r, r + 0.2);
      const tn = rng();
      nt.push(tn, tn);
    });
    this.netLines = makeLines(np, nb, nt, 40, 0.28);
    const rp: number[] = [], rb: number[] = [], rt: number[] = [];
    const rings = [
      [9.5, 0.3, 0], [7.2, -0.5, 0.7], [11.5, 1.2, 0.2],
    ];
    rings.forEach(([R, tx, tz], ri) => {
      const e = new THREE.Euler(tx, 0, tz);
      const seg = 160;
      for (let s = 0; s < seg; s++) {
        const a0 = (s / seg) * Math.PI * 2, a1 = ((s + 1) / seg) * Math.PI * 2;
        const p0 = new V3(Math.cos(a0) * R, 0, Math.sin(a0) * R).applyEuler(e);
        const p1 = new V3(Math.cos(a1) * R, 0, Math.sin(a1) * R).applyEuler(e);
        if (s % 8 > 5) continue;
        rp.push(p0.x, p0.y, p0.z, p1.x, p1.y, p1.z);
        rb.push(s / seg, (s + 1) / seg);
        rt.push(ri === 1 ? 0.9 : 0.1, ri === 1 ? 0.9 : 0.1);
      }
    });
    this.ringLines = makeLines(rp, rb, rt, 40, 0.25);
    this.netGroup.add(this.netLines, this.ringLines);
    this.netGroup.position.copy(C2);
    this.scene.add(this.netGroup);

    // structure
    const sp = [...edgePairs(new THREE.IcosahedronGeometry(4.8, 2)), ...edgePairs(new THREE.IcosahedronGeometry(2.4, 1).rotateY(0.5))];
    const sb: number[] = [], stt: number[] = [];
    for (let i = 0; i < sp.length / 6; i++) {
      const b0 = clamp((sp[i * 6 + 1] + 5) / 10) * 0.75 + rng() * 0.25;
      const b1 = clamp((sp[i * 6 + 4] + 5) / 10) * 0.75 + rng() * 0.05 + 0.02;
      sb.push(b0, Math.max(b0, b1));
      const tn = rng();
      stt.push(tn, tn);
    }
    this.structLines = makeLines(sp, sb, stt, 50, 0.3);
    this.structLines.position.copy(C7);
    this.scene.add(this.structLines);

    // clusters (dynamic): 15 pairs
    const cp = new Array(15 * 6).fill(0), cb: number[] = [], ct: number[] = [];
    for (let i = 0; i < 15; i++) { cb.push(0, 1); ct.push(0.9, 0.9); }
    this.clusterLines = makeLines(cp, cb, ct, 60, 0.5);
    this.scene.add(this.clusterLines);
  }

  // ---------------------------------------------------------------- city
  private buildCity(rng: () => number) {
    const geo = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0);
    const mat = new THREE.MeshStandardMaterial({ color: 0x0b0d0f, metalness: 0.9, roughness: 0.3, envMapIntensity: 0.16 });
    mat.onBeforeCompile = (sh) => {
      sh.uniforms.uGlow = { value: 1 };
      sh.uniforms.uScan = { value: 0 };
      this.cityShader = sh as unknown as { uniforms: Record<string, THREE.IUniform> };
      sh.vertexShader = sh.vertexShader
        .replace("#include <common>", "#include <common>\nvarying vec3 vWP; varying float vUp;")
        .replace("#include <project_vertex>", "#include <project_vertex>\nvWP = (modelMatrix * instanceMatrix * vec4(transformed,1.0)).xyz; vUp = abs(normal.y);");
      sh.fragmentShader = sh.fragmentShader
        .replace("#include <common>", "#include <common>\nvarying vec3 vWP; varying float vUp; uniform float uGlow; uniform float uScan;")
        .replace(
          "#include <dithering_fragment>",
          `#include <dithering_fragment>
          float band = step(0.9, fract(vWP.y * 1.8)) * (1.0 - step(0.5, vUp));
          float cell = fract(sin(dot(floor(vWP.xz * 0.9) + floor(vWP.y * 1.8), vec2(12.9898, 78.233))) * 43758.5453);
          vec3 wc = mix(vec3(0.8), vec3(0.71, 1.0, 0.23) * 1.6, step(0.9, cell));
          float scan = exp(-abs(vWP.y - uScan) * 3.0) * (1.0 - step(0.5, vUp));
          gl_FragColor.rgb += band * wc * 0.14 * step(0.72, cell) * uGlow + scan * vec3(0.71, 1.0, 0.23) * 0.22 * uGlow;`,
        );
    };
    const blds: Bld[] = [];
    const maxD = 13 * 2.4 * 1.414;
    for (let i = -13; i < 13; i++)
      for (let j = -16; j < 10; j++) {
        if (((i % 5) + 5) % 5 === 0 || ((j % 5) + 5) % 5 === 0) continue;
        const x = (i + 0.5) * 2.4, z = (j + 0.5) * 2.4;
        const d = Math.hypot(x, z) / maxD;
        let h = (0.6 + Math.pow(rng(), 3) * 11) * (1.25 - d * 0.75);
        if (rng() < 0.05) h *= 1.9;
        blds.push({ x, z, w: 1.4 + rng() * 0.6, d: 1.4 + rng() * 0.6, h, delay: d * 1.3 + rng() * 0.25, cap: rng() < 0.07 });
      }
    this.blds = blds;
    this.bMesh = new THREE.InstancedMesh(geo, mat, blds.length);
    this.capMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 0.05, 1), new THREE.MeshBasicMaterial({ color: 0xffffff }), blds.length);
    const col = new THREE.Color();
    blds.forEach((b, i) => {
      if (b.cap) col.setRGB(0.47 * 1.1, 1 * 1.1, 0.04 * 1.1);
      else col.setRGB(0.05, 0.055, 0.06);
      this.capMesh.setColorAt(i, col);
    });
    this.bMesh.frustumCulled = false;
    this.capMesh.frustumCulled = false;
    this.city.add(this.bMesh, this.capMesh);

    const grid = new THREE.GridHelper(160, 66, 0x3a4a22, 0x1a1c1f);
    (grid.material as THREE.Material).transparent = true;
    (grid.material as THREE.Material).opacity = 0.5;
    this.city.add(grid);

    // floating information panels
    const pdefs = [
      [-9, 11, -6, 0.3], [10, 13, -14, -0.4], [2, 16, -24, 0.1], [-12, 9, -26, 0.5], [13, 8, 2, -0.6],
    ];
    pdefs.forEach(([x, y, z, ry]) => {
      const g = new THREE.Group();
      const plane = new THREE.Mesh(
        new THREE.PlaneGeometry(7, 4),
        new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.04, side: THREE.DoubleSide, depthWrite: false }),
      );
      const edges = new THREE.LineSegments(
        new THREE.EdgesGeometry(new THREE.PlaneGeometry(7, 4)),
        new THREE.LineBasicMaterial({ color: new THREE.Color(0.7, 1.0, 0.25), transparent: true, opacity: 0.55 }),
      );
      const gp: THREE.Vector3[] = [];
      for (let k = 0; k <= 30; k++) gp.push(new V3(-3 + k * 0.2, -1.2 + Math.sin(k * 0.5 + x) * 0.5 + k * 0.05, 0.01));
      const graph = new THREE.Line(new THREE.BufferGeometry().setFromPoints(gp), new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8 }));
      for (let k = 0; k < 6; k++) {
        const bar = new THREE.Mesh(
          new THREE.PlaneGeometry(0.35, 1),
          new THREE.MeshBasicMaterial({ color: k === 4 ? new THREE.Color(0.7, 1, 0.25).multiplyScalar(1.4) : 0x666a70, transparent: true, opacity: 0.7 }),
        );
        const hh = 0.4 + ((k * 37 + x * 3) % 10) / 10 * 1.4;
        bar.scale.y = hh;
        bar.position.set(1.2 + k * 0.4, 1.6 - hh / 2 - 0.2, 0.01);
        g.add(bar);
      }
      g.add(plane, edges, graph);
      g.position.set(x, y, z);
      g.rotation.y = ry;
      this.panels.push(g);
      this.city.add(g);
    });

    // lights
    const dl = new THREE.DirectionalLight(0xffffff, 0.9);
    dl.position.set(20, 30, 10);
    const pl = new THREE.PointLight(0xe8ffd0, 18, 60, 1.5);
    pl.position.set(0, 12, -8);
    this.city.add(dl, pl, new THREE.AmbientLight(0xffffff, 0.08));

    // label anchors: tallest buildings
    const tall = [...blds].sort((a, b) => b.h - a.h).slice(0, 3);
    this.labelAnchors = tall.map((b) => new V3(b.x, b.h + 0.4, b.z));
    this.labelAnchors.push(new V3(10, 15.2, -14));
    this.labels = this.labelAnchors.map(() => ({ x: 0, y: 0, vis: 0 }));

    this.posCurve = new THREE.CatmullRomCurve3([new V3(24, 32, 50), new V3(10, 14, 28), new V3(1.2, 5.5, 8), new V3(1.2, 3.4, -16)]);
    this.lookCurve = new THREE.CatmullRomCurve3([new V3(0, 0, 0), new V3(0, 2, -2), new V3(1.2, 3.5, -12), new V3(1.2, 3, -42)]);
    this.scene.add(this.city);
  }

  // ---------------------------------------------------------------- camera
  private cameraAt(t: number) {
    const pos = new V3(), look = new V3();
    let fov = 55, roll = 0;
    if (t < 3) {
      const z = t < 2.55 ? lerp(18, 6.5, eio3(t / 2.55)) : lerp(6.5, -6, ei3(prog(t, 2.55, 3)));
      const f = 1 - t / 3;
      pos.set(Math.sin(t * 0.9) * 1.4 * f, 0.6 * Math.cos(t * 0.7) * f, z);
      look.set(0, 0, z - 12);
      roll = 0.06 * Math.sin(t * 1.3) * f;
    } else if (t < 6) {
      const p = (t - 3) / 3;
      const z = -6 - 28 * (1 - Math.pow(1 - p, 1.6));
      pos.set(Math.sin(p * Math.PI * 2) * 1.5, Math.sin(p * Math.PI * 2) * 0.8, z);
      look.set(pos.x * 0.4, pos.y * 0.4, z - 12);
      roll = Math.sin(p * Math.PI * 2) * 0.1;
    } else if (t < 9) {
      const p = (t - 6) / 3;
      const a = 1.25 * p + 0.15 * eio3(p);
      const r = 12 - 3 * eio3(p) - 4 * ei3(prog(t, 8.6, 9));
      pos.set(C2.x + Math.sin(a) * r, C2.y + 2.5 * Math.sin(p * Math.PI * 0.8), C2.z + Math.cos(a) * r);
      look.copy(C2);
      roll = -0.05 * Math.sin(p * Math.PI);
    } else if (t < 17.95) {
      pos.set(Math.sin(t * 0.25) * 2.5, 3 + Math.sin(t * 0.3) * 0.5, 14);
      look.set(0, -1.5, -10);
      fov = 50;
    } else if (t < 21) {
      const p = eio3(prog(t, 19.3, 21));
      const z = 10 - 38 * p;
      pos.set(0, 0, z);
      look.set(0, 0, z - 10);
      roll = Math.sin(p * Math.PI) * 0.5;
      fov = 50;
    } else if (t < 24) {
      const p = (t - 21) / 3;
      const a = 0.9 * eio3(p) + 0.1 * p;
      const r = 17 - 4 * eo3(p);
      pos.set(C7.x + Math.sin(a) * r, C7.y + 2.2 * Math.sin(p * Math.PI * 0.5), C7.z + Math.cos(a) * r);
      look.copy(C7);
      fov = 50;
    } else if (t < 27) {
      pos.set(0, 0, 16 - (t - 24) * 1.5);
      look.set(0, 0, 0);
      roll = 0.04 * Math.sin(t * 3);
    } else if (t < 30) {
      pos.set(0, 0, 20);
      look.set(0, 0, 0);
    } else if (t < 33) {
      const x = (t - 30) / 3;
      const p = x * 0.55 + eio3(x) * 0.45;
      pos.copy(this.posCurve.getPoint(p));
      look.copy(this.lookCurve.getPoint(p));
      roll = Math.sin(x * Math.PI) * -0.06;
      fov = 58;
    } else if (t < 34.2) {
      const p = eio3(prog(t, 33, 33.7));
      pos.copy(this.posCurve.getPoint(1)).lerp(new V3(0, 12, 46), p);
      look.copy(this.lookCurve.getPoint(1)).lerp(new V3(0, 0, 0), p);
      fov = 58;
    } else {
      const u = t - 34.2;
      pos.set(Math.sin(u * 0.08) * 3, 2.5 - u * 0.06, 24 - u * 0.45);
      look.set(0, -0.5, -6);
      fov = 45;
    }
    // subtle impact shake
    const impacts = [0.25, 3.0, 9.0, 18.25, 19.3, 22.9, 26.2, 30.0, 35.2];
    let sh = 0;
    for (const ti of impacts) if (t >= ti && t < ti + 0.6) sh += Math.exp(-(t - ti) * 9) * 0.08;
    if (sh > 0) {
      pos.x += Math.sin(t * 91) * sh;
      pos.y += Math.cos(t * 77) * sh;
    }
    return { pos, look, fov, roll };
  }

  // ---------------------------------------------------------------- update
  update(t: number) {
    const cam = this.cameraAt(t);
    this.camera.position.copy(cam.pos);
    this.camera.up.set(Math.sin(cam.roll), Math.cos(cam.roll), 0);
    this.camera.lookAt(cam.look);
    if (cam.fov !== this.lastFov) {
      this.camera.fov = cam.fov;
      this.camera.updateProjectionMatrix();
      this.lastFov = cam.fov;
    }
    this.camera.updateMatrixWorld();

    // particles morph
    let ci = 0;
    for (let i = 0; i < TRANS.length; i++) if (TRANS[i][0] <= t) ci = i;
    const cur = TRANS[ci];
    const prev = TRANS[Math.max(0, ci - 1)];
    const A = this.shapes[prev[2]], B = this.shapes[cur[2]];
    const p = clamp((t - cur[0]) / cur[1]);
    if (p < 1 && this.dyn[prev[2]]) this.dyn[prev[2]](t, A);
    if (this.dyn[cur[2]]) this.dyn[cur[2]](t, B);
    const scat = cur[3];
    const pos = this.pos;
    const amb = 0.02;
    for (let i = 0; i < N; i++) {
      const r = this.rand[i];
      const pi = clamp((p - r * 0.28) / 0.72);
      const e = pi * pi * (3 - 2 * pi);
      const s = scat * Math.sin(pi * Math.PI) * (0.4 + this.seed[i * 4 + 2]);
      const i3 = i * 3;
      const w = Math.sin(t * 1.3 + r * 40) * amb;
      pos[i3] = A[i3] + (B[i3] - A[i3]) * e + this.dir[i3] * (s + w);
      pos[i3 + 1] = A[i3 + 1] + (B[i3 + 1] - A[i3 + 1]) * e + this.dir[i3 + 1] * (s + w);
      pos[i3 + 2] = A[i3 + 2] + (B[i3 + 2] - A[i3 + 2]) * e + this.dir[i3 + 2] * (s + w);
    }
    this.points.geometry.attributes.position.needsUpdate = true;
    const pu = this.points.material.uniforms;
    pu.uOpacity.value = kf(t, K_OPACITY);
    pu.uSize.value = kf(t, K_SIZE);
    pu.uFocus.value = kf(t, K_FOCUS);
    pu.uAccent.value = kf(t, K_ACCENT);
    pu.uTime.value = t;
    pu.uScale.value = H / (2 * Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2)));

    // lattice lines
    const LL = this.latticeLines.material.uniforms;
    LL.uProgress.value = eo3(prog(t, 0.35, 1.9)) * 1.05;
    LL.uOpacity.value = t < 3 ? 1 : 1 - prog(t, 3, 3.4);
    const ls = 1 + eo3(prog(t, 3, 3.5)) * 1.6;
    this.latticeLines.scale.setScalar(ls);
    this.latticeLines.rotation.y = t * 0.12;
    this.latticeLines.rotation.x = t * 0.05;
    this.latticeLines.visible = t < 3.5;
    this.points.rotation.set(0, 0, 0);

    // branches
    const BL = this.branchLines.material.uniforms;
    BL.uProgress.value = eo3(prog(t, 3.0, 5.6)) * 1.05;
    BL.uOpacity.value = Math.min(prog(t, 3.0, 3.2), 1 - prog(t, 6.2, 7.0));
    this.branchLines.visible = t > 2.9 && t < 7.1;

    // network
    const nv = t > 5.9 && t < 9.1;
    this.netGroup.visible = nv;
    const NL = this.netLines.material.uniforms, RL = this.ringLines.material.uniforms;
    NL.uProgress.value = eo3(prog(t, 6.0, 7.4)) * 1.1;
    RL.uProgress.value = eo3(prog(t, 6.4, 8.0)) * 1.05;
    const nop = Math.min(prog(t, 5.9, 6.3), 1);
    NL.uOpacity.value = nop;
    RL.uOpacity.value = nop * 0.8;
    const col = ei3(prog(t, 8.7, 9.02));
    this.netGroup.scale.setScalar(Math.max(0.001, 1 - col));
    this.ringLines.rotation.y = t * 0.25;
    this.ringLines.rotation.x = Math.sin(t * 0.4) * 0.2;

    // structure + cluster lines
    const SL = this.structLines.material.uniforms;
    SL.uProgress.value = eo3(prog(t, 22.7, 23.8)) * 1.05;
    SL.uOpacity.value = t < 24 ? 1 : 1 - prog(t, 24, 24.45);
    this.structLines.scale.setScalar(1 + eo3(prog(t, 24, 24.5)) * 2.2);
    this.structLines.rotation.y = (t - 22) * 0.18;
    this.structLines.visible = t > 22.6 && t < 24.5;

    const CL = this.clusterLines;
    CL.visible = t > 21.4 && t < 23.4;
    if (CL.visible) {
      const arr = CL.geometry.attributes.position.array as Float32Array;
      let k = 0;
      for (let a = 0; a < 6; a++)
        for (let b = a + 1; b < 6; b++) {
          const pa = this.clusterCenter(a, t).clone();
          const pb = this.clusterCenter(b, t);
          arr.set([pa.x, pa.y, pa.z, pb.x, pb.y, pb.z], k * 6);
          k++;
        }
      CL.geometry.attributes.position.needsUpdate = true;
      CL.material.uniforms.uProgress.value = eo3(prog(t, 21.5, 22.5)) * 1.05;
      CL.material.uniforms.uOpacity.value = 1 - prog(t, 22.9, 23.4);
    }


    // city
    const cv = t > 29.9 && t < 34.1;
    this.city.visible = cv;
    if (cv) {
      const c = eio3(prog(t, 33.0, 33.65));
      this.city.scale.setScalar(Math.max(0.001, 1 - c * 0.995));
      this.blds.forEach((b, i) => {
        const bp = eoExpo(prog(t, 30.0 + b.delay, 30.75 + b.delay));
        const h = Math.max(0.001, b.h * bp);
        this.tmpS.set(b.w, h, b.d);
        this.tmpP.set(b.x, 0, b.z);
        this.tmpM.compose(this.tmpP, this.tmpQ, this.tmpS);
        this.bMesh.setMatrixAt(i, this.tmpM);
        this.tmpS.set(b.w * 1.001, bp > 0.01 ? 1 : 0.001, b.d * 1.001);
        this.tmpP.set(b.x, h, b.z);
        this.tmpM.compose(this.tmpP, this.tmpQ, this.tmpS);
        this.capMesh.setMatrixAt(i, this.tmpM);
      });
      this.bMesh.instanceMatrix.needsUpdate = true;
      this.capMesh.instanceMatrix.needsUpdate = true;
      if (this.cityShader) {
        this.cityShader.uniforms.uGlow.value = 1;
        this.cityShader.uniforms.uScan.value = ((t - 30) * 6) % 20;
      }
      this.panels.forEach((g, i) => {
        const s = eoExpo(prog(t, 30.8 + i * 0.18, 31.6 + i * 0.18));
        g.scale.set(Math.max(0.001, s), Math.max(0.001, s), 1);
        g.position.y += Math.sin(t * 0.8 + i) * 0.004;
      });
      this.scene.fog = null;
    }

    // labels (projected for DOM)
    this.labelAnchors.forEach((a, i) => {
      const v = a.clone().multiplyScalar(this.city.scale.x).project(this.camera);
      const L = this.labels[i];
      L.x = (v.x * 0.5 + 0.5) * W;
      L.y = (-v.y * 0.5 + 0.5) * H;
      L.vis = cv && v.z < 1 && Math.abs(v.x) < 0.95 && Math.abs(v.y) < 0.95 ? 1 : 0;
    });

    // post
    this.bloom.strength = kf(t, K_BLOOM);
    this.after.uniforms.damp.value = kf(t, K_DAMP);
    this.final.uniforms.uCA.value = kf(t, K_CA);
    this.final.uniforms.uFade.value = kf(t, K_FADE);

    this.composer.render();
  }

  dispose() {
    this.renderer.dispose();
  }
}

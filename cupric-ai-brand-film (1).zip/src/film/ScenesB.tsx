import { KText, Center, Logo } from "./Kinetic";
import { HudLabel } from "./ScenesA";
import { clamp, prog, eo3, eoExpo, ei3, eio3, eioExpo, eoBack, hash, lerp, mulberry32, LIME, LIME_RGB } from "./ease";

const MONO = '"JetBrains Mono", monospace';

// ============================================================ 24–27 MAKE NOISE
const WORDS = ["THINK", "BUILD", "TEST", "CREATE", "ITERATE", "LAUNCH"];
const wr = mulberry32(2024);
const INST = Array.from({ length: 36 }).map((_, k) => ({
  w: WORDS[k % 6],
  row: k % 6,
  copy: Math.floor(k / 6),
  at: 24.02 + k * 0.042,
  x: 140 + wr() * 1640,
  y: 130 + wr() * 820,
  s: 60 + Math.pow(wr(), 2) * 250,
  style: ((r) => (r < 0.45 ? "fill" : r < 0.86 ? "outline" : "lime"))(wr()),
  vx: (wr() - 0.5) * 900,
  vy: (wr() - 0.5) * 220,
  rot: wr() < 0.18 ? 90 : 0,
}));

export function Noise({ t }: { t: number }) {
  if (t < 23.95 || t > 27.15) return null;
  const c = ei3(prog(t, 25.98, 26.16));
  const pop = t >= 26.12;
  const pp = prog(t, 26.12, 26.5);
  const sq = eio3(prog(t, 26.82, 27.0));
  const glitch = t > 26.12 && t < 26.55 ? (hash(Math.floor(t * 30)) - 0.5) * 22 : 0;
  const flash = t > 26.12 ? (1 - prog(t, 26.12, 26.4)) * 0.22 : 0;
  const strobe = t < 25.3 && Math.floor(t * 30) % 5 === 0 ? 0.04 : 0;
  return (
    <>
      {(flash > 0 || strobe > 0) && <div style={{ position: "absolute", inset: 0, background: flash > 0 ? LIME : "#fff", opacity: flash || strobe }} />}
      {!pop &&
        INST.map((d, k) => {
          if (t < d.at) return null;
          const lt = t - d.at;
          const ap = eoExpo(clamp(lt / 0.25));
          const g = eioExpo(prog(t, 25.35 + d.row * 0.03, 25.8 + d.row * 0.03));
          const fx = d.x + d.vx * lt, fy = d.y + d.vy * lt;
          const gx = 960 + (d.copy - 2.5) * 34, gy = 540 + (d.row - 2.5) * 116;
          const x = lerp(fx, gx, g), y = lerp(lerp(fy, gy, g), 540, c);
          const size = lerp(d.s, 118, g);
          const rot = lerp(d.rot, 0, g);
          const isTop = d.copy === 5;
          const st = g > 0.5 ? (isTop ? "fill" : "outline") : d.style;
          return (
            <div
              key={k}
              style={{
                position: "absolute",
                left: x,
                top: y,
                transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${lerp(1.5, 1, ap)}, ${lerp(1.5, 1, ap) * (1 - c * 0.97)})`,
                fontSize: size,
                fontWeight: 800,
                letterSpacing: "-0.05em",
                lineHeight: 0.9,
                whiteSpace: "nowrap",
                color: st === "fill" ? "#fff" : st === "lime" ? LIME : "transparent",
                WebkitTextStroke: st === "outline" ? `1.3px rgba(255,255,255,${g > 0.5 ? 0.12 + d.copy * 0.08 : 0.6})` : undefined,
                opacity: clamp(lt / 0.06),
                filter: ap < 0.95 ? `blur(${(1 - ap) * 12}px)` : undefined,
                zIndex: isTop ? 2 : 1,
              }}
            >
              {d.w}
            </div>
          );
        })}
      {pop && (
        <Center>
          <div
            style={{
              fontSize: 290,
              fontWeight: 800,
              letterSpacing: "-0.055em",
              lineHeight: 0.9,
              whiteSpace: "nowrap",
              transform: `scale(${lerp(1.35, 1, eoExpo(pp)) + (t - 26.5) * 0.02}, ${Math.max(0.004, lerp(0.05, 1, eoBack(Math.min(1, pp * 1.4), 2.2)) * (1 - sq))})`,
              textShadow: glitch ? `${glitch}px 0 rgba(255,40,90,0.75), ${-glitch}px 0 rgba(40,220,255,0.75)` : "0 0 80px rgba(182,255,59,0.15)",
              opacity: 1 - prog(t, 26.98, 27.05),
            }}
          >
            MAKE NOISE<span style={{ color: LIME }}>.</span>
          </div>
        </Center>
      )}
      {t > 26.95 && <div style={{ position: "absolute", left: 960, top: 540, height: 2, width: 1500 * (1 - eio3(prog(t, 26.98, 27.12))), background: "#fff", transform: "translate(-50%,-50%)" }} />}
      <HudLabel x={80} y={70} text="009 — ITERATION LOOP" o={Math.min(prog(t, 24.1, 24.3), 1 - prog(t, 26.8, 27))} />
      <HudLabel x={1840} y={70} align="right" text={`CYCLES ${Math.floor(prog(t, 24, 26.1) * 10000).toLocaleString()}`} o={Math.min(prog(t, 24.1, 24.3), 1 - prog(t, 26.8, 27))} />
    </>
  );
}

// ============================================================ 27–30 HUMAN + MACHINE
export function HumanMachine({ t }: { t: number }) {
  if (t < 27.0 || t > 30.4) return null;
  const div = eo3(prog(t, 27.05, 27.45));
  const reveal = eo3(prog(t, 27.2, 28.3));
  const mg = eioExpo(prog(t, 29.15, 29.65));
  const dot = eoBack(prog(t, 28.3, 28.65));
  const flash = prog(t, 29.8, 30.35);
  const paths: string[] = [];
  for (let k = 0; k < 9; k++) {
    let d = "";
    for (let x = 120; x <= 960; x += 10) {
      const env = Math.pow((960 - x) / 840, 0.9);
      const y = 540 + ((k - 4) * 44 * env + Math.sin(x * 0.011 + t * 1.5 + k * 0.6) * 34 * env) * (1 - mg);
      d += `${x === 120 ? "M" : "L"}${x},${y.toFixed(1)} `;
    }
    paths.push(d);
  }
  const cols = 22, rows = 16;
  const cells = [];
  const fr = Math.floor(t * 24);
  const cp = prog(t, 27.3, 28.0) * 1.2;
  for (let i = 0; i < cols * rows; i++) {
    if (hash(i * 0.37) > cp) continue;
    const c = i % cols, r = Math.floor(i / cols);
    const v = hash(i * 1.31 + fr * 7.7);
    const fill = v > 0.94 ? LIME : v > 0.62 ? "rgba(255,255,255,0.55)" : "rgba(255,255,255,0.08)";
    cells.push(<rect key={i} x={1060 + c * 30} y={300 + r * 30} width={22} height={22} rx={3} fill={fill} />);
  }
  const wire = eo3(prog(t, 27.9, 28.35));
  return (
    <>
      <div style={{ position: "absolute", left: 960, top: 540, width: 1, height: 760 * div, background: "rgba(255,255,255,0.25)", transform: "translate(-50%,-50%)", opacity: 1 - mg }} />
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <defs>
          <clipPath id="hmL"><rect x={120} y={0} width={840 * reveal} height={1080} /></clipPath>
        </defs>
        <g style={{ transformOrigin: "960px 540px", transform: `scaleX(${1 - mg * 0.98})`, opacity: 1 - prog(t, 29.5, 29.7) }}>
          <g clipPath="url(#hmL)">
            {paths.map((d, k) => <path key={k} d={d} fill="none" stroke={k === 4 ? LIME : "#fff"} strokeOpacity={k === 4 ? 0.95 : 0.6} strokeWidth={k === 4 ? 2.4 : 1.6} />)}
          </g>
          {cells}
          {Array.from({ length: 8 }).map((_, k) => {
            const y = 315 + k * 64;
            const x1 = 1060 - (1060 - 960) * 0, y1 = y;
            return <line key={k} x1={x1} y1={y1} x2={lerp(x1, 960, wire)} y2={lerp(y1, 540, wire)} stroke={k === 3 ? LIME : "#fff"} strokeOpacity={0.5} strokeWidth={1} />;
          })}
        </g>
      </svg>
      {t > 28.28 && (
        <div style={{ position: "absolute", left: 960, top: 540, width: 18, height: 18, borderRadius: 99, background: "#f4ffe0", transform: `translate(-50%,-50%) scale(${dot * (1 + mg * 0.6 + ei3(prog(t, 29.75, 30.05)) * 3)})`, boxShadow: `0 0 ${40 + mg * 60}px ${14 + mg * 20}px rgba(${LIME_RGB},0.85)`, opacity: 1 - prog(t, 30.0, 30.15) }} />
      )}
      {t > 28.3 && t < 29.3 && <div style={{ position: "absolute", left: 960, top: 540, width: 40, height: 40, borderRadius: 99, border: `1px solid ${LIME}`, transform: `translate(-50%,-50%) scale(${1 + eo3(prog(t, 28.3, 29.2)) * 8})`, opacity: 1 - prog(t, 28.3, 29.2) }} />}
      <div style={{ position: "absolute", left: 540, top: 860, transform: `translate(-50%,-50%) translateX(${mg * 420}px) scale(${1 - ei3(prog(t, 29.5, 29.75))})`, opacity: 1 - prog(t, 29.55, 29.75), filter: mg > 0.02 ? `blur(${mg * 4}px)` : undefined }}>
        <KText text="HUMAN INTENT." t={t} at={27.55} inDur={0.8} stagger={0.03} variant="blur" exit="none" size={64} weight={500} tracking={-0.01} trackFrom={0.4} />
      </div>
      <div style={{ position: "absolute", left: 1390, top: 860, transform: `translate(-50%,-50%) translateX(${-mg * 430}px) scale(${1 - ei3(prog(t, 29.5, 29.75))})`, opacity: 1 - prog(t, 29.55, 29.75), filter: mg > 0.02 ? `blur(${mg * 4}px)` : undefined, mixBlendMode: "screen" }}>
        <KText text="MACHINE SPEED." t={t} at={27.95} inDur={0.4} stagger={0.02} variant="step" exit="none" size={50} weight={500} tracking={0.02} mono />
      </div>
      <HudLabel x={120} y={250} text="INPUT · HUMAN" o={Math.min(prog(t, 27.3, 27.6), 1 - mg)} />
      <HudLabel x={1720} y={250} align="right" text={`COMPUTE · ${(fr * 13337 % 99999).toString().padStart(5, "0")} OPS`} o={Math.min(prog(t, 27.3, 27.6), 1 - mg)} />
      <HudLabel x={80} y={70} text="010 — SYNCHRONIZATION" o={Math.min(prog(t, 27.3, 27.6), 1 - mg)} />
      {flash > 0 && flash < 1 && (
        <div style={{ position: "absolute", left: 960, top: 540, width: 100, height: 100, borderRadius: 999, transform: `translate(-50%,-50%) scale(${1 + eoExpo(flash) * 40})`, background: `radial-gradient(circle, rgba(244,255,224,0.9), rgba(${LIME_RGB},0.4) 35%, transparent 70%)`, opacity: 1 - flash }} />
      )}
    </>
  );
}

// ============================================================ 30–33 BUILD WHAT'S NEXT
const LABELS = ["edge · 312 regions", "builders +214%", "api.cupric/deploy · 12ms", "model · cupric-2"];
export function BuildNext({ t, labels }: { t: number; labels: { x: number; y: number; vis: number }[] }) {
  if (t < 30.2 || t > 33.3) return null;
  return (
    <>
      {labels.map((l, k) => {
        const o = Math.min(prog(t, 31.0 + k * 0.15, 31.3 + k * 0.15), 1 - prog(t, 32.7, 32.95)) * l.vis;
        if (o <= 0) return null;
        return (
          <div key={k} style={{ position: "absolute", left: l.x, top: l.y, opacity: o }}>
            <div style={{ position: "absolute", left: -4, top: -4, width: 8, height: 8, borderRadius: 9, background: LIME, boxShadow: `0 0 12px ${LIME}` }} />
            <div style={{ position: "absolute", left: 0, top: -64, width: 1, height: 60, background: "rgba(255,255,255,0.35)" }} />
            <div style={{ position: "absolute", left: 8, top: -84, whiteSpace: "nowrap", fontFamily: MONO, fontSize: 13, padding: "6px 10px", borderRadius: 8, background: "rgba(10,11,12,0.7)", border: "1px solid rgba(255,255,255,0.12)", backdropFilter: "blur(8px)", color: "rgba(255,255,255,0.85)" }}>{LABELS[k]}</div>
          </div>
        );
      })}
      <div style={{ position: "absolute", left: 130, top: 600, textShadow: "0 20px 80px rgba(0,0,0,0.9)" }}>
        <KText text="BUILD" t={t} at={30.5} out={32.55} inDur={0.6} outDur={0.35} size={190} weight={700} stagger={0.04} />
        <div style={{ height: 10 }} />
        <KText text="WHAT'S NEXT." t={t} at={31.25} out={32.62} inDur={0.6} outDur={0.35} size={190} weight={700} stagger={0.03} />
      </div>
      <HudLabel x={80} y={70} text="011 — ECOSYSTEM" o={Math.min(prog(t, 30.5, 30.8), 1 - prog(t, 32.7, 32.95))} />
      <HudLabel x={1840} y={70} align="right" text={`${Math.floor(eo3(prog(t, 30, 32)) * 548)} STRUCTURES ONLINE`} o={Math.min(prog(t, 30.5, 30.8), 1 - prog(t, 32.7, 32.95))} />
    </>
  );
}

// ============================================================ 33–40 BRAND
export function Brand({ t }: { t: number }) {
  if (t < 32.95) return null;
  const R = lerp(1500, 0, eio3(prog(t, 33.0, 33.75)));
  const vigO = 1 - prog(t, 34.3, 35.2);
  const lineW = 700 * eoExpo(prog(t, 33.7, 34.05));
  const lineRetract = eioExpo(prog(t, 34.05, 34.35));
  const draw = prog(t, 34.2, 34.85);
  const thick = eo3(prog(t, 34.75, 35.1));
  const wm = eoExpo(prog(t, 34.8, 35.4));
  const ai = eoExpo(prog(t, 35.12, 35.5));
  const glow = t > 35.2 ? 1 - prog(t, 35.2, 36.4) * 0.6 : thick * 0.6;
  const s1 = eio3(prog(t, 36.0, 36.6));
  const s2 = eio3(prog(t, 38.0, 38.6));
  const ly = lerp(0, -54, s1) + lerp(0, -34, s2);
  const ls = lerp(1, 0.8, s1) * lerp(1, 0.78, s2);
  const push = 1 + Math.max(0, t - 34) * 0.006;
  const fade = 1 - prog(t, 39.35, 39.9);
  const sweep = prog(t, 35.2, 35.95);
  return (
    <>
      <div style={{ position: "absolute", inset: 0, background: `radial-gradient(circle at 50% 50%, transparent ${R}px, #050505 ${R + 420}px)`, opacity: vigO }} />
      {t > 34.8 && <div style={{ position: "absolute", left: 960, top: 540 + ly, width: 1300, height: 700, transform: "translate(-50%,-50%)", background: `radial-gradient(ellipse at center, rgba(${LIME_RGB},0.13), transparent 60%)`, opacity: clamp((t - 34.8) * 2) * glow * fade }} />}
      {t > 33.68 && t < 34.4 && (
        <div style={{ position: "absolute", left: 960 - lineW / 2 + lineRetract * 0, top: 540, height: 2, width: lineW * (1 - lineRetract), background: LIME, transform: `translate(${-lineRetract * 290}px, -50%)`, boxShadow: `0 0 20px 2px rgba(${LIME_RGB},0.8)` }} />
      )}
      <div style={{ position: "absolute", inset: 0, transform: `scale(${push})`, opacity: fade }}>
        <Center y={ly}>
          <div style={{ display: "flex", alignItems: "center", gap: 38, transform: `scale(${ls})` }}>
            <Logo size={150} draw={draw} thick={thick} glow={glow} />
            <div style={{ position: "relative", fontSize: 158, fontWeight: 700, letterSpacing: "-0.04em", lineHeight: 1, whiteSpace: "nowrap", clipPath: `inset(-20% ${100 - wm * 100}% -20% 0)`, transform: `translateX(${(1 - wm) * -40}px)` }}>
              <span style={{ background: `linear-gradient(100deg, #fff 0%, #fff ${sweep * 140 - 30}%, #f3ffd9 ${sweep * 140 - 20}%, #fff ${sweep * 140 - 10}%, #fff 100%)`, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }}>Cupric</span>
              <span style={{ display: "inline-block", marginLeft: "0.22em", color: LIME, opacity: ai, transform: `translateY(${(1 - ai) * 30}px)`, filter: ai < 0.97 ? `blur(${(1 - ai) * 10}px)` : undefined, textShadow: `0 0 ${40 * glow}px rgba(${LIME_RGB},0.5)` }}>AI</span>
            </div>
          </div>
        </Center>
        <Center y={lerp(96, 52, s2)}>
          <KText text="INTELLIGENCE FOR PEOPLE WHO BUILD." t={t} at={36.3} inDur={1.0} stagger={0.018} variant="blur" exit="none" size={lerp(30, 26, s2)} weight={500} tracking={0.3} trackFrom={0.35} color="rgba(255,255,255,0.88)" accentChars="" />
        </Center>
        <Center y={140}>
          <div style={{ display: "flex", alignItems: "center", gap: 22, opacity: prog(t, 38.65, 39.1) }}>
            <div style={{ width: 60 * eo3(prog(t, 38.7, 39.3)), height: 1, background: `rgba(${LIME_RGB},0.6)` }} />
            <KText text="CREATE WITHOUT LIMITS." t={t} at={38.7} inDur={0.8} stagger={0.02} variant="blur" exit="none" size={17} weight={600} tracking={0.5} trackFrom={0.4} color={LIME} accentChars="" />
            <div style={{ width: 60 * eo3(prog(t, 38.7, 39.3)), height: 1, background: `rgba(${LIME_RGB},0.6)` }} />
          </div>
        </Center>
      </div>
    </>
  );
}

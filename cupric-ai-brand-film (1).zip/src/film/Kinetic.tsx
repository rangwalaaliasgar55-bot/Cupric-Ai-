import React from "react";
import { clamp, eoExpo, ei3, eo3, LIME } from "./ease";

export type Variant = "mask" | "blur" | "depth" | "slide" | "step" | "scale";
export type Exit = "up" | "blur" | "zoom" | "fade" | "down" | "collapse" | "none";

type Props = {
  text: string;
  t: number;
  at: number;
  out?: number;
  inDur?: number;
  outDur?: number;
  stagger?: number;
  variant?: Variant;
  exit?: Exit;
  size: number;
  weight?: number;
  tracking?: number; // em
  trackFrom?: number; // em extra at start
  color?: string;
  accentChars?: string; // characters rendered lime (e.g. ".")
  style?: React.CSSProperties;
  charStyle?: (i: number, p: number) => React.CSSProperties;
  mono?: boolean;
  lineHeight?: number;
  glow?: boolean;
  charTransform?: (i: number, e: number) => string;
  decorate?: (i: number, e: number) => React.ReactNode;
};

export function KText({
  text, t, at, out = 999, inDur = 0.7, outDur = 0.4, stagger = 0.035, variant = "mask", exit = "up", size, weight = 600,
  tracking = -0.045, trackFrom = 0, color = "#fff", accentChars = ".×", style, charStyle, mono, lineHeight = 0.92, glow, charTransform, decorate,
}: Props) {
  const chars = Array.from(text);
  const n = chars.length;
  const end = out + outDur + n * stagger * 0.5 + 0.05;
  if (t < at - 0.02 || t > end) return null;
  const pAll = clamp((t - at) / (inDur + n * stagger));
  const poAll = clamp((t - out) / outDur);
  const track = tracking + trackFrom * (1 - eoExpo(pAll));

  let cT = "";
  let cO = 1;
  let cF = "";
  if (exit === "zoom") {
    const e = ei3(poAll);
    cT = `scale(${1 + e * 7})`;
    cO = 1 - clamp(poAll * 1.3);
    cF = e > 0.001 ? `blur(${e * 14}px)` : "";
  } else if (exit === "collapse") {
    const e = ei3(poAll);
    cT = `scale(${Math.max(0.001, 1 - e)}, ${Math.max(0.001, 1 - e)})`;
    cO = 1 - clamp((poAll - 0.7) / 0.3);
  }

  return (
    <div
      style={{
        display: "inline-flex",
        whiteSpace: "pre",
        fontSize: size,
        fontWeight: weight,
        letterSpacing: `${track}em`,
        lineHeight,
        color,
        perspective: 1400,
        transform: cT || undefined,
        opacity: cO,
        filter: cF || undefined,
        fontFamily: mono ? '"JetBrains Mono", monospace' : undefined,
        textShadow: glow ? `0 0 60px rgba(182,255,59,0.18)` : undefined,
        ...style,
      }}
    >
      {chars.map((ch, i) => {
        const pi = clamp((t - at - i * stagger) / inDur);
        const po = clamp((t - out - i * stagger * 0.5) / outDur);
        const e = variant === "step" ? Math.floor(pi * 4) / 4 : eoExpo(pi);
        const eo = ei3(po);
        let tr = "";
        let op = 1;
        let blur = 0;
        const clip = variant === "mask" || exit === "up" || exit === "down";
        switch (variant) {
          case "mask": tr += `translateY(${(1 - e) * 110}%) `; break;
          case "blur": op = e; blur += (1 - e) * 22; tr += `translateY(${(1 - e) * 0.15}em) scale(${1 + (1 - e) * 0.25}) `; break;
          case "depth": op = eo3(pi); blur += (1 - e) * 10; tr += `translateZ(${-(1 - e) * 1400}px) rotateX(${(1 - e) * 60}deg) `; break;
          case "slide": op = clamp(pi * 3); blur += (1 - e) * 14; tr += `translateX(${(1 - e) * -1.4}em) skewX(${(1 - e) * -25}deg) `; break;
          case "step": op = pi > 0 ? 1 : 0; tr += `translateY(${(1 - e) * 40}%) `; break;
          case "scale": op = clamp(pi * 2); tr += `scale(${1 + (1 - e) * 1.6}) `; blur += (1 - e) * 16; break;
        }
        switch (exit) {
          case "up": tr += `translateY(${-eo * 110}%) `; break;
          case "down": tr += `translateY(${eo * 110}%) `; break;
          case "blur": op *= 1 - po; blur += eo * 18; tr += `translateY(${-eo * 0.2}em) `; break;
          case "fade": op *= 1 - po; break;
        }
        if (charTransform) tr += charTransform(i, e) + " ";
        const cs = charStyle ? charStyle(i, e) : {};
        const isAcc = accentChars.includes(ch);
        const span = (
          <span
            key={i}
            style={{
              display: "inline-block",
              transform: tr || undefined,
              opacity: op,
              filter: blur > 0.3 ? `blur(${blur}px)` : undefined,
              color: isAcc ? LIME : undefined,
              position: "relative",
              ...cs,
            }}
          >
            {ch === " " ? "\u00A0" : ch}
            {decorate ? decorate(i, e) : null}
          </span>
        );
        return clip ? (
          <span key={i} style={{ display: "inline-block", overflow: "hidden", padding: "0.06em 0.01em 0.1em", margin: "-0.06em -0.01em -0.1em" }}>
            {span}
          </span>
        ) : (
          span
        );
      })}
    </div>
  );
}

/** Absolute centered box helper */
export function Center({ children, y = 0, x = 0, style }: { children: React.ReactNode; y?: number; x?: number; style?: React.CSSProperties }) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        transform: `translate(${x}px, ${y}px)`,
        pointerEvents: "none",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

export function Logo({ size = 120, draw = 1, thick = 1, glow = 0 }: { size?: number; draw?: number; thick?: number; glow?: number }) {
  const rays = Array.from({ length: 8 });
  const sw = 1.6 + thick * 9.4;
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" style={{ overflow: "visible", filter: glow ? `drop-shadow(0 0 ${glow * 18}px rgba(182,255,59,${0.6 * glow}))` : undefined }}>
      {rays.map((_, k) => {
        const a = (k / 8) * Math.PI * 2 - Math.PI / 2;
        const p = clamp(draw * 1.6 - k * 0.075);
        const r0 = 19, r1 = 44;
        return (
          <line
            key={k}
            x1={50 + Math.cos(a) * r0}
            y1={50 + Math.sin(a) * r0}
            x2={50 + Math.cos(a) * r1}
            y2={50 + Math.sin(a) * r1}
            stroke={LIME}
            strokeWidth={sw}
            strokeLinecap="round"
            pathLength={1}
            strokeDasharray="1 1"
            strokeDashoffset={1 - eo3(p)}
            opacity={p > 0.001 ? 1 : 0}
          />
        );
      })}
      <circle cx={50} cy={50} r={7 * clamp(thick)} fill={LIME} />
    </svg>
  );
}

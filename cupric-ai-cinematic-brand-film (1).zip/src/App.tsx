import { useCallback, useEffect, useRef, useState } from 'react';
import { FilmRenderer } from './film/FilmRenderer';
import { Soundscape } from './film/Soundscape';
import { DURATION, FPS } from './film/math';

const chapters = [
  'The hook', 'Infinite directions', 'Intelligence in motion', 'Build faster',
  'Prompt to product', 'Less repetition', '10 times', 'Ideas connect',
  'Make noise', 'Human + machine', "Build what's next", 'Brand reveal',
  'Brand statement', 'End card',
];
const chapterStarts = [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 38];

type PlayerState = {
  time: number;
  origin: number;
  playing: boolean;
  exporting: boolean;
  recorder: MediaRecorder | null;
};

function BrandSymbol({ size = 24 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <path d="M20 4v11M20 25v11M4 20h11M25 20h11M8.7 8.7l7.8 7.8m7 7 7.8 7.8M31.3 8.7l-7.8 7.8m-7 7-7.8 7.8" stroke="currentColor" strokeWidth="3.4" strokeLinecap="round" />
      <circle cx="20" cy="20" r="3" fill="currentColor" />
    </svg>
  );
}

function PlayIcon({ playing }: { playing: boolean }) {
  return playing ? (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M8 5v14M16 5v14" stroke="currentColor" strokeWidth="2" strokeLinecap="square" /></svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m8 4 12 8-12 8V4Z" fill="currentColor" /></svg>
  );
}

function RestartIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4.5 11.5a7.5 7.5 0 1 1 1.7 5M4.5 5.5v6h6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function SoundIcon({ on }: { on: boolean }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M4 9v6h4l5 4V5L8 9H4Z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
      {on ? <><path d="M16 9a4 4 0 0 1 0 6M18.8 6.4a8 8 0 0 1 0 11.2" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" /></> : <path d="m17 9 4 6m0-6-4 6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />}
    </svg>
  );
}

function FullscreenIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 9V4h5m6 0h5v5m0 6v5h-5m-6 0H4v-5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function DownloadIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3v12m0 0 4.5-4.5M12 15l-4.5-4.5M4 17v3h16v-3" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function timecode(time: number) {
  const seconds = Math.min(39, Math.floor(time));
  const frames = Math.min(29, Math.floor((time - Math.floor(time)) * FPS + 0.001));
  if (time >= DURATION) return '00:40:00';
  return `00:${String(seconds).padStart(2, '0')}:${String(frames).padStart(2, '0')}`;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<FilmRenderer | null>(null);
  const soundRef = useRef<Soundscape | null>(null);
  const rafRef = useRef(0);
  const playerRef = useRef<PlayerState>({ time: 0, origin: 0, playing: true, exporting: false, recorder: null });
  const [currentTime, setCurrentTime] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [soundOn, setSoundOn] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    if (!canvasRef.current) return;
    const renderer = new FilmRenderer(canvasRef.current);
    const sound = new Soundscape();
    rendererRef.current = renderer;
    soundRef.current = sound;
    const state = playerRef.current;
    state.time = 0;
    state.playing = true;
    state.origin = performance.now();
    renderer.render(0);
    let lastUpdate = 0;
    let disposed = false;

    const frame = (now: number) => {
      if (disposed) return;
      if (state.playing) {
        const next = Math.min(DURATION, Math.max(0, Math.floor(((now - state.origin) / 1000) * FPS) / FPS));
        if (next !== state.time) {
          state.time = next;
          renderer.render(next);
          sound.update(next);
        }
        if (next >= DURATION) {
          state.playing = false;
          sound.setPlaying(false);
          setPlaying(false);
          if (state.recorder?.state === 'recording') state.recorder.stop();
        }
      }
      if (now - lastUpdate > 75 || state.time >= DURATION) {
        setCurrentTime(state.time);
        lastUpdate = now;
      }
      rafRef.current = requestAnimationFrame(frame);
    };
    rafRef.current = requestAnimationFrame(frame);
    void document.fonts.ready.then(() => {
      if (!disposed) renderer.refreshTypography();
    });
    return () => {
      disposed = true;
      cancelAnimationFrame(rafRef.current);
      if (state.recorder?.state === 'recording') state.recorder.stop();
      renderer.dispose();
      sound.dispose();
      rendererRef.current = null;
      soundRef.current = null;
    };
  }, []);

  const seek = useCallback((time: number) => {
    const state = playerRef.current;
    if (state.exporting) return;
    const next = Math.min(DURATION, Math.max(0, Math.round(time * FPS) / FPS));
    state.time = next;
    state.origin = performance.now() - next * 1000;
    rendererRef.current?.render(next);
    soundRef.current?.update(next);
    setCurrentTime(next);
    if (next >= DURATION) {
      state.playing = false;
      soundRef.current?.setPlaying(false);
      setPlaying(false);
    }
  }, []);

  const togglePlay = useCallback(() => {
    const state = playerRef.current;
    if (state.exporting) return;
    if (state.time >= DURATION) {
      state.time = 0;
      rendererRef.current?.render(0);
      setCurrentTime(0);
    }
    state.playing = !state.playing;
    state.origin = performance.now() - state.time * 1000;
    soundRef.current?.setPlaying(state.playing);
    setPlaying(state.playing);
  }, []);

  const restart = useCallback(() => {
    if (playerRef.current.exporting) return;
    seek(0);
    const state = playerRef.current;
    state.playing = true;
    state.origin = performance.now();
    soundRef.current?.setPlaying(true);
    setPlaying(true);
  }, [seek]);

  const toggleSound = useCallback(async () => {
    const sound = soundRef.current;
    if (!sound) return;
    if (sound.isEnabled) {
      sound.mute();
      setSoundOn(false);
    } else {
      const enabled = await sound.enable(playerRef.current.time);
      sound.setPlaying(playerRef.current.playing);
      setSoundOn(enabled);
      if (!enabled) setNotice('Audio could not be started in this browser.');
    }
  }, []);

  const toggleFullscreen = useCallback(async () => {
    if (!stageRef.current) return;
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await stageRef.current.requestFullscreen();
    } catch {
      setNotice('Fullscreen is not available in this browser.');
    }
  }, []);

  useEffect(() => {
    const onFullscreen = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFullscreen);
    const onKey = (event: KeyboardEvent) => {
      if (event.target instanceof HTMLInputElement) return;
      if (event.code === 'Space') { event.preventDefault(); togglePlay(); }
      if (event.code === 'ArrowRight') { event.preventDefault(); seek(playerRef.current.time + 1); }
      if (event.code === 'ArrowLeft') { event.preventDefault(); seek(playerRef.current.time - 1); }
      if (event.key.toLowerCase() === 'r') restart();
      if (event.key.toLowerCase() === 'm') void toggleSound();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('fullscreenchange', onFullscreen);
      window.removeEventListener('keydown', onKey);
    };
  }, [restart, seek, togglePlay, toggleSound]);

  const exportFilm = useCallback(async () => {
    const canvas = canvasRef.current;
    const renderer = rendererRef.current;
    const sound = soundRef.current;
    const state = playerRef.current;
    if (!canvas || !renderer || !sound || state.exporting) return;
    if (typeof MediaRecorder === 'undefined' || !canvas.captureStream) {
      setNotice('This browser cannot record canvas video. Try a recent Chrome or Edge browser.');
      return;
    }
    const mime = [
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm',
    ].find((type) => MediaRecorder.isTypeSupported(type));
    if (!mime) {
      setNotice('WebM recording is not supported in this browser.');
      return;
    }
    try {
      const hasAudio = await sound.enable(0);
      setSoundOn(hasAudio);
      state.time = 0;
      state.origin = performance.now();
      state.playing = true;
      state.exporting = true;
      renderer.render(0);
      sound.setPlaying(true);
      setCurrentTime(0);
      setPlaying(true);
      setExporting(true);
      setNotice('');

      const video = canvas.captureStream(FPS);
      const audioTracks = hasAudio ? sound.stream?.getAudioTracks() ?? [] : [];
      const stream = new MediaStream([...video.getVideoTracks(), ...audioTracks]);
      const recorder = new MediaRecorder(stream, {
        mimeType: mime,
        videoBitsPerSecond: 16_000_000,
        audioBitsPerSecond: 192_000,
      });
      state.recorder = recorder;
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (event) => { if (event.data.size > 0) chunks.push(event.data); };
      recorder.onerror = () => setNotice('The recording was interrupted. Please try again.');
      recorder.onstop = () => {
        stream.getTracks().forEach((track) => track.stop());
        state.recorder = null;
        state.exporting = false;
        setExporting(false);
        if (!chunks.length) return;
        const blob = new Blob(chunks, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'CUPRIC-AI_Brand-Film_1920x1080_30fps.webm';
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 60_000);
      };
      recorder.start(500);
      state.origin = performance.now();
    } catch (error) {
      state.exporting = false;
      setExporting(false);
      setNotice(error instanceof Error ? error.message : 'Recording could not be started.');
    }
  }, []);

  const chapter = chapterStarts.reduce((current, start, index) => currentTime >= start ? index : current, 0);

  return (
    <main className="film-app">
      <header className="film-header">
        <div className="header-brand" aria-label="Cupric AI">
          <span className="header-symbol"><BrandSymbol size={25} /></span>
          <span>CUPRIC <span className="brand-ai">AI</span></span>
        </div>
        <div className="header-center"><span className="header-indicator" /> A FILM ABOUT WHAT'S POSSIBLE</div>
        <div className="header-spec">ORIGINAL MOTION FILM <span>/</span> 001</div>
      </header>

      <section className="cinema" aria-label="Cupric AI 40 second brand film">
        <div className={`film-stage ${fullscreen ? 'is-fullscreen' : ''}`} ref={stageRef}>
          <canvas
            ref={canvasRef}
            width={1920}
            height={1080}
            aria-label="Cinematic animation for Cupric AI"
            onClick={togglePlay}
          />
          {!playing && !exporting && currentTime < DURATION && (
            <button className="stage-play" onClick={togglePlay} aria-label="Play film"><PlayIcon playing={false} /></button>
          )}
          {exporting && <div className="capture-label"><span className="capture-dot" /> CAPTURING 1080P / KEEP THIS TAB ACTIVE</div>}
        </div>
      </section>

      <footer className="film-controls">
        <div className="timeline-shell">
          <div className="timeline-rail" aria-hidden="true">
            <div className="timeline-fill" style={{ width: `${(currentTime / DURATION) * 100}%` }} />
            {chapterStarts.slice(1).map((start) => <span key={start} className="timeline-tick" style={{ left: `${(start / DURATION) * 100}%` }} />)}
            <span className="timeline-head" style={{ left: `${(currentTime / DURATION) * 100}%` }} />
          </div>
          <input
            className="timeline-input"
            type="range"
            min={0}
            max={DURATION}
            step={1 / FPS}
            value={currentTime}
            onChange={(event) => seek(Number(event.target.value))}
            disabled={exporting}
            aria-label="Seek through the film"
          />
        </div>
        <div className="controls-row">
          <div className="controls-left">
            <button className="icon-button main-play" onClick={togglePlay} disabled={exporting} aria-label={playing ? 'Pause film' : 'Play film'}><PlayIcon playing={playing} /></button>
            <button className="icon-button" onClick={restart} disabled={exporting} aria-label="Restart film"><RestartIcon /></button>
            <div className="time-display"><span>{timecode(currentTime)}</span><span className="time-separator">/</span><span className="time-total">00:40:00</span></div>
          </div>
          <div className="chapter-display"><span className="chapter-index">{String(chapter + 1).padStart(2, '0')} / 14</span><span className="chapter-divider" /><span className="chapter-title">{chapters[chapter]}</span></div>
          <div className="controls-right">
            <span className="film-format">1920 × 1080 <span>/</span> 30 FPS</span>
            <button className={`icon-button ${soundOn ? 'is-active' : ''}`} onClick={() => void toggleSound()} aria-label={soundOn ? 'Mute sound' : 'Enable sound'} title={soundOn ? 'Mute sound (M)' : 'Enable sound (M)'}><SoundIcon on={soundOn} /></button>
            <button className="icon-button" onClick={() => void toggleFullscreen()} aria-label="Toggle fullscreen" title="Fullscreen"><FullscreenIcon /></button>
            <button className="export-button" onClick={() => void exportFilm()} disabled={exporting} title="Record the full film in real time"><DownloadIcon /><span>{exporting ? 'CAPTURING' : 'EXPORT FILM'}</span></button>
          </div>
        </div>
        {notice && <div className="notice" role="status">{notice}<button onClick={() => setNotice('')} aria-label="Dismiss notice">×</button></div>}
      </footer>
    </main>
  );
}

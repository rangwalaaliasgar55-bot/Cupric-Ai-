export const W = 1920;
export const H = 1080;
export const DURATION = 40;
export const FPS = 30;
export const LIME = '#c8fb45';
export const WHITE = '#f1f4e9';

export const clamp = (value: number, min = 0, max = 1) =>
  Math.min(max, Math.max(min, value));

export const mix = (a: number, b: number, amount: number) =>
  a + (b - a) * amount;

export const smooth = (a: number, b: number, value: number) => {
  const x = clamp((value - a) / (b - a));
  return x * x * (3 - 2 * x);
};

export const easeOut = (value: number) => 1 - Math.pow(1 - clamp(value), 3);
export const easeInOut = (value: number) => {
  const x = clamp(value);
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
};

export const hash = (n: number, salt = 0) => {
  const x = Math.sin(n * 127.1 + salt * 311.7) * 43758.5453123;
  return x - Math.floor(x);
};

export const range = (start: number, end: number, value: number, fade = 0.28) =>
  smooth(start, start + fade, value) * (1 - smooth(end - fade, end, value));

export const rgba = (hex: string, alpha: number) => {
  const value = hex.replace('#', '');
  const number = parseInt(value, 16);
  return `rgba(${(number >> 16) & 255},${(number >> 8) & 255},${number & 255},${clamp(alpha)})`;
};
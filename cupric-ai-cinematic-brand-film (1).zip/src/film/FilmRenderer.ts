import { DURATION, H, LIME, W, WHITE, clamp, easeOut, hash, mix, range, rgba, smooth } from './math';
import { ThreeWorld } from './ThreeWorld';

type TextOptions = {
  color?: string;
  weight?: number;
  tracking?: number;
  align?: CanvasTextAlign;
  alpha?: number;
  stroke?: boolean;
  lineWidth?: number;
  family?: string;
};

type Fragment = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  rotation: number;
  group: number;
  lime: boolean;
};

const sceneTimes = [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 38, 40];
const sceneNames = [
  'ORIGIN', 'POSSIBILITY', 'INTELLIGENCE', 'WORKSPACE', 'TRANSFORMATION',
  'AUTOMATION', 'ACCELERATION', 'CONNECTION', 'EXPRESSION', 'SYNCHRONICITY',
  'THE FUTURE', 'CUPRIC AI', 'OUR PURPOSE', 'END CARD',
];

export class FilmRenderer {
  readonly canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private world: ThreeWorld | null = null;
  private grain: HTMLCanvasElement;
  private productImage = new Image();
  private fragments: Fragment[] = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.canvas.width = W;
    this.canvas.height = H;
    const context = canvas.getContext('2d', { alpha: false, desynchronized: true });
    if (!context) throw new Error('A 2D canvas is required to play the film.');
    this.ctx = context;
    try {
      this.world = new ThreeWorld();
    } catch (error) {
      console.warn('WebGL is unavailable. Playing the 2D film layer.', error);
    }
    this.productImage.src = '/images/product-form.jpg';
    this.grain = this.createGrain();
    this.makeFragments();
  }

  private createGrain() {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const context = canvas.getContext('2d')!;
    const image = context.createImageData(256, 256);
    for (let i = 0; i < image.data.length; i += 4) {
      const value = hash(i, 56) > 0.5 ? 255 : 0;
      image.data[i] = value;
      image.data[i + 1] = value;
      image.data[i + 2] = value;
      image.data[i + 3] = Math.floor(hash(i, 57) * 17);
    }
    context.putImageData(image, 0, 0);
    return canvas;
  }

  private makeFragments() {
    this.fragments = [];
    const canvas = document.createElement('canvas');
    canvas.width = 1350;
    canvas.height = 650;
    const context = canvas.getContext('2d')!;
    context.fillStyle = '#fff';
    context.textAlign = 'center';
    context.font = "900 620px 'Inter Tight', Arial, sans-serif";
    context.fillText('10×', 675, 515);
    const data = context.getImageData(0, 0, 1350, 650).data;
    let count = 0;
    for (let y = 0; y < 650; y += 13) {
      for (let x = 0; x < 1350; x += 13) {
        if (data[(y * 1350 + x) * 4 + 3] < 120 || hash(x * 13 + y, 4) < 0.18) continue;
        const angle = Math.atan2(y - 325, x - 675) + (hash(count, 11) - 0.5) * 1.6;
        const speed = 370 + hash(count, 12) * 670;
        this.fragments.push({
          x: 285 + x,
          y: 218 + y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          size: 2 + hash(count, 14) * 6,
          rotation: (hash(count, 15) - 0.5) * 8,
          group: count % 3,
          lime: hash(count, 16) > 0.82,
        });
        count++;
      }
    }
  }

  private font(size: number, weight = 800, family = 'Inter Tight') {
    this.ctx.font = `${weight} ${size}px '${family}', Arial, sans-serif`;
  }

  private text(text: string, x: number, y: number, size: number, options: TextOptions = {}) {
    const ctx = this.ctx;
    const {
      color = WHITE, weight = 800, tracking = 0, align = 'left', alpha = 1,
      stroke = false, lineWidth = 2, family = 'Inter Tight',
    } = options;
    ctx.save();
    ctx.globalAlpha *= clamp(alpha);
    ctx.fillStyle = color;
    ctx.strokeStyle = color;
    ctx.lineWidth = lineWidth;
    ctx.textBaseline = 'alphabetic';
    this.font(size, weight, family);
    if (!tracking) {
      ctx.textAlign = align;
      if (stroke) ctx.strokeText(text, x, y);
      else ctx.fillText(text, x, y);
    } else {
      const chars = [...text];
      const widths = chars.map((char) => ctx.measureText(char).width);
      const total = widths.reduce((a, b) => a + b, 0) + tracking * (chars.length - 1);
      let cursor = align === 'center' ? x - total / 2 : align === 'right' ? x - total : x;
      ctx.textAlign = 'left';
      chars.forEach((char, index) => {
        if (stroke) ctx.strokeText(char, cursor, y);
        else ctx.fillText(char, cursor, y);
        cursor += widths[index] + tracking;
      });
    }
    ctx.restore();
  }

  private reveal(text: string, x: number, y: number, size: number, progress: number, options: TextOptions = {}) {
    const ctx = this.ctx;
    const chars = [...text];
    const tracking = options.tracking ?? -size * 0.035;
    ctx.save();
    this.font(size, options.weight ?? 850, options.family ?? 'Inter Tight');
    const widths = chars.map((char) => ctx.measureText(char).width);
    const total = widths.reduce((a, b) => a + b, 0) + tracking * (chars.length - 1);
    const left = options.align === 'center' ? x - total / 2 : options.align === 'right' ? x - total : x;
    ctx.beginPath();
    ctx.rect(left - 55, y - size * 1.17, total + 110, size * 1.43);
    ctx.clip();
    let cursor = left;
    chars.forEach((char, index) => {
      const start = index / Math.max(1, chars.length) * 0.48;
      const p = smooth(start, start + 0.48, progress);
      if (p > 0) {
        ctx.save();
        ctx.globalAlpha *= p * (options.alpha ?? 1);
        ctx.translate(cursor + (1 - p) * 25, y + (1 - easeOut(p)) * size * 0.72);
        ctx.fillStyle = options.color ?? WHITE;
        ctx.textAlign = 'left';
        ctx.shadowColor = options.color ?? WHITE;
        ctx.shadowBlur = (1 - p) * 26;
        ctx.fillText(char, 0, 0);
        ctx.restore();
      }
      cursor += widths[index] + tracking;
    });
    ctx.restore();
  }

  private line(x1: number, y1: number, x2: number, y2: number, color = WHITE, alpha = 1, width = 1) {
    const ctx = this.ctx;
    ctx.save();
    ctx.strokeStyle = rgba(color, alpha);
    ctx.lineWidth = width;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.restore();
  }

  private box(x: number, y: number, w: number, h: number, radius = 12, fill = '#121713', stroke = 'rgba(228,244,220,.12)') {
    const ctx = this.ctx;
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, radius);
    ctx.fillStyle = fill;
    ctx.fill();
    if (stroke) {
      ctx.strokeStyle = stroke;
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  }

  private glow(x: number, y: number, radius: number, color = LIME, strength = 0.5) {
    const ctx = this.ctx;
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
    gradient.addColorStop(0, rgba(color, strength));
    gradient.addColorStop(0.15, rgba(color, strength * 0.24));
    gradient.addColorStop(1, rgba(color, 0));
    ctx.fillStyle = gradient;
    ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
  }

  private mark(x: number, y: number, size: number, progress = 1, alpha = 1) {
    const ctx = this.ctx;
    ctx.save();
    ctx.globalAlpha *= alpha;
    ctx.translate(x, y);
    ctx.strokeStyle = LIME;
    ctx.lineWidth = size * 0.085;
    ctx.lineCap = 'round';
    for (let i = 0; i < 8; i++) {
      const p = smooth(i / 9, i / 9 + 0.3, progress);
      if (!p) continue;
      const angle = i * Math.PI / 4 - Math.PI / 2;
      const inner = size * 0.14;
      const outer = mix(inner, size * (i % 2 === 0 ? 0.51 : 0.42), p);
      ctx.beginPath();
      ctx.moveTo(Math.cos(angle) * inner, Math.sin(angle) * inner);
      ctx.lineTo(Math.cos(angle) * outer, Math.sin(angle) * outer);
      ctx.stroke();
    }
    ctx.fillStyle = LIME;
    ctx.beginPath();
    ctx.arc(0, 0, size * 0.1 * progress, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  private drawCover(image: HTMLImageElement, x: number, y: number, w: number, h: number) {
    if (!image.complete || !image.naturalWidth) return;
    const sourceRatio = image.naturalWidth / image.naturalHeight;
    const targetRatio = w / h;
    const sw = sourceRatio > targetRatio ? image.naturalHeight * targetRatio : image.naturalWidth;
    const sh = sourceRatio > targetRatio ? image.naturalHeight : image.naturalWidth / targetRatio;
    this.ctx.drawImage(image, (image.naturalWidth - sw) / 2, (image.naturalHeight - sh) / 2, sw, sh, x, y, w, h);
  }

  private atmosphere(t: number) {
    const ctx = this.ctx;
    ctx.fillStyle = '#050705';
    ctx.fillRect(0, 0, W, H);
    if (t < 0.12) return;
    const mode = this.sceneAt(t);
    if (mode < 11) {
      const gradient = ctx.createRadialGradient(960, 520, 10, 960, 520, 1120);
      gradient.addColorStop(0, mode === 9 ? '#121a12' : '#101510');
      gradient.addColorStop(0.46, '#080d0a');
      gradient.addColorStop(1, '#030504');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, W, H);
      const wash = ctx.createLinearGradient(0, 0, W, H);
      wash.addColorStop(0, 'rgba(209,255,106,.032)');
      wash.addColorStop(0.42, 'rgba(0,0,0,0)');
      wash.addColorStop(1, 'rgba(108,135,95,.025)');
      ctx.fillStyle = wash;
      ctx.fillRect(0, 0, W, H);
    }
    if (this.world) {
      this.world.render(t);
      ctx.drawImage(this.world.canvas, 0, 0, W, H);
    }
  }

  private sceneAt(t: number) {
    for (let i = sceneTimes.length - 2; i >= 0; i--) if (t >= sceneTimes[i]) return i;
    return 0;
  }

  private sceneAlpha(index: number, t: number) {
    const start = sceneTimes[index];
    const end = sceneTimes[index + 1];
    const fadeIn = index === 0 ? 1 : smooth(start - 0.17, start + 0.35, t);
    const fadeOut = index === 13 ? 1 : 1 - smooth(end - 0.34, end + 0.16, t);
    return fadeIn * fadeOut;
  }

  private frameDetails(t: number) {
    if (t < 1.05 || t > 32.9) return;
    const ctx = this.ctx;
    const alpha = smooth(1.05, 1.5, t) * (1 - smooth(32.4, 32.9, t));
    ctx.save();
    ctx.globalAlpha = alpha;
    this.mark(94, 91, 31, 1, 0.6);
    this.text('CUPRIC / SYSTEM OF POSSIBILITY', 128, 99, 20, { family: 'IBM Plex Mono', weight: 500, tracking: 1.8, alpha: 0.48 });
    const number = String(this.sceneAt(t) + 1).padStart(2, '0');
    this.text(`${number} / ${sceneNames[this.sceneAt(t)]}`, 1820, 98, 19, { family: 'IBM Plex Mono', weight: 500, align: 'right', tracking: 1.3, alpha: 0.45 });
    this.line(77, 127, 1843, 127, WHITE, 0.13);
    this.line(77, 953, 1843, 953, WHITE, 0.11);
    this.text('INTELLIGENCE FOR PEOPLE WHO BUILD', 82, 997, 18, { family: 'IBM Plex Mono', weight: 500, tracking: 1.7, alpha: 0.32 });
    const frames = Math.floor((t % 1) * 30).toString().padStart(2, '0');
    const seconds = Math.floor(t).toString().padStart(2, '0');
    this.text(`00:00:${seconds}:${frames}`, 1839, 997, 19, { family: 'IBM Plex Mono', weight: 500, align: 'right', tracking: 1.8, alpha: 0.4 });
    ctx.restore();
  }

  private hook(t: number) {
    const ctx = this.ctx;
    const birth = smooth(0.13, 0.78, t);
    this.glow(960, 540, 500 * birth + 3, LIME, 0.33 * (1 - smooth(1.1, 2.5, t)));
    ctx.save();
    ctx.strokeStyle = rgba(LIME, 0.21 * birth);
    ctx.lineWidth = 1.5;
    for (let i = 0; i < 11; i++) {
      const radius = (78 + i * 75) * birth;
      ctx.beginPath();
      ctx.ellipse(960, 540, radius, radius * 0.48, -0.15 + t * 0.06, -1.6 + i * 0.35, -0.55 + i * 0.35);
      ctx.stroke();
    }
    for (let i = 0; i < 55; i++) {
      const a = hash(i, 72) * Math.PI * 2;
      const r = (hash(i, 73) * 820 + t * (80 + hash(i, 74) * 320)) % 1000;
      const x = 960 + Math.cos(a) * r;
      const y = 540 + Math.sin(a) * r * 0.56;
      this.line(x, y, x + Math.cos(a) * (30 + r * 0.09), y + Math.sin(a) * (16 + r * 0.04), LIME, birth * (1 - r / 1100) * 0.2, 1.2);
    }
    ctx.restore();
    if (t < 0.8) {
      const spark = smooth(0.12, 0.3, t);
      this.glow(960, 540, 50 + t * 100, LIME, 0.9 * spark);
      ctx.fillStyle = rgba(LIME, spark);
      ctx.beginPath();
      ctx.arc(960, 540, 2 + t * 4, 0, Math.PI * 2);
      ctx.fill();
    }
    const first = range(0.69, 1.95, t, 0.28);
    ctx.save();
    ctx.globalAlpha *= first;
    this.reveal('CREATE.', 960, 635, 284, smooth(0.72, 1.32, t), { align: 'center', tracking: -14, weight: 880 });
    ctx.restore();
    const second = range(1.63, 3.04, t, 0.28);
    ctx.save();
    ctx.globalAlpha *= second;
    this.reveal('WITH', 960, 427, 87, smooth(1.68, 2.06, t), { align: 'center', color: LIME, tracking: 20, weight: 620 });
    this.reveal('INTELLIGENCE.', 960, 658, 171, smooth(1.82, 2.44, t), { align: 'center', tracking: -8 });
    ctx.restore();
    const zoom = smooth(2.66, 3.06, t);
    if (zoom) {
      for (let i = 0; i < 22; i++) {
        const y = hash(i, 76) * H;
        const start = hash(i, 77) * W;
        this.line(start, y, start + zoom * (120 + hash(i, 78) * 800), y, LIME, zoom * 0.12, 1.5);
      }
    }
  }

  private directions(t: number) {
    const ctx = this.ctx;
    const local = t - 3;
    const burst = smooth(3, 3.56, t);
    for (let i = 0; i < 38; i++) {
      const a = i / 38 * Math.PI * 2;
      const r = 200 + (hash(i, 35) * 850) * burst;
      const endX = 960 + Math.cos(a) * r;
      const endY = 535 + Math.sin(a) * r * 0.58;
      this.line(960 + Math.cos(a) * 26, 535 + Math.sin(a) * 15, endX, endY, i % 5 === 0 ? LIME : WHITE, 0.05 + burst * (i % 5 === 0 ? 0.2 : 0.055), i % 5 === 0 ? 1.9 : 1);
      this.glow(endX, endY, 19, LIME, burst * (i % 6 === 0 ? 0.4 : 0.05));
    }
    ctx.save();
    ctx.globalAlpha *= 1 - smooth(4.25, 4.78, t);
    this.reveal('ONE IDEA.', 153, 539, 224, smooth(3.13, 3.79, t), { tracking: -12 });
    ctx.restore();
    ctx.save();
    ctx.globalAlpha *= smooth(4.07, 4.48, t);
    this.reveal('INFINITE', 148, 477, 171, smooth(4.13, 4.65, t), { color: LIME, tracking: -7 });
    this.reveal('DIRECTIONS.', 143, 710, 207, smooth(4.34, 5.0, t), { tracking: -11 });
    const split = smooth(5.13, 5.93, t);
    for (let i = 1; i <= 4; i++) {
      const displacement = split * i * 62;
      this.text('DIRECTIONS.', 143 + displacement * (i % 2 ? 1 : -0.46), 710 + displacement * (i % 2 ? 0.68 : -0.55), 207, {
        color: i % 2 ? LIME : WHITE, tracking: -11, alpha: split * (0.18 - i * 0.029), stroke: true, lineWidth: 1.6,
      });
    }
    ctx.restore();
    if (local > 2.5) this.glow(960, 540, 350, LIME, smooth(5.5, 6, t) * 0.2);
  }

  private intelligence(t: number) {
    const ctx = this.ctx;
    const inView = smooth(6, 6.7, t);
    ctx.save();
    ctx.translate(960, 540);
    ctx.rotate((t - 6) * 0.12);
    for (let i = 0; i < 5; i++) {
      ctx.strokeStyle = rgba(i === 2 ? LIME : WHITE, (i === 2 ? 0.16 : 0.045) * inView);
      ctx.lineWidth = i === 2 ? 1.6 : 1;
      ctx.beginPath();
      ctx.ellipse(0, 0, 302 + i * 87, 169 + i * 62, -0.3 + i * 0.16, 0, Math.PI * 2);
      ctx.stroke();
      const a = t * (0.6 + i * 0.18) + i * 2;
      this.glow(Math.cos(a) * (302 + i * 87), Math.sin(a) * (169 + i * 62), 45, LIME, inView * 0.42);
    }
    ctx.restore();
    const dark = ctx.createLinearGradient(0, 280, 0, 800);
    dark.addColorStop(0, 'rgba(4,7,5,0)');
    dark.addColorStop(0.25, 'rgba(4,7,5,.60)');
    dark.addColorStop(0.74, 'rgba(4,7,5,.57)');
    dark.addColorStop(1, 'rgba(4,7,5,0)');
    ctx.fillStyle = dark;
    ctx.fillRect(0, 280, W, 520);
    this.reveal('INTELLIGENCE', 960, 543, 185, smooth(6.25, 7.07, t), { align: 'center', tracking: -8 });
    this.reveal('IN MOTION.', 960, 713, 145, smooth(7.15, 8.04, t), { align: 'center', tracking: -4, color: LIME });
    for (let i = 0; i < 13; i++) {
      const x = 238 + i * 120 + Math.sin(i * 8.8) * 22;
      const y = 295 + (i % 4) * 130 + Math.cos(i * 11.2) * 45;
      this.line(x, y, x + 95, y + Math.sin(i * 4.3) * 80, LIME, 0.07 * inView, 1);
    }
  }

  private workspace(t: number) {
    const ctx = this.ctx;
    const enter = smooth(9.02, 9.76, t);
    this.glow(960, 540, 460 * smooth(8.95, 9.35, t), LIME, 0.21 * (1 - smooth(9.5, 10, t)));
    ctx.save();
    ctx.globalAlpha *= enter * (1 - smooth(11.37, 12.02, t));
    ctx.translate(960, 540);
    ctx.scale(0.9 + enter * 0.1, 0.9 + enter * 0.1);
    ctx.translate(-960, -540 + (1 - enter) * 110);
    this.drawWorkspaceFrame(t);
    ctx.restore();

    const build = range(10.04, 11.1, t, 0.2);
    ctx.save();
    ctx.globalAlpha *= build;
    this.reveal('BUILD', 960, 546, 294, smooth(10.1, 10.56, t), { align: 'center', tracking: -16 });
    ctx.restore();
    const fast = range(10.69, 12.0, t, 0.2);
    ctx.save();
    ctx.globalAlpha *= fast;
    const accelerate = smooth(11.25, 12.0, t);
    ctx.translate(960, 595);
    ctx.scale(1 + accelerate * 1.4, 1 + accelerate * 1.4);
    this.reveal('FASTER.', 0, 74, 292, smooth(10.72, 11.26, t), { align: 'center', color: LIME, tracking: -15 });
    ctx.restore();
    if (t > 11.4) {
      const velocity = smooth(11.4, 12.05, t);
      for (let i = 0; i < 28; i++) {
        const y = 150 + hash(i, 40) * 780;
        const x = hash(i, 41) * 1600;
        this.line(x, y, x + velocity * (140 + hash(i, 42) * 950), y, WHITE, velocity * 0.13, 1 + hash(i, 43) * 2);
      }
    }
  }

  private drawWorkspaceFrame(t: number) {
    const ctx = this.ctx;
    const progress = smooth(9.25, 10.1, t);
    this.box(225, 156, 1470, 777, 20, '#111713', 'rgba(220,239,213,.23)');
    ctx.fillStyle = '#151d17';
    ctx.fillRect(227, 228, 223 * progress, 702);
    this.line(225, 227, 1695, 227, WHITE, 0.13);
    this.line(451, 227, 451, 933, WHITE, 0.12);
    this.mark(265, 192, 34);
    this.text('cupric', 294, 201, 29, { weight: 730, tracking: -0.9 });
    this.text('WORKSPACE', 450, 198, 14, { family: 'IBM Plex Mono', weight: 500, tracking: 2.1, color: LIME, alpha: 0.8 });
    this.text('Create', 809, 199, 21, { weight: 620 });
    this.text('Automate', 953, 199, 21, { weight: 490, alpha: 0.48 });
    this.text('Library', 1115, 199, 21, { weight: 490, alpha: 0.48 });
    this.box(1534, 175, 119, 35, 6, '#c8fb45', '');
    this.text('PUBLISH', 1593, 199, 14, { family: 'IBM Plex Mono', align: 'center', weight: 700, color: '#162012', tracking: 0.6 });

    this.text('GENERAL', 254, 283, 15, { family: 'IBM Plex Mono', color: LIME, alpha: 0.66, tracking: 1.4, weight: 500 });
    ['Overview', 'Projects', 'Generations', 'Components'].forEach((item, i) => {
      if (i === 1) this.box(237, 281 + i * 58, 197, 45, 7, 'rgba(201,251,69,.09)', '');
      this.box(256, 306 + i * 58, 15, 15, 3, i === 1 ? LIME : '#4f6255', '');
      this.text(item, 290, 321 + i * 58, 19, { weight: i === 1 ? 660 : 500, alpha: i === 1 ? 1 : 0.52 });
    });
    this.text('YOUR SPACE', 254, 632, 15, { family: 'IBM Plex Mono', color: LIME, alpha: 0.66, tracking: 1.4, weight: 500 });
    this.text('Untitled concept', 255, 683, 18, { weight: 500, alpha: 0.65 });
    this.text('Launch collection', 255, 733, 18, { weight: 500, alpha: 0.45 });
    this.text('Settings', 255, 885, 18, { weight: 500, alpha: 0.4 });

    this.text('PROJECT  /  UNTITLED CONCEPT', 496, 281, 16, { family: 'IBM Plex Mono', color: LIME, tracking: 1.5, weight: 500, alpha: 0.77 });
    this.text('Build the next thing.', 496, 345, 59, { weight: 690, tracking: -2.8 });
    this.text('An intelligent space for everything you imagine.', 498, 382, 21, { weight: 450, alpha: 0.52 });
    this.box(496, 417, 754, 438, 11, '#0a100c', 'rgba(228,245,214,.13)');
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(498, 419, 750, 434, 10);
    ctx.clip();
    const gradient = ctx.createRadialGradient(879, 636, 1, 879, 636, 445);
    gradient.addColorStop(0, '#26331c');
    gradient.addColorStop(0.48, '#121e14');
    gradient.addColorStop(1, '#090f0b');
    ctx.fillStyle = gradient;
    ctx.fillRect(498, 419, 750, 434);
    for (let i = 0; i < 9; i++) {
      const radius = (35 + i * 37) * progress;
      ctx.strokeStyle = rgba(i === 4 ? LIME : WHITE, i === 4 ? 0.35 : 0.11);
      ctx.lineWidth = i === 4 ? 2 : 1;
      ctx.beginPath();
      ctx.ellipse(870, 615, radius, radius * 0.45, t * 0.09 + i * 0.19, 0, Math.PI * 2);
      ctx.stroke();
    }
    this.glow(870, 620, 160, LIME, 0.35);
    this.mark(870, 616, 74, progress);
    ctx.restore();
    this.text('LIVE CANVAS', 524, 454, 15, { family: 'IBM Plex Mono', weight: 500, tracking: 1.5, alpha: 0.65 });
    this.text('01 / 03', 1217, 824, 15, { family: 'IBM Plex Mono', weight: 500, align: 'right', alpha: 0.53 });

    this.box(1273, 417, 378, 438, 11, '#192119', 'rgba(228,245,214,.13)');
    this.text('AI COLLABORATOR', 1300, 457, 15, { family: 'IBM Plex Mono', tracking: 1.3, color: LIME, weight: 500 });
    this.line(1300, 479, 1623, 479, WHITE, 0.14);
    this.text('From thought', 1300, 537, 32, { weight: 650, tracking: -0.8 });
    this.text('to tangible.', 1300, 574, 32, { weight: 650, tracking: -0.8 });
    this.text('Design, develop and deploy', 1300, 621, 17, { weight: 440, alpha: 0.54 });
    this.text('at the speed of your ideas.', 1300, 648, 17, { weight: 440, alpha: 0.54 });
    ['Understanding intent', 'Building structure', 'Refining output'].forEach((item, i) => {
      const active = progress > (i + 1) * 0.22;
      this.box(1302, 684 + i * 44, 15, 15, 7, active ? LIME : '#38473a', '');
      this.text(item, 1330, 698 + i * 44, 16, { weight: 490, alpha: active ? 0.8 : 0.35 });
    });
    this.text('ALL SYSTEMS IN MOTION', 497, 901, 14, { family: 'IBM Plex Mono', tracking: 1.8, weight: 500, alpha: 0.4 });
  }

  private promptToProduct(t: number) {
    const ctx = this.ctx;
    const intro = smooth(12, 12.35, t);
    ctx.save();
    ctx.globalAlpha *= intro;
    this.box(191, 155, 1538, 780, 18, '#101612', 'rgba(228,244,218,.20)');
    this.line(192, 233, 1728, 233, WHITE, 0.14);
    this.mark(246, 194, 36);
    this.text('cupric', 276, 204, 31, { weight: 740, tracking: -1.5 });
    this.text('/ CREATE', 418, 202, 18, { family: 'IBM Plex Mono', tracking: 1.1, weight: 500, color: LIME });
    this.text('NEW PROJECT', 1679, 201, 16, { family: 'IBM Plex Mono', weight: 500, align: 'right', tracking: 1.1, alpha: 0.46 });

    this.text('Start with an idea.', 246, 286, 27, { weight: 640, tracking: -0.5 });
    this.box(245, 309, 1430, 87, 10, '#1a221b', 'rgba(207,247,173,.27)');
    this.mark(286, 353, 27);
    const prompt = 'Build something people will remember.';
    const typed = Math.min(prompt.length, Math.floor(smooth(12.3, 13.19, t) * (prompt.length + 1)));
    this.text(`“${prompt.slice(0, typed)}${typed === prompt.length ? '”' : ''}`, 325, 367, 32, { weight: 450, tracking: -0.5 });
    if (typed < prompt.length && Math.floor(t * 5) % 2 === 0) {
      this.font(32, 450);
      const cursor = 325 + ctx.measureText(`“${prompt.slice(0, typed)}`).width;
      this.line(cursor, 337, cursor, 370, LIME, 0.9, 2);
    }
    this.box(1580, 325, 75, 55, 7, LIME, '');
    this.text('↗', 1617, 363, 30, { color: '#0c160b', weight: 580, align: 'center' });

    const generated = smooth(13.13, 13.95, t);
    ctx.save();
    ctx.globalAlpha *= generated;
    ctx.translate(0, (1 - generated) * 95);
    this.box(245, 421, 846, 446, 10, '#0d110e', 'rgba(227,241,220,.15)');
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(247, 423, 842, 442, 9);
    ctx.clip();
    this.drawCover(this.productImage, 247, 423, 842, 442);
    const shade = ctx.createLinearGradient(247, 423, 800, 866);
    shade.addColorStop(0, 'rgba(3,7,5,.34)');
    shade.addColorStop(0.5, 'rgba(3,7,5,.03)');
    shade.addColorStop(1, 'rgba(3,7,5,.73)');
    ctx.fillStyle = shade;
    ctx.fillRect(247, 423, 842, 442);
    ctx.restore();
    this.text('FORM / 001', 281, 465, 15, { family: 'IBM Plex Mono', tracking: 1.8, weight: 500 });
    this.text('THE FUTURE', 280, 787, 59, { weight: 720, tracking: -2.6 });
    this.text('IS YOURS TO MAKE.', 280, 833, 29, { weight: 540, tracking: -0.6 });

    this.box(1114, 421, 561, 446, 10, '#1a211b', 'rgba(227,241,220,.15)');
    this.text('GENERATED OUTPUT', 1143, 459, 15, { family: 'IBM Plex Mono', weight: 500, color: LIME, tracking: 1.5 });
    this.line(1142, 483, 1645, 483, WHITE, 0.13);
    const modules = [
      ['01', 'Visual identity', 'Brand system ready'],
      ['02', 'Digital experience', 'Responsive layout built'],
      ['03', 'Content architecture', '8 modules generated'],
      ['04', 'Launch assets', 'Ready to refine'],
    ];
    modules.forEach(([number, title, description], i) => {
      const show = smooth(13.26 + i * 0.13, 13.62 + i * 0.13, t);
      ctx.save();
      ctx.globalAlpha *= show;
      this.text(number, 1144, 531 + i * 82, 16, { family: 'IBM Plex Mono', color: LIME, weight: 500 });
      this.text(title, 1201, 531 + i * 82, 25, { weight: 610, tracking: -0.5 });
      this.text(description, 1202, 554 + i * 82, 16, { weight: 440, alpha: 0.46 });
      this.line(1143, 572 + i * 82, 1643, 572 + i * 82, WHITE, 0.11);
      ctx.restore();
    });
    ctx.restore();
    this.text('CUPRIC / CREATION ENGINE', 247, 907, 15, { family: 'IBM Plex Mono', weight: 500, tracking: 1.5, alpha: 0.42 });
    ctx.restore();

    const from = range(12.05, 13.17, t, 0.24);
    this.reveal('FROM PROMPT', 960, 1019, 101, smooth(12.09, 12.55, t), { align: 'center', alpha: from, tracking: -4 });
    const to = range(13.83, 15.1, t, 0.22);
    this.reveal('TO PRODUCT.', 960, 1019, 113, smooth(13.89, 14.47, t), { align: 'center', color: LIME, alpha: to, tracking: -5 });
  }

  private automation(t: number) {
    const ctx = this.ctx;
    const local = t - 15;
    const chaos = 1 - smooth(16.0, 16.65, t);
    ctx.save();
    ctx.globalAlpha *= chaos;
    for (let i = 0; i < 18; i++) {
      const col = i % 6;
      const row = Math.floor(i / 6);
      const x = 145 + col * 275 + Math.sin(local * 12 + i * 5) * (4 + local * 3);
      const y = 199 + row * 224 + Math.cos(local * 10 + i * 3) * 5;
      this.box(x, y, 248, 190, 6, '#151c17', 'rgba(216,235,206,.18)');
      this.line(x, y + 38, x + 248, y + 38, WHITE, 0.17);
      this.box(x + 15, y + 13, 11, 11, 2, i % 5 === 0 ? LIME : '#526455', '');
      this.text('TASK_' + String(i + 1).padStart(3, '0'), x + 39, y + 25, 13, { family: 'IBM Plex Mono', tracking: 0.8, weight: 500, alpha: 0.65 });
      for (let j = 0; j < 4; j++) {
        this.box(x + 18, y + 57 + j * 28, 100 + hash(i * 9 + j, 92) * 99, 5, 2, j === 3 && i % 4 === 0 ? '#a0c24d' : '#465449', '');
        this.box(x + 214, y + 56 + j * 28, 13, 13, 6, j < 2 ? LIME : '#354338', '');
      }
    }
    ctx.restore();
    this.reveal('LESS REPETITION.', 960, 330, 155, smooth(15.16, 15.85, t), { align: 'center', tracking: -7, alpha: range(15.09, 16.74, t, 0.28) });

    const order = smooth(16.08, 16.78, t);
    ctx.save();
    ctx.globalAlpha *= order;
    const gradient = ctx.createLinearGradient(200, 0, 1700, 0);
    gradient.addColorStop(0, 'rgba(200,251,69,.13)');
    gradient.addColorStop(0.5, 'rgba(200,251,69,.8)');
    gradient.addColorStop(1, 'rgba(200,251,69,.13)');
    ctx.strokeStyle = gradient;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(246, 547);
    ctx.bezierCurveTo(630, 547, 1220, 547, 1674, 547);
    ctx.stroke();
    const labels = ['INTENT', 'REASON', 'CREATE', 'LAUNCH'];
    labels.forEach((label, i) => {
      const x = 325 + i * 420;
      this.glow(x, 547, 110, LIME, 0.3);
      this.box(x - 42, 505, 84, 84, 16, '#1b2919', 'rgba(200,251,69,.55)');
      this.mark(x, 547, 34, 1, i === 2 ? 1 : 0.5);
      this.text(label, x, 634, 19, { family: 'IBM Plex Mono', tracking: 2, align: 'center', weight: 500, alpha: 0.68 });
    });
    const traveler = 246 + smooth(16.2, 17.8, t) * 1428;
    this.glow(traveler, 547, 90, LIME, 0.55);
    ctx.fillStyle = LIME;
    ctx.beginPath();
    ctx.arc(traveler, 547, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    const more = range(16.51, 18.2, t, 0.3);
    this.reveal('MORE CREATION.', 960, 839, 178, smooth(16.6, 17.35, t), { align: 'center', color: LIME, tracking: -7, alpha: more });
  }

  private acceleration(t: number) {
    const ctx = this.ctx;
    ctx.fillStyle = rgba('#030503', smooth(18, 18.23, t) * 0.78);
    ctx.fillRect(0, 0, W, H);
    const before = 1 - smooth(19.05, 19.36, t);
    ctx.save();
    ctx.globalAlpha *= before;
    const impact = smooth(18.12, 18.35, t);
    const size = mix(490, 620, easeOut(impact));
    this.text('10×', 960, 752, size + 17, { align: 'center', tracking: -37, color: LIME, alpha: 0.16, stroke: true, lineWidth: 2.2 });
    this.text('10×', 960, 752, size, { align: 'center', tracking: -37, color: WHITE, weight: 900, alpha: impact });
    ctx.restore();
    if (t > 19.07) {
      const explosion = clamp((t - 19.12) / 1.28);
      const converge = smooth(20.37, 21.4, t);
      for (const fragment of this.fragments) {
        const x = fragment.x + fragment.vx * explosion * explosion;
        const y = fragment.y + fragment.vy * explosion * explosion;
        const targets = [[550, 460], [1370, 480], [960, 765]];
        const finalX = targets[fragment.group][0] + (hash(fragment.x, 1) - 0.5) * 280;
        const finalY = targets[fragment.group][1] + (hash(fragment.y, 2) - 0.5) * 230;
        const px = mix(x, finalX, converge);
        const py = mix(y, finalY, converge);
        if (px < -20 || px > W + 20 || py < -20 || py > H + 20) continue;
        ctx.save();
        ctx.translate(px, py);
        ctx.rotate(fragment.rotation * explosion);
        ctx.fillStyle = rgba(fragment.lime ? LIME : WHITE, (1 - converge * 0.32) * (0.35 + hash(fragment.x, 3) * 0.6));
        ctx.fillRect(-fragment.size / 2, -fragment.size / 2, fragment.size * (1 + explosion * 1.8), fragment.size * 0.58);
        ctx.restore();
      }
      this.glow(960, 550, 650 * explosion, LIME, (1 - explosion) * 0.3);
    }
    const shock = smooth(18.2, 18.52, t) * (1 - smooth(18.52, 18.8, t));
    ctx.strokeStyle = rgba(LIME, shock * 0.62);
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(960, 540, 150 + shock * 850, 70 + shock * 400, 0, 0, Math.PI * 2);
    ctx.stroke();
  }

  private connections(t: number) {
    const ctx = this.ctx;
    const converge = smooth(21.65, 23.28, t);
    const anchors = [[470, 441], [1450, 448], [960, 755]];
    ctx.save();
    ctx.strokeStyle = rgba(LIME, 0.14 + converge * 0.24);
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 3; i++) {
      const a = anchors[i];
      const b = anchors[(i + 1) % 3];
      ctx.beginPath();
      ctx.moveTo(a[0], a[1]);
      ctx.quadraticCurveTo(960, 475 + Math.sin(t + i) * 90, mix(a[0], b[0], converge), mix(a[1], b[1], converge));
      ctx.stroke();
      this.glow(a[0], a[1], 150, LIME, 0.18);
    }
    ctx.restore();
    this.reveal('IDEAS', 960, 473, 242, smooth(21.22, 21.96, t), { align: 'center', tracking: -14, alpha: 1 - smooth(22.52, 23.03, t) });
    this.reveal('CONNECT.', 960, 707, 234, smooth(22.16, 22.92, t), { align: 'center', color: LIME, tracking: -13 });
    const light = smooth(23.1, 23.75, t);
    this.glow(960, 540, 460, LIME, light * 0.19);
  }

  private kineticWord(word: string, x: number, y: number, size: number, angle: number, start: number, t: number, outline: boolean, lime: boolean) {
    const ctx = this.ctx;
    const enter = smooth(start, start + 0.4, t);
    const exit = smooth(25.37, 26.02, t);
    if (enter <= 0 || exit >= 1) return;
    ctx.save();
    ctx.globalAlpha *= enter * (1 - exit);
    const destinationX = 960;
    const destinationY = 570;
    ctx.translate(mix(x + (1 - enter) * (x < 960 ? -340 : 340), destinationX, exit), mix(y + (1 - enter) * 125, destinationY, exit));
    ctx.rotate(angle * (1 - exit));
    ctx.scale(1 - exit * 0.48, 1 - exit * 0.48);
    this.text(word, 0, 0, size, { align: 'center', tracking: -size * 0.04, color: lime ? LIME : WHITE, stroke: outline, lineWidth: 2, weight: 850 });
    ctx.restore();
  }

  private noise(t: number) {
    const ctx = this.ctx;
    const names: [string, number, number, number, number, number, boolean, boolean][] = [
      ['THINK', 425, 329, 199, -0.08, 24.08, false, false],
      ['BUILD', 1455, 308, 219, 0.08, 24.30, true, true],
      ['TEST', 710, 592, 216, 0.09, 24.50, true, false],
      ['CREATE', 1305, 619, 173, -0.06, 24.68, false, false],
      ['ITERATE', 490, 838, 145, 0.05, 24.85, true, true],
      ['LAUNCH', 1470, 847, 182, -0.06, 25.02, false, false],
    ];
    for (const [word, x, y, size, angle, start, outline, lime] of names) {
      this.kineticWord(word, x, y, size, angle, start, t, outline, lime);
    }
    const velocity = smooth(24, 25, t) * (1 - smooth(25.6, 26.25, t));
    for (let i = 0; i < 33; i++) {
      const y = hash(i, 61) * H;
      const startX = (hash(i, 62) * 2400 + t * (120 + hash(i, 63) * 200)) % 2200 - 150;
      this.line(startX, y, startX + (i % 2 ? -1 : 1) * 170, y, i % 6 === 0 ? LIME : WHITE, velocity * 0.11, 1);
    }
    const make = smooth(25.68, 26.19, t);
    const hold = 1 - smooth(26.7, 27.17, t);
    ctx.save();
    ctx.globalAlpha *= make * hold;
    ctx.translate(960, 520);
    ctx.scale(mix(1.16, 1, easeOut(make)), mix(1.16, 1, easeOut(make)));
    this.text('MAKE', 0, -15, 247, { align: 'center', tracking: -15 });
    this.text('NOISE.', 0, 222, 270, { align: 'center', tracking: -14, color: LIME });
    ctx.restore();
  }

  private humanMachine(t: number) {
    const ctx = this.ctx;
    const local = t - 27;
    const left = ctx.createLinearGradient(0, 0, 960, 0);
    left.addColorStop(0, '#10130f');
    left.addColorStop(1, '#111b12');
    ctx.fillStyle = left;
    ctx.fillRect(0, 0, 960, H);
    const right = ctx.createLinearGradient(960, 0, W, 0);
    right.addColorStop(0, '#0d170e');
    right.addColorStop(1, '#08100a');
    ctx.fillStyle = right;
    ctx.fillRect(960, 0, 960, H);
    this.line(960, 0, 960, H, LIME, 0.16);

    const intent = smooth(27.18, 28.46, t);
    ctx.save();
    ctx.lineCap = 'round';
    for (let i = 0; i < 7; i++) {
      const offset = i * 42;
      ctx.beginPath();
      ctx.moveTo(114 + offset * 0.3, 780 - offset * 0.85);
      ctx.bezierCurveTo(348 + offset * 0.3, 178 + i * 28, 513 + offset * 0.33, 899 - i * 58, 960 - (1 - intent) * (130 + i * 46), 540 + (i - 3) * 17);
      ctx.strokeStyle = rgba(i === 4 ? LIME : WHITE, intent * (i === 4 ? 0.52 : 0.12));
      ctx.lineWidth = i === 4 ? 3 : 1.5;
      ctx.stroke();
    }
    ctx.restore();

    const machine = smooth(27.62, 28.71, t);
    for (let row = 0; row < 21; row++) {
      const y = 188 + row * 34;
      const end = 960 + (1 - machine) * 220;
      this.line(1769 - hash(row, 81) * 300, y, end, y + Math.sin(row * 2.4) * 6, row % 4 === 0 ? LIME : WHITE, machine * (row % 4 === 0 ? 0.32 : 0.11), row % 4 === 0 ? 1.7 : 1);
      for (let col = 0; col < 9; col++) {
        const x = 1020 + col * 89;
        if (hash(row * 20 + col, 82) > 0.37) {
          ctx.fillStyle = rgba(row % 4 === 0 ? LIME : WHITE, machine * (row % 4 === 0 ? 0.58 : 0.21));
          ctx.fillRect(x, y - 2, row % 4 === 0 ? 5 : 3, row % 4 === 0 ? 5 : 3);
        }
      }
    }
    this.glow(960, 540, 50 + smooth(28.15, 29.45, t) * 365, LIME, smooth(28.15, 29.25, t) * 0.42);
    ctx.fillStyle = LIME;
    ctx.beginPath();
    ctx.arc(960, 540, 3 + smooth(28.35, 29.3, t) * 8, 0, Math.PI * 2);
    ctx.fill();

    const merge = smooth(29.02, 29.7, t);
    this.reveal('HUMAN INTENT.', mix(140, 960, merge), 920 - merge * 103, 88 - merge * 18, smooth(27.16, 27.83, t), {
      align: merge > 0.5 ? 'center' : 'left', tracking: -3, alpha: 1 - merge * 0.82,
    });
    this.reveal('MACHINE SPEED.', mix(1780, 960, merge), 920 - merge * 17, 88 - merge * 18, smooth(28.05, 28.74, t), {
      align: merge > 0.5 ? 'center' : 'right', tracking: -3, color: LIME, alpha: 1 - merge * 0.82,
    });
    ctx.save();
    ctx.globalAlpha *= smooth(29.2, 29.7, t);
    this.text('HUMAN INTENT.  MACHINE SPEED.', 960, 873, 71, { align: 'center', tracking: -2.5 });
    ctx.restore();
    if (local > 2.7) this.glow(960, 540, 560, LIME, smooth(29.7, 30.06, t) * 0.2);
  }

  private future(t: number) {
    const ctx = this.ctx;
    const fade = ctx.createLinearGradient(0, 0, 1200, 0);
    fade.addColorStop(0, 'rgba(3,6,4,.79)');
    fade.addColorStop(0.4, 'rgba(3,6,4,.44)');
    fade.addColorStop(1, 'rgba(3,6,4,0)');
    ctx.fillStyle = fade;
    ctx.fillRect(0, 0, 1300, H);
    const rays = smooth(30, 31.3, t);
    for (let i = 0; i < 28; i++) {
      const x = 960 + (i - 14) * 87;
      this.line(960, 720, x, 1070, LIME, rays * 0.025, 1);
    }
    this.reveal('BUILD', 154, 521, 286, smooth(30.18, 30.85, t), { tracking: -15, alpha: 1 - smooth(31.1, 31.55, t) });
    this.reveal("WHAT'S NEXT.", 147, 735, 207, smooth(31.17, 31.92, t), { tracking: -11, color: WHITE });
    this.line(153, 781, 685 + smooth(31.45, 32.36, t) * 577, 781, LIME, 0.72, 3);
    this.glow(1180, 594, 530, LIME, smooth(31.0, 32.8, t) * 0.1);
  }

  private brand(x: number, y: number, size: number, progress = 1, alpha = 1) {
    const ctx = this.ctx;
    ctx.save();
    ctx.globalAlpha *= alpha;
    const markSize = size * 0.86;
    const gap = size * 0.15;
    const gapAI = size * 0.12;
    this.font(size, 820);
    const cupricWidth = ctx.measureText('CUPRIC').width - size * 0.18;
    const aiWidth = ctx.measureText('AI').width - size * 0.04;
    const total = markSize + gap + cupricWidth + gapAI + aiWidth;
    const left = x - total / 2;
    const markX = left + markSize / 2;
    this.mark(markX, y - size * 0.35, markSize, progress);
    ctx.beginPath();
    ctx.rect(left + markSize + gap - 3, y - size * 1.25, (total - markSize - gap + 30) * smooth(0.1, 1, progress), size * 1.58);
    ctx.clip();
    this.text('CUPRIC', left + markSize + gap, y, size, { weight: 820, tracking: -size * 0.036 });
    this.text('AI', left + markSize + gap + cupricWidth + gapAI, y, size, { weight: 820, tracking: -size * 0.025, color: LIME });
    ctx.restore();
  }

  private brandReveal(t: number) {
    const ctx = this.ctx;
    const blackout = smooth(32.9, 33.38, t);
    ctx.fillStyle = rgba('#030503', blackout * 0.97);
    ctx.fillRect(0, 0, W, H);
    const point = smooth(33.1, 33.55, t) * (1 - smooth(34.05, 34.5, t));
    this.glow(960, 539, 270, LIME, 0.36 * point);
    const lineDraw = smooth(33.35, 34.1, t);
    const lineFade = 1 - smooth(34.1, 34.65, t);
    this.line(960 - lineDraw * 485, 540, 960 + lineDraw * 485, 540, LIME, lineFade * 0.9, 2.5);
    this.glow(960 + lineDraw * 485, 540, 84, LIME, lineFade * 0.7);
    const identity = smooth(34.04, 35.14, t);
    ctx.save();
    ctx.globalAlpha *= identity;
    this.glow(960, 526, 530, LIME, 0.11 * identity);
    this.brand(960, 626, 218, identity);
    ctx.restore();
  }

  private statement(t: number) {
    const ctx = this.ctx;
    ctx.fillStyle = rgba('#030503', 0.94);
    ctx.fillRect(0, 0, W, H);
    this.glow(960 + Math.sin(t * 0.38) * 35, 480, 530, LIME, 0.095);
    for (let i = 0; i < 65; i++) {
      const x = hash(i, 33) * W;
      const y = hash(i, 34) * H + Math.sin(t * 0.4 + i) * 8;
      ctx.fillStyle = rgba(i % 9 === 0 ? LIME : WHITE, 0.06 + hash(i, 35) * 0.16);
      ctx.fillRect(x, y, 1.5 + hash(i, 36), 1.5 + hash(i, 36));
    }
    this.brand(960, 498, 158, 1);
    const reveal = smooth(36.22, 36.88, t);
    this.line(727, 591, 727 + reveal * 466, 591, LIME, 0.52, 1.5);
    this.reveal('INTELLIGENCE FOR PEOPLE WHO BUILD.', 960, 687, 62, reveal, {
      align: 'center', weight: 580, tracking: 0.2,
    });
  }

  private endCard(t: number) {
    const ctx = this.ctx;
    ctx.fillStyle = '#030503';
    ctx.fillRect(0, 0, W, H);
    const appear = smooth(38.05, 38.63, t);
    const depart = 1 - smooth(39.53, DURATION, t);
    ctx.save();
    ctx.globalAlpha *= appear * depart;
    const push = 1 + smooth(38.1, 39.7, t) * 0.027;
    ctx.translate(960, 520);
    ctx.scale(push, push);
    ctx.translate(-960, -520);
    this.glow(960, 488, 610, LIME, 0.11);
    this.brand(960, 493, 182, 1);
    this.text('INTELLIGENCE FOR PEOPLE WHO BUILD.', 960, 638, 54, { align: 'center', weight: 530, tracking: 0.2 });
    this.line(860, 691, 1060, 691, LIME, 0.5, 1.5);
    this.text('CREATE WITHOUT LIMITS.', 960, 760, 34, { align: 'center', color: LIME, family: 'IBM Plex Mono', weight: 500, tracking: 3.5 });
    ctx.restore();
  }

  private transitionLights(t: number) {
    const transitions = [3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 38];
    for (let i = 0; i < transitions.length; i++) {
      const time = transitions[i];
      const pulse = smooth(time - 0.11, time + 0.02, t) * (1 - smooth(time + 0.02, time + 0.32, t));
      if (pulse < 0.001) continue;
      const x = i % 3 === 0 ? 960 : i % 3 === 1 ? 1420 : 550;
      this.glow(x, 540, 700, LIME, pulse * (time === 18 || time === 33 ? 0.14 : 0.06));
      this.line(0, 540 + i * 13, W, 540 + i * 13, LIME, pulse * 0.1, 1);
    }
  }

  private finish(t: number) {
    const ctx = this.ctx;
    const vignette = ctx.createRadialGradient(960, 500, 360, 960, 500, 1200);
    vignette.addColorStop(0, 'rgba(0,0,0,0)');
    vignette.addColorStop(0.55, 'rgba(0,0,0,.08)');
    vignette.addColorStop(1, 'rgba(0,0,0,.56)');
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, W, H);
    if (t > 0.13 && t < 39.55) {
      ctx.save();
      ctx.globalAlpha = 0.1;
      const shift = Math.floor(t * 30) % 4;
      for (let y = -256; y < H + 256; y += 256) {
        for (let x = -256; x < W + 256; x += 256) ctx.drawImage(this.grain, x + shift * 13, y + shift * 7);
      }
      ctx.restore();
    }
    if (t >= 39.55) {
      ctx.fillStyle = rgba('#030503', smooth(39.55, 40, t));
      ctx.fillRect(0, 0, W, H);
    }
  }

  render(time: number) {
    const t = clamp(time, 0, DURATION);
    const ctx = this.ctx;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    ctx.filter = 'none';
    this.atmosphere(t);
    const scenes = [
      this.hook, this.directions, this.intelligence, this.workspace,
      this.promptToProduct, this.automation, this.acceleration, this.connections,
      this.noise, this.humanMachine, this.future, this.brandReveal,
      this.statement, this.endCard,
    ];
    scenes.forEach((draw, index) => {
      if (t < sceneTimes[index] - 0.2 || t > sceneTimes[index + 1] + 0.2) return;
      const alpha = this.sceneAlpha(index, t);
      if (alpha <= 0.001) return;
      ctx.save();
      ctx.globalAlpha *= alpha;
      draw.call(this, t);
      ctx.restore();
    });
    this.transitionLights(t);
    this.frameDetails(t);
    this.finish(t);
  }

  dispose() {
    this.world?.dispose();
  }

  refreshTypography() {
    this.makeFragments();
  }
}
import * as THREE from 'three';
import { easeOut, hash, mix, smooth } from './math';

const COUNT = 2600;
const BOUNDARIES = [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 38, 40];

type PositionSet = Float32Array;

export class ThreeWorld {
  readonly canvas: HTMLCanvasElement;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(48, 16 / 9, 0.1, 150);
  private particleGeometry = new THREE.BufferGeometry();
  private particleMaterial: THREE.ShaderMaterial;
  private particles: THREE.Points;
  private positions = new Float32Array(COUNT * 3);
  private profiles: PositionSet[] = [];
  private connectionGeometry = new THREE.BufferGeometry();
  private connectionMaterial = new THREE.LineBasicMaterial({
    color: 0xc8fb45,
    transparent: true,
    opacity: 0,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  private connections: THREE.LineSegments;
  private connectionPositions = new Float32Array(1100 * 6);
  private networkEdges: [number, number][] = [];
  private crystals = new THREE.Group();
  private crystalSolids: THREE.Mesh[] = [];
  private crystalEdges: THREE.LineSegments[] = [];
  private city = new THREE.Group();
  private buildings!: THREE.InstancedMesh;
  private buildingData: { x: number; z: number; height: number; width: number; depth: number; delay: number }[] = [];
  private cityGrid!: THREE.GridHelper;
  private citySlabs: THREE.Group[] = [];
  private dummy = new THREE.Object3D();

  constructor() {
    this.renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    this.renderer.setSize(1600, 900, false);
    this.renderer.setPixelRatio(1);
    this.renderer.setClearColor(0x050705, 0);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.75;
    this.canvas = this.renderer.domElement;

    this.scene.add(new THREE.AmbientLight(0xdce9d2, 1.1));
    const limeLight = new THREE.PointLight(0xc8fb45, 50, 30);
    limeLight.position.set(-5, 6, 7);
    this.scene.add(limeLight);
    const whiteLight = new THREE.PointLight(0xffffff, 28, 35);
    whiteLight.position.set(7, 7, -8);
    this.scene.add(whiteLight);

    this.makeProfiles();
    this.makeNetworkEdges();

    const scales = new Float32Array(COUNT);
    const tones = new Float32Array(COUNT);
    const indices = new Float32Array(COUNT);
    for (let i = 0; i < COUNT; i++) {
      scales[i] = 0.35 + hash(i, 19) * 1.3;
      tones[i] = hash(i, 24) > 0.78 ? 1 : hash(i, 24) * 0.2;
      indices[i] = i;
    }
    this.particleGeometry.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
    this.particleGeometry.setAttribute('aScale', new THREE.BufferAttribute(scales, 1));
    this.particleGeometry.setAttribute('aTone', new THREE.BufferAttribute(tones, 1));
    this.particleGeometry.setAttribute('aIndex', new THREE.BufferAttribute(indices, 1));
    this.particleMaterial = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uOpacity: { value: 0 },
        uTime: { value: 0 },
      },
      vertexShader: `
        attribute float aScale;
        attribute float aTone;
        attribute float aIndex;
        uniform float uTime;
        varying float vTone;
        void main() {
          vTone = aTone;
          vec3 p = position;
          p.x += sin(uTime * .53 + aIndex * 1.73) * .035;
          p.y += cos(uTime * .41 + aIndex * .92) * .035;
          vec4 view = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * view;
          gl_PointSize = clamp(aScale * (52.0 / max(1.0, -view.z)), 1.0, 7.0);
        }
      `,
      fragmentShader: `
        uniform float uOpacity;
        varying float vTone;
        void main() {
          float d = length(gl_PointCoord - vec2(.5)) * 2.0;
          float halo = pow(max(0.0, 1.0 - d), 1.4);
          float core = 1.0 - smoothstep(.04, .32, d);
          vec3 color = mix(vec3(.69, .74, .68), vec3(.75, 1.0, .20), vTone);
          gl_FragColor = vec4(color, (halo * .54 + core * .7) * uOpacity);
        }
      `,
    });
    this.particles = new THREE.Points(this.particleGeometry, this.particleMaterial);
    this.particles.frustumCulled = false;
    this.scene.add(this.particles);

    this.connectionGeometry.setAttribute('position', new THREE.BufferAttribute(this.connectionPositions, 3));
    this.connectionGeometry.setDrawRange(0, 0);
    this.connections = new THREE.LineSegments(this.connectionGeometry, this.connectionMaterial);
    this.connections.frustumCulled = false;
    this.scene.add(this.connections);

    this.makeCrystals();
    this.makeCity();
  }

  private makeProfiles() {
    for (let mode = 0; mode < 14; mode++) {
      const arr = new Float32Array(COUNT * 3);
      for (let i = 0; i < COUNT; i++) {
        const p = i / COUNT;
        const r1 = hash(i, 1);
        const r2 = hash(i, 2);
        const r3 = hash(i, 3);
        let x = 0;
        let y = 0;
        let z = 0;
        if (mode === 0) {
          const a = i * 2.39996;
          const radius = Math.sqrt(p) * 5.7;
          x = Math.cos(a) * radius;
          y = Math.sin(a) * radius * 0.7;
          z = Math.sin(a * 0.39) * 1.3 + (r3 - 0.5) * 5;
        } else if (mode === 1) {
          const branch = i % 32;
          const along = Math.floor(i / 32) / Math.ceil(COUNT / 32);
          const a = (branch / 32) * Math.PI * 2 + Math.sin(along * 4 + branch) * 0.16;
          const radius = (5 + hash(branch, 8) * 3.8) * along;
          x = Math.cos(a) * radius;
          y = Math.sin(a) * radius * 0.57;
          z = 2 - along * 10 + (r3 - 0.5) * 0.5;
        } else if (mode === 2) {
          const v = 1 - 2 * (p + 0.0002);
          const radius = Math.sqrt(Math.max(0, 1 - v * v));
          const a = i * 2.39996;
          x = Math.cos(a) * radius * 5.1;
          y = v * 3.85;
          z = Math.sin(a) * radius * 4.15;
        } else if (mode === 3 || mode === 4) {
          x = (r1 - 0.5) * 12;
          y = (r2 - 0.5) * 6.7;
          z = -7 + r3 * 2;
        } else if (mode === 5) {
          const lane = i % 8;
          x = -5.5 + lane * 1.55 + (r1 - 0.5) * 0.8;
          y = (r2 - 0.5) * 5;
          z = -6 + r3 * 3;
        } else if (mode === 6) {
          const a = r1 * Math.PI * 2;
          const radius = 3 + r2 * 9;
          x = Math.cos(a) * radius;
          y = Math.sin(a) * radius * 0.65;
          z = (r3 - 0.5) * 12;
        } else if (mode === 7) {
          const cluster = i % 3;
          const centerX = [-4.7, 4.6, 0][cluster];
          const centerY = [0.9, 0.5, -2.2][cluster];
          const a = r1 * Math.PI * 2;
          const v = r2 * 2 - 1;
          const radius = Math.sqrt(1 - v * v) * (0.35 + r3 * 1.65);
          x = centerX + Math.cos(a) * radius;
          y = centerY + v * (0.35 + r3 * 1.65);
          z = Math.sin(a) * radius * 1.2;
        } else if (mode === 8) {
          x = (r1 - 0.5) * 17;
          y = (r2 - 0.5) * 9;
          z = (r3 - 0.5) * 8;
        } else if (mode === 9) {
          const side = i % 2 === 0 ? -1 : 1;
          x = side * (0.15 + r1 * 8);
          y = (r2 - 0.5) * 6;
          z = -3 + r3 * 2;
        } else if (mode === 10) {
          x = (r1 - 0.5) * 16;
          y = -2 + r2 * 7;
          z = -r3 * 24;
        } else if (mode === 11) {
          const a = r1 * Math.PI * 2;
          x = Math.cos(a) * r2 * 0.42;
          y = Math.sin(a) * r2 * 0.42;
          z = (r3 - 0.5) * 0.5;
        } else {
          x = (r1 - 0.5) * 19;
          y = (r2 - 0.5) * 10;
          z = -6 - r3 * 7;
        }
        arr[i * 3] = x;
        arr[i * 3 + 1] = y;
        arr[i * 3 + 2] = z;
      }
      this.profiles.push(arr);
    }
  }

  private makeNetworkEdges() {
    const points = this.profiles[2];
    for (let i = 0; i < 210; i++) {
      const candidates: { j: number; distance: number }[] = [];
      for (let j = i + 1; j < 210; j++) {
        const dx = points[i * 12 * 3] - points[j * 12 * 3];
        const dy = points[i * 12 * 3 + 1] - points[j * 12 * 3 + 1];
        const dz = points[i * 12 * 3 + 2] - points[j * 12 * 3 + 2];
        const distance = dx * dx + dy * dy + dz * dz;
        if (distance < 8) candidates.push({ j, distance });
      }
      candidates.sort((a, b) => a.distance - b.distance);
      for (const candidate of candidates.slice(0, 2)) this.networkEdges.push([i, candidate.j]);
    }
  }

  private makeCrystals() {
    const geometry = new THREE.IcosahedronGeometry(1.6, 1);
    const edgesGeometry = new THREE.EdgesGeometry(geometry, 20);
    for (let i = 0; i < 3; i++) {
      const solid = new THREE.Mesh(
        geometry,
        new THREE.MeshPhysicalMaterial({
          color: i === 1 ? 0x3d5630 : 0x1d2b22,
          metalness: 0.35,
          roughness: 0.16,
          transmission: 0.38,
          thickness: 1.4,
          transparent: true,
          opacity: 0.25,
          side: THREE.DoubleSide,
          depthWrite: false,
        }),
      );
      const edges = new THREE.LineSegments(
        edgesGeometry,
        new THREE.LineBasicMaterial({
          color: i === 1 ? 0xc8fb45 : 0xcdd5ca,
          transparent: true,
          opacity: 0.63,
          depthWrite: false,
        }),
      );
      const group = new THREE.Group();
      group.add(solid, edges);
      this.crystals.add(group);
      this.crystalSolids.push(solid);
      this.crystalEdges.push(edges);
    }
    this.scene.add(this.crystals);
    this.crystals.visible = false;
  }

  private makeCity() {
    const material = new THREE.MeshStandardMaterial({
      color: 0x1c241f,
      metalness: 0.72,
      roughness: 0.28,
      emissive: 0x0c190a,
      emissiveIntensity: 0.25,
    });
    for (let z = 2; z >= -28; z -= 1.36) {
      for (let x = -9; x <= 9; x += 1.36) {
        const seed = (x + 11) * 37 + (z + 30) * 17;
        if (hash(seed, 4) < 0.26 || (Math.abs(x) < 1.2 && z > -16)) continue;
        this.buildingData.push({
          x: x + (hash(seed, 2) - 0.5) * 0.22,
          z: z + (hash(seed, 3) - 0.5) * 0.22,
          height: 0.65 + Math.pow(hash(seed, 5), 1.4) * 6.1,
          width: 0.66 + hash(seed, 8) * 0.35,
          depth: 0.65 + hash(seed, 9) * 0.35,
          delay: hash(seed, 11) * 0.65 + (2 - z) * 0.012,
        });
      }
    }
    this.buildings = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), material, this.buildingData.length);
    this.buildings.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    for (let i = 0; i < this.buildingData.length; i++) {
      const seed = hash(i, 21);
      this.buildings.setColorAt(i, new THREE.Color(seed > 0.91 ? 0x577036 : seed > 0.74 ? 0x344639 : 0x24302a));
    }
    this.buildings.instanceColor!.needsUpdate = true;
    this.buildings.frustumCulled = false;
    this.city.add(this.buildings);

    this.cityGrid = new THREE.GridHelper(65, 48, 0x536c35, 0x28352b);
    this.cityGrid.position.set(0, -3.03, -13);
    const gridMaterial = this.cityGrid.material as THREE.LineBasicMaterial;
    gridMaterial.transparent = true;
    gridMaterial.opacity = 0.33;
    this.city.add(this.cityGrid);

    for (let i = 0; i < 7; i++) {
      const slab = new THREE.Group();
      const plane = new THREE.Mesh(
        new THREE.PlaneGeometry(1.8 + hash(i, 22) * 1.2, 1.1 + hash(i, 23) * 0.7),
        new THREE.MeshBasicMaterial({
          color: i % 3 === 0 ? 0xb7ed51 : 0x85998a,
          transparent: true,
          opacity: 0.055,
          side: THREE.DoubleSide,
          depthWrite: false,
        }),
      );
      const outline = new THREE.LineSegments(
        new THREE.EdgesGeometry(plane.geometry),
        new THREE.LineBasicMaterial({ color: 0xa5c777, transparent: true, opacity: 0.24 }),
      );
      slab.add(plane, outline);
      slab.position.set(i % 2 ? 3.5 + i * 0.45 : -3.5 - i * 0.43, 1.2 + (i % 3) * 1.35, -3 - i * 3.3);
      slab.rotation.y = i % 2 ? -0.28 : 0.28;
      this.city.add(slab);
      this.citySlabs.push(slab);
    }
    this.scene.add(this.city);
    this.city.visible = false;
  }

  private getMode(t: number) {
    let mode = 0;
    for (let i = 0; i < BOUNDARIES.length - 1; i++) {
      if (t >= BOUNDARIES[i]) mode = i;
    }
    return Math.min(mode, 13);
  }

  private updateParticles(t: number, mode: number, blend: number) {
    const a = this.profiles[mode];
    const b = this.profiles[Math.min(mode + 1, 13)];
    const origin = smooth(0.12, 1.15, t);
    const gather = mode === 7 ? 1 - smooth(21.4, 23.55, t) * 0.72 : 1;
    for (let i = 0; i < this.positions.length; i += 3) {
      this.positions[i] = mix(a[i], b[i], blend) * origin * gather;
      this.positions[i + 1] = mix(a[i + 1], b[i + 1], blend) * origin * gather;
      this.positions[i + 2] = mix(a[i + 2], b[i + 2], blend) * origin;
    }
    (this.particleGeometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    const opacity =
      mode <= 2 ? 0.9 :
      mode <= 5 ? 0.16 :
      mode === 6 ? 0.43 :
      mode === 7 ? 0.7 :
      mode === 8 ? 0.23 :
      mode === 9 ? 0.33 :
      mode === 10 ? 0.24 :
      mode === 11 ? 0.25 : 0.16;
    this.particleMaterial.uniforms.uOpacity.value = opacity * (mode === 0 ? origin : 1);
    this.particleMaterial.uniforms.uTime.value = t;
    this.particles.rotation.y = mode === 2 ? t * 0.18 : mode === 7 ? t * 0.09 : t * 0.025;
    this.particles.rotation.z = mode === 0 ? t * 0.11 : mode === 2 ? 0.08 : 0;
  }

  private updateConnections(t: number, mode: number) {
    let segments = 0;
    const add = (ax: number, ay: number, az: number, bx: number, by: number, bz: number) => {
      if (segments >= 1100) return;
      const offset = segments * 6;
      this.connectionPositions[offset] = ax;
      this.connectionPositions[offset + 1] = ay;
      this.connectionPositions[offset + 2] = az;
      this.connectionPositions[offset + 3] = bx;
      this.connectionPositions[offset + 4] = by;
      this.connectionPositions[offset + 5] = bz;
      segments++;
    };
    if (mode === 0) {
      const p = this.profiles[0];
      const grow = smooth(0.3, 1.4, t);
      for (let i = 0; i < 420; i++) {
        const a = (i * 6) % (COUNT - 24);
        const b = a + (i % 3 === 0 ? 21 : 13);
        add(p[a * 3] * grow, p[a * 3 + 1] * grow, p[a * 3 + 2], p[b * 3] * grow, p[b * 3 + 1] * grow, p[b * 3 + 2]);
      }
      this.connectionMaterial.opacity = smooth(0.35, 1.3, t) * 0.12;
    } else if (mode === 1) {
      const growth = smooth(3, 4.5, t);
      for (let branch = 0; branch < 32; branch++) {
        const angle = branch / 32 * Math.PI * 2;
        const radius = 5 + hash(branch, 8) * 3.8;
        for (let i = 0; i < 26; i++) {
          const from = i / 26 * growth;
          const to = (i + 1) / 26 * growth;
          const point = (p: number) => {
            const a = angle + Math.sin(p * 4 + branch) * 0.16;
            return [Math.cos(a) * radius * p, Math.sin(a) * radius * 0.57 * p, 2 - p * 10];
          };
          const a = point(from);
          const b = point(to);
          add(a[0], a[1], a[2], b[0], b[1], b[2]);
        }
      }
      this.connectionMaterial.opacity = 0.34;
    } else if (mode === 2) {
      const p = this.profiles[2];
      for (const [a, b] of this.networkEdges) {
        const ai = a * 12 * 3;
        const bi = b * 12 * 3;
        add(p[ai], p[ai + 1], p[ai + 2], p[bi], p[bi + 1], p[bi + 2]);
      }
      this.connectionMaterial.opacity = 0.28;
    } else if (mode === 7) {
      const p = this.profiles[7];
      const gather = 1 - smooth(21.4, 23.55, t) * 0.72;
      for (let group = 0; group < 3; group++) {
        for (let i = 0; i < 175; i++) {
          const a = i * 3 + group;
          const b = (i + 1) * 3 + group;
          add(p[a * 3] * gather, p[a * 3 + 1] * gather, p[a * 3 + 2], p[b * 3] * gather, p[b * 3 + 1] * gather, p[b * 3 + 2]);
        }
      }
      for (let i = 0; i < 65; i++) {
        const a = i * 3;
        const b = i * 3 + 1;
        add(p[a * 3] * gather, p[a * 3 + 1] * gather, p[a * 3 + 2], p[b * 3] * gather, p[b * 3 + 1] * gather, p[b * 3 + 2]);
        add(p[(a + 2) * 3] * gather, p[(a + 2) * 3 + 1] * gather, p[(a + 2) * 3 + 2], p[b * 3] * gather, p[b * 3 + 1] * gather, p[b * 3 + 2]);
      }
      this.connectionMaterial.opacity = 0.28;
    } else {
      this.connectionMaterial.opacity = 0;
    }
    this.connectionGeometry.setDrawRange(0, segments * 2);
    (this.connectionGeometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    this.connections.rotation.y = mode === 2 ? t * 0.18 : mode === 7 ? t * 0.09 : 0;
    this.connections.rotation.z = mode === 0 ? t * 0.11 : mode === 2 ? 0.08 : 0;
  }

  private updateCrystals(t: number) {
    const visibility = smooth(20.75, 21.5, t) * (1 - smooth(23.45, 24.25, t));
    this.crystals.visible = visibility > 0.002;
    if (!this.crystals.visible) return;
    const converge = smooth(21.5, 23.3, t);
    const starts: [number, number, number][] = [[-4.7, 0.9, -1], [4.6, 0.5, -2], [0, -2.2, 1]];
    this.crystals.children.forEach((group, i) => {
      group.position.set(starts[i][0] * (1 - converge * 0.78), starts[i][1] * (1 - converge * 0.78), starts[i][2] * (1 - converge * 0.5));
      group.rotation.set(t * (i % 2 ? -0.18 : 0.14), t * (i % 2 ? 0.2 : -0.17), t * 0.05);
      group.scale.setScalar(visibility * (0.68 + converge * 0.38));
      (this.crystalEdges[i].material as THREE.LineBasicMaterial).opacity = visibility * (i === 1 ? 0.75 : 0.55);
      (this.crystalSolids[i].material as THREE.MeshPhysicalMaterial).opacity = visibility * 0.26;
    });
  }

  private updateCity(t: number) {
    const appear = smooth(29.8, 30.45, t);
    const vanish = 1 - smooth(32.85, 33.75, t);
    const visible = appear * vanish;
    this.city.visible = visible > 0.002;
    if (!this.city.visible) return;
    const local = t - 30;
    this.city.scale.setScalar(1 - smooth(33, 33.7, t) * 0.97);
    for (let i = 0; i < this.buildingData.length; i++) {
      const data = this.buildingData[i];
      const rise = easeOut(smooth(data.delay, data.delay + 0.9, local)) * visible;
      this.dummy.position.set(data.x, -3 + data.height * rise * 0.5, data.z);
      this.dummy.scale.set(data.width, Math.max(0.001, data.height * rise), data.depth);
      this.dummy.rotation.set(0, 0, 0);
      this.dummy.updateMatrix();
      this.buildings.setMatrixAt(i, this.dummy.matrix);
    }
    this.buildings.instanceMatrix.needsUpdate = true;
    (this.cityGrid.material as THREE.LineBasicMaterial).opacity = visible * 0.34;
    this.citySlabs.forEach((slab, i) => {
      slab.scale.setScalar(smooth(0.25 + i * 0.12, 1.05 + i * 0.12, local) * visible);
      slab.position.y = 1.2 + (i % 3) * 1.35 + Math.sin(t * 0.7 + i) * 0.035;
    });
  }

  render(t: number) {
    const mode = this.getMode(t);
    const end = BOUNDARIES[mode + 1];
    const blend = mode < 13 ? smooth(end - (mode === 2 || mode === 5 ? 0.28 : 0.52), end, t) : 0;
    this.updateParticles(t, mode, blend);
    this.updateConnections(t, mode);
    this.updateCrystals(t);
    this.updateCity(t);

    if (mode === 0) {
      this.camera.position.set(0, 0, mix(20, 8.8, smooth(0.2, 3, t)));
      this.camera.lookAt(0, 0, -1);
    } else if (mode === 1) {
      this.camera.position.set(Math.sin(t * 0.55) * 2.1, Math.sin(t * 0.3) * 0.9, mix(13.5, 7.5, smooth(3, 6, t)));
      this.camera.lookAt(0, 0, -3);
    } else if (mode === 2) {
      this.camera.position.set(Math.sin((t - 6) * 0.55) * 5.2, 1.4 + Math.cos(t) * 0.5, 13.5 - (t - 6) * 0.6);
      this.camera.lookAt(0, 0, 0);
    } else if (mode === 7) {
      this.camera.position.set(Math.sin((t - 21) * 0.4) * 2.4, 0.7, 13 - (t - 21) * 0.7);
      this.camera.lookAt(0, 0, 0);
    } else if (mode === 10) {
      this.camera.position.set(-1.7 + (t - 30) * 0.7, 2.6 + Math.sin(t * 0.7) * 0.2, 13 - (t - 30) * 3.25);
      this.camera.lookAt(0, -0.45, -11 - (t - 30) * 2.5);
    } else {
      this.camera.position.set(0, 0, 15);
      this.camera.lookAt(0, 0, 0);
    }
    this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    this.particleGeometry.dispose();
    this.particleMaterial.dispose();
    this.connectionGeometry.dispose();
    this.connectionMaterial.dispose();
    this.renderer.dispose();
  }
}
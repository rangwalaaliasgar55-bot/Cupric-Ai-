import { clamp, smooth } from './math';

const cues = [
  [0.31, 'spark'], [1.73, 'lift'], [2.93, 'impact'], [3.58, 'tick'],
  [6.02, 'lift'], [8.94, 'impact'], [9.62, 'tick'], [10.82, 'lift'],
  [12.27, 'tick'], [12.63, 'tick'], [13.09, 'tick'], [13.81, 'lift'],
  [15.06, 'impact'], [16.43, 'tick'], [17.22, 'lift'], [18.1, 'impact'],
  [19.17, 'fracture'], [20.74, 'lift'], [21.02, 'impact'],
  [23.95, 'impact'], [25.79, 'impact'], [27.03, 'air'],
  [28.84, 'spark'], [30.03, 'impact'], [31.52, 'lift'],
  [33.08, 'impact'], [34.24, 'spark'], [36.08, 'air'], [38.1, 'resolve'],
] as const;

type CueType = (typeof cues)[number][1];

export class Soundscape {
  private context: AudioContext | null = null;
  private master: GainNode | null = null;
  private ambience: GainNode | null = null;
  private destination: MediaStreamAudioDestinationNode | null = null;
  private lastTime = -1;
  private enabled = false;
  private playing = false;
  private noiseBuffer: AudioBuffer | null = null;

  async enable(atTime = 0) {
    if (!this.context) this.initialize();
    if (!this.context || !this.master) return false;
    try {
      await this.context.resume();
      this.enabled = true;
      this.lastTime = atTime;
      this.setPlaying(this.playing);
      return true;
    } catch {
      return false;
    }
  }

  private initialize() {
    const context = new AudioContext();
    this.context = context;
    this.master = context.createGain();
    this.master.gain.value = 0;
    this.master.connect(context.destination);
    this.destination = context.createMediaStreamDestination();
    this.master.connect(this.destination);

    this.ambience = context.createGain();
    this.ambience.gain.value = 0.018;
    this.ambience.connect(this.master);
    [43.65, 55, 82.41, 110.0].forEach((frequency, i) => {
      const oscillator = context.createOscillator();
      oscillator.type = i < 2 ? 'sine' : 'triangle';
      oscillator.frequency.value = frequency;
      const level = context.createGain();
      level.gain.value = i < 2 ? 0.6 : 0.11;
      oscillator.connect(level);
      level.connect(this.ambience!);
      oscillator.start();
    });
    this.noiseBuffer = context.createBuffer(1, context.sampleRate * 2, context.sampleRate);
    const data = this.noiseBuffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  }

  setPlaying(playing: boolean) {
    this.playing = playing;
    if (!this.context || !this.master) return;
    this.master.gain.setTargetAtTime(this.enabled && playing ? 0.53 : 0, this.context.currentTime, 0.06);
  }

  mute() {
    this.enabled = false;
    this.setPlaying(this.playing);
  }

  get isEnabled() {
    return this.enabled;
  }

  get stream() {
    return this.destination?.stream ?? null;
  }

  private oscillator(frequency: number, end: number, duration: number, volume: number, type: OscillatorType = 'sine') {
    const context = this.context;
    if (!context || !this.master) return;
    const start = context.currentTime;
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, start);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(20, end), start + duration);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(volume, start + Math.min(0.035, duration * 0.2));
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    oscillator.connect(gain);
    gain.connect(this.master);
    oscillator.start(start);
    oscillator.stop(start + duration + 0.03);
    oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
  }

  private noise(duration: number, volume: number, highPass: number) {
    const context = this.context;
    if (!context || !this.master || !this.noiseBuffer) return;
    const start = context.currentTime;
    const source = context.createBufferSource();
    source.buffer = this.noiseBuffer;
    const filter = context.createBiquadFilter();
    filter.type = 'bandpass';
    filter.Q.value = 0.7;
    filter.frequency.setValueAtTime(highPass, start);
    filter.frequency.exponentialRampToValueAtTime(highPass * 2.7, start + duration);
    const gain = context.createGain();
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.linearRampToValueAtTime(volume, start + duration * 0.15);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    source.connect(filter);
    filter.connect(gain);
    gain.connect(this.master);
    source.start(start);
    source.stop(start + duration + 0.02);
    source.onended = () => { source.disconnect(); filter.disconnect(); gain.disconnect(); };
  }

  private playCue(type: CueType) {
    if (type === 'impact') {
      this.oscillator(97, 34, 0.72, 0.32);
      this.noise(0.32, 0.065, 90);
    } else if (type === 'spark') {
      this.oscillator(480, 260, 0.23, 0.085, 'sine');
      this.noise(0.13, 0.025, 1700);
    } else if (type === 'tick') {
      this.oscillator(620, 390, 0.075, 0.04, 'triangle');
      this.noise(0.06, 0.018, 2300);
    } else if (type === 'lift') {
      this.oscillator(68, 155, 0.75, 0.065, 'sine');
      this.noise(0.8, 0.03, 200);
    } else if (type === 'fracture') {
      this.oscillator(145, 45, 0.94, 0.24, 'sawtooth');
      this.noise(0.6, 0.1, 650);
    } else if (type === 'air') {
      this.noise(1.4, 0.024, 260);
    } else {
      this.oscillator(82, 55, 1.8, 0.11);
      this.oscillator(164.8, 110, 1.8, 0.055);
      this.noise(1.1, 0.025, 180);
    }
  }

  update(t: number) {
    if (!this.context || !this.enabled || !this.playing || !this.ambience) {
      this.lastTime = t;
      return;
    }
    if (t < this.lastTime || t - this.lastTime > 0.5) this.lastTime = t - 0.025;
    for (const [time, type] of cues) {
      if (time > this.lastTime && time <= t) this.playCue(type);
    }
    const energy = 0.35 + smooth(0, 3, t) * 0.25 + (t >= 18 && t <= 21 ? 0.4 : 0);
    const ending = 1 - smooth(38.3, 40, t);
    this.ambience.gain.setTargetAtTime(clamp(energy) * ending * 0.025, this.context.currentTime, 0.2);
    this.lastTime = t;
  }

  dispose() {
    void this.context?.close();
  }
}
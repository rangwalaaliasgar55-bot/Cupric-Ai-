import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react";
import { CHAPTERS, DURATION, drawFilmFrame } from "./film-engine";

type SoundRig = {
  context: AudioContext;
  master: GainNode;
  sources: OscillatorNode[];
};

const INITIAL_PREVIEW_TIME = 1.62;

function BrandMark({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="3.15" strokeLinecap="round">
        <path d="M16 3.3v7.4M16 21.3v7.4M3.3 16h7.4M21.3 16h7.4" />
        <path d="m6.95 6.95 5.25 5.25m7.6 7.6 5.25 5.25m0-18.1-5.25 5.25m-7.6 7.6-5.25 5.25" />
      </g>
      <circle cx="16" cy="16" r="2.5" fill="currentColor" />
    </svg>
  );
}

function TransportIcon({ playing }: { playing: boolean }) {
  return playing ? (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M6.5 4.5v11M13.5 4.5v11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ) : (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="m7 4.9 8.1 4.55a.65.65 0 0 1 0 1.13L7 15.13a.65.65 0 0 1-.97-.56V5.46A.65.65 0 0 1 7 4.9Z" fill="currentColor" />
    </svg>
  );
}

function SoundIcon({ muted }: { muted: boolean }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M3.2 8v4h3l4.2 3.2V4.8L6.2 8h-3Z" stroke="currentColor" strokeWidth="1.45" strokeLinejoin="round" />
      {muted ? (
        <path d="m13 8 4 4m0-4-4 4" stroke="currentColor" strokeWidth="1.45" strokeLinecap="round" />
      ) : (
        <>
          <path d="M13 7.2a4 4 0 0 1 0 5.6" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" />
          <path d="M15.4 5.2a6.9 6.9 0 0 1 0 9.6" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" opacity=".6" />
        </>
      )}
    </svg>
  );
}

function FullscreenIcon({ active }: { active: boolean }) {
  return active ? (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M7 3.8v3.1H3.9M13 3.8v3.1h3.1M7 16.2v-3.1H3.9m9.1 3.1v-3.1h3.1" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ) : (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M7 3.8H3.9v3.1M13 3.8h3.1v3.1M7 16.2H3.9v-3.1m9.1 3.1h3.1v-3.1" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function formatTime(value: number) {
  const totalSeconds = Math.floor(value);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function createSoundRig(): SoundRig | undefined {
  const AudioContextClass = window.AudioContext;
  if (!AudioContextClass) return undefined;

  const context = new AudioContextClass();
  const master = context.createGain();
  master.gain.value = 0.0001;
  master.connect(context.destination);

  const bass = context.createOscillator();
  const bassGain = context.createGain();
  bass.type = "sine";
  bass.frequency.value = 48;
  bassGain.gain.value = 0.19;
  bass.connect(bassGain);
  bassGain.connect(master);
  bass.start();

  const overtone = context.createOscillator();
  const overtoneGain = context.createGain();
  overtone.type = "triangle";
  overtone.frequency.value = 96;
  overtoneGain.gain.value = 0.035;
  overtone.connect(overtoneGain);
  overtoneGain.connect(master);
  overtone.start();

  const noiseBuffer = context.createBuffer(1, context.sampleRate * 2, context.sampleRate);
  const noise = noiseBuffer.getChannelData(0);
  for (let i = 0; i < noise.length; i += 1) noise[i] = (Math.random() * 2 - 1) * 0.18;
  const texture = context.createBufferSource();
  const filter = context.createBiquadFilter();
  const textureGain = context.createGain();
  texture.buffer = noiseBuffer;
  texture.loop = true;
  filter.type = "lowpass";
  filter.frequency.value = 390;
  textureGain.gain.value = 0.035;
  texture.connect(filter);
  filter.connect(textureGain);
  textureGain.connect(master);
  texture.start();

  return { context, master, sources: [bass, overtone] };
}

function setSoundLevel(rig: SoundRig | undefined, enabled: boolean, playing: boolean) {
  if (!rig) return;
  const target = enabled && playing ? 0.23 : 0.0001;
  rig.master.gain.setTargetAtTime(target, rig.context.currentTime, 0.45);
}

function playSceneCue(rig: SoundRig | undefined, scene: number) {
  if (!rig || rig.context.state !== "running") return;
  const now = rig.context.currentTime;
  const frequencies = [68, 94, 116, 57, 142, 72, 49, 128, 83, 63, 108, 42, 94, 55];
  const oscillator = rig.context.createOscillator();
  const envelope = rig.context.createGain();
  oscillator.type = scene === 8 ? "triangle" : "sine";
  oscillator.frequency.setValueAtTime(frequencies[scene % frequencies.length], now);
  oscillator.frequency.exponentialRampToValueAtTime(Math.max(36, frequencies[scene % frequencies.length] * 0.72), now + 0.52);
  envelope.gain.setValueAtTime(0.0001, now);
  envelope.gain.exponentialRampToValueAtTime(0.038, now + 0.045);
  envelope.gain.exponentialRampToValueAtTime(0.0001, now + 0.68);
  oscillator.connect(envelope);
  envelope.connect(rig.master);
  oscillator.start(now);
  oscillator.stop(now + 0.72);
}

export default function App() {
  const playerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const timeRef = useRef(INITIAL_PREVIEW_TIME);
  const playingRef = useRef(false);
  const dirtyRef = useRef(true);
  const startedAtRef = useRef(0);
  const playbackOffsetRef = useRef(0);
  const hasStartedRef = useRef(false);
  const lastFrameRef = useRef(-1);
  const lastCueSceneRef = useRef(-1);
  const pointerRef = useRef({ x: 0, y: 0 });
  const soundRigRef = useRef<SoundRig | undefined>(undefined);
  const soundOnRef = useRef(false);

  const [currentTime, setCurrentTime] = useState(INITIAL_PREVIEW_TIME);
  const [isPlaying, setIsPlaying] = useState(false);
  const [soundOn, setSoundOn] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const togglePlayback = useCallback(() => {
    if (playingRef.current) {
      const elapsed = (performance.now() - startedAtRef.current) / 1000 + playbackOffsetRef.current;
      const frameTime = Math.floor(elapsed * 30) / 30;
      timeRef.current = Math.min(DURATION, frameTime);
      playbackOffsetRef.current = timeRef.current;
      playingRef.current = false;
      setIsPlaying(false);
      setCurrentTime(timeRef.current);
      dirtyRef.current = true;
      setSoundLevel(soundRigRef.current, soundOn, false);
      return;
    }

    let startTime = timeRef.current;
    if (!hasStartedRef.current || startTime >= DURATION) {
      startTime = 0;
      timeRef.current = 0;
      lastCueSceneRef.current = -1;
      hasStartedRef.current = true;
      setCurrentTime(0);
      dirtyRef.current = true;
    }
    playbackOffsetRef.current = startTime;
    startedAtRef.current = performance.now();
    playingRef.current = true;
    setIsPlaying(true);
    const rig = soundRigRef.current;
    if (rig && rig.context.state === "suspended") void rig.context.resume();
    setSoundLevel(rig, soundOn, true);
  }, [soundOn]);

  const seekTo = useCallback((value: number) => {
    const nextTime = Math.max(0, Math.min(DURATION, value));
    timeRef.current = nextTime;
    playbackOffsetRef.current = nextTime;
    startedAtRef.current = performance.now();
    hasStartedRef.current = true;
    lastFrameRef.current = -1;
    dirtyRef.current = true;
    setCurrentTime(nextTime);
  }, []);

  const toggleSound = useCallback(() => {
    const nextEnabled = !soundOn;
    let rig = soundRigRef.current;
    if (nextEnabled && !rig) {
      rig = createSoundRig();
      soundRigRef.current = rig;
    }
    if (rig?.context.state === "suspended") void rig.context.resume();
    soundOnRef.current = nextEnabled;
    setSoundOn(nextEnabled);
    setSoundLevel(rig, nextEnabled, playingRef.current);
  }, [soundOn]);

  const toggleFullscreen = useCallback(async () => {
    if (!playerRef.current) return;
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await playerRef.current.requestFullscreen();
    } catch {
      // Fullscreen can be unavailable in embedded previews; playback still works normally.
    }
  }, []);

  useEffect(() => {
    const player = playerRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d", { alpha: false });
    if (!player || !canvas || !ctx) return;

    let animationFrame = 0;
    const paint = (time: number) => {
      if (playingRef.current) {
        const elapsed = (time - startedAtRef.current) / 1000 + playbackOffsetRef.current;
        const nextTime = Math.min(DURATION, Math.floor(elapsed * 30) / 30);
        const frame = Math.floor(nextTime * 30);

        if (frame !== lastFrameRef.current) {
          timeRef.current = nextTime;
          drawFilmFrame(ctx, nextTime, pointerRef.current.x, pointerRef.current.y);
          dirtyRef.current = false;
          lastFrameRef.current = frame;

          if (frame % 3 === 0 || nextTime >= DURATION) setCurrentTime(nextTime);
          const scene = CHAPTERS.reduce(
            (activeScene, chapter, index) => (nextTime >= chapter.time ? index : activeScene),
            0,
          );
          if (scene !== lastCueSceneRef.current) {
            if (lastCueSceneRef.current !== -1 || nextTime < 0.08) playSceneCue(soundRigRef.current, scene);
            lastCueSceneRef.current = scene;
          }
        }

        if (elapsed >= DURATION) {
          timeRef.current = DURATION;
          playbackOffsetRef.current = DURATION;
          playingRef.current = false;
          setIsPlaying(false);
          setCurrentTime(DURATION);
          setSoundLevel(soundRigRef.current, soundOnRef.current, false);
          dirtyRef.current = true;
        }
      }

      if (!playingRef.current && dirtyRef.current) {
        drawFilmFrame(ctx, timeRef.current, pointerRef.current.x, pointerRef.current.y);
        dirtyRef.current = false;
        lastFrameRef.current = Math.floor(timeRef.current * 30);
      }
      animationFrame = window.requestAnimationFrame(paint);
    };

    drawFilmFrame(ctx, timeRef.current, 0, 0);
    animationFrame = window.requestAnimationFrame(paint);
    return () => window.cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const handleFullscreen = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", handleFullscreen);
    return () => document.removeEventListener("fullscreenchange", handleFullscreen);
  }, []);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLButtonElement) return;
      if (event.code === "Space") {
        event.preventDefault();
        togglePlayback();
      } else if (event.code === "ArrowRight") {
        event.preventDefault();
        seekTo(timeRef.current + 1);
      } else if (event.code === "ArrowLeft") {
        event.preventDefault();
        seekTo(timeRef.current - 1);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [seekTo, togglePlayback]);

  useEffect(() => {
    return () => {
      soundRigRef.current?.sources.forEach((source) => {
        try {
          source.stop();
        } catch {
          // The source may already have been stopped by the browser.
        }
      });
      void soundRigRef.current?.context.close();
    };
  }, []);

  const chapterIndex = CHAPTERS.reduce(
    (activeScene, chapter, index) => (currentTime >= chapter.time ? index : activeScene),
    0,
  );
  const progress = Math.min(100, (currentTime / DURATION) * 100);

  return (
    <div className="studio-page">
      <header className="topbar">
        <a className="brand-lockup" href="#film" aria-label="Cupric AI brand film">
          <BrandMark className="brand-symbol" />
          <span className="brand-name">Cupric <span>AI</span></span>
        </a>

        <div className="film-edition" aria-label="Brand film number one">
          <span className="edition-dot" />
          <span>BRAND FILM</span>
          <span className="edition-slash">/</span>
          <span className="edition-number">001</span>
        </div>

        <div className="film-specs">
          <span>1920 <i>×</i> 1080</span>
          <span className="spec-divider" />
          <span>30 FPS</span>
        </div>
      </header>

      <main className="page-main" id="film">
        <div className="player" ref={playerRef}>
          <div className="film-frame">
            <canvas
              ref={canvasRef}
              className="film-canvas"
              width={1920}
              height={1080}
              aria-label="Cupric AI 40-second cinematic brand film"
              onPointerMove={(event) => {
                const bounds = event.currentTarget.getBoundingClientRect();
                pointerRef.current = {
                  x: (event.clientX - bounds.left) / bounds.width - 0.5,
                  y: (event.clientY - bounds.top) / bounds.height - 0.5,
                };
                dirtyRef.current = true;
              }}
              onPointerLeave={() => {
                pointerRef.current = { x: 0, y: 0 };
                dirtyRef.current = true;
              }}
            />
          </div>

          <section className="player-controls" aria-label="Film controls">
            <div className="timeline" style={{ "--progress": `${progress}%` } as CSSProperties}>
              <div className="chapter-ticks" aria-hidden="true">
                {CHAPTERS.slice(1).map((chapter) => (
                  <span key={chapter.time} style={{ left: `${(chapter.time / DURATION) * 100}%` }} />
                ))}
              </div>
              <input
                className="seek-control"
                type="range"
                min={0}
                max={DURATION}
                step={1 / 30}
                value={currentTime}
                aria-label="Seek through the 40-second film"
                onChange={(event) => seekTo(Number(event.target.value))}
              />
            </div>

            <div className="control-row">
              <button
                className={`play-button${isPlaying ? " is-playing" : ""}`}
                type="button"
                onClick={togglePlayback}
                aria-label={isPlaying ? "Pause film" : currentTime >= DURATION ? "Replay film" : "Play film from the beginning"}
                title={isPlaying ? "Pause" : "Play film"}
              >
                <TransportIcon playing={isPlaying} />
              </button>

              <div className="chapter-label" aria-live="polite">
                <span className="chapter-number">{String(chapterIndex + 1).padStart(2, "0")}</span>
                <span className="chapter-title">{CHAPTERS[chapterIndex].title}</span>
              </div>

              <div className="timecode" aria-label={`${formatTime(currentTime)} of ${formatTime(DURATION)}`}>
                <span>{formatTime(currentTime)}</span>
                <span className="time-separator">/</span>
                <span className="time-duration">{formatTime(DURATION)}</span>
              </div>

              <div className="control-spacer" />

              <button
                className={`utility-button sound-button${soundOn ? " is-active" : ""}`}
                type="button"
                onClick={toggleSound}
                aria-label={soundOn ? "Turn sound off" : "Turn sound on"}
                title={soundOn ? "Sound on" : "Sound off"}
              >
                <SoundIcon muted={!soundOn} />
                <span className="utility-word">SOUND</span>
              </button>

              <button
                className="utility-button fullscreen-button"
                type="button"
                onClick={toggleFullscreen}
                aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
                title={isFullscreen ? "Exit fullscreen" : "Fullscreen"}
              >
                <FullscreenIcon active={isFullscreen} />
              </button>
            </div>
          </section>
        </div>
      </main>

      <footer className="page-footer">
        <span>INTELLIGENCE FOR PEOPLE WHO BUILD.</span>
        <span className="footer-right">CREATE WITHOUT LIMITS <span className="footer-star">✳</span></span>
      </footer>
    </div>
  );
}
const W = 1920;
const H = 1080;
const LIME = "#c8ff38";
const WHITE = "#f2f3ee";
const MUTED = "#989d95";

export const DURATION = 40;

export const CHAPTERS = [
  { title: "The hook", time: 0 },
  { title: "Infinite directions", time: 3 },
  { title: "Intelligence in motion", time: 6 },
  { title: "Build faster", time: 9 },
  { title: "Prompt to product", time: 12 },
  { title: "Less repetition", time: 15 },
  { title: "10x", time: 18 },
  { title: "Ideas connect", time: 21 },
  { title: "Make noise", time: 24 },
  { title: "Human + machine", time: 27 },
  { title: "Build what's next", time: 30 },
  { title: "Cupric AI", time: 33 },
  { title: "Intelligence for people who build", time: 36 },
  { title: "Create without limits", time: 38 },
];

type Point3 = { x: number; y: number; z: number };
type ScreenPoint = { x: number; y: number; scale: number; z: number };

function clamp(value: number, min = 0, max = 1) {
  return Math.max(min, Math.min(max, value));
}

function smooth(start: number, end: number, value: number) {
  const x = clamp((value - start) / (end - start));
  return x * x * (3 - 2 * x);
}

function mix(a: number, b: number, amount: number) {
  return a + (b - a) * amount;
}

function seededRandom(seed: number) {
  let state = seed >>> 0;
  return () => {
    state += 0x6d2b79f5;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

const random = seededRandom(90731);

function project(
  point: Point3,
  rotationY = 0,
  rotationX = 0,
  cameraZ = 8,
  offsetX = 0,
  offsetY = 0,
): ScreenPoint {
  const cosY = Math.cos(rotationY);
  const sinY = Math.sin(rotationY);
  const rotatedX = point.x * cosY - point.z * sinY;
  const rotatedZ = point.x * sinY + point.z * cosY;
  const cosX = Math.cos(rotationX);
  const sinX = Math.sin(rotationX);
  const rotatedY = point.y * cosX - rotatedZ * sinX;
  const depth = point.y * sinX + rotatedZ * cosX;
  const distance = Math.max(1.25, cameraZ - depth);
  const scale = 890 / distance;

  return {
    x: W / 2 + offsetX + rotatedX * scale,
    y: H / 2 + offsetY - rotatedY * scale,
    scale,
    z: depth,
  };
}

function trackedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  size: number,
  color: string,
  weight = 500,
  tracking = 0,
  progress = 1,
  align: CanvasTextAlign = "center",
) {
  const chars = [...text];
  ctx.save();
  ctx.font = `${weight} ${size}px "Manrope", "Helvetica Neue", Arial, sans-serif`;
  ctx.textBaseline = "middle";
  ctx.fillStyle = color;
  ctx.textAlign = "left";

  const widths = chars.map((char) => ctx.measureText(char).width);
  const total = widths.reduce((sum, width) => sum + width, 0) + Math.max(0, chars.length - 1) * tracking;
  let cursor = align === "left" ? x : align === "right" ? x - total : x - total / 2;

  chars.forEach((char, index) => {
    const reveal = clamp((progress - (index / Math.max(1, chars.length)) * 0.56) / 0.44);
    if (reveal > 0) {
      ctx.globalAlpha *= reveal;
      ctx.fillText(char, cursor, y + (1 - reveal) * 28);
      ctx.globalAlpha /= reveal;
    }
    cursor += widths[index] + tracking;
  });
  ctx.restore();
}

function plainText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  size: number,
  color = WHITE,
  weight = 500,
  align: CanvasTextAlign = "left",
) {
  ctx.save();
  ctx.font = `${weight} ${size}px "Manrope", "Helvetica Neue", Arial, sans-serif`;
  ctx.textBaseline = "middle";
  ctx.textAlign = align;
  ctx.fillStyle = color;
  ctx.fillText(text, x, y);
  ctx.restore();
}

function label(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, color = MUTED, size = 15) {
  trackedText(ctx, text.toUpperCase(), x, y, size, color, 600, 3, 1, "left");
}

function roundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
  fill?: string | CanvasGradient,
  stroke?: string,
) {
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, radius);
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.stroke();
  }
}

function drawMark(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, alpha = 1, rotation = 0) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rotation);
  ctx.globalAlpha *= alpha;
  ctx.strokeStyle = LIME;
  ctx.fillStyle = LIME;
  ctx.lineWidth = Math.max(2, size * 0.095);
  ctx.lineCap = "round";
  ctx.shadowColor = "rgba(195, 255, 48, 0.7)";
  ctx.shadowBlur = size * 0.34;
  for (let i = 0; i < 8; i += 1) {
    const angle = (Math.PI * 2 * i) / 8;
    const inner = size * 0.17;
    const outer = size * (i % 2 === 0 ? 0.48 : 0.42);
    ctx.beginPath();
    ctx.moveTo(Math.cos(angle) * inner, Math.sin(angle) * inner);
    ctx.lineTo(Math.cos(angle) * outer, Math.sin(angle) * outer);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.arc(0, 0, size * 0.105, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawPoint(ctx: CanvasRenderingContext2D, x: number, y: number, radius: number, color = LIME, alpha = 1) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawGlow(ctx: CanvasRenderingContext2D, x: number, y: number, radius: number, alpha = 0.4, color = "195, 255, 57") {
  const glow = ctx.createRadialGradient(x, y, 0, x, y, radius);
  glow.addColorStop(0, `rgba(${color}, ${alpha})`);
  glow.addColorStop(0.24, `rgba(${color}, ${alpha * 0.2})`);
  glow.addColorStop(1, `rgba(${color}, 0)`);
  ctx.fillStyle = glow;
  ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
}

function drawAtmosphere(ctx: CanvasRenderingContext2D, time: number) {
  const background = ctx.createLinearGradient(0, 0, 0, H);
  background.addColorStop(0, "#080a08");
  background.addColorStop(0.52, "#060706");
  background.addColorStop(1, "#030403");
  ctx.fillStyle = background;
  ctx.fillRect(0, 0, W, H);

  const driftX = 960 + Math.sin(time * 0.13) * 220;
  const driftY = 520 + Math.cos(time * 0.16) * 105;
  drawGlow(ctx, driftX, driftY, 630, 0.075);
  drawGlow(ctx, 960 - Math.sin(time * 0.1) * 500, 545, 690, 0.022, "176, 204, 130");

  const vignette = ctx.createRadialGradient(960, 530, 280, 960, 530, 1080);
  vignette.addColorStop(0, "rgba(0, 0, 0, 0)");
  vignette.addColorStop(0.69, "rgba(0, 0, 0, 0.1)");
  vignette.addColorStop(1, "rgba(0, 0, 0, 0.76)");
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, W, H);
}

function drawGrain(ctx: CanvasRenderingContext2D, frame: number) {
  ctx.save();
  ctx.globalAlpha = 0.12;
  for (let i = 0; i < 170; i += 1) {
    const x = (i * 977 + frame * 29) % W;
    const y = (i * 431 + frame * 17) % H;
    const light = (i + frame) % 3 === 0;
    ctx.fillStyle = light ? "#ffffff" : "#000000";
    ctx.fillRect(x, y, 2, 2);
  }
  ctx.restore();
}

function drawTransition(ctx: CanvasRenderingContext2D, local: number, chapter: number) {
  const start = 1 - smooth(0.02, 0.43, local);
  const end = smooth(2.64, 2.99, local);
  const strength = Math.max(start, end) * 0.24;
  if (strength <= 0.01) return;

  ctx.save();
  ctx.globalAlpha = strength;
  const direction = chapter % 2 === 0 ? 1 : -1;
  for (let i = 0; i < 20; i += 1) {
    const y = 110 + i * 46 + Math.sin(local * 11 + i) * 13;
    const x = direction > 0 ? -80 + local * 720 : W + 80 - local * 720;
    const length = 210 + (i % 5) * 92;
    const gradient = ctx.createLinearGradient(x, y, x + length * direction, y);
    gradient.addColorStop(0, "rgba(196, 255, 54, 0)");
    gradient.addColorStop(0.52, "rgba(228, 255, 197, 0.65)");
    gradient.addColorStop(1, "rgba(196, 255, 54, 0)");
    ctx.strokeStyle = gradient;
    ctx.lineWidth = i % 4 === 0 ? 1.5 : 0.7;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + length * direction, y);
    ctx.stroke();
  }
  ctx.restore();
}

function drawSphere(ctx: CanvasRenderingContext2D, time: number, growth: number, zoom: number) {
  const rows = 28;
  const columns = 54;
  const points: ScreenPoint[][] = [];
  const radiusScale = growth * zoom;
  const rotationY = time * 0.36;
  const rotationX = 0.3 + Math.sin(time * 0.2) * 0.12;

  for (let row = 0; row <= rows; row += 1) {
    const latitude = (row / rows) * Math.PI;
    const line: ScreenPoint[] = [];
    for (let column = 0; column <= columns; column += 1) {
      const longitude = (column / columns) * Math.PI * 2;
      const warp = 1 + 0.12 * Math.sin(longitude * 4 + time * 0.4) * Math.sin(latitude * 5 - time * 0.23);
      const radius = 2.38 * radiusScale * warp;
      const point = {
        x: radius * Math.sin(latitude) * Math.cos(longitude),
        y: radius * Math.cos(latitude),
        z: radius * Math.sin(latitude) * Math.sin(longitude),
      };
      line.push(project(point, rotationY, rotationX, 7.3 - zoom * 0.28));
    }
    points.push(line);
  }

  ctx.save();
  ctx.lineWidth = 0.8;
  ctx.strokeStyle = "rgba(187, 240, 111, 0.19)";
  ctx.shadowColor = "rgba(190, 255, 80, 0.22)";
  ctx.shadowBlur = 8;
  for (let row = 1; row < rows; row += 2) {
    ctx.beginPath();
    points[row].forEach((point, column) => {
      if (column === 0) ctx.moveTo(point.x, point.y);
      else ctx.lineTo(point.x, point.y);
    });
    ctx.stroke();
  }
  for (let column = 0; column < columns; column += 3) {
    ctx.beginPath();
    points.forEach((row, index) => {
      if (index === 0) ctx.moveTo(row[column].x, row[column].y);
      else ctx.lineTo(row[column].x, row[column].y);
    });
    ctx.stroke();
  }
  ctx.shadowBlur = 0;
  for (let row = 1; row < rows; row += 1) {
    for (let column = 0; column < columns; column += 1) {
      const point = points[row][column];
      const depthAlpha = clamp((point.scale - 93) / 180, 0.24, 0.95);
      drawPoint(ctx, point.x, point.y, 1.05 + point.scale / 175, row % 5 === 0 ? "#e1ffb4" : LIME, depthAlpha);
    }
  }
  ctx.restore();
}

function drawHook(ctx: CanvasRenderingContext2D, local: number, time: number) {
  const growth = 0.035 + smooth(0.01, 0.88, local) * 0.98;
  const zoom = 1 + smooth(1.72, 2.8, local) * 0.55;
  drawGlow(ctx, 960, 540, 260 + growth * 250, 0.16 * growth);
  drawSphere(ctx, time, growth, zoom);

  if (local < 0.72) {
    const pointSize = 1.2 + smooth(0, 0.55, local) * 8;
    drawPoint(ctx, 960, 540, pointSize, "#efffda", 0.9);
    drawGlow(ctx, 960, 540, 55 + local * 210, 0.75);
  }
  if (local > 0.68) {
    const reveal = smooth(0.68, 1.14, local);
    trackedText(ctx, "CREATE.", 960, 472, 185, WHITE, 600, -5, reveal);
    if (local > 1.18) {
      trackedText(ctx, "WITH INTELLIGENCE.", 960, 618, 67, "#d5d9d0", 450, 7, smooth(1.18, 1.62, local));
    }
  }
}

type BranchNode = { point: Point3; parent: number; level: number };

const branchNodes: BranchNode[] = (() => {
  const nodes: BranchNode[] = [{ point: { x: 0, y: 0, z: -2.5 }, parent: -1, level: 0 }];
  let parents = [0];
  for (let level = 1; level <= 6; level += 1) {
    const next: number[] = [];
    const spread = 3.65 / 2 ** (level - 1);
    for (const parentIndex of parents) {
      const parent = nodes[parentIndex];
      for (const side of [-1, 1]) {
        const point = {
          x: parent.point.x + side * spread * (0.46 + random() * 0.12),
          y: parent.point.y + (random() - 0.5) * 0.48 + (side === -1 ? 0.1 : -0.1),
          z: parent.point.z + 0.78 + random() * 0.26,
        };
        nodes.push({ point, parent: parentIndex, level });
        next.push(nodes.length - 1);
      }
    }
    parents = next;
  }
  return nodes;
})();

function drawBranches(ctx: CanvasRenderingContext2D, time: number, local: number) {
  const reveal = smooth(0.02, 0.84, local);
  const rotation = Math.sin(time * 0.15) * 0.18;
  const projected = branchNodes.map((node) => {
    const depthDrift = smooth(0, 1, local) * 1.3;
    return project(
      { ...node.point, z: node.point.z + depthDrift },
      rotation,
      Math.sin(time * 0.2) * 0.11,
      8.7 - smooth(2.1, 2.9, local) * 1.5,
    );
  });

  ctx.save();
  ctx.lineWidth = 1;
  ctx.shadowColor = "rgba(194, 255, 80, 0.28)";
  ctx.shadowBlur = 6;
  branchNodes.forEach((node, index) => {
    if (node.parent < 0 || node.level / 6 > reveal + 0.16) return;
    const from = projected[node.parent];
    const to = projected[index];
    const depthAlpha = clamp((to.scale - 65) / 200, 0.12, 0.64);
    ctx.globalAlpha = depthAlpha;
    ctx.strokeStyle = node.level % 3 === 0 ? "#c8ff38" : "#b9c3b0";
    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(to.x, to.y);
    ctx.stroke();

    if (node.level > 2 && (index + node.level) % 5 === 0) {
      const flow = (time * 0.29 + index * 0.107) % 1;
      drawPoint(ctx, mix(from.x, to.x, flow), mix(from.y, to.y, flow), 2.1, "#f1ffd8", 0.84);
    }
  });
  ctx.restore();

  drawGlow(ctx, 960, 540, 420, 0.09);
  if (local > 0.32) {
    const titleProgress = smooth(0.27, 0.67, local);
    trackedText(ctx, "ONE IDEA.", 960, 390, 148, WHITE, 550, -3, titleProgress);
    if (local > 0.72) {
      const subProgress = smooth(0.7, 1.05, local);
      trackedText(ctx, "INFINITE", 960, 522, 46, LIME, 600, 12, subProgress);
      trackedText(ctx, "DIRECTIONS.", 960, 650, 113, WHITE, 500, -1, subProgress);

      const split = smooth(1.92, 2.54, local);
      if (split > 0) {
        ctx.save();
        ctx.globalAlpha *= split * 0.43;
        trackedText(ctx, "DIRECTIONS", 398 - split * 230, 815, 38, "#c8ff38", 500, 4, 1);
        trackedText(ctx, "DIRECTIONS", 1522 + split * 230, 257, 38, "#e8ede2", 500, 4, 1);
        trackedText(ctx, "DIRECTIONS", 1480 + split * 190, 816, 38, "#c8ff38", 500, 4, 1);
        ctx.restore();
      }
    }
  }
}

type NetworkNode = Point3 & { phase: number };

const networkNodes: NetworkNode[] = Array.from({ length: 108 }, () => {
  const azimuth = random() * Math.PI * 2;
  const vertical = random() * 2 - 1;
  const radius = 1.5 + random() * 2.2;
  const spread = Math.sqrt(1 - vertical * vertical) * radius;
  return {
    x: Math.cos(azimuth) * spread,
    y: vertical * radius * 0.8,
    z: Math.sin(azimuth) * spread,
    phase: random() * Math.PI * 2,
  };
});

function drawNetwork(ctx: CanvasRenderingContext2D, time: number, local: number) {
  const rotation = time * 0.14;
  const points = networkNodes.map((node) => {
    const breathing = 1 + Math.sin(time * 0.7 + node.phase) * 0.045;
    const migration = smooth(2.15, 2.95, local);
    return project(
      {
        x: node.x * breathing + Math.sin(node.phase * 2 + time * 0.2) * migration * 0.26,
        y: node.y * breathing + Math.cos(node.phase + time * 0.26) * migration * 0.2,
        z: node.z * breathing,
      },
      rotation,
      Math.sin(time * 0.17) * 0.22,
      8.3 - migration * 1.4,
    );
  });

  ctx.save();
  ctx.lineWidth = 0.8;
  for (let i = 0; i < points.length; i += 1) {
    for (let j = i + 1; j < points.length; j += 1) {
      const a = points[i];
      const b = points[j];
      const distance = Math.hypot(a.x - b.x, a.y - b.y);
      if (distance < 182 && distance > 28) {
        const alpha = (1 - distance / 182) * 0.28;
        ctx.strokeStyle = `rgba(189, 224, 157, ${alpha})`;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        if ((i * 3 + j) % 17 === 0) {
          const flow = (time * 0.17 + (i + j) * 0.021) % 1;
          drawPoint(ctx, mix(a.x, b.x, flow), mix(a.y, b.y, flow), 1.8, "#e5ffbd", 0.76);
        }
      }
    }
  }
  ctx.restore();

  points.forEach((point, index) => {
    if (index % 2 === 0) drawPoint(ctx, point.x, point.y, index % 9 === 0 ? 3.4 : 1.8, index % 7 === 0 ? LIME : "#d8e9c7", 0.72);
  });

  for (let ring = 0; ring < 3; ring += 1) {
    ctx.save();
    ctx.translate(960, 540);
    ctx.rotate(time * (ring % 2 ? -0.11 : 0.08) + ring * 0.5);
    ctx.strokeStyle = `rgba(189, 241, 112, ${0.14 - ring * 0.025})`;
    ctx.lineWidth = 0.9;
    ctx.beginPath();
    ctx.ellipse(0, 0, 405 + ring * 51, 96 + ring * 38, ring * 0.22, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  drawGlow(ctx, 960, 540, 330, 0.11);
  if (local > 0.25) {
    const progress = smooth(0.24, 0.69, local);
    trackedText(ctx, "INTELLIGENCE", 960, 472, 117, WHITE, 530, -4, progress);
    if (local > 0.94) trackedText(ctx, "IN MOTION.", 960, 615, 149, LIME, 480, -3, smooth(0.92, 1.3, local));
  }
}

function drawMiniChart(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, time: number, accent = LIME) {
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.075)";
  ctx.lineWidth = 1;
  for (let i = 1; i <= 3; i += 1) {
    const lineY = y + (height * i) / 4;
    ctx.beginPath();
    ctx.moveTo(x, lineY);
    ctx.lineTo(x + width, lineY);
    ctx.stroke();
  }
  ctx.beginPath();
  for (let i = 0; i <= 30; i += 1) {
    const u = i / 30;
    const wave = Math.sin(u * 8 + time * 1.8) * 0.12 + Math.sin(u * 21 - time) * 0.04;
    const value = 0.67 - u * 0.43 + wave;
    const px = x + u * width;
    const py = y + value * height;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.strokeStyle = accent;
  ctx.globalAlpha = 0.92;
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();
}

function drawProductArtwork(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, progress: number, time: number) {
  const background = ctx.createLinearGradient(x, y, x + width, y + height);
  background.addColorStop(0, "#192119");
  background.addColorStop(0.58, "#111713");
  background.addColorStop(1, "#0a0d0b");
  roundedRect(ctx, x, y, width, height, 8, background);

  ctx.save();
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, 8);
  ctx.clip();
  drawGlow(ctx, x + width * 0.7, y + height * 0.53, width * 0.46, 0.24, "174, 208, 107");

  const enter = smooth(0.06, 0.86, progress);
  const objectX = x + width * 0.69;
  const objectY = y + height * 0.49 + (1 - enter) * 90;
  const scale = 0.72 + enter * 0.38;

  ctx.save();
  ctx.translate(objectX, objectY);
  ctx.scale(scale, scale);
  ctx.rotate(-0.17 + Math.sin(time * 0.28) * 0.025);
  ctx.shadowColor = "rgba(178, 230, 123, 0.28)";
  ctx.shadowBlur = 35;

  const body = ctx.createLinearGradient(-130, -180, 130, 170);
  body.addColorStop(0, "#cbd2c4");
  body.addColorStop(0.26, "#69736a");
  body.addColorStop(0.68, "#303a32");
  body.addColorStop(1, "#a9b4a4");
  ctx.fillStyle = body;
  ctx.beginPath();
  ctx.moveTo(-134, -126);
  ctx.quadraticCurveTo(-82, -187, 12, -166);
  ctx.quadraticCurveTo(117, -145, 127, -50);
  ctx.lineTo(102, 102);
  ctx.quadraticCurveTo(82, 148, 1, 156);
  ctx.quadraticCurveTo(-100, 145, -124, 86);
  ctx.lineTo(-151, -23);
  ctx.quadraticCurveTo(-160, -87, -134, -126);
  ctx.fill();

  ctx.strokeStyle = "rgba(240, 248, 229, 0.48)";
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.ellipse(-8, -12, 99, 136, 0.11, -2.18, 1.18);
  ctx.stroke();
  ctx.strokeStyle = "rgba(195, 255, 74, 0.72)";
  ctx.lineWidth = 1.1;
  for (let i = 0; i < 5; i += 1) {
    ctx.beginPath();
    ctx.ellipse(-4, 3, 92 + i * 9, 126 + i * 9, 0.12, -2.34 + i * 0.04, 0.5 + i * 0.1);
    ctx.stroke();
  }
  ctx.restore();

  ctx.strokeStyle = "rgba(227, 241, 218, 0.13)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 5; i += 1) {
    const lineY = y + 50 + i * 53;
    ctx.beginPath();
    ctx.moveTo(x, lineY);
    ctx.lineTo(x + width, lineY);
    ctx.stroke();
  }
  ctx.restore();

  label(ctx, "OBJECT 01 / FORM STUDY", x + 23, y + 24, "#d7e4ce", 11);
  label(ctx, "A quieter kind of sound.", x + 24, y + height - 33, "#d4dbd0", 13);
}

function drawWorkspace(
  ctx: CanvasRenderingContext2D,
  time: number,
  progress: number,
  variant: "assemble" | "generate",
) {
  const enter = smooth(0.02, variant === "assemble" ? 0.74 : 0.52, progress);
  const x = variant === "generate" ? 322 : 365;
  const y = variant === "generate" ? 320 : 232;
  const width = variant === "generate" ? 1276 : 1190;
  const height = variant === "generate" ? 625 : 690;
  const offsetY = (1 - enter) * (variant === "generate" ? 90 : 135);

  ctx.save();
  ctx.globalAlpha *= variant === "assemble" ? 0.2 + enter * 0.53 : 0.38 + enter * 0.62;
  ctx.translate(0, offsetY);
  ctx.shadowColor = "rgba(0, 0, 0, 0.65)";
  ctx.shadowBlur = 50;
  roundedRect(ctx, x, y, width, height, 13, "#0b0d0b", "rgba(230, 239, 223, 0.17)");
  ctx.shadowBlur = 0;

  const topHeight = 54;
  ctx.fillStyle = "#101310";
  ctx.fillRect(x + 1, y + 1, width - 2, topHeight);
  ctx.strokeStyle = "rgba(255, 255, 255, 0.075)";
  ctx.beginPath();
  ctx.moveTo(x, y + topHeight);
  ctx.lineTo(x + width, y + topHeight);
  ctx.stroke();

  drawMark(ctx, x + 26, y + 27, 18, 0.95, time * 0.1);
  plainText(ctx, "cupric", x + 45, y + 28, 17, "#e9ede5", 650);
  plainText(ctx, "STUDIO", x + 112, y + 28, 10, "#80867c", 650);
  plainText(ctx, "UNTITLED PROJECT", x + width * 0.5, y + 28, 12, "#acb3a9", 550, "center");
  roundedRect(ctx, x + width - 169, y + 15, 100, 25, 5, "#20251e", "rgba(224, 239, 210, 0.1)");
  plainText(ctx, "SHARE", x + width - 119, y + 28, 10, "#c4cdbd", 600, "center");
  roundedRect(ctx, x + width - 59, y + 15, 44, 25, 5, LIME);
  plainText(ctx, "RUN", x + width - 37, y + 28, 10, "#141811", 750, "center");

  const navX = x + 21;
  const contentX = x + 190;
  ctx.strokeStyle = "rgba(255,255,255,0.065)";
  ctx.beginPath();
  ctx.moveTo(x + 174, y + topHeight);
  ctx.lineTo(x + 174, y + height);
  ctx.stroke();

  label(ctx, "WORKSPACE", navX, y + 91, "#747c71", 10);
  ["Overview", "Canvas", "Components", "Assets"].forEach((item, index) => {
    const rowY = y + 125 + index * 40;
    if (index === 1) roundedRect(ctx, navX - 9, rowY - 15, 145, 30, 5, "#1b2119");
    ctx.fillStyle = index === 1 ? LIME : "#60665e";
    ctx.beginPath();
    ctx.arc(navX + 2, rowY, 3, 0, Math.PI * 2);
    ctx.fill();
    plainText(ctx, item, navX + 16, rowY, 13, index === 1 ? "#eff6e8" : "#899087", 500);
  });
  label(ctx, "RECENT", navX, y + 322, "#747c71", 10);
  plainText(ctx, "Untitled project", navX + 7, y + 355, 12, "#969d91", 450);
  plainText(ctx, "Spring / landing", navX + 7, y + 388, 12, "#747a70", 450);

  const canvasY = y + 93;
  label(ctx, variant === "generate" ? "GENERATED PRODUCT / V1" : "LIVE CANVAS / PREVIEW", contentX, canvasY, "#9da498", 10);
  plainText(ctx, "A new point of view", contentX, canvasY + 38, 24, "#f0f2ec", 550);
  plainText(ctx, "Refined from your brief · Just now", contentX, canvasY + 65, 12, "#82897f", 450);

  const artWidth = variant === "generate" ? 572 : 525;
  const artHeight = variant === "generate" ? 352 : 356;
  const artY = canvasY + 90;
  drawProductArtwork(ctx, contentX, artY, artWidth, artHeight, enter, time);

  const detailsX = contentX + artWidth + 24;
  const detailsWidth = x + width - 24 - detailsX;
  roundedRect(ctx, detailsX, artY, detailsWidth, artHeight, 7, "#111410", "rgba(238, 245, 231, 0.08)");
  label(ctx, "DESIGN SYSTEM", detailsX + 18, artY + 26, "#8a9187", 10);
  plainText(ctx, "Form, made useful.", detailsX + 18, artY + 66, 19, "#eef0e9", 550);
  plainText(ctx, "A considered home for good sound.", detailsX + 18, artY + 94, 11, "#858c82", 450);
  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.beginPath();
  ctx.moveTo(detailsX + 18, artY + 125);
  ctx.lineTo(detailsX + detailsWidth - 18, artY + 125);
  ctx.stroke();
  label(ctx, "COLOR / 04", detailsX + 18, artY + 153, "#7e857a", 9);
  ["#d7ddcf", "#a9bf95", "#667264", "#292e29"].forEach((color, index) => {
    roundedRect(ctx, detailsX + 18 + index * 34, artY + 174, 25, 25, 5, color);
  });
  label(ctx, "SIGNAL", detailsX + 18, artY + 230, "#7e857a", 9);
  drawMiniChart(ctx, detailsX + 18, artY + 245, Math.max(90, detailsWidth - 36), 75, time, "#badc80");

  if (variant === "assemble") {
    const footerY = artY + artHeight + 30;
    label(ctx, "CONTENT", contentX, footerY, "#787f75", 9);
    ["Overview", "Materials", "Details"].forEach((item, index) => {
      const tabX = contentX + index * 106;
      plainText(ctx, item, tabX + 5, footerY + 27, 12, index === 0 ? "#dbe3d3" : "#7d847a", 500);
      if (index === 0) {
        ctx.fillStyle = LIME;
        ctx.fillRect(tabX + 5, footerY + 43, 54, 2);
      }
    });
    roundedRect(ctx, x + width - 250, footerY + 9, 203, 38, 6, "#1b2118", "rgba(211, 255, 156, 0.25)");
    drawMark(ctx, x + width - 226, footerY + 28, 13, 1);
    plainText(ctx, "Open preview", x + width - 209, footerY + 29, 12, "#dcedd0", 550);
  } else {
    const promptY = y + height - 83;
    roundedRect(ctx, contentX, promptY, artWidth + detailsWidth + 24, 46, 6, "#171b16", "rgba(198, 255, 59, 0.22)");
    drawMark(ctx, contentX + 22, promptY + 23, 14, 0.95, time * 0.2);
    plainText(ctx, "Build something people will remember.", contentX + 45, promptY + 23, 15, "#dee5d9", 450);
    plainText(ctx, "↵", contentX + artWidth + detailsWidth - 3, promptY + 22, 17, "#c8ff38", 500, "right");
  }
  ctx.restore();
}

function drawBuildFaster(ctx: CanvasRenderingContext2D, time: number, local: number) {
  drawWorkspace(ctx, time, local, "assemble");
  const first = smooth(0.32, 0.62, local);
  trackedText(ctx, "BUILD", 960, 429, 163, WHITE, 620, 0, first);
  if (local > 0.71) {
    const rise = smooth(0.72, 1.19, local);
    const zoom = 1 + smooth(1.66, 2.68, local) * 0.73;
    ctx.save();
    ctx.translate(960, 610);
    ctx.scale(zoom, zoom);
    ctx.translate(-960, -610);
    ctx.globalAlpha *= 1 - smooth(2.34, 2.85, local) * 0.84;
    trackedText(ctx, "FASTER.", 960, 610, 194, LIME, 600, -5, rise);
    ctx.restore();
  }
}

function drawPromptProduct(ctx: CanvasRenderingContext2D, time: number, local: number) {
  drawWorkspace(ctx, time, local, "generate");
  const titleFade = 1 - smooth(2.43, 2.91, local) * 0.74;
  ctx.save();
  ctx.globalAlpha *= titleFade;
  trackedText(ctx, "FROM PROMPT", 960, 154, 82, "#f0f2ec", 550, -1, smooth(0.18, 0.58, local));
  if (local > 0.62) {
    trackedText(ctx, "TO PRODUCT.", 960, 246, 82, LIME, 540, -1, smooth(0.61, 1.0, local));
  }
  ctx.restore();

  if (local < 1.65) {
    const progress = smooth(0.22, 1.58, local);
    ctx.save();
    ctx.globalAlpha *= (1 - progress) * 0.74;
    for (let i = 0; i < 40; i += 1) {
      const x = 750 + ((i * 113 + time * 330) % 690);
      const y = 756 + Math.sin(i * 1.7 + time * 2.1) * (36 + progress * 80);
      drawPoint(ctx, x, y, 1 + (i % 3) * 0.45, i % 5 === 0 ? LIME : "#dce7d3", 0.7);
    }
    ctx.restore();
  }
}

function drawTaskWindow(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, index: number, time: number, alpha: number) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.translate(x, y);
  ctx.rotate(Math.sin(time * 0.7 + index) * 0.035);
  roundedRect(ctx, -width / 2, -height / 2, width, height, 7, "#111310", "rgba(238, 245, 232, 0.17)");
  ctx.fillStyle = "#1c201b";
  ctx.fillRect(-width / 2, -height / 2, width, 25);
  for (let i = 0; i < 3; i += 1) drawPoint(ctx, -width / 2 + 13 + i * 10, -height / 2 + 12, 2, i === 0 ? LIME : "#50564e", 0.85);
  plainText(ctx, ["Summarize notes", "Resize assets", "Review comments", "Update copy"][index % 4], -width / 2 + 13, -height / 2 + 45, 12, "#d7ddd2", 500);
  ctx.fillStyle = "rgba(220, 228, 214, 0.12)";
  ctx.fillRect(-width / 2 + 13, -height / 2 + 61, width * 0.55, 4);
  ctx.fillRect(-width / 2 + 13, -height / 2 + 73, width * 0.77, 3);
  ctx.fillRect(-width / 2 + 13, -height / 2 + 84, width * 0.43, 3);
  roundedRect(ctx, width / 2 - 43, height / 2 - 24, 30, 11, 4, index % 3 === 0 ? "#91b260" : "#353a33");
  ctx.restore();
}

function drawAutomationFlow(ctx: CanvasRenderingContext2D, time: number, progress: number) {
  const reveal = smooth(0.32, 0.78, progress);
  ctx.save();
  ctx.globalAlpha *= reveal;
  const nodes = ["BRIEF", "RESEARCH", "DRAFT", "PUBLISH"];
  const xStart = 540;
  const gap = 280;
  const y = 555;
  ctx.strokeStyle = "rgba(197, 245, 130, 0.56)";
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(xStart, y);
  ctx.lineTo(xStart + gap * 3, y);
  ctx.stroke();

  nodes.forEach((item, index) => {
    const x = xStart + gap * index;
    const radius = index === 0 || index === 3 ? 26 : 33;
    ctx.fillStyle = "#0b0f0b";
    ctx.strokeStyle = index === 2 ? "rgba(200, 255, 56, 0.92)" : "rgba(225, 238, 216, 0.45)";
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    if (index === 2) drawMark(ctx, x, y, 17, 1, time * 0.24);
    else drawPoint(ctx, x, y, 4, index === 3 ? LIME : "#dce7d4", 0.94);
    label(ctx, item, x, y + 56, "#aab3a4", 10);
    if (index < 3) {
      const flow = (time * 0.32 + index * 0.24) % 1;
      drawPoint(ctx, x + 49 + flow * (gap - 98), y, 2.7, "#e9ffd2", 0.95);
    }
  });
  ctx.restore();
}

function drawRepetition(ctx: CanvasRenderingContext2D, time: number, local: number) {
  const order = smooth(0.32, 0.92, local);
  const chaosAlpha = 1 - smooth(0.39, 0.69, local);
  for (let i = 0; i < 15; i += 1) {
    const column = i % 5;
    const row = Math.floor(i / 5);
    const originX = 226 + column * 363;
    const originY = 280 + row * 270;
    const phase = (i % 5) * 0.07;
    const collapse = smooth(0.26 + phase, 0.78 + phase, local);
    const x = mix(originX, 960 + Math.sin(i * 1.9 + time) * 16, collapse);
    const y = mix(originY, 545 + Math.cos(i * 1.1 + time * 0.4) * 12, collapse);
    drawTaskWindow(ctx, x, y, 228, 136, i, time, chaosAlpha * (1 - order * 0.55));
  }
  drawAutomationFlow(ctx, time, local);

  trackedText(ctx, "LESS REPETITION.", 960, 178, 94, WHITE, 560, -2, smooth(0.18, 0.48, local));
  if (local > 0.84) trackedText(ctx, "MORE CREATION.", 960, 881, 90, LIME, 530, -2, smooth(0.83, 1.18, local));
}

type FracturePoint = { x: number; y: number; vx: number; vy: number; size: number; lime: boolean };
let fracturePoints: FracturePoint[] | undefined;

function getFracturePoints() {
  if (fracturePoints) return fracturePoints;
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return [];
  ctx.font = `700 385px "Manrope", "Helvetica Neue", Arial, sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillStyle = "#ffffff";
  ctx.fillText("10×", W / 2, H / 2 - 10);
  const data = ctx.getImageData(0, 0, W, H).data;
  const points: FracturePoint[] = [];
  const localRandom = seededRandom(18290);
  for (let y = 332; y < 750; y += 9) {
    for (let x = 470; x < 1450; x += 9) {
      const alpha = data[(y * W + x) * 4 + 3];
      if (alpha > 100) {
        const angle = Math.atan2(y - H / 2, x - W / 2) + (localRandom() - 0.5) * 0.75;
        const speed = 0.5 + localRandom() * 1.35;
        points.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          size: 1.4 + localRandom() * 2.8,
          lime: localRandom() > 0.74,
        });
      }
    }
  }
  fracturePoints = points;
  return points;
}

function drawFracture(ctx: CanvasRenderingContext2D, local: number, time: number) {
  const explosion = smooth(0.52, 1.42, local);
  const dissolve = smooth(2.54, 2.98, local);
  const textAlpha = 1 - smooth(0.43, 0.75, local);

  if (textAlpha > 0) {
    const scale = 1 + smooth(0.04, 0.5, local) * 0.12;
    ctx.save();
    ctx.translate(960, 540);
    ctx.scale(scale, scale);
    ctx.translate(-960, -540);
    ctx.globalAlpha *= textAlpha;
    ctx.shadowColor = "rgba(200,255,56,0.2)";
    ctx.shadowBlur = 28;
    trackedText(ctx, "10×", 960, 535, 368, WHITE, 650, -9, smooth(0.03, 0.37, local));
    ctx.restore();
  }

  if (explosion > 0) {
    ctx.save();
    ctx.globalAlpha *= (1 - dissolve) * 0.94;
    ctx.globalCompositeOperation = "lighter";
    const points = getFracturePoints();
    points.forEach((particle, index) => {
      const drift = explosion * (360 + (index % 9) * 30);
      const orbit = time * (particle.lime ? 0.09 : -0.06);
      const x = 960 + (particle.x - 960) * (1 - explosion * 0.12) + particle.vx * drift * Math.cos(orbit) - particle.vy * drift * Math.sin(orbit);
      const y = 530 + (particle.y - 530) * (1 - explosion * 0.12) + particle.vy * drift * Math.cos(orbit) + particle.vx * drift * Math.sin(orbit);
      const trailX = x - particle.vx * (12 + explosion * 54);
      const trailY = y - particle.vy * (12 + explosion * 54);
      ctx.strokeStyle = particle.lime ? "rgba(200, 255, 56, 0.75)" : "rgba(233, 238, 228, 0.52)";
      ctx.lineWidth = particle.size;
      ctx.beginPath();
      ctx.moveTo(trailX, trailY);
      ctx.lineTo(x, y);
      ctx.stroke();
    });
    ctx.restore();
  }
  drawGlow(ctx, 960, 540, 290 + explosion * 380, 0.17 * (1 - dissolve));
}

type IdeaNode = { x: number; y: number; z: number; cluster: number; radius: number };

const ideaNodes: IdeaNode[] = Array.from({ length: 96 }, (_, index) => {
  const cluster = index % 4;
  const centerX = [-3.1, 3.2, -2.2, 2.0][cluster];
  const centerY = [-1.05, 0.8, 1.55, -1.7][cluster];
  return {
    x: centerX + (random() - 0.5) * 1.7,
    y: centerY + (random() - 0.5) * 1.45,
    z: (random() - 0.5) * 3.8,
    cluster,
    radius: 1.4 + random() * 2.7,
  };
});

function drawIdeas(ctx: CanvasRenderingContext2D, time: number, local: number) {
  const connect = smooth(0.32, 1.48, local);
  const points = ideaNodes.map((node, index) => {
    const ringAngle = index * 2.399 + time * 0.08;
    const target = {
      x: Math.cos(ringAngle) * (2.2 + node.radius * 0.18),
      y: Math.sin(ringAngle * 1.4) * 1.95,
      z: Math.sin(ringAngle) * 2.25,
    };
    const from = {
      x: node.x + Math.sin(time * 0.35 + index) * 0.08,
      y: node.y + Math.cos(time * 0.24 + index) * 0.08,
      z: node.z,
    };
    return project(
      {
        x: mix(from.x, target.x, connect),
        y: mix(from.y, target.y, connect),
        z: mix(from.z, target.z, connect),
      },
      time * 0.1,
      0.22,
      8.1,
    );
  });

  ctx.save();
  for (let i = 0; i < points.length; i += 1) {
    for (let j = i + 1; j < points.length; j += 1) {
      const distance = Math.hypot(points[i].x - points[j].x, points[i].y - points[j].y);
      if (distance < 195 && (distance < 108 || (i + j) % 8 === 0)) {
        const opacity = connect * (1 - distance / 230) * 0.45;
        ctx.strokeStyle = `rgba(196, 232, 159, ${opacity})`;
        ctx.lineWidth = 0.85;
        ctx.beginPath();
        ctx.moveTo(points[i].x, points[i].y);
        ctx.lineTo(points[j].x, points[j].y);
        ctx.stroke();
      }
    }
  }
  ctx.restore();
  points.forEach((point, index) => {
    drawPoint(ctx, point.x, point.y, index % 13 === 0 ? 3.7 : 1.6, index % 8 === 0 ? LIME : "#e4ecd9", 0.78);
  });

  for (let i = 0; i < 4; i += 1) {
    const angle = time * 0.1 + i * Math.PI * 0.5;
    const x = 960 + Math.cos(angle) * (410 - connect * 100);
    const y = 540 + Math.sin(angle * 1.2) * (170 - connect * 42);
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle * 0.33);
    ctx.strokeStyle = `rgba(207, 246, 159, ${0.28 + connect * 0.28})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    if (i % 2 === 0) ctx.arc(0, 0, 32, 0.15, Math.PI * 1.73);
    else {
      ctx.moveTo(0, -36);
      ctx.lineTo(32, 18);
      ctx.lineTo(-32, 18);
      ctx.closePath();
    }
    ctx.stroke();
    ctx.restore();
  }

  trackedText(ctx, "IDEAS", 960, 165, 66, "#c7ff57", 600, 10, smooth(0.19, 0.49, local));
  if (local > 0.72) trackedText(ctx, "CONNECT.", 960, 885, 98, WHITE, 520, -1, smooth(0.71, 1.03, local));
}

const kineticWords = [
  { text: "THINK", x: 390, y: 285, angle: -0.08, size: 88 },
  { text: "BUILD", x: 1450, y: 340, angle: 0.07, size: 102 },
  { text: "TEST", x: 320, y: 700, angle: 0.05, size: 83 },
  { text: "CREATE", x: 1390, y: 748, angle: -0.06, size: 85 },
  { text: "ITERATE", x: 600, y: 868, angle: 0.025, size: 65 },
  { text: "LAUNCH", x: 1320, y: 190, angle: -0.03, size: 63 },
];

function drawNoise(ctx: CanvasRenderingContext2D, local: number, time: number) {
  const order = smooth(1.52, 2.27, local);
  const accents = [WHITE, LIME, "#bdc2b8", "#e5e8e0", LIME, "#c9cec5"];
  kineticWords.forEach((word, index) => {
    const drift = 18 + (index % 3) * 8;
    const x = mix(word.x + Math.sin(time * 0.8 + index) * drift, 960, order);
    const y = mix(word.y + Math.cos(time * 0.9 + index) * drift, 545 + (index - 2.5) * 12, order);
    const scale = mix(1, 0.65, order);
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(word.angle * (1 - order) + Math.sin(time * 0.35 + index) * 0.012 * (1 - order));
    ctx.scale(scale, scale);
    ctx.globalAlpha *= 1 - order * 0.68;
    trackedText(ctx, word.text, 0, 0, word.size, accents[index], 650, -3, smooth(0.08, 0.45, local));
    ctx.restore();
  });

  if (local > 1.63) {
    const arrive = smooth(1.63, 2.11, local);
    const impact = 1 + (1 - smooth(2.08, 2.36, local)) * 0.035;
    ctx.save();
    ctx.translate(960, 548);
    ctx.scale(impact, impact);
    ctx.translate(-960, -548);
    trackedText(ctx, "MAKE NOISE.", 960, 548, 183, WHITE, 620, -5, arrive);
    ctx.restore();
  }
}

function drawHumanIntent(ctx: CanvasRenderingContext2D, time: number, intensity: number) {
  ctx.save();
  ctx.globalAlpha *= intensity;
  const wave = time * 0.32;
  const paths = [
    [
      [210, 540], [360, 360], [500, 755], [650, 470], [795, 548],
    ],
    [
      [238, 430], [390, 640], [498, 352], [645, 695], [812, 514],
    ],
    [
      [272, 655], [398, 470], [568, 590], [690, 405], [838, 586],
    ],
  ];
  paths.forEach((points, index) => {
    ctx.beginPath();
    ctx.moveTo(points[0][0], points[0][1]);
    ctx.bezierCurveTo(
      points[1][0] + Math.sin(wave + index) * 16,
      points[1][1],
      points[2][0],
      points[2][1] + Math.cos(wave + index) * 20,
      points[3][0],
      points[3][1],
    );
    ctx.quadraticCurveTo(points[4][0] - 24, points[4][1] - 50, points[4][0], points[4][1]);
    ctx.strokeStyle = index === 1 ? "rgba(202, 255, 87, 0.78)" : "rgba(235, 239, 230, 0.43)";
    ctx.lineWidth = index === 1 ? 2.1 : 1.15;
    ctx.shadowColor = index === 1 ? "rgba(194, 255, 69, 0.34)" : "transparent";
    ctx.shadowBlur = index === 1 ? 18 : 0;
    ctx.stroke();
  });
  ctx.restore();
}

function drawMachineSystem(ctx: CanvasRenderingContext2D, time: number, intensity: number) {
  ctx.save();
  ctx.globalAlpha *= intensity;
  const xStart = 1120;
  const yStart = 293;
  const width = 470;
  const height = 495;
  ctx.strokeStyle = "rgba(210, 222, 204, 0.12)";
  ctx.lineWidth = 0.8;
  for (let column = 0; column <= 13; column += 1) {
    const x = xStart + (width * column) / 13;
    ctx.beginPath();
    ctx.moveTo(x, yStart);
    ctx.lineTo(x, yStart + height);
    ctx.stroke();
  }
  for (let row = 0; row <= 14; row += 1) {
    const y = yStart + (height * row) / 14;
    ctx.beginPath();
    ctx.moveTo(xStart, y);
    ctx.lineTo(xStart + width, y);
    ctx.stroke();
  }

  for (let i = 0; i < 18; i += 1) {
    const x = xStart + ((i * 79 + time * 93) % width);
    const y = yStart + ((i * 119 + time * 47) % height);
    ctx.strokeStyle = i % 4 === 0 ? "rgba(202, 255, 56, 0.76)" : "rgba(222, 235, 214, 0.56)";
    ctx.beginPath();
    ctx.moveTo(x - 11, y);
    ctx.lineTo(x + 12, y);
    ctx.stroke();
    drawPoint(ctx, x, y, i % 4 === 0 ? 2.5 : 1.2, i % 4 === 0 ? LIME : "#dce9d2", 0.8);
  }
  ctx.restore();
}

function drawHumanMachine(ctx: CanvasRenderingContext2D, time: number, local: number) {
  const merge = smooth(0.12, 0.78, local);
  const leftIntensity = 1 - smooth(0.78, 1, local) * 0.36;
  drawHumanIntent(ctx, time, leftIntensity);
  drawMachineSystem(ctx, time, leftIntensity);

  const centerX = 960;
  const centerY = 540;
  ctx.save();
  ctx.lineWidth = 1.2;
  for (let i = 0; i < 9; i += 1) {
    const stagger = i * 0.055;
    const reach = smooth(0.17 + stagger, 0.73 + stagger, local);
    const spread = (i - 4) * 23;
    ctx.strokeStyle = i % 3 === 0 ? "rgba(200,255,56,0.68)" : "rgba(218,231,207,0.33)";
    ctx.beginPath();
    ctx.moveTo(455 + spread * 0.48, centerY + spread * 1.65);
    ctx.bezierCurveTo(690, centerY + spread, 760, centerY + spread * (1 - reach), centerX, centerY + spread * (1 - reach));
    ctx.bezierCurveTo(1160, centerY + spread * (1 - reach), 1230, centerY - spread, 1460 - spread * 0.48, centerY - spread * 1.65);
    ctx.stroke();
  }
  ctx.restore();
  drawGlow(ctx, centerX, centerY, 130 + merge * 120, 0.28 + merge * 0.2);
  drawPoint(ctx, centerX, centerY, 4 + merge * 7, "#efffd2", 0.96);

  if (local > 0.15) {
    const phraseOne = smooth(0.15, 0.46, local) * (1 - smooth(1.26, 1.58, local));
    const phraseTwo = smooth(0.58, 0.88, local) * (1 - smooth(1.48, 1.8, local));
    const centerMove = smooth(1.44, 2.05, local);
    ctx.save();
    ctx.globalAlpha *= phraseOne;
    trackedText(ctx, "HUMAN INTENT.", mix(545, 960, centerMove), mix(453, 476, centerMove), 69, WHITE, 530, -1, smooth(0.16, 0.53, local), centerMove > 0.8 ? "center" : "left");
    ctx.restore();
    ctx.save();
    ctx.globalAlpha *= phraseTwo;
    trackedText(ctx, "MACHINE SPEED.", mix(1370, 960, centerMove), mix(637, 604, centerMove), 69, LIME, 520, -1, smooth(0.58, 0.96, local), centerMove > 0.8 ? "center" : "right");
    ctx.restore();
    if (local > 2.03) {
      ctx.save();
      ctx.globalAlpha *= smooth(2.02, 2.3, local) * 0.7;
      trackedText(ctx, "HUMAN INTENT.  MACHINE SPEED.", 960, 840, 34, "#e3ebdc", 500, 3, smooth(2.02, 2.34, local));
      ctx.restore();
    }
  }
}

type Building = { x: number; z: number; width: number; depth: number; height: number; tone: number; type: number };

const buildings: Building[] = Array.from({ length: 118 }, (_, index) => {
  const lane = index % 17;
  const row = Math.floor(index / 17);
  return {
    x: (lane - 8) * (0.78 + random() * 0.11),
    z: row * 1.55 - 4.3 + (random() - 0.5) * 0.45,
    width: 0.28 + random() * 0.58,
    depth: 0.3 + random() * 0.52,
    height: 0.6 + random() * (index % 11 === 0 ? 5.4 : 3.2),
    tone: random(),
    type: index % 5,
  };
});

function drawCity(ctx: CanvasRenderingContext2D, time: number, local: number) {
  const construction = smooth(0.02, 1.05, local);
  const cameraZ = 10.6 - local * 1.18;
  const cameraShift = smooth(1.2, 2.88, local) * 2.6;
  const angle = Math.sin(time * 0.16) * 0.1;
  drawGlow(ctx, 960, 555, 620, 0.11, "147, 180, 99");

  ctx.save();
  ctx.strokeStyle = "rgba(193, 223, 166, 0.13)";
  ctx.lineWidth = 0.8;
  for (let i = -12; i <= 12; i += 1) {
    const near = project({ x: i * 0.8, y: -1.5, z: -5.5 + cameraShift }, angle, 0.06, cameraZ);
    const far = project({ x: i * 0.15, y: -1.5, z: 9 }, angle, 0.06, cameraZ);
    ctx.beginPath();
    ctx.moveTo(near.x, near.y);
    ctx.lineTo(far.x, far.y);
    ctx.stroke();
  }
  for (let i = 0; i < 15; i += 1) {
    const z = -5 + i * 1.1;
    const left = project({ x: -12, y: -1.5, z }, angle, 0.06, cameraZ);
    const right = project({ x: 12, y: -1.5, z }, angle, 0.06, cameraZ);
    ctx.beginPath();
    ctx.moveTo(left.x, left.y);
    ctx.lineTo(right.x, right.y);
    ctx.stroke();
  }
  ctx.restore();

  const sorted = [...buildings].sort((a, b) => b.z - a.z);
  sorted.forEach((building, index) => {
    const localDepth = building.z + cameraShift;
    const rise = construction * Math.min(1, 0.72 + ((index * 7) % 24) / 70);
    const height = building.height * rise;
    const yBase = -1.5;
    const x = building.x + Math.sin(time * 0.09 + index) * 0.035;
    const frontA = project({ x: x - building.width / 2, y: yBase, z: localDepth - building.depth / 2 }, angle, 0.06, cameraZ);
    const frontB = project({ x: x + building.width / 2, y: yBase, z: localDepth - building.depth / 2 }, angle, 0.06, cameraZ);
    const frontC = project({ x: x + building.width / 2, y: yBase + height, z: localDepth - building.depth / 2 }, angle, 0.06, cameraZ);
    const frontD = project({ x: x - building.width / 2, y: yBase + height, z: localDepth - building.depth / 2 }, angle, 0.06, cameraZ);
    const sideB = project({ x: x + building.width / 2, y: yBase, z: localDepth + building.depth / 2 }, angle, 0.06, cameraZ);
    const sideC = project({ x: x + building.width / 2, y: yBase + height, z: localDepth + building.depth / 2 }, angle, 0.06, cameraZ);

    const brightness = 0.065 + building.tone * 0.1;
    ctx.fillStyle = `rgba(180, 197, 167, ${brightness})`;
    ctx.beginPath();
    ctx.moveTo(frontA.x, frontA.y);
    ctx.lineTo(frontB.x, frontB.y);
    ctx.lineTo(frontC.x, frontC.y);
    ctx.lineTo(frontD.x, frontD.y);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = `rgba(195, 211, 183, ${brightness * 0.72})`;
    ctx.beginPath();
    ctx.moveTo(frontB.x, frontB.y);
    ctx.lineTo(sideB.x, sideB.y);
    ctx.lineTo(sideC.x, sideC.y);
    ctx.lineTo(frontC.x, frontC.y);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = building.type === 0 ? "rgba(209, 247, 149, 0.42)" : "rgba(220, 235, 209, 0.23)";
    ctx.lineWidth = 0.85;
    ctx.beginPath();
    ctx.moveTo(frontA.x, frontA.y);
    ctx.lineTo(frontD.x, frontD.y);
    ctx.lineTo(frontC.x, frontC.y);
    ctx.lineTo(sideC.x, sideC.y);
    ctx.lineTo(sideB.x, sideB.y);
    ctx.lineTo(frontB.x, frontB.y);
    ctx.stroke();

    if (building.type === 1 && index % 2 === 0) {
      const top = project({ x, y: yBase + height + 0.5, z: localDepth }, angle, 0.06, cameraZ);
      const low = project({ x, y: yBase + height, z: localDepth }, angle, 0.06, cameraZ);
      ctx.strokeStyle = "rgba(197, 255, 79, 0.5)";
      ctx.beginPath();
      ctx.moveTo(low.x, low.y);
      ctx.lineTo(top.x, top.y);
      ctx.stroke();
    }

    if (index % 5 === 0 && frontD.y > 120 && frontD.y < 940) {
      const windowCount = 3;
      for (let window = 0; window < windowCount; window += 1) {
        const u = (window + 1) / (windowCount + 1);
        const px = mix(frontA.x, frontB.x, u);
        const py = mix(frontD.y, frontA.y, 0.62);
        if ((index + window) % 6 === 0) drawPoint(ctx, px, py, 1.7, LIME, 0.8);
      }
    }
  });

  for (let i = 0; i < 8; i += 1) {
    const orbit = time * 0.14 + i * 0.79;
    const point = project({ x: Math.sin(orbit) * 5.2, y: 1.2 + Math.cos(orbit * 1.4) * 1.2, z: Math.cos(orbit) * 4 + cameraShift }, angle, 0.05, cameraZ);
    drawPoint(ctx, point.x, point.y, 2.1 + (i % 3), i % 3 === 0 ? LIME : "#e2efd8", 0.8);
  }

  if (local > 0.22) {
    const titleProgress = smooth(0.2, 0.58, local);
    trackedText(ctx, "BUILD", 960, 410, 155, WHITE, 600, -5, titleProgress);
    if (local > 0.86) trackedText(ctx, "WHAT'S NEXT.", 960, 574, 106, WHITE, 520, -2, smooth(0.83, 1.18, local));
  }
}

function drawBrandReveal(ctx: CanvasRenderingContext2D, local: number, time: number) {
  const collapse = 1 - smooth(0.03, 0.7, local);
  if (collapse > 0) {
    ctx.save();
    ctx.globalAlpha *= collapse;
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < 85; i += 1) {
      const angle = (i / 85) * Math.PI * 2 + time * 0.1;
      const radius = 80 + (i % 13) * 58;
      const x = 960 + Math.cos(angle) * radius;
      const y = 540 + Math.sin(angle) * radius * 0.57;
      ctx.strokeStyle = i % 5 === 0 ? "rgba(200,255,56,0.72)" : "rgba(230,238,224,0.37)";
      ctx.lineWidth = i % 7 === 0 ? 1.8 : 0.8;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(mix(x, 960, smooth(0.08, 0.72, local)), mix(y, 540, smooth(0.08, 0.72, local)));
      ctx.stroke();
      drawPoint(ctx, x, y, 1.3, i % 5 === 0 ? LIME : "#e9f5df", 0.88);
    }
    ctx.restore();
  }

  const lineProgress = smooth(0.46, 1.05, local);
  if (lineProgress > 0) {
    ctx.save();
    ctx.globalAlpha *= 1 - smooth(1.55, 1.88, local) * 0.9;
    const half = 490 * lineProgress;
    const gradient = ctx.createLinearGradient(960 - half, 0, 960 + half, 0);
    gradient.addColorStop(0, "rgba(200,255,56,0)");
    gradient.addColorStop(0.45, "rgba(200,255,56,0.92)");
    gradient.addColorStop(0.55, "rgba(237,255,207,0.98)");
    gradient.addColorStop(1, "rgba(200,255,56,0)");
    ctx.shadowColor = "rgba(200,255,56,0.84)";
    ctx.shadowBlur = 18;
    ctx.strokeStyle = gradient;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(960 - half, 541);
    ctx.lineTo(960 + half, 541);
    ctx.stroke();
    ctx.restore();
  }

  if (local > 0.82) {
    const reveal = smooth(0.79, 1.28, local);
    const logoFade = 1 - smooth(2.66, 2.98, local) * 0.75;
    ctx.save();
    ctx.globalAlpha *= reveal * logoFade;
    const markX = 687;
    drawMark(ctx, markX, 533, 71, 1, time * 0.04);
    trackedText(ctx, "CUPRIC", 787, 542, 111, WHITE, 650, 6, reveal, "left");
    trackedText(ctx, "AI", 1220, 542, 48, LIME, 650, 12, reveal, "left");
    ctx.restore();
  }
}

function drawBrandHold(ctx: CanvasRenderingContext2D, local: number, time: number) {
  const titleOpacity = smooth(0.03, 0.38, local);
  drawMark(ctx, 736, 476, 53, 0.95, Math.sin(time * 0.15) * 0.025);
  trackedText(ctx, "CUPRIC", 818, 484, 91, WHITE, 650, 5, titleOpacity, "left");
  trackedText(ctx, "AI", 1168, 484, 40, LIME, 650, 10, titleOpacity, "left");
  ctx.save();
  ctx.globalAlpha *= smooth(0.33, 0.72, local);
  trackedText(ctx, "INTELLIGENCE FOR PEOPLE WHO BUILD.", 960, 636, 42, "#e0e4db", 480, 5, smooth(0.35, 0.76, local));
  ctx.restore();
  drawGlow(ctx, 960, 541, 365, 0.08);
}

function drawEndCard(ctx: CanvasRenderingContext2D, local: number, time: number) {
  const fade = smooth(0.02, 0.46, local);
  const push = 1 + smooth(0.1, 2, local) * 0.018;
  ctx.save();
  ctx.translate(960, 540);
  ctx.scale(push, push);
  ctx.translate(-960, -540);
  ctx.globalAlpha *= fade;
  drawGlow(ctx, 960, 454, 320, 0.13 + Math.sin(time * 0.65) * 0.02);
  drawMark(ctx, 742, 469, 51, 0.97, Math.sin(time * 0.12) * 0.025);
  trackedText(ctx, "CUPRIC", 825, 478, 94, WHITE, 650, 5, fade, "left");
  trackedText(ctx, "AI", 1173, 478, 41, LIME, 650, 10, fade, "left");
  trackedText(ctx, "INTELLIGENCE FOR PEOPLE WHO BUILD.", 960, 604, 31, "#d8ddd3", 470, 4, smooth(0.18, 0.61, local));
  trackedText(ctx, "CREATE WITHOUT LIMITS.", 960, 684, 19, "#aeb5a8", 520, 6, smooth(0.39, 0.75, local));
  ctx.restore();
}

function drawAmbientParticles(ctx: CanvasRenderingContext2D, time: number, pointerX: number, pointerY: number) {
  ctx.save();
  ctx.globalAlpha = 0.2;
  for (let i = 0; i < 80; i += 1) {
    const x = (i * 419 + Math.sin(time * 0.15 + i) * 110 + pointerX * 12 + 2400) % W;
    const y = (i * 173 + Math.cos(time * 0.13 + i * 2) * 85 + pointerY * 8 + 1300) % H;
    const radius = i % 11 === 0 ? 1.7 : 0.8;
    drawPoint(ctx, x, y, radius, i % 9 === 0 ? LIME : "#b7c2ae", 0.36 + 0.18 * Math.sin(time + i));
  }
  ctx.restore();
}

export function drawFilmFrame(
  ctx: CanvasRenderingContext2D,
  time: number,
  pointerX = 0,
  pointerY = 0,
) {
  const safeTime = clamp(time, 0, DURATION - 1 / 30);
  const chapter = safeTime < 36 ? Math.floor(safeTime / 3) : safeTime < 38 ? 12 : 13;
  const chapterStart = chapter === 12 ? 36 : chapter === 13 ? 38 : chapter * 3;
  const local = safeTime - chapterStart;
  const frame = Math.floor(safeTime * 30);

  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, W, H);
  drawAtmosphere(ctx, safeTime);
  drawAmbientParticles(ctx, safeTime, pointerX, pointerY);
  ctx.save();
  ctx.translate(pointerX * 7, pointerY * 5);
  ctx.translate(W / 2, H / 2);
  ctx.scale(1 + Math.sin(safeTime * 0.09) * 0.0035, 1 + Math.sin(safeTime * 0.09) * 0.0035);
  ctx.translate(-W / 2, -H / 2);

  const enter = smooth(0, 0.22, local);
  const exit = 1 - smooth(2.79, 3, local);
  ctx.save();
  ctx.globalAlpha *= enter * exit;

  switch (chapter) {
    case 0:
      drawHook(ctx, local, safeTime);
      break;
    case 1:
      drawBranches(ctx, safeTime, local);
      break;
    case 2:
      drawNetwork(ctx, safeTime, local);
      break;
    case 3:
      drawBuildFaster(ctx, safeTime, local);
      break;
    case 4:
      drawPromptProduct(ctx, safeTime, local);
      break;
    case 5:
      drawRepetition(ctx, safeTime, local);
      break;
    case 6:
      drawFracture(ctx, local, safeTime);
      break;
    case 7:
      drawIdeas(ctx, safeTime, local);
      break;
    case 8:
      drawNoise(ctx, local, safeTime);
      break;
    case 9:
      drawHumanMachine(ctx, safeTime, local);
      break;
    case 10:
      drawCity(ctx, safeTime, local);
      break;
    case 11:
      drawBrandReveal(ctx, local, safeTime);
      break;
    case 12:
      drawBrandHold(ctx, local, safeTime);
      break;
    default:
      drawEndCard(ctx, local, safeTime);
      break;
  }
  ctx.restore();

  if (chapter < 11) drawTransition(ctx, local, chapter);
  if (chapter >= 11) drawGrain(ctx, frame);
  ctx.restore();
  ctx.restore();
}
"""Post-build validation of a generated CapCut/JianYing draft."""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List


def validate_draft(draft_dir: str, expected: Dict[str, Any]) -> Dict[str, Any]:
    problems: List[str] = []
    content_path = os.path.join(draft_dir, "draft_content.json")
    if not os.path.exists(content_path):
        return {"ok": False, "problems": [f"draft_content.json missing in {draft_dir}"], "stats": {}}
    if not os.path.exists(os.path.join(draft_dir, "draft_meta_info.json")):
        problems.append("draft_meta_info.json missing")
    try:
        with open(content_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as exc:
        return {"ok": False, "problems": [f"draft_content.json is not valid JSON: {exc}"], "stats": {}}

    counts: Dict[str, int] = {}
    for track in data.get("tracks", []):
        t = track.get("type", "?")
        counts[t] = counts.get(t, 0) + len(track.get("segments", []))
    for key in ("video", "audio", "text"):
        exp = int(expected.get(key, 0))
        got = counts.get(key, 0)
        if got != exp:
            problems.append(f"expected {exp} {key} segment(s) but draft contains {got}")

    missing = []
    mats = data.get("materials", {})
    for m in mats.get("videos", []) + mats.get("audios", []):
        p = m.get("path")
        if p and not os.path.exists(p):
            missing.append(p)
    if missing:
        problems.append(f"{len(missing)} referenced media file(s) are missing: {', '.join(missing[:5])}")

    duration_s = data.get("duration", 0) / 1_000_000
    exp_dur = float(expected.get("duration_s", 0))
    fps = float(data.get("fps", 30) or 30)
    if exp_dur and abs(duration_s - exp_dur) > 2.0 / fps + 0.05:
        problems.append(f"draft duration {duration_s:.3f}s differs from planned {exp_dur:.3f}s")
    canvas = data.get("canvas_config", {})
    if expected.get("width") and canvas.get("width") != expected["width"]:
        problems.append(f"canvas width {canvas.get('width')} ≠ {expected['width']}")
    return {"ok": not problems, "problems": problems, "stats": {"segments": counts, "duration_s": round(duration_s, 3), "tracks": len(data.get("tracks", [])), "canvas": canvas}}

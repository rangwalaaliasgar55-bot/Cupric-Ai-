"""Deterministic CapCut/JianYing draft builder.

Input : a *resolved build plan* compiled from the validated EDL (+ project config
        + media inventory). Every segment already carries absolute timeline and
        source times. This module makes NO creative decisions — it executes.
Output: a CapCut draft folder written exclusively through pyJianYingDraft APIs.

Library enum members keep their original (Chinese) identifiers; we only map our
stable EDL enum values onto them and report anything the installed library
does not support instead of faking it.
"""
from __future__ import annotations

import math
import os
import shutil
import subprocess
from typing import Any, Dict, List, Optional

from backups import prune, stamp, swap_in
from protocol import EngineError, ffmpeg_exe, log, progress, to_us
from validation import validate_draft

TRANSITIONS = {"dissolve": "叠化", "flash_white": "闪白", "push_in": "推近", "pull_out": "拉远", "blur": "模糊", "slide": "滑动"}
TEXT_INTRO = {"fade": "渐显", "pop": "弹入", "typewriter": "打字机_I", "slide_up": "向上滑动", "zoom": "轻微放大"}
TEXT_OUTRO = {"fade": "渐隐", "pop": "弹出", "typewriter": "渐隐", "slide_up": "向下滑动", "zoom": "缩小"}
LOOKS = {
    "neutral_clean": None, "cool_tech": "冷白", "warm_cinematic": "情感电影", "bright_airy": "清晰明亮",
    "moody_dark": "暗夜", "natural": "清透自然", "vintage_film": "港风", "high_contrast": "明晰", "luxury": "臻金",
}


class Builder:
    def __init__(self, plan: Dict[str, Any]):
        self.plan = plan
        self.notes: List[str] = []
        self.unsupported: List[str] = []
        import pyJianYingDraft as draft  # type: ignore

        self.d = draft

    # ---------- helpers ----------
    def enum(self, enum_cls: Any, member: Optional[str], what: str) -> Any:
        if not member:
            return None
        val = getattr(enum_cls, member, None)
        if val is None:
            self.unsupported.append(f"{what} '{member}' is not available in the installed pyJianYingDraft; skipped.")
        return val

    def tr(self, start_s: float, dur_s: float) -> Any:
        return self.d.Timerange(to_us(start_s), max(1, to_us(dur_s)))

    def extract_audio(self, source: str) -> Optional[str]:
        """Extract a clip's audio to WAV (cached) so dialogue lives on its own tracks (enables J/L cuts)."""
        cache = self.plan["audio_cache_dir"]
        os.makedirs(cache, exist_ok=True)
        st = os.stat(source)
        key = f"{abs(hash((source, st.st_size, int(st.st_mtime)))) :x}"
        out = os.path.join(cache, f"{os.path.splitext(os.path.basename(source))[0]}_{key}.wav")
        if os.path.exists(out) and os.path.getsize(out) > 0:
            return out
        r = subprocess.run([ffmpeg_exe(), "-y", "-loglevel", "error", "-i", source, "-vn", "-ac", "2", "-ar", "48000", "-c:a", "pcm_s16le", out],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=1800)
        if r.returncode != 0:
            raise EngineError("AUDIO_EXTRACT_FAILED", f"Dialogue audio could not be extracted from {os.path.basename(source)}.",
                              {"stderr": r.stderr.decode("utf-8", "ignore")[-500:], "path": source})
        return out

    # ---------- segments ----------
    def video_segment(self, v: Dict[str, Any]) -> Any:
        d = self.d
        if not os.path.exists(v["path"]):
            raise EngineError("FILE_NOT_FOUND", f"CapCut draft generation failed because {os.path.basename(v['path'])} could not be found.", {"path": v["path"]})
        speed = float(v.get("speed") or 1.0)
        kwargs: Dict[str, Any] = {"volume": 0.0 if v.get("mute") else float(v.get("volume", 1.0))}
        if v.get("kind") == "image":
            seg = d.VideoSegment(v["path"], self.tr(v["tl_start"], v["tl_dur"]), **kwargs)
        else:
            seg = d.VideoSegment(v["path"], self.tr(v["tl_start"], v["tl_dur"]), source_timerange=self.tr(v["src_in"], v["dur_src"]), speed=speed, **kwargs)
        dur_us = to_us(v["tl_dur"])
        zoom = v.get("zoom")
        pos = v.get("position") or {}
        if zoom and abs(float(zoom["end"]) - float(zoom["start"])) > 1e-4:
            # pyJianYingDraft keyframes are linear between points; approximate an
            # ease-in-out curve with 5 sampled keyframes so motion never feels robotic.
            for i in range(5):
                t = i / 4
                eased = 0.5 - 0.5 * math.cos(math.pi * t)
                val = float(zoom["start"]) + (float(zoom["end"]) - float(zoom["start"])) * eased
                seg.add_keyframe(d.KeyframeProperty.uniform_scale, int(dur_us * t) if i < 4 else max(0, dur_us - 1), val)
        elif zoom and float(zoom["start"]) != 1.0:
            seg.add_keyframe(d.KeyframeProperty.uniform_scale, 0, float(zoom["start"]))
        if pos.get("x"):
            seg.add_keyframe(d.KeyframeProperty.position_x, 0, float(pos["x"]))
        if pos.get("y"):
            seg.add_keyframe(d.KeyframeProperty.position_y, 0, float(pos["y"]))
        color = v.get("color") or {}
        for prop, key in ((d.KeyframeProperty.brightness, "brightness"), (d.KeyframeProperty.contrast, "contrast"), (d.KeyframeProperty.saturation, "saturation")):
            if abs(float(color.get(key, 0) or 0)) > 0.005:
                seg.add_keyframe(prop, 0, max(-1.0, min(1.0, float(color[key]))))
        if v.get("transition_out"):
            t = v["transition_out"]
            tt = self.enum(d.TransitionType, TRANSITIONS.get(t["type"]), "Transition")
            if tt is not None:
                seg.add_transition(tt, duration=to_us(t.get("duration", 0.4)))
        if v.get("background_fill"):
            try:
                seg.add_background_filling("blur", 0.0625)
            except Exception as exc:
                self.notes.append(f"Background blur fill skipped: {exc}")
        return seg

    def audio_segment(self, a: Dict[str, Any], path: str) -> Any:
        d = self.d
        speed = float(a.get("speed") or 1.0)
        seg = d.AudioSegment(path, self.tr(a["tl_start"], a["tl_dur"]), source_timerange=self.tr(a["src_in"], a["dur_src"]), speed=speed, volume=float(a.get("volume", 1.0)))
        fi, fo = float(a.get("fade_in", 0) or 0), float(a.get("fade_out", 0) or 0)
        if fi > 0 or fo > 0:
            seg.add_fade(to_us(fi), to_us(fo))
        for k in a.get("duck", []) or []:
            seg.add_keyframe(max(0, to_us(k["t"])), float(k["v"]))
        return seg

    # ---------- build ----------
    def build(self) -> Dict[str, Any]:
        d, p = self.d, self.plan
        root, name = p["draft_root"], p["draft_name"]
        if not os.path.isdir(root):
            raise EngineError("DRAFT_ROOT_MISSING", f"The CapCut draft folder {root} does not exist. Set it in Settings → Storage.", {"draft_root": root})
        if not os.access(root, os.W_OK):
            raise EngineError("DRAFT_ROOT_READONLY", f"The CapCut draft folder {root} is not writable.", {"draft_root": root})
        temp_name = f".{name}__building_{stamp()}"
        temp_dir = os.path.join(root, temp_name)
        try:
            progress(3, "create_draft", f"Creating draft '{name}' ({p['width']}×{p['height']} @ {p['fps']}fps)")
            folder = d.DraftFolder(root)
            script = folder.create_draft(temp_name, int(p["width"]), int(p["height"]), fps=int(p["fps"]), allow_replace=False)

            progress(8, "tracks", "Creating tracks")
            T = d.TrackType
            specs = [d.TrackSpec(T.video, "Main")]
            if p.get("overlay"):
                specs.append(d.TrackSpec(T.video, "Overlay"))
            lanes = sorted({int(a.get("lane", 0)) for a in p.get("dialogue", [])})
            for lane in lanes:
                specs.append(d.TrackSpec(T.audio, f"Dialogue {'AB'[lane]}"))
            for key, label in (("music", "Music"), ("sfx", "SFX"), ("ambience", "Ambience")):
                if p.get(key):
                    specs.append(d.TrackSpec(T.audio, label))
            cap_lanes = sorted({int(c.get("lane", 0)) for c in p.get("captions", [])})
            for lane in cap_lanes:
                specs.append(d.TrackSpec(T.text, "Captions" if lane == 0 else f"Captions {lane + 1}"))
            look = p.get("look") or {}
            if look.get("filter"):
                specs.append(d.TrackSpec(T.filter, "Look"))
            if look.get("vignette") or look.get("grain"):
                specs.append(d.TrackSpec(T.effect, "Texture"))
            refs = {r.name: r for r in script.append_tracks(specs)}

            videos = p.get("video", [])
            for i, v in enumerate(videos):
                progress(10 + 30 * (i / max(1, len(videos))), "video", f"Adding video {i + 1}/{len(videos)}: {os.path.basename(v['path'])}")
                script.add_segment(self.video_segment(v), refs["Main"])
            for v in p.get("overlay", []):
                script.add_segment(self.video_segment(v), refs["Overlay"])

            dialogue = p.get("dialogue", [])
            for i, a in enumerate(dialogue):
                progress(42 + 18 * (i / max(1, len(dialogue))), "audio", f"Adding dialogue {i + 1}/{len(dialogue)}")
                wav = self.extract_audio(a["source_path"])
                script.add_segment(self.audio_segment(a, wav), refs[f"Dialogue {'AB'[int(a.get('lane', 0))]}"])
            for a in p.get("music", []):
                progress(61, "audio", f"Adding music {os.path.basename(a['path'])} with dialogue ducking")
                script.add_segment(self.audio_segment(a, a["path"]), refs["Music"])
            for a in p.get("ambience", []):
                script.add_segment(self.audio_segment(a, a["path"]), refs["Ambience"])

            caps = p.get("captions", [])
            for i, c in enumerate(caps):
                if i % 10 == 0:
                    progress(64 + 14 * (i / max(1, len(caps))), "captions", f"Adding captions {i + 1}/{len(caps)}")
                font = self.enum(d.FontType, c.get("font"), "Font") if c.get("font") else None
                style = d.TextStyle(size=float(c.get("size", 8)), bold=bool(c.get("bold")), color=tuple(c.get("color", [1, 1, 1])),
                                    align=1, auto_wrapping=True, max_line_width=float(c.get("max_line_width", 0.82)))
                seg = d.TextSegment(c["text"], self.tr(c["tl_start"], c["tl_dur"]), font=font, style=style,
                                    clip_settings=d.ClipSettings(transform_y=float(c.get("y", -0.6))),
                                    border=d.TextBorder(width=float(c.get("border_width", 35))) if c.get("border", True) else None)
                anim_len = min(0.25, c["tl_dur"] / 3)
                if c.get("intro") and c["tl_dur"] > 0.5:
                    it = self.enum(d.TextIntro, TEXT_INTRO.get(c["intro"]), "Text intro")
                    if it is not None:
                        seg.add_animation(it, to_us(anim_len))
                if c.get("outro") and c["tl_dur"] > 0.8:
                    ot = self.enum(d.TextOutro, TEXT_OUTRO.get(c["outro"]), "Text outro")
                    if ot is not None:
                        seg.add_animation(ot, to_us(anim_len))
                script.add_segment(seg, refs["Captions" if int(c.get("lane", 0)) == 0 else f"Captions {int(c['lane']) + 1}"])

            progress(80, "sfx", f"Adding {len(p.get('sfx', []))} sound effect(s)")
            sfx_list = sorted(p.get("sfx", []), key=lambda s: s["tl_start"])
            last_end = -1.0
            sfx_added = 0
            for s in sfx_list:
                if s["tl_start"] < last_end:
                    self.notes.append(f"SFX at {s['tl_start']:.2f}s overlapped a previous SFX and was skipped.")
                    continue
                script.add_segment(self.audio_segment(s, s["path"]), refs["SFX"])
                last_end = s["tl_start"] + s["tl_dur"]
                sfx_added += 1

            progress(84, "effects", "Applying colour look & texture")
            total = float(p["total_duration"])
            if look.get("filter"):
                ft = self.enum(d.FilterType, LOOKS.get(look["filter"], look["filter"]) or None, "Filter")
                if ft is not None:
                    script.add_filter(ft, self.tr(0, total), "Look", intensity=float(look.get("intensity", 50)))
            fx_start = 0.0
            if look.get("vignette"):
                vt = self.enum(d.VideoSceneEffectType, "暗角", "Effect")
                if vt is not None:
                    script.add_effect(vt, self.tr(0, total), "Texture")
                    fx_start = total
            if look.get("grain") and not fx_start:
                gt = self.enum(d.VideoSceneEffectType, "噪点", "Effect")
                if gt is not None:
                    script.add_effect(gt, self.tr(0, total), "Texture")
            elif look.get("grain"):
                self.notes.append("Grain skipped: only one texture effect is applied to keep the look subtle.")

            progress(88, "save", "Saving draft")
            script.save()

            progress(92, "validate", "Validating generated draft")
            expected = {"video": len(videos) + len(p.get("overlay", [])),
                        "audio": len(dialogue) + len(p.get("music", [])) + len(p.get("ambience", [])) + sfx_added,
                        "text": len(caps), "duration_s": total, "width": int(p["width"])}
            report = validate_draft(temp_dir, expected)
            if not report["ok"]:
                raise EngineError("DRAFT_VALIDATION_FAILED", "The generated draft failed validation: " + "; ".join(report["problems"]), report)

            progress(96, "install", "Backing up previous draft and installing new version")
            installed = swap_in(root, temp_name, name, p["backup_dir"])
            pruned = prune(p["backup_dir"], name, int(p.get("backup_retention", 10)))
            progress(100, "complete", "Draft ready")
            return {**installed, "validation": report, "notes": self.notes, "unsupported": self.unsupported, "pruned_backups": pruned}
        except EngineError:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise
        except Exception as exc:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise EngineError("BUILD_FAILED", f"CapCut draft generation failed: {type(exc).__name__}: {exc}", {"type": type(exc).__name__})


def build(plan: Dict[str, Any]) -> Dict[str, Any]:
    try:
        import pyJianYingDraft  # noqa: F401  # type: ignore
    except Exception as exc:
        raise EngineError("PYJIANYINGDRAFT_MISSING", "pyJianYingDraft is not installed. Run `pip install pyJianYingDraft`.", {"reason": str(exc)})
    log(f"Building draft '{plan.get('draft_name')}' with {len(plan.get('video', []))} video segment(s)")
    return Builder(plan).build()

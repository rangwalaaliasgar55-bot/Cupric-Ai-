"""Local transcription with faster-whisper (word-level timestamps, confidences)."""
from __future__ import annotations

import os
import time
from typing import Any, Dict, Optional

from protocol import EngineError, progress


def transcribe(path: str, model_size: str = "small", language: Optional[str] = None, device: str = "auto",
               compute_type: str = "auto", word_timestamps: bool = True, model_dir: Optional[str] = None) -> Dict[str, Any]:
    try:
        from faster_whisper import WhisperModel  # type: ignore
    except Exception as exc:
        raise EngineError("WHISPER_MISSING", "faster-whisper is not installed. Run `pip install faster-whisper`.", {"reason": str(exc)})
    if not os.path.exists(path):
        raise EngineError("FILE_NOT_FOUND", f"{os.path.basename(path)} could not be found for transcription.", {"path": path})

    if device == "auto":
        device = "cpu"
        try:
            import ctranslate2  # type: ignore

            if ctranslate2.get_cuda_device_count() > 0:
                device = "cuda"
        except Exception:
            pass
    if compute_type == "auto":
        compute_type = "float16" if device == "cuda" else "int8"

    progress(2, "transcribe", f"Loading Whisper '{model_size}' model on {device} ({compute_type}) — first use downloads the model")
    t0 = time.time()
    try:
        model = WhisperModel(model_size, device=device, compute_type=compute_type, download_root=model_dir)
    except Exception as exc:
        raise EngineError("WHISPER_MODEL_LOAD_FAILED", f"The Whisper model '{model_size}' could not be loaded: {exc}", {"model": model_size, "device": device})

    progress(8, "transcribe", "Transcribing audio")
    try:
        segments_iter, info = model.transcribe(path, language=language or None, word_timestamps=word_timestamps, vad_filter=True, beam_size=5)
        duration = float(getattr(info, "duration", 0) or 0)
        segments = []
        for seg in segments_iter:
            words = []
            for w in (seg.words or []):
                words.append({"word": w.word.strip(), "start": round(float(w.start), 3), "end": round(float(w.end), 3), "confidence": round(float(w.probability), 3)})
            segments.append({
                "id": len(segments),
                "start": round(float(seg.start), 3),
                "end": round(float(seg.end), 3),
                "text": seg.text.strip(),
                "avg_logprob": round(float(seg.avg_logprob), 3),
                "no_speech_prob": round(float(seg.no_speech_prob), 3),
                "speaker": None,  # faster-whisper does not perform diarization
                "words": words,
            })
            if duration > 0:
                progress(8 + 90 * min(1.0, seg.end / duration), "transcribe", f"{seg.end:.1f}s / {duration:.1f}s")
    except Exception as exc:
        raise EngineError("TRANSCRIPTION_FAILED", f"Transcription of {os.path.basename(path)} failed: {exc}", {"path": path})

    progress(100, "transcribe", "Transcript complete")
    return {
        "language": getattr(info, "language", language),
        "language_probability": round(float(getattr(info, "language_probability", 0) or 0), 3),
        "duration_s": duration,
        "model": model_size,
        "device": device,
        "elapsed_s": round(time.time() - t0, 2),
        "speaker_diarization": False,
        "segments": segments,
    }

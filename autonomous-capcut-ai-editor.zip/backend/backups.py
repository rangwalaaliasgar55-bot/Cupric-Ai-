"""Backups + atomic draft replacement.

Rules:
  * An existing draft is ALWAYS copied to a timestamped backup before replacement.
  * A new draft is built under a temporary folder name and only swapped in after
    it has been saved and validated. If anything fails, the previous draft stays intact.
"""
from __future__ import annotations

import os
import shutil
import time
from typing import Any, Dict, List, Optional

from protocol import EngineError


def stamp() -> str:
    return time.strftime("%Y%m%d-%H%M%S") + f"-{int(time.time() * 1000) % 1000:03d}"


def backup_draft(draft_root: str, name: str, backup_dir: str) -> Optional[str]:
    src = os.path.join(draft_root, name)
    if not os.path.isdir(src):
        return None
    os.makedirs(backup_dir, exist_ok=True)
    dst = os.path.join(backup_dir, f"{name}__{stamp()}")
    shutil.copytree(src, dst)
    if not os.path.exists(os.path.join(dst, "draft_content.json")) and os.path.exists(os.path.join(src, "draft_content.json")):
        raise EngineError("BACKUP_FAILED", f"Backup of draft '{name}' is incomplete; generation aborted to protect the original.", {"backup": dst})
    return dst


def swap_in(draft_root: str, temp_name: str, final_name: str, backup_dir: str) -> Dict[str, Any]:
    """Backup existing final draft (if any) then atomically replace it with the temp draft."""
    final = os.path.join(draft_root, final_name)
    temp = os.path.join(draft_root, temp_name)
    if not os.path.isdir(temp):
        raise EngineError("TEMP_DRAFT_MISSING", "The newly built draft disappeared before it could be installed.", {"temp": temp})
    backup = backup_draft(draft_root, final_name, backup_dir)
    old = None
    if os.path.isdir(final):
        old = os.path.join(draft_root, f".{final_name}__old_{stamp()}")
        os.rename(final, old)
    try:
        os.rename(temp, final)
    except Exception as exc:
        if old and not os.path.exists(final):
            os.rename(old, final)
        raise EngineError("SWAP_FAILED", f"Could not install the new draft ({exc}); the previous draft was restored.", {"final": final})
    if old:
        shutil.rmtree(old, ignore_errors=True)
    return {"draft_path": final, "backup_path": backup}


def restore(backup_path: str, draft_root: str, final_name: str, backup_dir: str) -> Dict[str, Any]:
    if not os.path.isdir(backup_path):
        raise EngineError("BACKUP_NOT_FOUND", f"Backup folder {backup_path} no longer exists.", {"backup": backup_path})
    temp_name = f".{final_name}__restore_{stamp()}"
    shutil.copytree(backup_path, os.path.join(draft_root, temp_name))
    return swap_in(draft_root, temp_name, final_name, backup_dir)


def prune(backup_dir: str, name: str, keep: int) -> List[str]:
    if keep <= 0 or not os.path.isdir(backup_dir):
        return []
    mine = sorted([d for d in os.listdir(backup_dir) if d.startswith(f"{name}__")])
    removed = []
    for d in mine[:-keep]:
        shutil.rmtree(os.path.join(backup_dir, d), ignore_errors=True)
        removed.append(d)
    return removed

"""Media ingestion + automatic analysis.

probe()   – fast metadata + problem detection (never silently fails).
analyze() – thumbnails, filmstrip, scene boundaries, audio levels, silence
            regions, waveform, visual statistics and heuristic shot labels.
"""
from __future__ import annotations

import hashlib
import math
import os
import re
import subprocess
from typing import Any, Dict, List, Optional

from protocol import EngineError, ffmpeg_exe, progress

VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".avi", ".webm", ".mts", ".m2ts", ".wmv", ".flv", ".3gp"}
AUDIO_EXT = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".opus", ".wma", ".aiff", ".aif"}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".heic", ".tif", ".tiff", ".gif"}
# Codecs CapCut/JianYing reliably imports. Others are flagged, not rejected.
CAPCUT_SAFE_VIDEO = {"h264", "hevc", "prores", "mpeg4", "vp9", "mjpeg", "png", "dnxhd", "av1"}
CAPCUT_SAFE_IMAGE = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
SCREEN_RES = {(1920, 1080), (2560, 1440), (2880, 1800), (1440, 900), (3024, 1964), (3456, 2234), (1680, 1050), (3840, 2160), (2560, 1600), (1366, 768)}


def media_kind(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext in VIDEO_EXT:
        return "video"
    if ext in AUDIO_EXT:
        return "audio"
    if ext in IMAGE_EXT:
        return "image"
    return "unknown"


def quick_hash(path: str) -> str:
    """Content fingerprint: size + first/last MiB. Used for duplicate detection & cache keys."""
    size = os.path.getsize(path)
    h = hashlib.sha1(str(size).encode())
    with open(path, "rb") as f:
        h.update(f.read(1 << 20))
        if size > (2 << 20):
            f.seek(-(1 << 20), os.SEEK_END)
            h.update(f.read(1 << 20))
    return h.hexdigest()


def _warn(code: str, severity: str, message: str) -> Dict[str, str]:
    return {"code": code, "severity": severity, "message": message}


def probe(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        raise EngineError("FILE_NOT_FOUND", f"{os.path.basename(path)} could not be found at {path}.", {"path": path})
    kind = media_kind(path)
    info: Dict[str, Any] = {
        "path": path,
        "filename": os.path.basename(path),
        "kind": kind,
        "size_bytes": os.path.getsize(path),
        "mtime_ms": int(os.path.getmtime(path) * 1000),
        "hash": quick_hash(path),
        "duration_s": None,
        "width": None,
        "height": None,
        "fps": None,
        "variable_fps": False,
        "codec": None,
        "audio_codec": None,
        "has_audio": False,
        "sample_rate": None,
        "aspect_ratio": None,
        "warnings": [],
        "readable": True,
    }
    warnings: List[Dict[str, str]] = info["warnings"]
    if kind == "unknown":
        warnings.append(_warn("UNSUPPORTED_TYPE", "error", f"{info['filename']} is not a recognised video, audio or image file."))
        info["readable"] = False
        return info
    try:
        import av  # type: ignore

        container = av.open(path)
    except Exception as exc:
        warnings.append(_warn("CORRUPT", "error", f"{info['filename']} could not be opened; the file may be corrupt or truncated ({exc})."))
        info["readable"] = False
        return info
    try:
        if container.duration:
            info["duration_s"] = round(container.duration / 1_000_000, 3)
        vstream = next((s for s in container.streams if s.type == "video"), None)
        astream = next((s for s in container.streams if s.type == "audio"), None)
        if vstream is not None:
            cc = vstream.codec_context
            info["codec"] = cc.name
            info["width"], info["height"] = cc.width or None, cc.height or None
            avg = float(vstream.average_rate) if vstream.average_rate else None
            base = float(vstream.base_rate) if getattr(vstream, "base_rate", None) else None
            guessed = float(vstream.guessed_rate) if getattr(vstream, "guessed_rate", None) else None
            fps = avg or guessed or base
            info["fps"] = round(fps, 3) if fps else None
            if kind == "video" and avg and base and abs(avg - base) / base > 0.01:
                info["variable_fps"] = True
            if kind == "video" and not info["duration_s"] and vstream.duration and vstream.time_base:
                info["duration_s"] = round(float(vstream.duration * vstream.time_base), 3)
            # Decode one frame to catch corrupt payloads that still have valid headers.
            try:
                next(container.decode(video=0))
            except StopIteration:
                warnings.append(_warn("NO_FRAMES", "error", f"{info['filename']} contains no decodable video frames."))
                info["readable"] = False
            except Exception as exc:
                warnings.append(_warn("CORRUPT", "error", f"{info['filename']} has a video stream that failed to decode ({exc})."))
                info["readable"] = False
        if astream is not None:
            info["has_audio"] = True
            info["audio_codec"] = astream.codec_context.name
            info["sample_rate"] = astream.codec_context.sample_rate
    finally:
        container.close()

    if kind == "image":
        info["duration_s"] = None
        info["fps"] = None
        if os.path.splitext(path)[1].lower() not in CAPCUT_SAFE_IMAGE:
            warnings.append(_warn("UNSUPPORTED_CODEC", "warning", f"{info['filename']}: this image format may not import into CapCut; convert to JPG/PNG."))
    if kind == "video":
        if vstream is None:
            warnings.append(_warn("NO_VIDEO_STREAM", "error", f"{info['filename']} has a video extension but no video stream."))
            info["readable"] = False
        if not info["has_audio"]:
            warnings.append(_warn("MISSING_AUDIO", "info", f"{info['filename']} has no audio track; it can only be used as B-roll."))
        if info["codec"] and info["codec"] not in CAPCUT_SAFE_VIDEO:
            warnings.append(_warn("UNSUPPORTED_CODEC", "warning", f"{info['filename']} uses the '{info['codec']}' codec which CapCut may not import. Transcode to H.264."))
        if info["variable_fps"]:
            warnings.append(_warn("VARIABLE_FPS", "warning", f"{info['filename']} appears to be variable frame rate; cuts may drift by a frame in CapCut."))
    if kind in ("video", "image") and info["width"] and info["height"]:
        w, h = info["width"], info["height"]
        g = math.gcd(w, h) or 1
        info["aspect_ratio"] = f"{w // g}:{h // g}" if (w // g) < 100 else f"{w / h:.3f}:1"
        if min(w, h) < 360:
            warnings.append(_warn("LOW_RESOLUTION", "warning", f"{info['filename']} is only {w}×{h}; it will look soft when scaled."))
    if kind in ("video", "audio") and not info["duration_s"]:
        warnings.append(_warn("NO_DURATION", "error", f"{info['filename']}: duration could not be determined."))
        info["readable"] = False
    return info


def _run(cmd: List[str], timeout: int = 900) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)


def _thumbnail(path: str, out: str, at: float, width: int = 480) -> bool:
    r = _run([ffmpeg_exe(), "-y", "-loglevel", "error", "-ss", f"{max(0.0, at):.3f}", "-i", path, "-frames:v", "1", "-vf", f"scale={width}:-2", "-q:v", "3", out], 120)
    return r.returncode == 0 and os.path.exists(out)


def _scenes(path: str, threshold: float = 0.32) -> List[float]:
    r = _run([ffmpeg_exe(), "-hide_banner", "-i", path, "-an", "-vf", f"scale=320:-2,select='gt(scene,{threshold})',showinfo", "-f", "null", "-"])
    text = r.stderr.decode("utf-8", "ignore")
    return [round(float(m), 3) for m in re.findall(r"pts_time:([0-9.]+)", text)]


def _audio_analysis(path: str, duration: float) -> Dict[str, Any]:
    import numpy as np  # type: ignore

    sr = 8000
    r = _run([ffmpeg_exe(), "-loglevel", "error", "-i", path, "-vn", "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"])
    if r.returncode != 0 or not r.stdout:
        return {"error": r.stderr.decode("utf-8", "ignore")[-400:] or "no audio decoded"}
    samples = np.frombuffer(r.stdout, dtype=np.int16).astype(np.float32) / 32768.0
    if samples.size == 0:
        return {"error": "empty audio"}
    buckets = 240
    chunk = max(1, samples.size // buckets)
    waveform = [round(float(np.abs(samples[i:i + chunk]).max()), 4) for i in range(0, chunk * buckets, chunk) if i < samples.size]
    win = int(sr * 0.25)
    n = samples.size // win
    rms = np.sqrt(np.mean(samples[: n * win].reshape(n, win) ** 2, axis=1) + 1e-12) if n else np.array([1e-6])
    db = 20 * np.log10(rms + 1e-9)
    silent = db < -42.0
    silences: List[Dict[str, float]] = []
    start: Optional[int] = None
    for i, s in enumerate(list(silent) + [False]):
        if s and start is None:
            start = i
        elif not s and start is not None:
            if (i - start) * 0.25 >= 0.6:
                silences.append({"start_s": round(start * 0.25, 2), "end_s": round(i * 0.25, 2)})
            start = None
    active = db[~silent] if (~silent).any() else db
    mean, std = float(active.mean()), float(active.std())
    spikes = [round(i * 0.25, 2) for i in range(len(db)) if db[i] > mean + 2.2 * std and db[i] > -20]
    dedup: List[float] = []
    for t in spikes:
        if not dedup or t - dedup[-1] > 1.5:
            dedup.append(t)
    return {
        "waveform": waveform,
        "mean_db": round(mean, 2),
        "peak_db": round(float(db.max()), 2),
        "silences": silences,
        "active_ratio": round(float((~silent).mean()), 3),
        "loudness_timeline": [round(float(x), 1) for x in db[:: max(1, len(db) // 120)]],
        "spikes_s": dedup[:12],
    }


def _visual_stats(frames: List[str]) -> Dict[str, Any]:
    from PIL import Image  # type: ignore
    import numpy as np  # type: ignore

    lumas, temps, sats, contrasts, flat = [], [], [], [], []
    for fp in frames:
        try:
            im = Image.open(fp).convert("RGB").resize((96, 96))
        except Exception:
            continue
        a = np.asarray(im).astype(np.float32) / 255.0
        luma = 0.2126 * a[..., 0] + 0.7152 * a[..., 1] + 0.0722 * a[..., 2]
        lumas.append(float(luma.mean()))
        contrasts.append(float(luma.std()))
        temps.append(float(a[..., 0].mean() - a[..., 2].mean()))
        mx, mn = a.max(axis=2), a.min(axis=2)
        sats.append(float(((mx - mn) / (mx + 1e-6)).mean()))
        q = (a * 7).astype(np.int32)
        codes = q[..., 0] * 64 + q[..., 1] * 8 + q[..., 2]
        counts = np.bincount(codes.ravel())
        flat.append(float(np.sort(counts)[-6:].sum() / codes.size))
    if not lumas:
        return {}
    avg = lambda xs: round(sum(xs) / len(xs), 4)  # noqa: E731
    return {"luma": avg(lumas), "contrast": avg(contrasts), "warmth": avg(temps), "saturation": avg(sats), "flatness": avg(flat)}


def _describe(kind: str, info: Dict[str, Any], vis: Dict[str, Any], audio: Dict[str, Any], scenes: List[float], shot: str) -> str:
    parts: List[str] = []
    if vis:
        parts.append("bright" if vis["luma"] > 0.6 else "dark" if vis["luma"] < 0.3 else "mid-exposure")
        parts.append("warm-toned" if vis["warmth"] > 0.05 else "cool-toned" if vis["warmth"] < -0.05 else "neutral colour")
        parts.append("high-contrast" if vis["contrast"] > 0.25 else "soft-contrast")
    dur = info.get("duration_s") or 0
    if kind == "video":
        rate = len(scenes) / max(dur / 60, 0.1)
        parts.append("static/continuous shot" if not scenes else f"{len(scenes)} scene change(s) ({rate:.1f}/min)")
    if audio and "active_ratio" in audio:
        parts.append("mostly speech/sound" if audio["active_ratio"] > 0.6 else "sparse audio" if audio["active_ratio"] > 0.15 else "near-silent audio")
    label = shot.replace("_", " ")
    return f"Heuristic: likely {label}; " + ", ".join(parts) + "."


def classify(kind: str, info: Dict[str, Any], vis: Dict[str, Any], audio: Dict[str, Any], scenes: List[float]) -> Dict[str, Any]:
    """Heuristic shot typing from measurable signals only (no vision model)."""
    tags: List[str] = []
    if kind == "image":
        shot = "still_image"
        if vis.get("flatness", 0) > 0.45:
            tags.append("graphic_or_screenshot")
        return {"shot_type": shot, "tags": tags, "confidence": 0.9}
    if kind == "audio":
        return {"shot_type": "audio_only", "tags": ["music_or_voice"], "confidence": 0.95}
    dur = info.get("duration_s") or 1
    active = audio.get("active_ratio", 0) if audio else 0
    cut_rate = len(scenes) / max(dur / 60, 0.1)
    w, h = info.get("width") or 0, info.get("height") or 0
    conf = 0.55
    if vis.get("flatness", 0) > 0.42 and ((w, h) in SCREEN_RES or vis.get("saturation", 1) < 0.18):
        shot, conf = "screen_recording", 0.7
    elif active > 0.45 and cut_rate < 4:
        shot, conf = "talking_head", 0.6
    elif not info.get("has_audio") or active < 0.15:
        shot, conf = "b_roll", 0.6
    else:
        shot = "mixed"
    if cut_rate > 12:
        tags.append("fast_cut_source")
    if audio and audio.get("spikes_s"):
        tags.append("audio_peaks")
    if h > w:
        tags.append("vertical_source")
    return {"shot_type": shot, "tags": tags, "confidence": conf}


def analyze(path: str, out_dir: str, stage_base: float = 0.0, stage_span: float = 100.0) -> Dict[str, Any]:
    os.makedirs(out_dir, exist_ok=True)
    step = lambda frac, msg: progress(stage_base + stage_span * frac, "analyze", msg)  # noqa: E731
    step(0.02, f"Probing {os.path.basename(path)}")
    info = probe(path)
    kind = info["kind"]
    out: Dict[str, Any] = {"probe": info, "thumbnail": None, "filmstrip": [], "scenes_s": [], "audio": {}, "visual": {}, "classification": {}, "description": ""}
    if not info["readable"]:
        out["description"] = "Unreadable media; analysis skipped."
        return out
    dur = info.get("duration_s") or 0
    if kind in ("video", "image"):
        step(0.1, "Generating thumbnail & filmstrip")
        thumb = os.path.join(out_dir, "thumb.jpg")
        if _thumbnail(path, thumb, dur * 0.15 if kind == "video" else 0):
            out["thumbnail"] = thumb
        if kind == "video" and dur > 0:
            for i in range(6):
                fp = os.path.join(out_dir, f"strip_{i}.jpg")
                if _thumbnail(path, fp, dur * (i + 0.5) / 6, 200):
                    out["filmstrip"].append(fp)
        out["visual"] = _visual_stats(out["filmstrip"] or ([thumb] if out["thumbnail"] else []))
    if kind == "video":
        step(0.4, "Detecting scene boundaries")
        out["scenes_s"] = _scenes(path)
    if info.get("has_audio") or kind == "audio":
        step(0.7, "Measuring audio levels & silence")
        out["audio"] = _audio_analysis(path, dur)
    out["classification"] = classify(kind, info, out["visual"], out["audio"], out["scenes_s"])
    out["description"] = _describe(kind, info, out["visual"], out["audio"], out["scenes_s"], out["classification"]["shot_type"])
    step(1.0, "Analysis complete")
    return out

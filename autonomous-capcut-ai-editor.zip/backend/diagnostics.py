"""Environment diagnostics for the first-run experience and the Diagnostics tool."""
from __future__ import annotations

import importlib
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from typing import Any, Dict, List

from protocol import ffmpeg_exe


def _check(name: str, ok: bool, detail: str, fix: str = "", level: str = "error") -> Dict[str, Any]:
    return {"name": name, "ok": ok, "detail": detail, "fix": "" if ok else fix, "level": "ok" if ok else level}


def default_capcut_dirs() -> List[str]:
    home = os.path.expanduser("~")
    local = os.environ.get("LOCALAPPDATA", os.path.join(home, "AppData", "Local"))
    return [
        os.path.join(local, "CapCut", "User Data", "Projects", "com.lveditor.draft"),
        os.path.join(local, "JianyingPro", "User Data", "Projects", "com.lveditor.draft"),
        os.path.join(home, "Movies", "CapCut", "User Data", "Projects", "com.lveditor.draft"),
        os.path.join(home, "Movies", "JianyingPro", "User Data", "Projects", "com.lveditor.draft"),
    ]


def run(draft_dir: str, project_dir: str, whisper_model: str, model_dir: str | None) -> Dict[str, Any]:
    checks: List[Dict[str, Any]] = []
    checks.append(_check("Python", sys.version_info >= (3, 9), f"{platform.python_version()} ({sys.executable})", "Install Python 3.9+"))
    for mod, label, pip in [("numpy", "NumPy", "numpy"), ("PIL", "Pillow", "pillow"), ("av", "PyAV", "av")]:
        try:
            m = importlib.import_module(mod)
            checks.append(_check(label, True, getattr(m, "__version__", "installed")))
        except Exception as exc:
            checks.append(_check(label, False, str(exc), f"pip install {pip}"))
    try:
        exe = ffmpeg_exe()
        out = subprocess.run([exe, "-version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20).stdout.decode().splitlines()[0]
        checks.append(_check("FFmpeg", True, f"{out} — {exe}"))
    except Exception as exc:
        checks.append(_check("FFmpeg", False, str(exc), "Install FFmpeg or `pip install imageio-ffmpeg`"))
    try:
        fw = importlib.import_module("faster_whisper")
        checks.append(_check("faster-whisper", True, getattr(fw, "__version__", "installed")))
        cache_hits = []
        roots = [model_dir] if model_dir else []
        roots.append(os.path.join(os.path.expanduser("~"), ".cache", "huggingface", "hub"))
        for root in roots:
            if root and os.path.isdir(root):
                cache_hits += [d for d in os.listdir(root) if "faster-whisper" in d or d.startswith("models--Systran")]
        has_model = any(whisper_model in h for h in cache_hits)
        checks.append(_check(f"Whisper model '{whisper_model}'", has_model,
                             "cached locally" if has_model else f"not downloaded yet (cached: {', '.join(cache_hits) or 'none'})",
                             "The model downloads automatically on first transcription (internet required once).", "warning"))
    except Exception as exc:
        checks.append(_check("faster-whisper", False, str(exc), "pip install faster-whisper"))
    try:
        pj = importlib.import_module("pyJianYingDraft")
        ver = "installed"
        try:
            from importlib.metadata import version

            ver = version("pyJianYingDraft")
        except Exception:
            pass
        checks.append(_check("pyJianYingDraft", True, f"{ver} — {os.path.dirname(pj.__file__)}"))
    except Exception as exc:
        checks.append(_check("pyJianYingDraft", False, str(exc), "pip install pyJianYingDraft"))

    detected = [d for d in default_capcut_dirs() if os.path.isdir(d)]
    if draft_dir and os.path.isdir(draft_dir):
        writable = os.access(draft_dir, os.W_OK)
        checks.append(_check("CapCut draft directory", writable, f"{draft_dir}{'' if writable else ' (not writable)'}", "Choose a writable draft folder in Settings → Storage"))
    else:
        checks.append(_check("CapCut draft directory", False, f"{draft_dir or '(not set)'} does not exist. Detected: {', '.join(detected) or 'none'}",
                             "Set the CapCut draft folder in Settings → Storage (CapCut → Settings → Draft location).", "warning"))
    try:
        os.makedirs(project_dir, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=project_dir):
            pass
        checks.append(_check("Project directory permissions", True, f"{project_dir} is writable"))
    except Exception as exc:
        checks.append(_check("Project directory permissions", False, str(exc), "Choose a writable project directory"))
    try:
        usage = shutil.disk_usage(project_dir)
        free_gb = usage.free / 1e9
        checks.append(_check("Available disk space", free_gb > 2, f"{free_gb:.1f} GB free", "Free up disk space (≥ 2 GB recommended)", "warning"))
    except Exception as exc:
        checks.append(_check("Available disk space", False, str(exc), ""))
    return {"platform": f"{platform.system()} {platform.release()}", "checks": checks, "detected_capcut_dirs": detected}

"""Line-oriented JSON protocol between the desktop UI host (Node) and the Python engine.

Every message is a single line on stdout:
    @@PROGRESS {"pct": 0-100, "stage": "...", "message": "..."}
    @@LOG {"level": "info", "message": "..."}
    @@RESULT {...}
    @@ERROR {"code": "...", "message": "...", "details": {...}}

The engine never executes AI-generated code or shell strings. All subprocess
invocations use fixed argument vectors.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import time
from typing import Any, Dict, Optional


class EngineError(Exception):
    """An explicit, user-presentable engine failure."""

    def __init__(self, code: str, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}


def _emit(tag: str, payload: Dict[str, Any]) -> None:
    sys.stdout.write(f"@@{tag} {json.dumps(payload, ensure_ascii=False, default=str)}\n")
    sys.stdout.flush()


def progress(pct: float, stage: str, message: str = "") -> None:
    _emit("PROGRESS", {"pct": round(max(0.0, min(100.0, pct)), 2), "stage": stage, "message": message, "ts": time.time()})


def log(message: str, level: str = "info") -> None:
    _emit("LOG", {"level": level, "message": message})


def result(payload: Dict[str, Any]) -> None:
    _emit("RESULT", payload)


def error(err: EngineError) -> None:
    _emit("ERROR", {"code": err.code, "message": err.message, "details": err.details})


def ffmpeg_exe() -> str:
    """Resolve an FFmpeg binary: explicit env → PATH → imageio-ffmpeg bundled static build."""
    env = os.environ.get("FFMPEG_PATH")
    if env and os.path.exists(env):
        return env
    found = shutil.which("ffmpeg")
    if found:
        return found
    try:
        import imageio_ffmpeg  # type: ignore

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception as exc:  # pragma: no cover - environment dependent
        raise EngineError(
            "FFMPEG_MISSING",
            "FFmpeg was not found. Install FFmpeg or run `pip install imageio-ffmpeg`.",
            {"reason": str(exc)},
        )


def to_us(seconds: float) -> int:
    """Seconds → microseconds (pyJianYingDraft time unit)."""
    return int(round(float(seconds) * 1_000_000))

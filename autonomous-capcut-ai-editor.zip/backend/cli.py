"""Engine CLI entrypoint — the only surface the desktop host talks to.

Usage: python3 backend/cli.py <command> <request.json>

Commands: probe | analyze | transcribe | build | validate_draft | restore_backup | diagnostics
The request is a JSON file written by the host; no shell strings are ever evaluated.
"""
from __future__ import annotations

import json
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from protocol import EngineError, error, result  # noqa: E402


def main() -> int:
    if len(sys.argv) < 3:
        error(EngineError("USAGE", "usage: cli.py <command> <request.json>"))
        return 2
    command, req_path = sys.argv[1], sys.argv[2]
    try:
        with open(req_path, "r", encoding="utf-8") as f:
            req = json.load(f)
    except Exception as exc:
        error(EngineError("BAD_REQUEST", f"Engine request could not be read: {exc}"))
        return 2
    try:
        if command == "probe":
            from media_analysis import probe

            items = []
            for p in req["paths"]:
                try:
                    items.append(probe(p))
                except EngineError as exc:
                    items.append({"path": p, "filename": os.path.basename(p), "readable": False,
                                  "warnings": [{"code": exc.code, "severity": "error", "message": exc.message}]})
            result({"items": items})
        elif command == "analyze":
            from media_analysis import analyze

            result(analyze(req["path"], req["out_dir"]))
        elif command == "transcribe":
            from transcription import transcribe

            result(transcribe(req["path"], req.get("model", "small"), req.get("language"), req.get("device", "auto"),
                              req.get("compute_type", "auto"), req.get("word_timestamps", True), req.get("model_dir")))
        elif command == "build":
            from capcut_builder import build

            result(build(req["plan"]))
        elif command == "validate_draft":
            from validation import validate_draft

            result(validate_draft(req["draft_dir"], req.get("expected", {})))
        elif command == "restore_backup":
            from backups import restore

            result(restore(req["backup_path"], req["draft_root"], req["draft_name"], req["backup_dir"]))
        elif command == "diagnostics":
            from diagnostics import run

            result(run(req.get("draft_dir", ""), req["project_dir"], req.get("whisper_model", "small"), req.get("model_dir")))
        else:
            raise EngineError("UNKNOWN_COMMAND", f"Unknown engine command '{command}'")
        return 0
    except EngineError as exc:
        error(exc)
        return 1
    except Exception as exc:  # explicit, never "something went wrong"
        error(EngineError("ENGINE_CRASH", f"{type(exc).__name__}: {exc}", {"traceback": traceback.format_exc()[-2000:]}))
        return 1


if __name__ == "__main__":
    sys.exit(main())

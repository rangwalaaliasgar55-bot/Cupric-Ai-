"""Engine tests: media ingestion, CapCut builder, backups and recovery.

Run: python3 -m unittest discover -s tests/engine -v
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "backend"))

from protocol import EngineError, ffmpeg_exe  # noqa: E402
from media_analysis import probe, analyze  # noqa: E402
from capcut_builder import build  # noqa: E402
from backups import restore  # noqa: E402


def make_media(d):
    ff = ffmpeg_exe()
    run = lambda *a: subprocess.run([ff, "-y", "-loglevel", "error", *a], check=True)  # noqa: E731
    run("-f", "lavfi", "-i", "testsrc2=size=1080x1920:rate=30", "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000", "-t", "6", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", os.path.join(d, "talk.mp4"))
    run("-f", "lavfi", "-i", "mandelbrot=size=640x360:rate=30", "-t", "4", "-c:v", "libx264", "-pix_fmt", "yuv420p", os.path.join(d, "broll.mp4"))
    run("-f", "lavfi", "-i", "sine=frequency=220:sample_rate=44100", "-t", "12", os.path.join(d, "music.mp3"))
    shutil.copy(os.path.join(d, "talk.mp4"), os.path.join(d, "talk_copy.mp4"))
    with open(os.path.join(d, "corrupt.mp4"), "wb") as f:
        f.write(b"\x00\x00\x00\x18ftypmp42" + os.urandom(2048))


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp(prefix="cutline-test-")
        cls.media = os.path.join(cls.tmp, "media")
        os.makedirs(cls.media)
        make_media(cls.media)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def m(self, name):
        return os.path.join(self.media, name)


class MediaTests(Base):
    def test_metadata_extraction(self):
        info = probe(self.m("talk.mp4"))
        self.assertEqual((info["width"], info["height"]), (1080, 1920))
        self.assertAlmostEqual(info["duration_s"], 6.0, delta=0.1)
        self.assertEqual(info["fps"], 30.0)
        self.assertTrue(info["has_audio"])
        self.assertEqual(info["codec"], "h264")
        self.assertEqual(info["aspect_ratio"], "9:16")

    def test_missing_audio_and_low_res_warnings(self):
        codes = {w["code"] for w in probe(self.m("broll.mp4"))["warnings"]}
        self.assertIn("MISSING_AUDIO", codes)

    def test_corrupt_file_is_flagged_not_crashing(self):
        info = probe(self.m("corrupt.mp4"))
        self.assertFalse(info["readable"])
        self.assertTrue(any(w["severity"] == "error" for w in info["warnings"]))

    def test_missing_file_raises_explicit_error(self):
        with self.assertRaises(EngineError) as ctx:
            probe(self.m("nope.mp4"))
        self.assertEqual(ctx.exception.code, "FILE_NOT_FOUND")

    def test_duplicate_detection_by_hash(self):
        self.assertEqual(probe(self.m("talk.mp4"))["hash"], probe(self.m("talk_copy.mp4"))["hash"])
        self.assertNotEqual(probe(self.m("talk.mp4"))["hash"], probe(self.m("broll.mp4"))["hash"])

    def test_analysis_outputs(self):
        out = analyze(self.m("talk.mp4"), os.path.join(self.tmp, "an"))
        self.assertTrue(os.path.exists(out["thumbnail"]))
        self.assertEqual(len(out["filmstrip"]), 6)
        self.assertIn("waveform", out["audio"])
        self.assertIn("shot_type", out["classification"])


class BuilderTests(Base):
    def plan(self, root, name="Test Draft", **over):
        p = {
            "draft_root": root, "draft_name": name, "backup_dir": os.path.join(self.tmp, "backups"), "audio_cache_dir": os.path.join(self.tmp, "cache"),
            "backup_retention": 5, "width": 1080, "height": 1920, "fps": 30, "total_duration": 5.0,
            "video": [
                {"path": self.m("talk.mp4"), "kind": "video", "src_in": 1.0, "dur_src": 3.0, "tl_start": 0, "tl_dur": 3.0, "speed": 1, "mute": True, "zoom": {"start": 1.0, "end": 1.05}},
                {"path": self.m("broll.mp4"), "kind": "video", "src_in": 0, "dur_src": 2.0, "tl_start": 3.0, "tl_dur": 2.0, "speed": 1, "mute": True, "transition_out": None, "background_fill": True},
            ],
            "overlay": [{"path": self.m("broll.mp4"), "kind": "video", "src_in": 0, "dur_src": 1.0, "tl_start": 1.0, "tl_dur": 1.0, "speed": 1, "mute": True}],
            "dialogue": [{"source_path": self.m("talk.mp4"), "src_in": 1.0, "dur_src": 3.0, "tl_start": 0, "tl_dur": 3.0, "volume": 1, "lane": 0}],
            "music": [{"path": self.m("music.mp3"), "src_in": 0, "dur_src": 5.0, "tl_start": 0, "tl_dur": 5.0, "volume": 0.4, "fade_in": 0.3, "fade_out": 0.5, "duck": [{"t": 0, "v": 0.1}, {"t": 3.0, "v": 0.1}, {"t": 3.3, "v": 0.4}]}],
            "captions": [{"text": "Hello world", "tl_start": 0.2, "tl_dur": 1.2, "size": 9, "bold": True, "y": -0.6, "intro": "pop", "outro": "fade"},
                         {"text": "AUTOMATICALLY", "tl_start": 1.5, "tl_dur": 1.0, "size": 10, "color": [1, 0.8, 0.2], "intro": "fade"}],
            "sfx": [], "ambience": [],
            "look": {"filter": "cool_tech", "intensity": 40, "vignette": 20},
        }
        p.update(over)
        return p

    def root(self, name):
        r = os.path.join(self.tmp, name)
        os.makedirs(r, exist_ok=True)
        return r

    def load(self, path):
        with open(os.path.join(path, "draft_content.json"), encoding="utf-8") as f:
            return json.load(f)

    def test_simple_multi_track_project(self):
        res = build(self.plan(self.root("drafts1")))
        self.assertTrue(res["validation"]["ok"], res["validation"])
        data = self.load(res["draft_path"])
        types = [t["type"] for t in data["tracks"]]
        self.assertEqual(types.count("video"), 2)
        self.assertGreaterEqual(types.count("audio"), 2)
        self.assertIn("text", types)
        self.assertIn("filter", types)
        self.assertEqual(data["canvas_config"]["width"], 1080)
        main = next(t for t in data["tracks"] if t["type"] == "video")
        seg = main["segments"][0]
        self.assertEqual(seg["source_timerange"]["start"], 1_000_000)
        self.assertEqual(seg["target_timerange"]["duration"], 3_000_000)
        # eased punch-in = 5 sampled keyframes on the scale property
        self.assertTrue(any(len(k["keyframe_list"]) == 5 for k in seg.get("common_keyframes", [])))

    def test_backup_before_overwrite_and_restore(self):
        root = self.root("drafts2")
        first = build(self.plan(root))
        self.assertIsNone(first["backup_path"])
        second = build(self.plan(root, total_duration=5.0))
        self.assertTrue(second["backup_path"] and os.path.isdir(second["backup_path"]))
        self.assertTrue(os.path.exists(os.path.join(second["backup_path"], "draft_content.json")))
        res = restore(second["backup_path"], root, "Test Draft", os.path.join(self.tmp, "backups"))
        self.assertTrue(os.path.isdir(res["draft_path"]))
        self.assertTrue(res["backup_path"])  # current draft was backed up before restoring

    def test_failed_generation_leaves_previous_draft_intact(self):
        root = self.root("drafts3")
        ok = build(self.plan(root))
        before = open(os.path.join(ok["draft_path"], "draft_content.json"), "rb").read()
        bad = self.plan(root)
        bad["video"][1]["path"] = self.m("clip_07.mp4")
        with self.assertRaises(EngineError) as ctx:
            build(bad)
        self.assertEqual(ctx.exception.code, "FILE_NOT_FOUND")
        self.assertIn("clip_07.mp4", ctx.exception.message)
        after = open(os.path.join(ok["draft_path"], "draft_content.json"), "rb").read()
        self.assertEqual(before, after)
        self.assertEqual([d for d in os.listdir(root) if "__building_" in d], [])

    def test_missing_draft_root_is_explicit(self):
        with self.assertRaises(EngineError) as ctx:
            build(self.plan(os.path.join(self.tmp, "does-not-exist")))
        self.assertEqual(ctx.exception.code, "DRAFT_ROOT_MISSING")


if __name__ == "__main__":
    unittest.main()

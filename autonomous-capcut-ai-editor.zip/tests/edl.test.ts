import { describe, expect, it } from "vitest";
import { parseAiJson, validateEdl, type InventoryItem } from "../src/lib/edl/validate";
import { captionBeats, compileEdl } from "../src/lib/edl/compile";

const words = [
  { word: "This", start: 1.0, end: 1.2 }, { word: "tool", start: 1.2, end: 1.5 }, { word: "edits", start: 1.5, end: 1.9 },
  { word: "automatically.", start: 1.9, end: 2.6 }, { word: "You", start: 3.0, end: 3.2 }, { word: "save", start: 3.2, end: 3.5 },
  { word: "80%", start: 3.5, end: 3.9 }, { word: "time.", start: 3.9, end: 4.3 },
];
const inv: InventoryItem[] = [
  { filename: "talk.mp4", path: "/m/talk.mp4", kind: "video", durationS: 10, hasAudio: true, readable: true, width: 1080, height: 1920, words, luma: 0.4 },
  { filename: "broll.mp4", path: "/m/broll.mp4", kind: "video", durationS: 6, hasAudio: false, readable: true, width: 1920, height: 1080, luma: 0.6 },
  { filename: "music.mp3", path: "/m/music.mp3", kind: "audio", durationS: 60, hasAudio: true, readable: true },
  { filename: "whoosh.wav", path: "/m/whoosh.wav", kind: "audio", durationS: 1.2, hasAudio: true, readable: true },
  { filename: "broken.mp4", path: "/m/broken.mp4", kind: "video", durationS: 5, hasAudio: true, readable: false },
];
const base = () => ({
  project: { target_duration_s: 8, aspect_ratio: "9:16", fps: 30 },
  sections: [
    { role: "hook", clips: [{ source_file: "talk.mp4", in_s: 3.0, out_s: 4.3, keyframe_zoom: { start_scale: 1, end_scale: 1.05 }, broll: [], sfx: [{ source_file: "whoosh.wav", at_s: 0, duration_s: 0.8 }] }] },
    { role: "body", clips: [{ source_file: "talk.mp4", in_s: 1.0, out_s: 2.6, broll: [{ source_file: "broll.mp4", in_s: 0, out_s: 1, at_s: 0.3 }] }] },
  ],
  music: { source_file: "music.mp3", volume: 0.5 },
  captions: { emphasis_words: ["automatically", "80%"] },
});

describe("AI JSON parsing", () => {
  it("strips markdown fences and prose", () => {
    expect(parseAiJson('Sure!\n```json\n{"a":1}\n```')).toEqual({ a: 1 });
  });
  it("rejects malformed JSON explicitly", () => {
    expect(() => parseAiJson('{"a":')).toThrow(/JSON/);
    expect(() => parseAiJson("no json here")).toThrow(/did not contain/);
  });
});

describe("EDL schema validation", () => {
  it("accepts a valid EDL and fills defaults", () => {
    const r = validateEdl(base(), inv);
    expect(r.errors).toEqual([]);
    expect(r.ok).toBe(true);
    expect(r.edl!.sections[0].clips[0].transition_in).toBe("hard_cut");
    expect(r.edl!.sections[0].clips[0].id).toBeTruthy();
  });
  it("rejects missing fields", () => {
    const e = base() as Record<string, unknown>;
    delete e.project;
    const r = validateEdl(e, inv);
    expect(r.ok).toBe(false);
    expect(r.errors[0].path).toContain("project");
  });
  it("rejects invalid enum values", () => {
    const e = base();
    (e.sections[0] as { role: string }).role = "explosion";
    expect(validateEdl(e, inv).ok).toBe(false);
  });
  it("rejects negative durations", () => {
    const e = base();
    e.sections[0].clips[0].out_s = 2.0;
    const r = validateEdl(e, inv);
    expect(r.ok).toBe(false);
    expect(r.errors.some((x) => /negative duration/.test(x.message))).toBe(true);
  });
  it("rejects hallucinated files", () => {
    const e = base();
    e.sections[0].clips[0].source_file = "clip_07.mp4";
    const r = validateEdl(e, inv);
    expect(r.ok).toBe(false);
    expect(r.errors[0].message).toMatch(/does not exist/);
  });
  it("repairs case/path differences in filenames", () => {
    const e = base();
    e.sections[0].clips[0].source_file = "/Users/x/TALK.mp4";
    const r = validateEdl(e, inv);
    expect(r.ok).toBe(true);
    expect(r.edl!.sections[0].clips[0].source_file).toBe("talk.mp4");
    expect(r.repairs.length).toBeGreaterThan(0);
  });
  it("clamps small overshoot but rejects timestamps far beyond the file", () => {
    const e = base();
    e.sections[1].clips[0].out_s = 10.4;
    expect(validateEdl(e, inv).edl!.sections[1].clips[0].out_s).toBe(10);
    e.sections[1].clips[0].out_s = 25;
    expect(validateEdl(e, inv).ok).toBe(false);
  });
  it("refuses unreadable media and wrong media kinds", () => {
    const e = base();
    e.sections[0].clips[0].source_file = "broken.mp4";
    expect(validateEdl(e, inv).ok).toBe(false);
    const e2 = base();
    e2.music.source_file = "broll.mp4";
    expect(validateEdl(e2, inv).ok).toBe(false);
  });
  it("removes malformed captions when repairing and rejects without repair", () => {
    const e = base() as ReturnType<typeof base> & { sections: { clips: { captions?: unknown[] }[] }[] };
    e.sections[0].clips[0].captions = [{ text: "bad", start_s: 4, end_s: 3.5 }];
    const r = validateEdl(e, inv, { repair: true });
    expect(r.ok).toBe(true);
    expect(r.edl!.sections[0].clips[0].captions).toHaveLength(0);
    expect(validateEdl(e, inv, { repair: false }).ok).toBe(false);
  });
  it("rejects overlapping B-roll on the same clip", () => {
    const e = base();
    e.sections[1].clips[0].broll = [{ source_file: "broll.mp4", in_s: 0, out_s: 1, at_s: 0 }, { source_file: "broll.mp4", in_s: 2, out_s: 3, at_s: 0.5 }];
    expect(validateEdl(e, inv).ok).toBe(false);
  });
  it("fixes an incoming transition on the very first clip", () => {
    const e = base() as ReturnType<typeof base> & { sections: { clips: { transition_in?: string }[] }[] };
    e.sections[0].clips[0].transition_in = "dissolve";
    const r = validateEdl(e, inv);
    expect(r.edl!.sections[0].clips[0].transition_in).toBe("hard_cut");
  });
});

describe("compiler", () => {
  it("builds a contiguous timeline with dialogue, captions, sfx, broll and ducked music", () => {
    const r = validateEdl(base(), inv);
    const { plan } = compileEdl(r.edl!, inv, { width: 1080, height: 1920, fps: 30 });
    expect(plan.video).toHaveLength(2);
    expect(plan.video[1].tl_start).toBeCloseTo(1.3, 3);
    expect(plan.total_duration).toBeCloseTo(2.9, 3);
    expect(plan.dialogue).toHaveLength(2);
    expect(plan.overlay).toHaveLength(1);
    expect(plan.sfx).toHaveLength(1);
    expect(plan.captions.length).toBeGreaterThan(0);
    expect(plan.captions.some((c) => String(c.text).includes("AUTOMATICALLY"))).toBe(true);
    for (let i = 1; i < plan.captions.length; i++) expect(plan.captions[i].tl_start).toBeGreaterThanOrEqual(plan.captions[i - 1].tl_start + plan.captions[i - 1].tl_dur - 1e-6);
    const duck = plan.music[0].duck as { t: number; v: number }[];
    expect(duck.some((k) => k.v < 0.5)).toBe(true);
    expect(plan.video[1].background_fill).toBe(false);
  });
  it("applies J-cuts by leading audio and trimming the previous dialogue", () => {
    const e = base() as ReturnType<typeof base> & { sections: { clips: { audio_offset?: unknown }[] }[] };
    e.sections[1].clips[0].audio_offset = { type: "j_cut", seconds: 0.3 };
    const r = validateEdl(e, inv);
    const { plan } = compileEdl(r.edl!, inv, { width: 1080, height: 1920, fps: 30 });
    expect(plan.dialogue[1].tl_start).toBeCloseTo(1.0, 3);
    expect(plan.dialogue[0].tl_start + plan.dialogue[0].tl_dur).toBeCloseTo(1.0, 3);
  });
  it("groups caption beats at punctuation and max words", () => {
    const beats = captionBeats(words, 3);
    expect(beats[0].map((w) => w.word)).toEqual(["This", "tool", "edits"]);
    expect(beats.every((b) => b.length <= 3)).toBe(true);
  });
});

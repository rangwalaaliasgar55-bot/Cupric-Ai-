export type PresetDef = { name: string; description: string; instructions: string; structure?: { role: string; share: number; note?: string }[] };

export const BUILTIN_PRESETS: PresetDef[] = [
  {
    name: "SaaS Promo",
    description: "Hook → Problem → Product → Proof → single CTA. Scales to any duration.",
    instructions:
      "Structure strictly as HOOK, PROBLEM, PRODUCT/SOLUTION, PROOF, CTA. Lead with the most compelling result or a direct viewer call-out. Show the product (screen recordings) during the solution section and cut on UI state changes. Proof = numbers, testimonials or visible outcomes from the footage. The CTA must be clear and singular. Crisp, confident pacing; clean captions; cool_tech or neutral_clean look.",
    structure: [
      { role: "hook", share: 0.1, note: "0–3s of 30s" },
      { role: "problem", share: 0.1667, note: "3–8s" },
      { role: "solution", share: 0.4, note: "8–20s" },
      { role: "proof", share: 0.1667, note: "20–25s" },
      { role: "cta", share: 0.1667, note: "25–30s" },
    ],
  },
  { name: "Cinematic", description: "Breathing room, motivated motion, restrained captions.", instructions: "Let shots breathe (3–6s where the image earns it). Motivated slow push-ins (1.00→1.04). Prefer L-cuts to carry emotion across cuts. Minimal, elegant captions (phrase mode, fade). warm_cinematic or moody_dark look with a light vignette. Dissolves only for time passage." },
  { name: "Tech SaaS", description: "Clear, modern, product-forward.", instructions: "Prioritise clarity of the product. Cut on information changes in screen recordings. Punch-ins to highlight UI details. Clean phrase captions with emphasis on outcome words. cool_tech look, no grain." },
  { name: "Luxury", description: "Slow, confident, premium.", instructions: "Slow deliberate pacing, long holds, very subtle motion, sparse captions (or none), no SFX spam. luxury or moody_dark look with gentle vignette. Only hard cuts or rare dissolves." },
  { name: "Fast-paced Short", description: "High retention short-form.", instructions: "Aggressive silence removal, 1.2–3s beats, pattern interrupts every 2–4s via punch-ins, B-roll and caption emphasis. Word or karaoke captions, 3–4 words max. Strongest line first. No dead air." },
  { name: "YouTube Explainer", description: "Structured teaching with visual support.", instructions: "Hook with the payoff, then context and steps. Use B-roll/screen to illustrate each point. Moderate pacing, phrase captions, subtle punch-ins between points. natural look." },
  { name: "Minimal", description: "Intentional simplicity.", instructions: "Hard cuts only, no SFX, no zooms unless essential, simple phrase captions, neutral_clean look. Story clarity above all." },
  { name: "Podcast", description: "Conversation-first clips.", instructions: "Select the most quotable, self-contained exchange. Keep natural pauses that land jokes/points. J-cuts and L-cuts between speakers. Karaoke captions for retention. Gentle punch-ins to mark emphasis." },
  { name: "UGC", description: "Authentic creator style.", instructions: "Feels native and unpolished-but-tight. Direct-to-camera hook, quick cuts, word captions, natural look, occasional SFX only on reveals." },
  { name: "Product Demo", description: "Show, don't tell.", instructions: "Result-before-process opener. Each feature: show it working. Cut on state changes, punch-in on details, captions name the benefit. End with one clear CTA. high_contrast or cool_tech look." },
];

/** Scale a preset structure to the target duration (proportional). */
export function scaleStructure(structure: { role: string; share: number; note?: string }[], target: number) {
  let t = 0;
  return structure.map((s) => {
    const start = t;
    t += s.share * target;
    return { role: s.role, start_s: Math.round(start * 10) / 10, end_s: Math.round(t * 10) / 10 };
  });
}

import "server-only";
import { db } from "@/db";
import { aiRequests } from "@/db/schema";
import { EDL_SCHEMA_DOC, type Edl } from "@/shared/schemas/edl";
import { parseAiJson, validateEdl, type InventoryItem, type ValidationReport } from "@/lib/edl/validate";
import { getSecret } from "@/lib/secrets";
import { getSettings, PROMPT_VERSION } from "@/lib/settings";
import { scaleStructure } from "./presets";

export type DirectorBrief = {
  style: string;
  audience: string;
  platform: string;
  mustKeep: string;
  prohibited: string;
  reference: string;
  presetName?: string;
  presetInstructions?: string;
  presetStructure?: { role: string; share: number }[] | null;
  targetDurationS: number;
  aspectRatio: string;
  fps: number;
};

export type MediaContext = InventoryItem & {
  shotType?: string;
  description?: string;
  scenes?: number[];
  silences?: { start_s: number; end_s: number }[];
  segments?: { start: number; end: number; text: string; words?: { word: string; start: number; end: number }[] }[];
  hookCandidates?: { start: number; end: number; text: string; score: number }[];
};

export type RegenMode =
  | { kind: "full" }
  | { kind: "section"; sectionId: string; instruction?: string }
  | { kind: "clip"; clipId: string; instruction?: string }
  | { kind: "modifier"; modifier: string };

export const SYSTEM_PROMPT = `You are a professional video editor and AI editing director.
Your job is to transform raw footage into a coherent, engaging edit plan.
You do not write CapCut project files. You output only the application's EDL JSON, which is validated before anything is built.

Make editorial decisions based on: narrative structure, information hierarchy, pacing, visual variety, retention, dialogue continuity, audio rhythm, caption readability, motion, sound design, visual consistency.

HARD RULES
- Never add information that does not exist in the source footage. Never invent dialogue. Never invent timestamps: every in_s/out_s/caption time must come from the provided transcript word timings, scene boundaries or file durations.
- Never reference files that are not in the MEDIA INVENTORY. Use exact filenames.
- Output valid JSON only — one object matching the EDL schema. No prose, no Markdown, no comments, no CapCut JSON.

CRAFT
- Hook: open with the strongest statement / strongest visual / curiosity gap / unusual moment / direct viewer call-out / result-before-process. Do NOT default to the first recorded clip.
- Pacing: vary shot lengths. For short-form ~1.5–4s per visual beat is typical, but allow longer holds when content needs it. Cut when the information or visual reason changes, never because a timer says so.
- Dialogue: cut on word boundaries (use word end/start times), remove silences and false starts, keep natural pauses that land a point. Use j_cut / l_cut when it improves flow.
- Pattern interrupts with purpose: punch-ins (subtle, e.g. 1.00→1.05), B-roll overlays during speech, screen changes, caption emphasis, SFX on real events only. Do not spam effects.
- Transitions: default "hard_cut". Other transitions only with an editorial reason (time passage, location change).
- Captions: leave "captions": [] on clips to auto-caption verbatim from the transcript; choose emphasis_words deliberately (outcome words, numbers, key nouns) — never random.
- Motion: subtle, eased; avoid constant zooming.
- Colour: one coherent color_grade_mood for the whole project.
- Audio: dialogue has priority; music ducks under speech; only use music/SFX files that exist in the inventory (kind=audio).
Prefer intentional simplicity over excessive effects. A professional edit should not look like an effects template.`;

const round = (n: number) => Math.round(n * 100) / 100;

export function buildContext(brief: DirectorBrief, media: MediaContext[]) {
  return {
    brief: {
      editing_style: brief.style,
      preset: brief.presetName || null,
      preset_instructions: brief.presetInstructions || null,
      structure: brief.presetStructure ? scaleStructure(brief.presetStructure, brief.targetDurationS) : null,
      audience: brief.audience,
      platform: brief.platform,
      must_keep: brief.mustKeep,
      prohibited: brief.prohibited,
      reference_style: brief.reference,
      target_duration_s: brief.targetDurationS,
      aspect_ratio: brief.aspectRatio,
      fps: brief.fps,
    },
    media_inventory: media.map((m) => ({
      filename: m.filename,
      kind: m.kind,
      duration_s: m.durationS,
      resolution: m.width && m.height ? `${m.width}x${m.height}` : null,
      has_audio: m.hasAudio,
      shot_type: m.shotType || null,
      description: m.description || null,
      scene_boundaries_s: (m.scenes || []).slice(0, 40),
      silences_s: (m.silences || []).slice(0, 40).map((s) => [s.start_s, s.end_s]),
      hook_candidates: (m.hookCandidates || []).slice(0, 5),
      transcript: (m.segments || []).map((s) => ({
        t: [round(s.start), round(s.end)],
        text: s.text,
        words: (s.words || []).map((w) => `${w.word}@${round(w.start)}-${round(w.end)}`).join(" "),
      })),
    })),
  };
}

type GeminiTurn = { role: "user" | "model"; parts: { text: string }[] };

async function callGemini(turns: GeminiTurn[], projectId: string | null, purpose: string, summary: Record<string, unknown>) {
  const s = await getSettings();
  const key = await getSecret("gemini_api_key");
  if (!key) throw new DirectorError("GEMINI_KEY_MISSING", "No Gemini API key is configured. Add it in Settings → AI.");
  const body = JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] }, contents: turns, generationConfig: { temperature: s.ai.temperature, responseMimeType: "application/json" } });
  const bytes = Buffer.byteLength(body);
  let lastErr: DirectorError | null = null;
  for (let attempt = 0; attempt <= s.ai.retryCount; attempt++) {
    try {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(s.ai.model)}:generateContent`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-goog-api-key": key },
        body,
        signal: AbortSignal.timeout(180_000),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: { message?: string; status?: string }; candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] }; finishReason?: string }[] };
      if (!res.ok) {
        const msg = json.error?.message || res.statusText;
        lastErr = new DirectorError(res.status === 401 || res.status === 403 ? "GEMINI_AUTH" : res.status === 429 ? "GEMINI_RATE_LIMIT" : "GEMINI_HTTP", `Gemini request failed (${res.status} ${json.error?.status || ""}): ${msg}`);
        if (res.status === 400 || res.status === 401 || res.status === 403 || res.status === 404) break;
        await new Promise((r) => setTimeout(r, 1500 * (attempt + 1)));
        continue;
      }
      const text = (json.candidates?.[0]?.content?.parts || []).filter((p) => !p.thought).map((p) => p.text || "").join("");
      if (!text) {
        lastErr = new DirectorError("GEMINI_EMPTY", `Gemini returned no content (finish reason: ${json.candidates?.[0]?.finishReason || "unknown"}).`);
        continue;
      }
      await db.insert(aiRequests).values({ projectId, model: s.ai.model, purpose, bytesSent: bytes, summary, status: "ok" });
      return text;
    } catch (e) {
      lastErr = e instanceof DirectorError ? e : new DirectorError("GEMINI_NETWORK", `Could not reach Gemini: ${(e as Error).message}`);
    }
  }
  await db.insert(aiRequests).values({ projectId, model: s.ai.model, purpose, bytesSent: bytes, summary, status: "failed", error: lastErr?.message });
  throw lastErr!;
}

export class DirectorError extends Error {
  constructor(public code: string, message: string, public details: unknown = {}) {
    super(message);
  }
}

const MODIFIERS: Record<string, string> = {
  faster: "Make the edit faster: tighter trims, remove pauses, shorter beats, keep meaning intact.",
  calmer: "Make the edit calmer: longer holds, fewer interrupts, gentler motion, softer captions.",
  cinematic: "Make it more cinematic: motivated slow push-ins, L-cuts, breathing room, warm_cinematic or moody_dark look, restrained captions.",
  energetic: "Make it more energetic: punchier cuts, more pattern interrupts with purpose, word captions, stronger emphasis.",
  minimal: "Make it more minimal: hard cuts, remove SFX and most zooms, simple phrase captions.",
  retention: "Make it more retention-focused: strongest hook first, open loops, pattern interrupt every 2–4s, cut all dead air.",
  stronger_hook: "Rewrite only the opening (first section) with the strongest possible hook from the footage; keep the rest unchanged.",
};

/**
 * Runs the AI Director with validation feedback loops. Returns the validated EDL.
 * Section/clip regenerations are spliced deterministically so untouched parts are guaranteed unchanged.
 */
export async function runDirector(opts: {
  projectId: string;
  brief: DirectorBrief;
  media: MediaContext[];
  current?: Edl | null;
  mode: RegenMode;
  onProgress?: (msg: string, pct: number) => void;
}): Promise<{ edl: Edl; report: ValidationReport; attempts: number; promptVersion: string }> {
  const s = await getSettings();
  const ctx = buildContext(opts.brief, opts.media);
  const inv: InventoryItem[] = opts.media;
  let task: string;
  const mode = opts.mode;
  if (mode.kind === "full" || !opts.current) {
    task = "Create the complete EDL for this project.";
  } else if (mode.kind === "section") {
    task = `Regenerate ONLY the section with id "${mode.sectionId}". ${mode.instruction || "Improve its editorial quality."} Return the FULL EDL; all other sections must be byte-identical to CURRENT_EDL.`;
  } else if (mode.kind === "clip") {
    task = `Regenerate ONLY the clip with id "${mode.clipId}" (choose a better source moment or trim). ${mode.instruction || ""} Return the FULL EDL; everything else must be identical to CURRENT_EDL.`;
  } else {
    task = `Revise CURRENT_EDL: ${MODIFIERS[mode.modifier] || mode.modifier} Preserve decisions that don't need to change.`;
  }
  const userText = [
    `TASK: ${task}`,
    `EDL SCHEMA:\n${EDL_SCHEMA_DOC}`,
    `PROJECT CONTEXT (transcript words are "word@start-end" in source seconds):\n${JSON.stringify(ctx)}`,
    opts.current && mode.kind !== "full" ? `CURRENT_EDL:\n${JSON.stringify(opts.current)}` : "",
    "Respond with the EDL JSON object only.",
  ].filter(Boolean).join("\n\n");

  const summary = {
    files: opts.media.length,
    transcript_words: opts.media.reduce((a, m) => a + (m.segments || []).reduce((b, sg) => b + (sg.words?.length || 0), 0), 0),
    includes: ["filenames", "durations", "resolutions", "heuristic shot labels", "scene/silence timings", "transcript text + word timings", "editing brief"],
    excludes: ["video files", "audio files", "images/thumbnails", "file system paths", "API keys"],
    mode: mode.kind,
  };
  const turns: GeminiTurn[] = [{ role: "user", parts: [{ text: userText }] }];
  let lastReport: ValidationReport | null = null;
  for (let attempt = 1; attempt <= Math.max(1, s.ai.maxAttempts); attempt++) {
    opts.onProgress?.(`Gemini attempt ${attempt}/${s.ai.maxAttempts}`, 10 + (attempt - 1) * 25);
    const raw = await callGemini(turns, opts.projectId, attempt === 1 ? `director:${mode.kind}` : "director:repair", summary);
    let candidate: unknown;
    try {
      candidate = parseAiJson(raw);
    } catch (e) {
      lastReport = { ok: false, errors: [{ path: "(root)", message: (e as Error).message }], warnings: [], repairs: [], edl: null };
      turns.push({ role: "model", parts: [{ text: raw.slice(0, 4000) }] }, { role: "user", parts: [{ text: `Your reply was not valid JSON (${(e as Error).message}). Return only the corrected EDL JSON object.` }] });
      continue;
    }
    // Deterministic splice for partial regenerations
    if (opts.current && (mode.kind === "section" || mode.kind === "clip")) candidate = splice(opts.current, candidate, mode);
    opts.onProgress?.("Validating EDL", 10 + attempt * 25);
    const report = validateEdl(candidate, inv, { repair: true });
    if (report.ok && report.edl) return { edl: report.edl, report, attempts: attempt, promptVersion: PROMPT_VERSION };
    lastReport = report;
    turns.push(
      { role: "model", parts: [{ text: raw.slice(0, 30000) }] },
      { role: "user", parts: [{ text: `The EDL failed validation. Fix ALL of these errors using only real files and real timestamps, then return the full corrected EDL JSON only:\n${report.errors.map((e) => `- ${e.path}: ${e.message}`).join("\n")}` }] },
    );
  }
  throw new DirectorError("EDL_INVALID", `Gemini could not produce a valid EDL after ${s.ai.maxAttempts} attempt(s). Last errors: ${(lastReport?.errors || []).slice(0, 4).map((e) => `${e.path}: ${e.message}`).join("; ")}`, lastReport);
}

function splice(current: Edl, candidate: unknown, mode: RegenMode): unknown {
  const cand = candidate as Edl;
  if (!cand || !Array.isArray(cand.sections)) return candidate;
  const next = structuredClone(current);
  if (mode.kind === "section") {
    const idx = next.sections.findIndex((s) => s.id === mode.sectionId);
    const repl = cand.sections.find((s) => s.id === mode.sectionId) || cand.sections[idx];
    if (idx >= 0 && repl) next.sections[idx] = { ...repl, id: mode.sectionId };
  } else if (mode.kind === "clip") {
    for (const s of next.sections) {
      const ci = s.clips.findIndex((c) => c.id === mode.clipId);
      if (ci < 0) continue;
      const repl = cand.sections.flatMap((x) => x.clips).find((c) => c.id === mode.clipId) || cand.sections.find((x) => x.id === s.id)?.clips[ci];
      if (repl) s.clips[ci] = { ...repl, id: mode.clipId };
    }
  }
  return next;
}

/** Deterministic, local (no-AI) EDL modifiers. */
export function localModifier(edl: Edl, modifier: string): Edl | null {
  const next = structuredClone(edl);
  if (modifier === "fewer_effects") {
    for (const s of next.sections)
      for (const c of s.clips) {
        c.transition_in = "hard_cut";
        c.sfx = [];
        if (c.keyframe_zoom && Math.abs(c.keyframe_zoom.end_scale - c.keyframe_zoom.start_scale) < 0.06) continue;
        c.keyframe_zoom = null;
      }
    next.look.grain = 0;
    next.look.vignette = Math.min(next.look.vignette, 10);
    return next;
  }
  if (modifier === "stronger_captions") {
    next.captions.enabled = true;
    next.captions.mode = next.captions.mode === "phrase" ? "karaoke" : next.captions.mode;
    next.captions.max_words = Math.min(next.captions.max_words, 4);
    next.captions.animation = "pop";
    return next;
  }
  return null;
}

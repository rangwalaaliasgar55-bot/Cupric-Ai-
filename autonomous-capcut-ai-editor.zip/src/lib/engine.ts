import "server-only";
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";

export type EngineProgress = { pct: number; stage: string; message: string };
export class EngineFailure extends Error {
  constructor(public code: string, message: string, public details: unknown = {}) {
    super(message);
  }
}

const PYTHON = process.env.PYTHON_BIN || (process.platform === "win32" ? "python" : "python3");
const CLI = path.join(process.cwd(), "backend", "cli.py");
const ALLOWED = new Set(["probe", "analyze", "transcribe", "build", "validate_draft", "restore_backup", "diagnostics"]);

/**
 * Runs one engine command. Fixed argv only (no shell); the request travels in a
 * temp JSON file. Resolves with the @@RESULT payload or rejects with EngineFailure.
 */
export function runEngine<T = Record<string, unknown>>(
  command: string,
  request: unknown,
  opts: { onProgress?: (p: EngineProgress) => void; onLog?: (line: string) => void; signal?: AbortSignal } = {},
): Promise<T> {
  if (!ALLOWED.has(command)) return Promise.reject(new EngineFailure("UNKNOWN_COMMAND", `Engine command '${command}' is not allowed`));
  const reqFile = path.join(os.tmpdir(), `capcut-ai-${crypto.randomUUID()}.json`);
  fs.writeFileSync(reqFile, JSON.stringify(request));
  return new Promise<T>((resolve, reject) => {
    const child = spawn(PYTHON, [CLI, command, reqFile], { stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, PYTHONUNBUFFERED: "1", PYTHONIOENCODING: "utf-8" } });
    let buf = "";
    let stderr = "";
    let settled = false;
    let resultPayload: T | null = null;
    let errorPayload: { code: string; message: string; details: unknown } | null = null;
    const finish = (fn: () => void) => {
      if (settled) return;
      settled = true;
      fs.rm(reqFile, { force: true }, () => {});
      fn();
    };
    const onAbort = () => {
      child.kill("SIGTERM");
      finish(() => reject(new EngineFailure("CANCELLED", "Cancelled by user")));
    };
    opts.signal?.addEventListener("abort", onAbort, { once: true });
    child.stdout.on("data", (chunk: Buffer) => {
      buf += chunk.toString("utf8");
      let idx: number;
      while ((idx = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, idx).trim();
        buf = buf.slice(idx + 1);
        if (!line) continue;
        const m = /^@@(PROGRESS|LOG|RESULT|ERROR) (.*)$/.exec(line);
        if (!m) {
          opts.onLog?.(line);
          continue;
        }
        try {
          const payload = JSON.parse(m[2]);
          if (m[1] === "PROGRESS") opts.onProgress?.(payload);
          else if (m[1] === "LOG") opts.onLog?.(`[${payload.level}] ${payload.message}`);
          else if (m[1] === "RESULT") resultPayload = payload;
          else errorPayload = payload;
        } catch {
          opts.onLog?.(line);
        }
      }
    });
    child.stderr.on("data", (c: Buffer) => {
      stderr += c.toString("utf8");
      if (stderr.length > 20000) stderr = stderr.slice(-20000);
    });
    child.on("error", (err) =>
      finish(() => reject(new EngineFailure("PYTHON_NOT_FOUND", `The Python engine could not be started (${PYTHON}): ${err.message}. Install Python 3.9+ or set PYTHON_BIN.`))),
    );
    child.on("close", (code) => {
      opts.signal?.removeEventListener("abort", onAbort);
      finish(() => {
        if (errorPayload) reject(new EngineFailure(errorPayload.code, errorPayload.message, { ...(errorPayload.details as object), stderr: stderr.slice(-1500) }));
        else if (resultPayload) resolve(resultPayload);
        else reject(new EngineFailure("ENGINE_NO_RESULT", `The engine exited (code ${code}) without a result. ${stderr.split("\n").filter(Boolean).slice(-3).join(" | ")}`, { stderr: stderr.slice(-3000) }));
      });
    });
  });
}

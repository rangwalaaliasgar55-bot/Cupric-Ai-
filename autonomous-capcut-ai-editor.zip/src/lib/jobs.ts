import "server-only";
import fs from "node:fs";
import path from "node:path";
import { and, asc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { jobs, type Job } from "@/db/schema";
import { appHome } from "./settings";

export type JobType = "import_media" | "analyze_media" | "transcribe_media" | "ai_director" | "build_draft" | "restore_backup";
export type JobCtx = {
  job: Job;
  signal: AbortSignal;
  progress: (pct: number, stage?: string, message?: string) => Promise<void>;
  log: (line: string) => void;
  stage: (key: string, status: "pending" | "running" | "done" | "failed" | "skipped") => Promise<void>;
};
export class JobError extends Error {
  constructor(public code: string, message: string, public details: unknown = {}, public actions: string[] = ["retry"]) {
    super(message);
  }
}
type Handler = (ctx: JobCtx) => Promise<Record<string, unknown>>;

const LANES: Record<JobType, { lane: string; concurrency: number }> = {
  import_media: { lane: "ingest", concurrency: 1 },
  analyze_media: { lane: "analysis", concurrency: 2 },
  transcribe_media: { lane: "transcription", concurrency: 1 },
  ai_director: { lane: "ai", concurrency: 1 },
  build_draft: { lane: "build", concurrency: 1 },
  restore_backup: { lane: "build", concurrency: 1 },
};

type State = { handlers: Map<string, Handler>; running: Map<string, { lane: string; ctrl: AbortController }>; booted: boolean; pumping: boolean };
const g = globalThis as typeof globalThis & { __capcutJobs?: State };
const state: State = (g.__capcutJobs ??= { handlers: new Map(), running: new Map(), booted: false, pumping: false });

export function registerHandler(type: JobType, fn: Handler) {
  state.handlers.set(type, fn);
}

async function boot() {
  if (state.booted) return;
  state.booted = true;
  // Jobs that were running when the app stopped can't be resumed mid-process.
  await db
    .update(jobs)
    .set({ status: "failed", finishedAt: new Date(), error: { code: "INTERRUPTED", message: "The application stopped while this job was running. Retry to run it again.", actions: ["retry"] } })
    .where(eq(jobs.status, "running"));
}

export async function enqueue(type: JobType, title: string, payload: Record<string, unknown>, projectId: string | null, stages: { key: string; label: string }[] = []) {
  await boot();
  const [row] = await db
    .insert(jobs)
    .values({ type, title, payload, projectId, stages: stages.map((s) => ({ ...s, status: "pending" })) })
    .returning();
  void pump();
  return row;
}

export async function cancelJob(id: string) {
  const r = state.running.get(id);
  if (r) r.ctrl.abort();
  await db.update(jobs).set({ status: "cancelled", finishedAt: new Date(), message: "Cancelled by user" }).where(and(eq(jobs.id, id), inArray(jobs.status, ["queued", "running"])));
}

export async function retryJob(id: string) {
  const [old] = await db.select().from(jobs).where(eq(jobs.id, id));
  if (!old) throw new Error("Job not found");
  return enqueue(old.type as JobType, old.title, (old.payload || {}) as Record<string, unknown>, old.projectId, (old.stages || []).map((s) => ({ key: s.key, label: s.label })));
}

function logFile(job: Job) {
  const dir = path.join(appHome(), "logs");
  fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, `${job.createdAt.toISOString().slice(0, 10)}_${job.type}_${job.id}.log`);
}

export async function pump() {
  await boot();
  if (state.pumping) return;
  state.pumping = true;
  try {
    const queued = await db.select().from(jobs).where(eq(jobs.status, "queued")).orderBy(asc(jobs.createdAt)).limit(50);
    for (const job of queued) {
      const cfg = LANES[job.type as JobType];
      if (!cfg) continue;
      const busy = [...state.running.values()].filter((r) => r.lane === cfg.lane).length;
      if (busy >= cfg.concurrency) continue;
      void runJob(job, cfg.lane);
    }
  } finally {
    state.pumping = false;
  }
}

async function runJob(job: Job, lane: string) {
  const handler = state.handlers.get(job.type);
  const ctrl = new AbortController();
  state.running.set(job.id, { lane, ctrl });
  const file = logFile(job);
  let logBuf = "";
  let stages = [...(job.stages || [])];
  let lastWrite = 0;
  const log = (line: string) => {
    const l = `[${new Date().toISOString()}] ${line.replace(/AIza[0-9A-Za-z_-]{20,}/g, "[redacted-key]")}\n`;
    logBuf += l;
    fs.appendFile(file, l, () => {});
  };
  const ctx: JobCtx = {
    job,
    signal: ctrl.signal,
    log,
    progress: async (pct, stage, message) => {
      if (message) log(`${stage ? `[${stage}] ` : ""}${message}`);
      const now = Date.now();
      if (now - lastWrite < 350 && pct < 100) return;
      lastWrite = now;
      await db.update(jobs).set({ progress: pct, stage: stage ?? undefined, message: message ?? undefined, log: logBuf.slice(-20000) }).where(eq(jobs.id, job.id));
    },
    stage: async (key, status) => {
      stages = stages.map((s) => (s.key === key ? { ...s, status } : s));
      await db.update(jobs).set({ stages }).where(eq(jobs.id, job.id));
    },
  };
  try {
    await db.update(jobs).set({ status: "running", startedAt: new Date() }).where(eq(jobs.id, job.id));
    log(`Job started: ${job.title}`);
    if (!handler) throw new JobError("NO_HANDLER", `No handler registered for job type ${job.type}`);
    const result = await handler(ctx);
    if (ctrl.signal.aborted) throw new JobError("CANCELLED", "Cancelled by user", {}, []);
    log("Job completed successfully");
    await db.update(jobs).set({ status: "succeeded", progress: 100, result, finishedAt: new Date(), log: logBuf.slice(-20000) }).where(eq(jobs.id, job.id));
  } catch (e) {
    const err = e as JobError & { details?: unknown };
    const cancelled = ctrl.signal.aborted || err.code === "CANCELLED";
    log(`${cancelled ? "Cancelled" : "FAILED"}: ${err.code || "ERROR"} — ${err.message}`);
    stages = stages.map((s) => (s.status === "running" ? { ...s, status: cancelled ? "skipped" : "failed" } : s));
    await db
      .update(jobs)
      .set({
        status: cancelled ? "cancelled" : "failed",
        finishedAt: new Date(),
        stages,
        error: cancelled ? null : { code: err.code || "ERROR", message: err.message, details: err.details, actions: err.actions || ["retry"] },
        log: logBuf.slice(-20000) + `\nLog file: ${file}`,
      })
      .where(eq(jobs.id, job.id));
  } finally {
    state.running.delete(job.id);
    void pump();
  }
}

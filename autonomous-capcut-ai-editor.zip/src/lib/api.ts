import "server-only";
import { desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { edls, jobs, media, projects, versions } from "@/db/schema";
import { compileEdl } from "./edl/compile";
import { validateEdl } from "./edl/validate";
import { projectMedia, toInventory } from "./media";
import { getSettings } from "./settings";
import type { Edl } from "@/shared/schemas/edl";

export const ok = (data: unknown, status = 200) => Response.json(data, { status });
export const fail = (code: string, message: string, status = 400, details?: unknown) => Response.json({ error: { code, message, details } }, { status });

export async function listProjects() {
  const rows = await db.select().from(projects).orderBy(desc(projects.updatedAt));
  if (!rows.length) return [];
  const ids = rows.map((r) => r.id);
  const stats = await db
    .select({ projectId: media.projectId, count: sql<number>`count(*)::int`, duration: sql<number>`coalesce(sum(${media.durationS}),0)::float`, thumb: sql<string | null>`max(${media.thumbnail})` })
    .from(media)
    .where(inArray(media.projectId, ids))
    .groupBy(media.projectId);
  const vers = await db
    .select({ projectId: versions.projectId, number: sql<number>`max(${versions.number})::int`, last: sql<string>`max(${versions.createdAt})` })
    .from(versions)
    .where(inArray(versions.projectId, ids))
    .groupBy(versions.projectId);
  const running = await db.select({ projectId: jobs.projectId, n: sql<number>`count(*)::int` }).from(jobs).where(inArray(jobs.status, ["queued", "running"])).groupBy(jobs.projectId);
  return rows.map((p) => {
    const st = stats.find((s) => s.projectId === p.id);
    const v = vers.find((x) => x.projectId === p.id);
    return { ...p, clipCount: st?.count ?? 0, footageDurationS: st?.duration ?? 0, thumbnail: st?.thumb ?? null, lastVersion: v?.number ?? null, lastGeneratedAt: v?.last ?? null, activeJobs: running.find((r) => r.projectId === p.id)?.n ?? 0 };
  });
}

export async function projectDetail(id: string) {
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return null;
  const rows = await projectMedia(id);
  const s = await getSettings();
  let current: { id: string; label: string; source: string; createdAt: Date; edl: Edl; validation: unknown; compiled: ReturnType<typeof compileEdl> | null } | null = null;
  if (p.currentEdlId) {
    const [e] = await db.select().from(edls).where(eq(edls.id, p.currentEdlId));
    if (e) {
      const inv = toInventory(rows);
      const report = validateEdl(e.edl, inv, { repair: false });
      let compiled = null;
      if (report.ok && report.edl) {
        try {
          compiled = compileEdl(report.edl, inv, { width: p.width, height: p.height, fps: p.fps, captionSize: s.captions.size, emphasisColor: s.captions.emphasisColor, duckLevel: s.audio.duckLevel });
        } catch {
          compiled = null;
        }
      }
      current = { id: e.id, label: e.label, source: e.source, createdAt: e.createdAt, edl: e.edl as unknown as Edl, validation: { ok: report.ok, errors: report.errors, warnings: report.warnings, stats: report.stats }, compiled };
    }
  }
  const history = await db.select({ id: edls.id, label: edls.label, source: edls.source, createdAt: edls.createdAt }).from(edls).where(eq(edls.projectId, id)).orderBy(desc(edls.createdAt)).limit(30);
  const vers = await db.select().from(versions).where(eq(versions.projectId, id)).orderBy(desc(versions.number));
  return { project: p, media: rows.map(slimMedia), current, edlHistory: history, versions: vers, draftDir: s.storage.draftDir };
}

export function slimMedia(m: typeof media.$inferSelect) {
  const a = (m.analysis || {}) as Record<string, unknown>;
  const t = (m.transcript || null) as { segments?: unknown[]; language?: string; source?: string } | null;
  return {
    ...m,
    analysis: m.analysis ? { classification: a.classification, description: a.description, scenes_s: a.scenes_s, audio: a.audio, visual: a.visual, filmstrip: a.filmstrip } : null,
    transcript: t,
    transcriptWordCount: m.transcriptText ? m.transcriptText.split(/\s+/).filter(Boolean).length : 0,
  };
}

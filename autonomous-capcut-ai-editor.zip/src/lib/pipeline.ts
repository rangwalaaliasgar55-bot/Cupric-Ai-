import "server-only";
import fs from "node:fs";
import path from "node:path";
import { and, desc, eq, max } from "drizzle-orm";
import { db } from "@/db";
import { edls, media, projects, versions, type Project } from "@/db/schema";
import { runEngine, EngineFailure } from "./engine";
import { enqueue, JobError, registerHandler, type JobCtx } from "./jobs";
import { expandPaths, projectMedia, toInventory, toMediaContext, uniqueFilename } from "./media";
import { APP_VERSION, getSettings, PROMPT_VERSION } from "./settings";
import { compileEdl } from "./edl/compile";
import { validateEdl } from "./edl/validate";
import { DirectorError, localModifier, runDirector, type DirectorBrief, type RegenMode } from "./ai/director";
import type { Edl } from "@/shared/schemas/edl";

const asJobError = (e: unknown, actions = ["retry"]): JobError => {
  if (e instanceof JobError) return e;
  if (e instanceof EngineFailure) {
    const act = e.code === "FILE_NOT_FOUND" ? ["retry", "locate", "skip", "cancel"] : e.code === "DRAFT_ROOT_MISSING" || e.code === "DRAFT_ROOT_READONLY" ? ["settings", "retry"] : actions;
    return new JobError(e.code, e.message, e.details, act);
  }
  if (e instanceof DirectorError) return new JobError(e.code, e.message, e.details, e.code === "GEMINI_KEY_MISSING" || e.code === "GEMINI_AUTH" ? ["settings", "retry"] : ["retry"]);
  return new JobError("UNEXPECTED", `${(e as Error).name}: ${(e as Error).message}`, {}, actions);
};

export async function getProject(id: string): Promise<Project> {
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) throw new JobError("PROJECT_NOT_FOUND", `Project ${id} no longer exists.`, {}, []);
  return p;
}

export async function writeManifest(projectId: string) {
  const p = await getProject(projectId);
  const rows = await projectMedia(projectId);
  const [cur] = p.currentEdlId ? await db.select().from(edls).where(eq(edls.id, p.currentEdlId)) : [];
  const manifest = { format: "capcut-ai-project", version: 1, app_version: APP_VERSION, project: { ...p, id: undefined }, media: rows.map((m) => ({ filename: m.filename, path: m.path, hash: m.hash })), current_edl: cur?.edl || null };
  fs.mkdirSync(p.location, { recursive: true });
  fs.writeFileSync(path.join(p.location, "capcut-ai-project.json"), JSON.stringify(manifest, null, 2));
}

export async function saveEdl(projectId: string, edl: Edl, source: string, label: string, extra: { prompt?: Record<string, unknown>; parentId?: string | null } = {}) {
  const rows = await projectMedia(projectId);
  const report = validateEdl(edl, toInventory(rows), { repair: true });
  const [row] = await db
    .insert(edls)
    .values({ projectId, label, source, edl: (report.edl || edl) as unknown as Record<string, unknown>, validation: { ok: report.ok, errors: report.errors, warnings: report.warnings, repairs: report.repairs, stats: report.stats }, prompt: extra.prompt, parentId: extra.parentId ?? null })
    .returning();
  await db.update(projects).set({ currentEdlId: row.id, updatedAt: new Date(), status: "planned" }).where(eq(projects.id, projectId));
  void writeManifest(projectId).catch(() => {});
  return { row, report };
}

// ---------------- handlers ----------------

registerHandler("import_media", async (ctx) => {
  const { projectId, paths } = ctx.job.payload as { projectId: string; paths: string[] };
  const { files, problems } = expandPaths(paths);
  problems.forEach((p) => ctx.log(`WARN ${p}`));
  if (!files.length) throw new JobError("NO_MEDIA", `No supported media files were found. ${problems.join("; ")}`, { problems }, []);
  const existing = await projectMedia(projectId);
  const byPath = new Set(existing.map((m) => m.path));
  const todo = files.filter((f) => !byPath.has(f));
  await ctx.progress(5, "probe", `Probing ${todo.length} file(s) (${files.length - todo.length} already imported)`);
  const imported: string[] = [];
  const settings = await getSettings();
  for (let i = 0; i < todo.length; i += 10) {
    const batch = todo.slice(i, i + 10);
    const res = await runEngine<{ items: Record<string, unknown>[] }>("probe", { paths: batch }, { signal: ctx.signal });
    for (const it of res.items) {
      const hash = (it.hash as string) || null;
      const warnings = [...((it.warnings as { code: string; severity: string; message: string }[]) || [])];
      const dup = hash ? [...existing].find((m) => m.hash === hash) : undefined;
      if (dup) warnings.push({ code: "DUPLICATE", severity: "warning", message: `Duplicate of ${dup.filename} (identical content).` });
      const filename = await uniqueFilename(projectId, (it.filename as string) || path.basename(it.path as string));
      const [row] = await db
        .insert(media)
        .values({
          projectId, filename, path: it.path as string, kind: (it.kind as string) || "unknown", hash, sizeBytes: (it.size_bytes as number) ?? null, mtimeMs: (it.mtime_ms as number) ?? null,
          durationS: (it.duration_s as number) ?? null, width: (it.width as number) ?? null, height: (it.height as number) ?? null, fps: (it.fps as number) ?? null,
          variableFps: !!it.variable_fps, codec: (it.codec as string) ?? null, audioCodec: (it.audio_codec as string) ?? null, hasAudio: !!it.has_audio,
          aspectRatio: (it.aspect_ratio as string) ?? null, readable: it.readable !== false, warnings,
          analysisStatus: it.readable === false ? "skipped" : "queued",
          transcriptStatus: it.readable === false || !(it.has_audio) ? "not_applicable" : "queued",
        })
        .returning();
      existing.push(row);
      imported.push(row.id);
      ctx.log(`Imported ${filename} (${row.kind}, ${row.durationS ?? "-"}s)${warnings.length ? ` — ${warnings.map((w) => w.code).join(", ")}` : ""}`);
      if (row.readable) await enqueue("analyze_media", `Analyze ${filename}`, { mediaId: row.id }, projectId);
      if (row.readable && row.hasAudio) await enqueue("transcribe_media", `Transcribe ${filename}`, { mediaId: row.id, model: settings.transcription.model }, projectId);
    }
    await ctx.progress(5 + 90 * Math.min(1, (i + batch.length) / todo.length), "probe", `Probed ${Math.min(todo.length, i + batch.length)}/${todo.length}`);
  }
  await db.update(projects).set({ updatedAt: new Date(), status: "ingested" }).where(eq(projects.id, projectId));
  void writeManifest(projectId).catch(() => {});
  return { imported: imported.length, skipped: files.length - todo.length, problems };
});

registerHandler("analyze_media", async (ctx) => {
  const { mediaId, force } = ctx.job.payload as { mediaId: string; force?: boolean };
  const [m] = await db.select().from(media).where(eq(media.id, mediaId));
  if (!m) throw new JobError("MEDIA_NOT_FOUND", "This media item was removed from the project.", {}, []);
  if (!fs.existsSync(m.path)) {
    await db.update(media).set({ analysisStatus: "failed", analysisError: `${m.filename} could not be found at ${m.path}` }).where(eq(media.id, mediaId));
    throw new JobError("FILE_NOT_FOUND", `${m.filename} could not be found at ${m.path}.`, { path: m.path }, ["locate", "retry"]);
  }
  const st = fs.statSync(m.path);
  const key = `${m.hash}:${st.size}:${Math.floor(st.mtimeMs)}`;
  if (!force && m.analysisStatus === "done" && m.analysisKey === key) return { cached: true };
  await db.update(media).set({ analysisStatus: "running", analysisError: null }).where(eq(media.id, mediaId));
  const s = await getSettings();
  const outDir = path.join(s.storage.cacheDir, "analysis", `${m.hash || m.id}`);
  try {
    const res = await runEngine<Record<string, unknown>>("analyze", { path: m.path, out_dir: outDir }, { signal: ctx.signal, onProgress: (p) => void ctx.progress(p.pct, p.stage, p.message), onLog: ctx.log });
    await db.update(media).set({ analysisStatus: "done", analysisKey: key, analysis: res, thumbnail: (res.thumbnail as string) || null }).where(eq(media.id, mediaId));
    return { thumbnail: res.thumbnail };
  } catch (e) {
    const err = asJobError(e);
    await db.update(media).set({ analysisStatus: err.code === "CANCELLED" ? "queued" : "failed", analysisError: err.message }).where(eq(media.id, mediaId));
    throw err;
  }
});

registerHandler("transcribe_media", async (ctx) => {
  const { mediaId, force, model: modelOverride } = ctx.job.payload as { mediaId: string; force?: boolean; model?: string };
  const [m] = await db.select().from(media).where(eq(media.id, mediaId));
  if (!m) throw new JobError("MEDIA_NOT_FOUND", "This media item was removed from the project.", {}, []);
  const s = await getSettings();
  const model = modelOverride || s.transcription.model;
  const key = `${m.hash}:${model}:${s.transcription.language || "auto"}`;
  if (!force && m.transcriptStatus === "done" && m.transcriptKey === key) return { cached: true };
  await db.update(media).set({ transcriptStatus: "running", transcriptError: null }).where(eq(media.id, mediaId));
  try {
    const res = await runEngine<{ segments: { text: string }[] }>(
      "transcribe",
      { path: m.path, model, language: s.transcription.language || null, device: s.transcription.device, compute_type: s.transcription.computeType, word_timestamps: s.transcription.wordTimestamps, model_dir: path.join(s.storage.cacheDir, "whisper-models") },
      { signal: ctx.signal, onProgress: (p) => void ctx.progress(p.pct, p.stage, p.message), onLog: ctx.log },
    );
    const text = res.segments.map((x) => x.text).join(" ");
    await db.update(media).set({ transcriptStatus: "done", transcriptKey: key, transcript: { ...res, source: "whisper" }, transcriptText: text }).where(eq(media.id, mediaId));
    return { segments: res.segments.length, words: text.split(/\s+/).filter(Boolean).length };
  } catch (e) {
    const err = asJobError(e, ["retry", "import_transcript"]);
    if (err.code !== "FILE_NOT_FOUND") err.actions = ["retry", "import_transcript"];
    await db.update(media).set({ transcriptStatus: err.code === "CANCELLED" ? "queued" : "failed", transcriptError: err.message }).where(eq(media.id, mediaId));
    throw err;
  }
});

registerHandler("ai_director", async (ctx) => {
  const { projectId, mode } = ctx.job.payload as { projectId: string; mode: RegenMode };
  const p = await getProject(projectId);
  const rows = await projectMedia(projectId);
  const pending = rows.filter((m) => ["queued", "running"].includes(m.analysisStatus) || ["queued", "running"].includes(m.transcriptStatus));
  if (pending.length) ctx.log(`WARN ${pending.length} file(s) still analysing/transcribing; the Director will use what is available.`);
  const usable = rows.filter((m) => m.readable);
  if (!usable.some((m) => m.kind === "video" || m.kind === "image")) throw new JobError("NO_VISUALS", "The project has no readable video or image files to edit.", {}, []);
  const [cur] = p.currentEdlId ? await db.select().from(edls).where(eq(edls.id, p.currentEdlId)) : [];
  const brief = { ...((p.directorBrief || {}) as Partial<DirectorBrief>), targetDurationS: p.targetDurationS, aspectRatio: p.aspectRatio, fps: p.fps } as DirectorBrief;
  await ctx.stage("context", "running");
  await ctx.progress(5, "context", `Preparing context: ${usable.length} files, transcript words and analysis (no media files are uploaded)`);
  await ctx.stage("context", "done");
  if (mode.kind === "modifier" && cur) {
    const local = localModifier(cur.edl as unknown as Edl, mode.modifier);
    if (local) {
      const { row } = await saveEdl(projectId, local, "local", `Local: ${mode.modifier.replace("_", " ")}`, { parentId: cur.id });
      await ctx.stage("gemini", "skipped");
      await ctx.stage("validate", "done");
      return { edlId: row.id, local: true };
    }
  }
  await ctx.stage("gemini", "running");
  try {
    const out = await runDirector({
      projectId, brief, media: toMediaContext(usable), current: (cur?.edl as unknown as Edl) || null, mode,
      onProgress: (msg, pct) => {
        ctx.log(msg);
        void ctx.progress(pct, "gemini", msg);
      },
    });
    await ctx.stage("gemini", "done");
    await ctx.stage("validate", "done");
    out.report.repairs.forEach((r) => ctx.log(`REPAIR ${r.path}: ${r.message}`));
    out.report.warnings.forEach((r) => ctx.log(`WARN ${r.path}: ${r.message}`));
    const label = mode.kind === "full" ? "AI edit" : mode.kind === "section" ? `AI: regenerate section ${mode.sectionId}` : mode.kind === "clip" ? `AI: regenerate clip ${mode.clipId}` : `AI: ${mode.modifier.replace("_", " ")}`;
    const { row } = await saveEdl(projectId, out.edl, "ai", label, { prompt: { version: out.promptVersion, attempts: out.attempts, mode, brief }, parentId: cur?.id ?? null });
    return { edlId: row.id, attempts: out.attempts, repairs: out.report.repairs.length, warnings: out.report.warnings.length };
  } catch (e) {
    throw asJobError(e);
  }
});

export const BUILD_STAGES = [
  { key: "validate_project", label: "Validate project" },
  { key: "validate_media", label: "Validate media" },
  { key: "validate_edl", label: "Validate EDL" },
  { key: "create_draft", label: "Create CapCut draft" },
  { key: "tracks", label: "Create tracks" },
  { key: "video", label: "Add video + keyframes" },
  { key: "audio", label: "Add dialogue & music" },
  { key: "captions", label: "Add captions" },
  { key: "sfx", label: "Add SFX" },
  { key: "effects", label: "Apply look & effects" },
  { key: "save", label: "Save draft" },
  { key: "validate", label: "Validate generated draft" },
  { key: "install", label: "Backup & install" },
  { key: "complete", label: "Complete" },
];

registerHandler("build_draft", async (ctx) => {
  const { projectId, edlId, newDraftPerVersion } = ctx.job.payload as { projectId: string; edlId: string; newDraftPerVersion?: boolean };
  const s = await getSettings();
  await ctx.stage("validate_project", "running");
  const p = await getProject(projectId);
  if (!fs.existsSync(s.storage.draftDir)) throw new JobError("DRAFT_ROOT_MISSING", `CapCut draft generation failed because the draft folder ${s.storage.draftDir} does not exist.`, {}, ["settings", "retry"]);
  await ctx.stage("validate_project", "done");
  await ctx.stage("validate_media", "running");
  const rows = await projectMedia(projectId);
  const [edlRow] = await db.select().from(edls).where(and(eq(edls.id, edlId), eq(edls.projectId, projectId)));
  if (!edlRow) throw new JobError("EDL_NOT_FOUND", "The selected edit plan no longer exists.", {}, []);
  const inv = toInventory(rows);
  const edl = edlRow.edl as unknown as Edl;
  const used = new Set<string>();
  for (const sec of edl.sections || []) for (const c of sec.clips || []) {
    used.add(c.source_file);
    (c.broll || []).forEach((b) => used.add(b.source_file));
    (c.sfx || []).forEach((x) => used.add(x.source_file));
  }
  if (edl.music?.source_file) used.add(edl.music.source_file);
  for (const f of used) {
    const it = inv.find((i) => i.filename === f);
    if (!it || !fs.existsSync(it.path)) throw new JobError("FILE_NOT_FOUND", `CapCut draft generation failed because ${f} could not be found${it ? ` at ${it.path}` : " in the project"}.`, { filename: f, path: it?.path }, ["retry", "locate", "skip", "cancel"]);
  }
  await ctx.stage("validate_media", "done");
  await ctx.stage("validate_edl", "running");
  const report = validateEdl(edl, inv, { repair: false });
  if (!report.ok || !report.edl) throw new JobError("EDL_INVALID", `The edit plan is invalid and will not be built: ${report.errors.slice(0, 4).map((e) => `${e.path}: ${e.message}`).join("; ")}`, report, ["edit_plan", "retry"]);
  await ctx.stage("validate_edl", "done");

  const [{ n }] = await db.select({ n: max(versions.number) }).from(versions).where(eq(versions.projectId, projectId));
  const number = (n || 0) + 1;
  const vtag = `v${String(number).padStart(3, "0")}`;
  const draftName = newDraftPerVersion ? `${p.draftName} ${vtag}` : p.draftName;
  const { plan, notes } = compileEdl(report.edl, inv, { width: p.width, height: p.height, fps: p.fps, captionFont: s.captions.font, captionSize: s.captions.size, emphasisColor: s.captions.emphasisColor, dialogueGain: s.audio.dialogueGain, sfxGain: s.audio.sfxGain, duckLevel: s.audio.duckLevel, musicDucking: s.audio.musicDucking });
  notes.forEach((x) => ctx.log(`NOTE ${x}`));
  const fullPlan = { ...plan, draft_root: s.storage.draftDir, draft_name: draftName, backup_dir: path.join(p.location, "backups"), audio_cache_dir: path.join(s.storage.cacheDir, "dialogue-audio"), backup_retention: s.storage.backupRetention };
  fs.mkdirSync(path.join(p.location, "versions"), { recursive: true });
  fs.writeFileSync(path.join(p.location, "versions", `${vtag}.plan.json`), JSON.stringify({ edl: report.edl, plan: fullPlan }, null, 2));
  const stageKeys = BUILD_STAGES.map((x) => x.key);
  let active = "";
  const settingsSnap = { width: p.width, height: p.height, fps: p.fps, aspectRatio: p.aspectRatio, targetDurationS: p.targetDurationS, draftName, captions: s.captions, audio: s.audio };
  const mediaRefs = inv.filter((i) => used.has(i.filename)).map((i) => ({ filename: i.filename, path: i.path, hash: rows.find((r) => r.filename === i.filename)?.hash }));
  try {
    const res = await runEngine<{ draft_path: string; backup_path: string | null; validation: Record<string, unknown>; notes: string[]; unsupported: string[] }>("build", { plan: fullPlan }, {
      signal: ctx.signal,
      onLog: ctx.log,
      onProgress: (pr) => {
        if (pr.stage !== active && stageKeys.includes(pr.stage)) {
          const prev = active;
          active = pr.stage;
          void (async () => {
            if (prev) await ctx.stage(prev, "done");
            await ctx.stage(pr.stage, "running");
          })();
        }
        void ctx.progress(pr.pct, pr.stage, pr.message);
      },
    });
    for (const k of stageKeys) await ctx.stage(k, "done");
    res.notes.forEach((x) => ctx.log(`NOTE ${x}`));
    res.unsupported.forEach((x) => ctx.log(`UNSUPPORTED ${x}`));
    const [v] = await db
      .insert(versions)
      .values({ projectId, number, edlId, edl: report.edl as unknown as Record<string, unknown>, settings: settingsSnap, mediaRefs, draftPath: res.draft_path, backupPath: res.backup_path, status: "succeeded", report: { validation: res.validation, notes: [...notes, ...res.notes], unsupported: res.unsupported }, promptVersion: ((edlRow.prompt as { version?: string } | null)?.version) || PROMPT_VERSION, appVersion: APP_VERSION })
      .returning();
    await db.update(projects).set({ status: "generated", updatedAt: new Date() }).where(eq(projects.id, projectId));
    void writeManifest(projectId).catch(() => {});
    return { versionId: v.id, number, draftPath: res.draft_path, backupPath: res.backup_path, draftName };
  } catch (e) {
    const err = asJobError(e);
    await db.insert(versions).values({ projectId, number, edlId, edl: report.edl as unknown as Record<string, unknown>, settings: settingsSnap, mediaRefs, status: "failed", report: { error: { code: err.code, message: err.message } }, promptVersion: PROMPT_VERSION, appVersion: APP_VERSION });
    throw err;
  }
});

registerHandler("restore_backup", async (ctx) => {
  const { projectId, backupPath, draftName } = ctx.job.payload as { projectId: string; backupPath: string; draftName: string };
  const p = await getProject(projectId);
  const s = await getSettings();
  await ctx.progress(10, "restore", `Restoring ${path.basename(backupPath)}`);
  try {
    const res = await runEngine<Record<string, unknown>>("restore_backup", { backup_path: backupPath, draft_root: s.storage.draftDir, draft_name: draftName, backup_dir: path.join(p.location, "backups") }, { signal: ctx.signal });
    return res;
  } catch (e) {
    throw asJobError(e);
  }
});

export async function latestVersion(projectId: string) {
  const [v] = await db.select().from(versions).where(eq(versions.projectId, projectId)).orderBy(desc(versions.number)).limit(1);
  return v || null;
}

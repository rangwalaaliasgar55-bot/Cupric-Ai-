import "server-only";
import os from "node:os";
import path from "node:path";
import fs from "node:fs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { settings as settingsTable } from "@/db/schema";

export const APP_VERSION = "1.0.0";
export const PROMPT_VERSION = "director-2026.09-r3";

export type AppSettings = {
  onboarded: boolean;
  ai: { model: string; temperature: number; retryCount: number; maxAttempts: number };
  transcription: { model: string; language: string; device: string; computeType: string; wordTimestamps: boolean };
  video: { aspectRatio: string; width: number; height: number; fps: number };
  captions: { font: string; size: number; position: "bottom" | "center" | "top"; animation: string; maxWords: number; mode: "phrase" | "word" | "karaoke"; emphasisColor: string };
  audio: { musicDucking: boolean; duckLevel: number; musicVolume: number; dialogueGain: number; sfxGain: number };
  storage: { projectDir: string; cacheDir: string; draftDir: string; backupRetention: number };
};

export function appHome(): string {
  return process.env.CAPCUT_AI_HOME || path.join(os.homedir(), "CapCutAI");
}

export function detectCapcutDirs(): string[] {
  const home = os.homedir();
  const local = process.env.LOCALAPPDATA || path.join(home, "AppData", "Local");
  return [
    path.join(local, "CapCut", "User Data", "Projects", "com.lveditor.draft"),
    path.join(local, "JianyingPro", "User Data", "Projects", "com.lveditor.draft"),
    path.join(home, "Movies", "CapCut", "User Data", "Projects", "com.lveditor.draft"),
    path.join(home, "Movies", "JianyingPro", "User Data", "Projects", "com.lveditor.draft"),
  ].filter((d) => fs.existsSync(d));
}

export function defaultSettings(): AppSettings {
  const home = appHome();
  return {
    onboarded: false,
    ai: { model: "gemini-2.5-flash", temperature: 0.6, retryCount: 2, maxAttempts: 3 },
    transcription: { model: "small", language: "", device: "auto", computeType: "auto", wordTimestamps: true },
    video: { aspectRatio: "9:16", width: 1080, height: 1920, fps: 30 },
    captions: { font: "", size: 9, position: "bottom", animation: "pop", maxWords: 5, mode: "phrase", emphasisColor: "#FFD23F" },
    audio: { musicDucking: true, duckLevel: 0.18, musicVolume: 0.45, dialogueGain: 1.0, sfxGain: 0.7 },
    storage: {
      projectDir: path.join(home, "Projects"),
      cacheDir: path.join(home, "Cache"),
      draftDir: detectCapcutDirs()[0] || path.join(home, "CapCut Drafts"),
      backupRetention: 10,
    },
  };
}

function merge<T>(base: T, over: unknown): T {
  if (!over || typeof over !== "object" || Array.isArray(over)) return base;
  const out: Record<string, unknown> = { ...(base as Record<string, unknown>) };
  for (const [k, v] of Object.entries(over as Record<string, unknown>)) {
    const b = out[k];
    out[k] = b && typeof b === "object" && !Array.isArray(b) ? merge(b, v) : v;
  }
  return out as T;
}

export async function getSettings(): Promise<AppSettings> {
  const row = await db.select().from(settingsTable).where(eq(settingsTable.key, "app")).limit(1);
  const s = merge(defaultSettings(), row[0]?.value);
  for (const dir of [s.storage.projectDir, s.storage.cacheDir]) fs.mkdirSync(dir, { recursive: true });
  if (s.storage.draftDir.startsWith(appHome())) fs.mkdirSync(s.storage.draftDir, { recursive: true });
  return s;
}

export async function saveSettings(patch: Partial<AppSettings>): Promise<AppSettings> {
  const next = merge(await getSettings(), patch);
  await db
    .insert(settingsTable)
    .values({ key: "app", value: next })
    .onConflictDoUpdate({ target: settingsTable.key, set: { value: next, updatedAt: new Date() } });
  return next;
}

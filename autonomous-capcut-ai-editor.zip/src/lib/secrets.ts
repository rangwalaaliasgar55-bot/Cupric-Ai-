import "server-only";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { secrets } from "@/db/schema";
import { appHome } from "./settings";

/**
 * API keys are encrypted with AES-256-GCM using a 32-byte key stored in a
 * machine-local file (mode 0600) outside the database. The DB only holds
 * ciphertext. Plaintext never reaches the frontend or logs.
 */
function masterKey(): Buffer {
  const file = path.join(appHome(), ".keystore");
  fs.mkdirSync(appHome(), { recursive: true });
  if (!fs.existsSync(file)) fs.writeFileSync(file, crypto.randomBytes(32).toString("base64"), { mode: 0o600 });
  return Buffer.from(fs.readFileSync(file, "utf8").trim(), "base64");
}

export async function setSecret(key: string, value: string) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", masterKey(), iv);
  const ct = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  const row = { key, ciphertext: ct.toString("base64"), iv: iv.toString("base64"), tag: cipher.getAuthTag().toString("base64"), hint: `••••${value.slice(-4)}`, updatedAt: new Date() };
  await db.insert(secrets).values(row).onConflictDoUpdate({ target: secrets.key, set: row });
}

export async function deleteSecret(key: string) {
  await db.delete(secrets).where(eq(secrets.key, key));
}

export async function getSecret(key: string): Promise<string | null> {
  const [row] = await db.select().from(secrets).where(eq(secrets.key, key)).limit(1);
  if (!row) return key === "gemini_api_key" ? process.env.GEMINI_API_KEY || null : null;
  try {
    const decipher = crypto.createDecipheriv("aes-256-gcm", masterKey(), Buffer.from(row.iv, "base64"));
    decipher.setAuthTag(Buffer.from(row.tag, "base64"));
    return Buffer.concat([decipher.update(Buffer.from(row.ciphertext, "base64")), decipher.final()]).toString("utf8");
  } catch {
    return null;
  }
}

export async function secretHint(key: string): Promise<{ configured: boolean; hint: string | null; source: "local" | "env" | null }> {
  const [row] = await db.select({ hint: secrets.hint }).from(secrets).where(eq(secrets.key, key)).limit(1);
  if (row) return { configured: true, hint: row.hint, source: "local" };
  if (key === "gemini_api_key" && process.env.GEMINI_API_KEY) return { configured: true, hint: "from GEMINI_API_KEY env", source: "env" };
  return { configured: false, hint: null, source: null };
}

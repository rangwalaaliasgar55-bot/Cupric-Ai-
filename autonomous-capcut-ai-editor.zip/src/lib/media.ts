import "server-only";
import fs from "node:fs";
import path from "node:path";
import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { media, type Media } from "@/db/schema";
import type { InventoryItem } from "@/lib/edl/validate";
import type { MediaContext } from "@/lib/ai/director";

export const MEDIA_EXT = new Set([".mp4", ".mov", ".m4v", ".mkv", ".avi", ".webm", ".mts", ".m2ts", ".wmv", ".flv", ".3gp", ".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".opus", ".wma", ".aiff", ".aif", ".jpg", ".jpeg", ".png", ".webp", ".bmp", ".heic", ".tif", ".tiff", ".gif"]);

export function expandPaths(inputs: string[], limit = 2000): { files: string[]; problems: string[] } {
  const files: string[] = [];
  const problems: string[] = [];
  const walk = (p: string, depth: number) => {
    if (files.length >= limit) return;
    let st: fs.Stats;
    try {
      st = fs.statSync(p);
    } catch {
      problems.push(`${p} does not exist or is not accessible`);
      return;
    }
    if (st.isDirectory()) {
      if (depth > 6) return;
      for (const name of fs.readdirSync(p).sort()) if (!name.startsWith(".")) walk(path.join(p, name), depth + 1);
    } else if (MEDIA_EXT.has(path.extname(p).toLowerCase())) files.push(path.resolve(p));
    else if (depth === 0) problems.push(`${path.basename(p)} is not a supported media type`);
  };
  for (const i of inputs) walk(i.trim(), 0);
  return { files, problems };
}

type Word = { word: string; start: number; end: number; confidence?: number };
type Segment = { start: number; end: number; text: string; words?: Word[] };

export function transcriptSegments(m: Media): Segment[] {
  const t = m.transcript as { segments?: Segment[] } | null;
  return t?.segments || [];
}

const HOOK_PATTERNS: [RegExp, number, string][] = [
  [/\?/, 2, "question"],
  [/\b(you|your)\b/i, 1.5, "viewer call-out"],
  [/\b\d+(\.\d+)?\s*(%|x|k|m|hours?|minutes?|days?|seconds?|times|dollars?)?\b/i, 2, "specific number"],
  [/\b(never|stop|secret|mistake|wrong|actually|nobody|everyone|instantly|automatically|finally|biggest|best|worst|only)\b/i, 2, "strong claim"],
  [/\b(how to|here's how|this is why|what if|imagine)\b/i, 2, "curiosity gap"],
  [/!/, 1, "exclamation"],
];

export function hookCandidates(segs: Segment[]) {
  return segs
    .map((s) => {
      let score = 0;
      const why: string[] = [];
      for (const [re, w, label] of HOOK_PATTERNS)
        if (re.test(s.text)) {
          score += w;
          why.push(label);
        }
      const dur = s.end - s.start;
      if (dur > 1 && dur < 7) score += 1;
      return { start: s.start, end: s.end, text: s.text, score, why: why.join(", ") };
    })
    .filter((c) => c.score >= 2.5)
    .sort((a, b) => b.score - a.score)
    .slice(0, 6);
}

export async function projectMedia(projectId: string) {
  return db.select().from(media).where(eq(media.projectId, projectId)).orderBy(asc(media.createdAt));
}

function luma(m: Media): number | null {
  const v = (m.analysis as { visual?: { luma?: number } } | null)?.visual?.luma;
  return typeof v === "number" ? v : null;
}

export function toInventory(rows: Media[]): InventoryItem[] {
  return rows.map((m) => ({
    filename: m.filename,
    path: m.path,
    kind: m.kind,
    durationS: m.durationS,
    hasAudio: !!m.hasAudio,
    readable: !!m.readable && fs.existsSync(m.path),
    width: m.width,
    height: m.height,
    luma: luma(m),
    words: transcriptSegments(m).flatMap((s) => s.words || []),
  }));
}

export function toMediaContext(rows: Media[]): MediaContext[] {
  const inv = toInventory(rows);
  return rows.map((m, i) => {
    const a = (m.analysis || {}) as { classification?: { shot_type?: string }; description?: string; scenes_s?: number[]; audio?: { silences?: { start_s: number; end_s: number }[] } };
    const segs = transcriptSegments(m);
    return { ...inv[i], shotType: a.classification?.shot_type, description: a.description, scenes: a.scenes_s, silences: a.audio?.silences, segments: segs, hookCandidates: hookCandidates(segs) };
  });
}

/** Unique filename within a project (EDL references are filenames). */
export async function uniqueFilename(projectId: string, filename: string) {
  const rows = await db.select({ filename: media.filename }).from(media).where(eq(media.projectId, projectId));
  const taken = new Set(rows.map((r) => r.filename));
  if (!taken.has(filename)) return filename;
  const ext = path.extname(filename);
  const base = filename.slice(0, filename.length - ext.length);
  for (let i = 2; ; i++) if (!taken.has(`${base}_${i}${ext}`)) return `${base}_${i}${ext}`;
}

export type SearchHit = { mediaId: string; filename: string; score: number; reasons: string[]; matches: { start: number; end: number; text: string }[] };

/** Search footage by filename, transcript words, detected scene/shot labels, duration and media type. */
export async function searchMedia(projectId: string, q: string, filters: { kind?: string; minDur?: number; maxDur?: number } = {}): Promise<SearchHit[]> {
  const rows = await projectMedia(projectId);
  const terms = q.toLowerCase().split(/\s+/).filter((t) => t.length > 1);
  const hits: SearchHit[] = [];
  for (const m of rows) {
    if (filters.kind && m.kind !== filters.kind) continue;
    if (filters.minDur && (m.durationS ?? 0) < filters.minDur) continue;
    if (filters.maxDur && (m.durationS ?? Infinity) > filters.maxDur) continue;
    let score = 0;
    const reasons: string[] = [];
    const matches: SearchHit["matches"] = [];
    if (!terms.length) {
      hits.push({ mediaId: m.id, filename: m.filename, score: 0, reasons: [], matches });
      continue;
    }
    const fname = m.filename.toLowerCase();
    const a = (m.analysis || {}) as { classification?: { shot_type?: string; tags?: string[] }; description?: string };
    const labels = [a.classification?.shot_type, ...(a.classification?.tags || []), a.description].filter(Boolean).join(" ").toLowerCase().replace(/_/g, " ");
    for (const t of terms) {
      if (fname.includes(t)) (score += 3), reasons.push(`filename “${t}”`);
      if (labels.includes(t)) (score += 2), reasons.push(`analysis “${t}”`);
    }
    for (const s of transcriptSegments(m)) {
      const text = s.text.toLowerCase();
      const n = terms.filter((t) => text.includes(t)).length;
      if (n) {
        score += n * 2 + (n === terms.length ? 3 : 0);
        matches.push({ start: s.start, end: s.end, text: s.text });
      }
    }
    if (matches.length) reasons.push(`${matches.length} transcript match(es)`);
    if (score > 0) hits.push({ mediaId: m.id, filename: m.filename, score, reasons: [...new Set(reasons)], matches: matches.slice(0, 5) });
  }
  return hits.sort((x, y) => y.score - x.score);
}

export async function mediaByPath(projectId: string, p: string) {
  return db.select().from(media).where(and(eq(media.projectId, projectId), eq(media.path, p))).limit(1);
}

import { EdlSchema, type Edl } from "../../shared/schemas/edl";

export type InventoryItem = {
  filename: string;
  path: string;
  kind: string; // video | audio | image
  durationS: number | null;
  hasAudio: boolean;
  readable: boolean;
  width?: number | null;
  height?: number | null;
  words?: { word: string; start: number; end: number }[];
  luma?: number | null;
};

export type Issue = { path: string; message: string };
export type ValidationReport = {
  ok: boolean;
  errors: Issue[];
  warnings: Issue[];
  repairs: Issue[];
  edl: Edl | null;
  stats?: { clipCount: number; timelineDurationS: number };
};

const EPS = 0.001;
const r3 = (n: number) => Math.round(n * 1000) / 1000;

/** Strip Markdown fences / leading prose and parse JSON. Throws with an explicit message. */
export function parseAiJson(raw: string): unknown {
  let text = raw.trim();
  const fence = /```(?:json)?\s*([\s\S]*?)```/i.exec(text);
  if (fence) text = fence[1].trim();
  const first = text.indexOf("{");
  const last = text.lastIndexOf("}");
  if (first < 0 || last <= first) throw new Error("AI response did not contain a JSON object");
  try {
    return JSON.parse(text.slice(first, last + 1));
  } catch (e) {
    throw new Error(`AI response was malformed JSON: ${(e as Error).message}`);
  }
}

function resolveFile(name: string, inv: Map<string, InventoryItem>, lowerIdx: Map<string, InventoryItem[]>) {
  if (inv.has(name)) return { item: inv.get(name)!, repaired: false };
  const base = name.split(/[\\/]/).pop() || name;
  if (inv.has(base)) return { item: inv.get(base)!, repaired: true };
  const hits = lowerIdx.get(base.toLowerCase());
  if (hits && hits.length === 1) return { item: hits[0], repaired: true };
  return { item: null, repaired: false };
}

/**
 * Validates an EDL candidate against the schema AND the real media inventory.
 * Safe deterministic repairs are applied and reported; anything unsafe is an error.
 * A report with errors must never be built.
 */
export function validateEdl(candidate: unknown, inventoryList: InventoryItem[], opts: { repair?: boolean } = {}): ValidationReport {
  const repair = opts.repair ?? true;
  const errors: Issue[] = [];
  const warnings: Issue[] = [];
  const repairs: Issue[] = [];
  const parsed = EdlSchema.safeParse(candidate);
  if (!parsed.success) {
    for (const iss of parsed.error.issues) errors.push({ path: iss.path.join(".") || "(root)", message: iss.message });
    return { ok: false, errors, warnings, repairs, edl: null };
  }
  const edl: Edl = structuredClone(parsed.data);
  const inv = new Map(inventoryList.map((i) => [i.filename, i]));
  const lowerIdx = new Map<string, InventoryItem[]>();
  for (const i of inventoryList) lowerIdx.set(i.filename.toLowerCase(), [...(lowerIdx.get(i.filename.toLowerCase()) || []), i]);

  const fixFile = (p: string, name: string, kinds: string[], setter: (n: string) => void): InventoryItem | null => {
    const { item, repaired } = resolveFile(name, inv, lowerIdx);
    if (!item) {
      errors.push({ path: p, message: `references "${name}" which does not exist in the media inventory` });
      return null;
    }
    if (repaired) {
      if (!repair) {
        errors.push({ path: p, message: `"${name}" does not exactly match an inventory filename` });
        return null;
      }
      setter(item.filename);
      repairs.push({ path: p, message: `filename "${name}" corrected to "${item.filename}"` });
    }
    if (!item.readable) {
      errors.push({ path: p, message: `"${item.filename}" is unreadable/corrupt and cannot be used` });
      return null;
    }
    if (!kinds.includes(item.kind)) {
      errors.push({ path: p, message: `"${item.filename}" is ${item.kind}; expected ${kinds.join(" or ")}` });
      return null;
    }
    return item;
  };

  const fixRange = (p: string, obj: { in_s: number; out_s: number }, item: InventoryItem) => {
    if (item.kind === "image") {
      if (obj.in_s !== 0) {
        repairs.push({ path: p, message: `image in_s ${obj.in_s} reset to 0` });
        obj.out_s = obj.out_s - obj.in_s;
        obj.in_s = 0;
      }
      if (obj.out_s <= 0) errors.push({ path: p, message: "image display duration must be positive" });
      return;
    }
    const dur = item.durationS ?? 0;
    if (obj.in_s < 0) {
      if (obj.in_s > -0.5 && repair) {
        repairs.push({ path: `${p}.in_s`, message: `negative in_s ${obj.in_s} clamped to 0` });
        obj.in_s = 0;
      } else errors.push({ path: `${p}.in_s`, message: `in_s ${obj.in_s} is negative` });
    }
    if (dur > 0 && obj.out_s > dur + EPS) {
      if (obj.out_s - dur <= 1.0 && repair) {
        repairs.push({ path: `${p}.out_s`, message: `out_s ${obj.out_s} exceeded ${item.filename} duration ${dur}; clamped` });
        obj.out_s = r3(dur);
      } else errors.push({ path: `${p}.out_s`, message: `out_s ${obj.out_s} is beyond the end of ${item.filename} (${dur}s)` });
    }
    if (obj.out_s - obj.in_s <= EPS) errors.push({ path: p, message: `invalid range ${obj.in_s}→${obj.out_s} (zero or negative duration)` });
    else if (obj.out_s - obj.in_s < 0.25) errors.push({ path: p, message: `range ${obj.in_s}→${obj.out_s} is shorter than 0.25s` });
  };

  let timeline = 0;
  let clipCount = 0;
  const seenIds = new Set<string>();
  edl.sections.forEach((section, si) => {
    section.id = section.id && !seenIds.has(section.id) ? section.id : `s${si + 1}`;
    seenIds.add(section.id);
    section.clips.forEach((clip, ci) => {
      const p = `sections.${si}.clips.${ci}`;
      clip.id = clip.id && !seenIds.has(clip.id) ? clip.id : `${section.id}c${ci + 1}`;
      seenIds.add(clip.id);
      clipCount++;
      const item = fixFile(`${p}.source_file`, clip.source_file, ["video", "image"], (n) => (clip.source_file = n));
      if (!item) return;
      fixRange(p, clip, item);
      const clipDur = (clip.out_s - clip.in_s) / clip.speed;
      if (clipDur <= 0) return;
      if (item.kind === "image" && clip.use_audio) clip.use_audio = false;
      if (clip.use_audio && !item.hasAudio && item.kind === "video") {
        clip.use_audio = false;
        repairs.push({ path: `${p}.use_audio`, message: `${item.filename} has no audio; use_audio set to false` });
      }
      if (clip.audio_offset !== "none" && clip.audio_offset.seconds >= clipDur * 0.8) {
        errors.push({ path: `${p}.audio_offset`, message: `${clip.audio_offset.type} of ${clip.audio_offset.seconds}s is too long for a ${clipDur.toFixed(2)}s clip` });
      }
      if (si === 0 && ci === 0 && clip.transition_in !== "hard_cut") {
        repairs.push({ path: `${p}.transition_in`, message: "first clip cannot have an incoming transition; set to hard_cut" });
        clip.transition_in = "hard_cut";
      }
      if (clip.keyframe_zoom && Math.abs(clip.keyframe_zoom.end_scale - clip.keyframe_zoom.start_scale) > 0.35) {
        warnings.push({ path: `${p}.keyframe_zoom`, message: "zoom delta > 35% is aggressive; consider a subtler punch-in" });
      }
      // captions (source time within clip range)
      const keptCaps: typeof clip.captions = [];
      let lastEnd = -Infinity;
      for (const [ki, cap] of [...clip.captions].sort((a, b) => a.start_s - b.start_s).entries()) {
        const cp = `${p}.captions.${ki}`;
        if (cap.end_s <= cap.start_s) {
          if (repair) {
            repairs.push({ path: cp, message: `malformed caption "${cap.text}" (end ≤ start) removed` });
            continue;
          }
          errors.push({ path: cp, message: "caption end_s must be after start_s" });
          continue;
        }
        if (cap.start_s < clip.in_s - 0.25 || cap.end_s > clip.out_s + 0.25) {
          if (repair && cap.end_s > clip.in_s && cap.start_s < clip.out_s) {
            cap.start_s = Math.max(cap.start_s, clip.in_s);
            cap.end_s = Math.min(cap.end_s, clip.out_s);
            repairs.push({ path: cp, message: `caption clamped into clip range` });
          } else if (repair) {
            repairs.push({ path: cp, message: `caption "${cap.text}" outside clip range removed` });
            continue;
          } else {
            errors.push({ path: cp, message: "caption lies outside the clip's source range" });
            continue;
          }
        }
        cap.start_s = Math.max(cap.start_s, clip.in_s);
        cap.end_s = Math.min(cap.end_s, clip.out_s);
        if (cap.start_s < lastEnd) {
          cap.start_s = lastEnd;
          if (cap.end_s - cap.start_s < 0.15) {
            repairs.push({ path: cp, message: "overlapping caption removed" });
            continue;
          }
          repairs.push({ path: cp, message: "overlapping caption trimmed" });
        }
        lastEnd = cap.end_s;
        keptCaps.push(cap);
      }
      clip.captions = keptCaps;
      // sfx
      clip.sfx.forEach((s, ki) => {
        const sp = `${p}.sfx.${ki}`;
        const sItem = fixFile(`${sp}.source_file`, s.source_file, ["audio"], (n) => (s.source_file = n));
        if (!sItem) return;
        if (sItem.durationS && s.in_s + s.duration_s > sItem.durationS + EPS) {
          const nd = r3(sItem.durationS - s.in_s);
          if (nd > 0.05 && repair) {
            repairs.push({ path: sp, message: `SFX duration trimmed to ${nd}s` });
            s.duration_s = nd;
          } else errors.push({ path: sp, message: "SFX in_s beyond audio file length" });
        }
        if (s.at_s > clipDur) errors.push({ path: `${sp}.at_s`, message: `SFX at_s ${s.at_s} is after the clip ends (${clipDur.toFixed(2)}s)` });
      });
      // broll overlays
      const keptB: typeof clip.broll = [];
      let bEnd = -Infinity;
      for (const [bi, b] of [...clip.broll].sort((a, b2) => a.at_s - b2.at_s).entries()) {
        const bp = `${p}.broll.${bi}`;
        const bItem = fixFile(`${bp}.source_file`, b.source_file, ["video", "image"], (n) => (b.source_file = n));
        if (!bItem) continue;
        fixRange(bp, b, bItem);
        const len = b.out_s - b.in_s;
        if (len <= 0) continue;
        if (b.at_s >= clipDur - 0.2) {
          errors.push({ path: `${bp}.at_s`, message: `B-roll starts at ${b.at_s}s but the clip is only ${clipDur.toFixed(2)}s` });
          continue;
        }
        if (b.at_s + len > clipDur + EPS) {
          b.out_s = r3(b.in_s + (clipDur - b.at_s));
          repairs.push({ path: bp, message: "B-roll trimmed to fit inside its parent clip" });
        }
        if (b.at_s < bEnd - EPS) {
          errors.push({ path: bp, message: "B-roll overlaps another B-roll on the same clip (impossible on one overlay track)" });
          continue;
        }
        bEnd = b.at_s + (b.out_s - b.in_s);
        keptB.push(b);
      }
      clip.broll = keptB;
      timeline += clipDur;
    });
  });

  if (edl.music.enabled && edl.music.source_file) {
    const m = fixFile("music.source_file", edl.music.source_file, ["audio"], (n) => (edl.music.source_file = n));
    if (m && m.durationS && edl.music.in_s >= m.durationS) errors.push({ path: "music.in_s", message: "music in_s is beyond the end of the music file" });
    if (m && m.durationS && m.durationS - edl.music.in_s < timeline - 0.5) warnings.push({ path: "music", message: `music (${m.durationS.toFixed(1)}s) is shorter than the edit (${timeline.toFixed(1)}s); it will end early` });
  } else if (edl.music.enabled && !edl.music.source_file) {
    warnings.push({ path: "music", message: "no music file selected — add an audio file to the project to score the edit" });
  }
  const target = edl.project.target_duration_s;
  if (timeline > 0 && Math.abs(timeline - target) / target > 0.25) {
    warnings.push({ path: "project.target_duration_s", message: `edit runs ${timeline.toFixed(1)}s vs target ${target}s` });
  }
  if (clipCount === 0) errors.push({ path: "sections", message: "EDL contains no clips" });
  return { ok: errors.length === 0, errors, warnings, repairs, edl, stats: { clipCount, timelineDurationS: r3(timeline) } };
}

import type { Edl, EdlClip } from "../../shared/schemas/edl";
import type { InventoryItem } from "./validate";

export type CompileOptions = {
  width: number;
  height: number;
  fps: number;
  captionFont?: string;
  captionSize?: number;
  emphasisColor?: string; // #RRGGBB
  dialogueGain?: number;
  sfxGain?: number;
  duckLevel?: number; // absolute music volume during speech
  musicDucking?: boolean;
};

type Seg = Record<string, unknown> & { tl_start: number; tl_dur: number };
export type TimelineItem = { track: string; start: number; dur: number; label: string; ref?: string; kind?: string };
export type BuildPlan = {
  width: number;
  height: number;
  fps: number;
  total_duration: number;
  video: Seg[];
  overlay: Seg[];
  dialogue: Seg[];
  music: Seg[];
  sfx: Seg[];
  ambience: Seg[];
  captions: Seg[];
  look: { filter: string | null; intensity: number; vignette: number | null; grain: number | null };
};

const r3 = (n: number) => Math.round(n * 1000) / 1000;
const hexToRgb = (hex: string): [number, number, number] => {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || "");
  if (!m) return [1, 0.82, 0.25];
  const n = parseInt(m[1], 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255].map((x) => Math.round(x * 1000) / 1000) as [number, number, number];
};
const clean = (w: string) => w.toLowerCase().replace(/[^\p{L}\p{N}']/gu, "");

type Word = { word: string; start: number; end: number };

/** Caption engine: groups verbatim transcript words into readable beats. */
export function captionBeats(words: Word[], maxWords: number): Word[][] {
  const beats: Word[][] = [];
  let cur: Word[] = [];
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    const prev = cur[cur.length - 1];
    const gap = prev ? w.start - prev.end : 0;
    if (cur.length && (cur.length >= maxWords || gap > 0.5)) {
      beats.push(cur);
      cur = [];
    }
    cur.push(w);
    const endsSentence = /[.!?…]$/.test(w.word);
    const softBreak = /[,;:]$/.test(w.word) && cur.length >= Math.max(2, Math.ceil(maxWords * 0.6));
    if (endsSentence || softBreak) {
      beats.push(cur);
      cur = [];
    }
  }
  if (cur.length) beats.push(cur);
  return beats;
}

function captionY(position: string, width: number, height: number) {
  const vertical = height > width;
  if (position === "top") return vertical ? 0.62 : 0.72;
  if (position === "center") return 0;
  return vertical ? -0.58 : -0.74; // safe margin above platform UI / lower third
}

export function clipTimeline(edl: Edl) {
  const out: { clip: EdlClip; sectionRole: string; sectionId: string; start: number; dur: number }[] = [];
  let t = 0;
  for (const s of edl.sections) {
    for (const c of s.clips) {
      const dur = r3((c.out_s - c.in_s) / c.speed);
      out.push({ clip: c, sectionRole: s.role, sectionId: s.id || "", start: r3(t), dur });
      t += dur;
    }
  }
  return { clips: out, total: r3(t) };
}

export function compileEdl(edl: Edl, inventory: InventoryItem[], opt: CompileOptions): { plan: BuildPlan; timeline: TimelineItem[]; notes: string[] } {
  const inv = new Map(inventory.map((i) => [i.filename, i]));
  const notes: string[] = [];
  const { clips, total } = clipTimeline(edl);
  const plan: BuildPlan = { width: opt.width, height: opt.height, fps: opt.fps, total_duration: total, video: [], overlay: [], dialogue: [], music: [], sfx: [], ambience: [], captions: [], look: { filter: null, intensity: 45, vignette: null, grain: null } };
  const timeline: TimelineItem[] = [];
  const canvasAspect = opt.width / opt.height;

  // Exposure normalisation: pull every main clip toward the median measured luma.
  const lumas = clips.map((c) => inv.get(c.clip.source_file)?.luma).filter((x): x is number => typeof x === "number").sort((a, b) => a - b);
  const targetLuma = lumas.length ? lumas[Math.floor(lumas.length / 2)] : null;

  const speech: [number, number][] = [];
  clips.forEach(({ clip, start, dur, sectionRole }, idx) => {
    const item = inv.get(clip.source_file)!;
    const next = clips[idx + 1];
    const srcAspect = item.width && item.height ? item.width / item.height : canvasAspect;
    let color: Record<string, number> | null = null;
    if (edl.look.normalize && targetLuma !== null && typeof item.luma === "number") {
      const b = Math.max(-0.2, Math.min(0.2, (targetLuma - item.luma) * 0.8));
      if (Math.abs(b) > 0.01) color = { brightness: r3(b) };
    }
    plan.video.push({
      path: item.path,
      kind: item.kind,
      label: clip.source_file,
      src_in: clip.in_s,
      dur_src: r3(clip.out_s - clip.in_s),
      tl_start: start,
      tl_dur: dur,
      speed: clip.speed,
      mute: true, // dialogue lives on dedicated audio tracks
      zoom: clip.keyframe_zoom ? { start: clip.keyframe_zoom.start_scale, end: clip.keyframe_zoom.end_scale } : null,
      position: clip.position,
      color,
      background_fill: Math.abs(srcAspect - canvasAspect) > 0.05,
      transition_out: next && next.clip.transition_in !== "hard_cut" ? { type: next.clip.transition_in, duration: Math.min(0.5, next.dur / 3, dur / 3) } : null,
    });
    timeline.push({ track: "V1", start, dur, label: clip.source_file, ref: clip.id, kind: sectionRole });

    // Dialogue with J/L cuts on alternating lanes
    if (clip.use_audio && item.hasAudio) {
      let aStart = start, aSrcIn = clip.in_s, aSrcDur = clip.out_s - clip.in_s;
      if (clip.audio_offset !== "none" && clip.audio_offset.type === "j_cut") {
        const lead = Math.min(clip.audio_offset.seconds, clip.in_s, start);
        aStart -= lead;
        aSrcIn -= lead * clip.speed;
        aSrcDur += lead * clip.speed;
        const prevDia = plan.dialogue[plan.dialogue.length - 1];
        if (prevDia && prevDia.tl_start + prevDia.tl_dur > aStart) {
          const cut = prevDia.tl_start + prevDia.tl_dur - aStart;
          prevDia.tl_dur = r3(prevDia.tl_dur - cut);
          prevDia.dur_src = r3((prevDia.dur_src as number) - cut * ((prevDia.speed as number) || 1));
        }
      }
      const prevClip = clips[idx - 1]?.clip;
      if (prevClip && prevClip.audio_offset !== "none" && prevClip.audio_offset.type === "l_cut") {
        const tail = Math.min(prevClip.audio_offset.seconds, dur * 0.8);
        aStart += tail;
        aSrcIn += tail * clip.speed;
        aSrcDur -= tail * clip.speed;
      }
      if (clip.audio_offset !== "none" && clip.audio_offset.type === "l_cut" && item.durationS) {
        const avail = item.durationS - clip.out_s;
        aSrcDur += Math.max(0, Math.min(clip.audio_offset.seconds * clip.speed, avail));
      }
      const aDur = r3(aSrcDur / clip.speed);
      if (aDur > 0.05) {
        plan.dialogue.push({ source_path: item.path, label: clip.source_file, src_in: r3(aSrcIn), dur_src: r3(aSrcDur), tl_start: r3(aStart), tl_dur: aDur, speed: clip.speed, volume: opt.dialogueGain ?? 1, fade_in: 0.02, fade_out: 0.04, lane: plan.dialogue.length % 2 });
        timeline.push({ track: plan.dialogue.length % 2 ? "A1" : "A2", start: r3(aStart), dur: aDur, label: `🗣 ${clip.source_file}` });
        const words = (item.words || []).filter((w) => w.end > aSrcIn && w.start < aSrcIn + aSrcDur);
        if (words.length) for (const w of words) speech.push([aStart + (Math.max(w.start, aSrcIn) - aSrcIn) / clip.speed, aStart + (Math.min(w.end, aSrcIn + aSrcDur) - aSrcIn) / clip.speed]);
        else speech.push([aStart, aStart + aDur]);
      }
    }

    // Captions
    if (edl.captions.enabled) {
      const emphasisSet = new Set(edl.captions.emphasis_words.map(clean));
      let beats: { words: Word[]; emphasis: Set<string> }[] = [];
      if (clip.captions.length) {
        beats = clip.captions.map((c) => {
          const ws = c.text.split(/\s+/).filter(Boolean);
          const step = (c.end_s - c.start_s) / ws.length;
          return { words: ws.map((w, i) => ({ word: w, start: c.start_s + i * step, end: c.start_s + (i + 1) * step })), emphasis: new Set([...emphasisSet, ...c.emphasis.map(clean)]) };
        });
      } else if (edl.captions.auto_from_transcript && clip.use_audio) {
        const words = (item.words || []).filter((w) => w.start >= clip.in_s - 0.05 && w.end <= clip.out_s + 0.05);
        beats = captionBeats(words, edl.captions.max_words).map((ws) => ({ words: ws, emphasis: emphasisSet }));
      }
      const toTl = (s: number) => Math.max(start, Math.min(start + dur, start + (s - clip.in_s) / clip.speed));
      const baseSize = opt.captionSize ?? 9;
      const emph = hexToRgb(opt.emphasisColor || "#FFD23F");
      const y = captionY(edl.captions.position, opt.width, opt.height);
      const anim = edl.captions.animation === "none" ? null : edl.captions.animation;
      const push = (text: string, s: number, e: number, isEmph: boolean) => {
        const last = plan.captions[plan.captions.length - 1];
        let st = r3(s);
        if (last && st < last.tl_start + last.tl_dur) st = r3(last.tl_start + last.tl_dur);
        const clipEnd = start + dur;
        const d = r3(Math.min(Math.max(e, st + 0.2), clipEnd, total) - st);
        if (d < 0.1) return;
        plan.captions.push({ text, tl_start: st, tl_dur: d, size: isEmph && edl.captions.mode === "word" ? baseSize * 1.2 : baseSize, bold: true, color: isEmph ? emph : [1, 1, 1], y, font: opt.captionFont || null, intro: anim, outro: edl.captions.mode === "phrase" && anim ? "fade" : null, border: true, lane: 0 });
      };
      for (const beat of beats) {
        const isE = (w: Word) => beat.emphasis.has(clean(w.word));
        const fmt = (w: Word) => (isE(w) ? w.word.toUpperCase() : w.word);
        if (edl.captions.mode === "word") {
          beat.words.forEach((w, i) => push(fmt(w), toTl(w.start), toTl(beat.words[i + 1]?.start ?? w.end), isE(w)));
        } else if (edl.captions.mode === "karaoke") {
          // progressive reveal: each spoken word appends to the phrase; the newest emphasised word colours the beat
          beat.words.forEach((w, i) => push(beat.words.slice(0, i + 1).map(fmt).join(" "), toTl(w.start), toTl(beat.words[i + 1]?.start ?? w.end), isE(w)));
        } else {
          const first = beat.words[0], last = beat.words[beat.words.length - 1];
          push(beat.words.map(fmt).join(" "), toTl(first.start), toTl(last.end) + 0.08, false);
        }
      }
    }

    // SFX
    for (const s of clip.sfx) {
      if (!s.enabled) continue;
      const sItem = inv.get(s.source_file)!;
      const st = r3(start + s.at_s);
      const d = r3(Math.min(s.duration_s, total - st));
      if (d <= 0.05) continue;
      plan.sfx.push({ path: sItem.path, label: s.source_file, src_in: s.in_s, dur_src: d, tl_start: st, tl_dur: d, volume: r3(s.volume * (opt.sfxGain ?? 0.7)) });
      timeline.push({ track: "SFX", start: st, dur: d, label: s.source_file });
    }
    // B-roll overlays
    for (const b of clip.broll) {
      const bItem = inv.get(b.source_file)!;
      const st = r3(start + b.at_s);
      const d = r3(b.out_s - b.in_s);
      plan.overlay.push({ path: bItem.path, kind: bItem.kind, label: b.source_file, src_in: b.in_s, dur_src: d, tl_start: st, tl_dur: d, speed: 1, mute: true, zoom: b.keyframe_zoom ? { start: b.keyframe_zoom.start_scale, end: b.keyframe_zoom.end_scale } : { start: 1.0, end: 1.04 }, position: null, color: null, background_fill: false, transition_out: null });
      timeline.push({ track: "V2", start: st, dur: d, label: b.source_file, ref: clip.id });
    }
  });

  // Music with dialogue ducking
  if (edl.music.enabled && edl.music.source_file && inv.get(edl.music.source_file)) {
    const m = inv.get(edl.music.source_file)!;
    const avail = (m.durationS ?? total) - edl.music.in_s;
    const d = r3(Math.min(total, avail));
    const base = edl.music.volume;
    const duck: { t: number; v: number }[] = [];
    if (edl.music.duck_under_dialogue && opt.musicDucking !== false && speech.length) {
      const low = Math.min(base, opt.duckLevel ?? 0.18);
      const merged: [number, number][] = [];
      for (const iv of speech.sort((a, b) => a[0] - b[0])) {
        const lastIv = merged[merged.length - 1];
        if (lastIv && iv[0] - lastIv[1] < 0.6) lastIv[1] = Math.max(lastIv[1], iv[1]);
        else merged.push([iv[0], iv[1]]);
      }
      for (const [a, b] of merged) {
        const pre = Math.max(0, a - 0.2);
        if (!duck.length || pre > duck[duck.length - 1].t) duck.push({ t: r3(pre), v: base });
        duck.push({ t: r3(Math.max(pre + 0.01, a)), v: low });
        duck.push({ t: r3(Math.min(d, b)), v: low });
        if (b + 0.35 < d) duck.push({ t: r3(b + 0.35), v: base });
      }
    }
    plan.music.push({ path: m.path, label: m.filename, src_in: edl.music.in_s, dur_src: d, tl_start: 0, tl_dur: d, volume: base, fade_in: edl.music.fade_in_s, fade_out: edl.music.fade_out_s, duck: duck.filter((k) => k.t <= d) });
    timeline.push({ track: "Music", start: 0, dur: d, label: `♪ ${m.filename}` });
  } else if (edl.music_mood) {
    notes.push(`Music mood "${edl.music_mood}" recorded, but no music file is assigned — add an audio file to score the edit.`);
  }

  plan.look = {
    filter: edl.color_grade_mood === "neutral_clean" ? null : edl.color_grade_mood,
    intensity: edl.look.intensity,
    vignette: edl.look.vignette > 0 ? edl.look.vignette : null,
    grain: edl.look.grain > 0 ? edl.look.grain : null,
  };
  for (const c of plan.captions) timeline.push({ track: "Text", start: c.tl_start, dur: c.tl_dur, label: String(c.text) });
  if (edl.look.normalize && targetLuma === null) notes.push("Exposure normalisation skipped: clips have not been analysed yet.");
  notes.push("White-balance temperature is not exposed via pyJianYingDraft keyframes; normalisation adjusts exposure only.");
  return { plan, timeline, notes };
}

"use client";
import { Diagnostics } from "@/features/settings/Diagnostics";

export default function DiagnosticsPage() {
  return (
    <div className="mx-auto max-w-[980px] px-8 py-7">
      <div className="label">System</div>
      <h1 className="mb-1 mt-1 text-[22px] font-semibold tracking-tight">Diagnostics</h1>
      <p className="mb-5 text-ink-400">Checks Python, engine dependencies, FFmpeg, Whisper, the CapCut draft directory, permissions, disk space, Gemini configuration and project integrity.</p>
      <Diagnostics autoRun />
    </div>
  );
}

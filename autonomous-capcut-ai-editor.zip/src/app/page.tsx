"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { api, setActiveProject, usePoll } from "@/components/hooks";
import { Badge, Button, Empty, ErrorBox, ago, fileUrl, fmtTime } from "@/components/ui";
import type { Project } from "@/shared/types";

type Row = Project & { clipCount: number; footageDurationS: number; thumbnail: string | null; lastVersion: number | null; lastGeneratedAt: string | null; activeJobs: number };

const STATUS: Record<string, { label: string; tone: "neutral" | "ok" | "warn" | "accent" | "signal" }> = {
  new: { label: "Empty", tone: "neutral" },
  ingested: { label: "Footage ready", tone: "signal" },
  planned: { label: "Plan ready", tone: "accent" },
  generated: { label: "Draft generated", tone: "ok" },
};

export default function Dashboard() {
  const router = useRouter();
  const { data, error, reload } = usePoll<{ projects: Row[] }>("/api/projects", 5000);
  const { data: settings } = usePoll<{ settings: { onboarded: boolean } }>("/api/settings", 0);
  const [importPath, setImportPath] = useState("");
  const [showImport, setShowImport] = useState(false);
  const [actionErr, setActionErr] = useState<{ code?: string; message: string } | null>(null);

  const act = async (fn: () => Promise<unknown>) => {
    setActionErr(null);
    try {
      await fn();
      await reload();
    } catch (e) {
      setActionErr(e as { message: string });
    }
  };
  const projects = data?.projects || [];

  return (
    <div className="mx-auto max-w-[1400px] px-8 py-7">
      <div className="mb-6 flex items-end justify-between">
        <div>
          <div className="label">Workspace</div>
          <h1 className="mt-1 text-[22px] font-semibold tracking-tight">Projects</h1>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setShowImport(!showImport)}>Import Project</Button>
          <Button variant="primary" onClick={() => router.push("/projects/new")}>New Project</Button>
        </div>
      </div>

      {settings && !settings.settings.onboarded && (
        <div className="fade-up mb-6 flex items-center justify-between rounded-lg border border-accent/30 bg-accent/[0.06] px-5 py-4">
          <div>
            <div className="font-semibold text-ink-100">Welcome — let&apos;s verify your editing engine</div>
            <div className="mt-0.5 text-ink-300">Checks Python, FFmpeg, Whisper, pyJianYingDraft, your CapCut draft folder and Gemini before your first project.</div>
          </div>
          <Button variant="primary" onClick={() => router.push("/welcome")}>Start setup</Button>
        </div>
      )}

      {showImport && (
        <div className="fade-up mb-6 flex gap-2 rounded-lg border border-ink-700 bg-ink-900 p-4">
          <input className="field tc" placeholder="/path/to/project-folder (contains capcut-ai-project.json)" value={importPath} onChange={(e) => setImportPath(e.target.value)} />
          <Button variant="primary" onClick={() => act(async () => { const r = await api<{ project: Project }>("/api/projects", "POST", { action: "import", path: importPath }); setShowImport(false); router.push(`/projects/${r.project.id}/media`); })}>Import</Button>
        </div>
      )}
      <ErrorBox error={actionErr || (error ? { message: `Projects could not be loaded: ${error.message}`, code: error.code } : null)} />

      {data && projects.length === 0 && (
        <Empty title="No projects yet" action={<Button variant="primary" onClick={() => router.push("/projects/new")}>Create your first project</Button>}>
          Create a project, drop in raw footage, describe the style — Cutline analyses, transcribes, plans the edit with Gemini and builds a real CapCut draft.
        </Empty>
      )}

      <div className="grid grid-cols-[repeat(auto-fill,minmax(290px,1fr))] gap-4">
        {projects.map((p) => {
          const st = STATUS[p.status] || STATUS.new;
          return (
            <div key={p.id} className="group overflow-hidden rounded-lg border border-ink-700 bg-ink-900 transition-colors hover:border-ink-500">
              <Link href={`/projects/${p.id}/media`} onClick={() => setActiveProject(p.id)} className="block">
                <div className="relative aspect-video bg-ink-850">
                  {p.thumbnail ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={fileUrl(p.thumbnail)} alt="" className="h-full w-full object-cover opacity-90 transition-opacity group-hover:opacity-100" />
                  ) : (
                    <div className="grid h-full place-items-center text-ink-500">No footage</div>
                  )}
                  <div className="absolute left-2 top-2 flex gap-1.5">
                    <Badge tone={st.tone}>{st.label}</Badge>
                    {p.activeJobs > 0 && <Badge tone="accent">● {p.activeJobs} job(s)</Badge>}
                  </div>
                  <div className="tc absolute bottom-2 right-2 rounded bg-black/70 px-1.5 py-0.5 text-[11px]">{p.aspectRatio} · {p.width}×{p.height}</div>
                </div>
              </Link>
              <div className="p-3.5">
                <div className="flex items-start justify-between gap-2">
                  <Link href={`/projects/${p.id}/media`} onClick={() => setActiveProject(p.id)} className="truncate text-[14px] font-semibold hover:text-accent">{p.name}</Link>
                  <span className="shrink-0 text-[11px] text-ink-400">{ago(p.updatedAt)}</span>
                </div>
                <div className="mt-2.5 grid grid-cols-3 gap-2 text-[11.5px]">
                  <div><div className="label">Clips</div><div className="tc mt-0.5 text-ink-100">{p.clipCount}</div></div>
                  <div><div className="label">Footage</div><div className="tc mt-0.5 text-ink-100">{fmtTime(p.footageDurationS)}</div></div>
                  <div><div className="label">Version</div><div className="tc mt-0.5 text-ink-100">{p.lastVersion ? `v${String(p.lastVersion).padStart(3, "0")}` : "—"}</div></div>
                </div>
                <div className="mt-3 flex gap-1 border-t border-ink-700 pt-2.5 opacity-70 transition-opacity group-hover:opacity-100">
                  <Button size="sm" variant="ghost" onClick={() => { setActiveProject(p.id); router.push(`/projects/${p.id}/media`); }}>Open</Button>
                  <Button size="sm" variant="ghost" onClick={() => act(() => api(`/api/projects/${p.id}`, "POST", { action: "duplicate" }))}>Duplicate</Button>
                  <Button size="sm" variant="ghost" className="ml-auto text-bad hover:text-bad" onClick={() => { if (confirm(`Delete “${p.name}”? Source footage and generated CapCut drafts are not deleted.`)) void act(() => api(`/api/projects/${p.id}?removeFiles=${confirm("Also delete the app workspace folder (cache, logs, uploaded copies)?") ? 1 : 0}`, "DELETE")); }}>Delete</Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/components/hooks";
import { Button, ErrorBox, Field, cx } from "@/components/ui";
import { Diagnostics } from "@/features/settings/Diagnostics";

export default function Welcome() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [key, setKey] = useState("");
  const [draftDir, setDraftDir] = useState("");
  const [err, setErr] = useState<{ message: string; code?: string } | null>(null);
  const [saved, setSaved] = useState("");
  const steps = ["Welcome", "Environment", "CapCut & Gemini", "First project"];
  const finish = async () => {
    await api("/api/settings", "PUT", { onboarded: true });
    router.push("/projects/new");
  };
  return (
    <div className="mx-auto max-w-[900px] px-8 py-10">
      <div className="mb-8 flex gap-2">
        {steps.map((s, i) => <div key={s} className={cx("flex-1 border-t-2 pt-2 text-[11.5px]", i <= step ? "border-accent text-ink-100" : "border-ink-700 text-ink-500")}>{i + 1}. {s}</div>)}
      </div>
      {step === 0 && (
        <div className="fade-up space-y-4">
          <h1 className="text-[28px] font-semibold tracking-tight">Raw footage in. A real CapCut draft out.</h1>
          <p className="max-w-2xl text-[14px] leading-relaxed text-ink-300">Cutline analyses your footage and transcribes it locally with Whisper. Gemini acts as the AI Director and writes a strict edit decision list, which is validated before a deterministic builder turns it into a CapCut draft with pyJianYingDraft. You review everything before it&apos;s built, and export in CapCut.</p>
          <p className="text-ink-400">Your footage stays on this machine. Only transcripts and metadata go to Gemini, and only when you ask it to plan an edit.</p>
          <Button variant="primary" size="lg" onClick={() => setStep(1)}>Check my environment →</Button>
        </div>
      )}
      {step === 1 && (
        <div className="fade-up space-y-4">
          <h2 className="text-[18px] font-semibold">Environment</h2>
          <Diagnostics autoRun />
          <div className="flex justify-end"><Button variant="primary" onClick={() => setStep(2)}>Continue →</Button></div>
        </div>
      )}
      {step === 2 && (
        <div className="fade-up space-y-5">
          <h2 className="text-[18px] font-semibold">CapCut draft folder & Gemini</h2>
          <Field label="CapCut draft folder" hint="In CapCut: Settings → Drafts → location. Windows usually: %LOCALAPPDATA%\CapCut\User Data\Projects\com.lveditor.draft">
            <input className="field tc text-[12px]" value={draftDir} onChange={(e) => setDraftDir(e.target.value)} placeholder="Leave empty to keep the detected/default folder" />
          </Field>
          <Field label="Gemini API key" hint="Encrypted with a machine-local key, never logged and never sent to the browser. Get one at aistudio.google.com.">
            <input className="field tc" type="password" autoComplete="off" value={key} onChange={(e) => setKey(e.target.value)} placeholder="AIza…" />
          </Field>
          <ErrorBox error={err} />
          {saved && <div className="text-[12px] text-ok">{saved}</div>}
          <div className="flex justify-between">
            <Button variant="ghost" onClick={() => setStep(3)}>Skip</Button>
            <Button variant="primary" onClick={async () => {
              setErr(null);
              try {
                if (draftDir.trim()) await api("/api/settings", "PUT", { storage: { draftDir: draftDir.trim() } });
                if (key.trim()) {
                  await api("/api/settings", "POST", { action: "set_key", key: key.trim() });
                  setKey("");
                  await api("/api/settings", "POST", { action: "test_gemini" });
                  setSaved("Gemini key saved and verified.");
                }
                setStep(3);
              } catch (e) {
                setErr(e as { message: string });
              }
            }}>Save & verify →</Button>
          </div>
        </div>
      )}
      {step === 3 && (
        <div className="fade-up space-y-4">
          <h2 className="text-[18px] font-semibold">You&apos;re set up</h2>
          <p className="text-ink-300">Create your first project, drop in footage, and describe the edit you want.</p>
          <Button variant="primary" size="lg" onClick={finish}>Create first project →</Button>
        </div>
      )}
    </div>
  );
}

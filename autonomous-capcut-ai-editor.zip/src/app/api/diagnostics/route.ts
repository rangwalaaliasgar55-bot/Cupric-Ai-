import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { sql, count } from "drizzle-orm";
import { db } from "@/db";
import { media, projects } from "@/db/schema";
import { fail, ok } from "@/lib/api";
import { runEngine, EngineFailure } from "@/lib/engine";
import { getSettings } from "@/lib/settings";
import { secretHint } from "@/lib/secrets";

export const dynamic = "force-dynamic";
export const maxDuration = 600;

type Check = { name: string; ok: boolean; detail: string; fix: string; level: string };

export async function POST(req: Request) {
  const b = (await req.json().catch(() => ({}))) as { action?: string };
  const s = await getSettings();
  if (b.action === "install_engine") {
    // Fixed, reviewed command: installs the engine's pinned requirements. Never AI-generated.
    const reqFile = path.join(process.cwd(), "backend", "requirements.txt");
    const py = process.env.PYTHON_BIN || (process.platform === "win32" ? "python" : "python3");
    const out = await new Promise<{ code: number; log: string }>((resolve) => {
      const args = ["-m", "pip", "install", "--user", "-r", reqFile];
      if (process.platform !== "win32") args.push("--break-system-packages");
      const c = spawn(py, args, { stdio: ["ignore", "pipe", "pipe"] });
      let log = "";
      c.stdout.on("data", (d) => (log += d));
      c.stderr.on("data", (d) => (log += d));
      c.on("error", (e) => resolve({ code: -1, log: `Could not start ${py}: ${e.message}` }));
      c.on("close", (code) => resolve({ code: code ?? -1, log }));
    });
    if (out.code !== 0) return fail("INSTALL_FAILED", "Installing engine dependencies failed. See log.", 500, { log: out.log.slice(-4000) });
    return ok({ installed: true, log: out.log.slice(-2000) });
  }
  const checks: Check[] = [];
  let engine: { checks: Check[]; platform: string; detected_capcut_dirs: string[] } | null = null;
  try {
    const res = await runEngine<{ checks: Check[]; platform: string; detected_capcut_dirs: string[] }>("diagnostics", { draft_dir: s.storage.draftDir, project_dir: s.storage.projectDir, whisper_model: s.transcription.model, model_dir: path.join(s.storage.cacheDir, "whisper-models") });
    engine = res;
    checks.push(...res.checks);
  } catch (e) {
    const err = e as EngineFailure;
    checks.push({ name: "Python engine", ok: false, detail: err.message, fix: "Install Python 3.9+ and click “Install engine dependencies”.", level: "error" });
  }
  try {
    await db.execute(sql`select 1`);
    const [{ n }] = await db.select({ n: count() }).from(projects);
    checks.push({ name: "Local database", ok: true, detail: `connected — ${n} project(s)`, fix: "", level: "ok" });
  } catch (e) {
    checks.push({ name: "Local database", ok: false, detail: (e as Error).message, fix: "Check DATABASE_URL", level: "error" });
  }
  const g = await secretHint("gemini_api_key");
  checks.push({ name: "Gemini API", ok: g.configured, detail: g.configured ? `key configured (${g.hint}) · model ${s.ai.model}` : "no API key configured", fix: "Settings → AI → add your Gemini API key", level: g.configured ? "ok" : "warning" });
  // Project integrity: referenced media still on disk
  const rows = await db.select({ path: media.path, filename: media.filename }).from(media);
  const missing = rows.filter((r) => !fs.existsSync(r.path));
  checks.push({ name: "Project integrity", ok: missing.length === 0, detail: missing.length ? `${missing.length} media file(s) missing: ${missing.slice(0, 3).map((m) => m.filename).join(", ")}` : `${rows.length} media reference(s) verified`, fix: "Use “Locate file” in the Media browser", level: missing.length ? "warning" : "ok" });
  return ok({ checks, platform: engine?.platform ?? process.platform, detectedCapcutDirs: engine?.detected_capcut_dirs ?? [], ranAt: new Date().toISOString() });
}

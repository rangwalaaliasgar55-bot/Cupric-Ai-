import fs from "node:fs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { media } from "@/db/schema";
import { fail, ok, slimMedia } from "@/lib/api";
import { enqueue } from "@/lib/jobs";
import "@/lib/pipeline";

export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ id: string }> };

export async function GET(_r: Request, { params }: Ctx) {
  const { id } = await params;
  const [m] = await db.select().from(media).where(eq(media.id, id));
  if (!m) return fail("NOT_FOUND", "Media not found.", 404);
  return ok({ media: slimMedia(m) });
}

export async function DELETE(_r: Request, { params }: Ctx) {
  const { id } = await params;
  await db.delete(media).where(eq(media.id, id));
  return ok({ deleted: true });
}

type Word = { word: string; start: number; end: number; confidence?: number };
type Seg = { id: number; start: number; end: number; text: string; words: Word[]; speaker: string | null };

const ts = (s: string) => {
  const m = /(?:(\d+):)?(\d+):(\d+)[.,](\d+)/.exec(s.trim());
  if (!m) return NaN;
  return (Number(m[1] || 0) * 3600) + Number(m[2]) * 60 + Number(m[3]) + Number(`0.${m[4]}`);
};

/** Parse SRT / VTT / JSON (word or segment lists). Word timings are interpolated for cue-based formats and flagged. */
function parseTranscript(text: string, format: string): { segments: Seg[]; interpolated: boolean } {
  const trimmed = text.trim();
  if (format === "json" || trimmed.startsWith("{") || trimmed.startsWith("[")) {
    const data = JSON.parse(trimmed);
    const segs = Array.isArray(data) ? data : data.segments;
    if (Array.isArray(segs) && segs.length && "word" in segs[0]) {
      const words = segs as Word[];
      const out: Seg[] = [];
      let cur: Word[] = [];
      for (const w of words) {
        cur.push(w);
        if (/[.!?]$/.test(w.word) || cur.length >= 14) (out.push({ id: out.length, start: cur[0].start, end: w.end, text: cur.map((x) => x.word).join(" "), words: cur, speaker: null }), (cur = []));
      }
      if (cur.length) out.push({ id: out.length, start: cur[0].start, end: cur[cur.length - 1].end, text: cur.map((x) => x.word).join(" "), words: cur, speaker: null });
      return { segments: out, interpolated: false };
    }
    if (!Array.isArray(segs)) throw new Error("JSON must be an array of words/segments or an object with a 'segments' array");
    return { segments: segs.map((s: Seg, i: number) => ({ id: i, start: Number(s.start), end: Number(s.end), text: String(s.text), words: s.words || [], speaker: s.speaker ?? null })), interpolated: segs.some((s: Seg) => !s.words?.length) };
  }
  const blocks = trimmed.replace(/\r/g, "").split(/\n\s*\n/);
  const segments: Seg[] = [];
  for (const b of blocks) {
    const lines = b.split("\n").filter((l) => l && l !== "WEBVTT");
    const tl = lines.findIndex((l) => l.includes("-->"));
    if (tl < 0) continue;
    const [a, z] = lines[tl].split("-->");
    const start = ts(a), end = ts(z);
    const body = lines.slice(tl + 1).join(" ").replace(/<[^>]+>/g, "").trim();
    if (!body || !isFinite(start) || !isFinite(end) || end <= start) continue;
    const ws = body.split(/\s+/);
    const step = (end - start) / ws.length;
    segments.push({ id: segments.length, start, end, text: body, speaker: null, words: ws.map((w, i) => ({ word: w, start: +(start + i * step).toFixed(3), end: +(start + (i + 1) * step).toFixed(3), confidence: 0 })) });
  }
  if (!segments.length) throw new Error("No timed cues were found. Supported formats: SRT, WebVTT, JSON.");
  return { segments, interpolated: true };
}

export async function POST(req: Request, { params }: Ctx) {
  const { id } = await params;
  const [m] = await db.select().from(media).where(eq(media.id, id));
  if (!m) return fail("NOT_FOUND", "Media not found.", 404);
  const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  switch (b.action) {
    case "reanalyze": {
      const job = await enqueue("analyze_media", `Re-analyze ${m.filename}`, { mediaId: id, force: true }, m.projectId);
      return ok({ job });
    }
    case "retranscribe": {
      if (!m.hasAudio) return fail("NO_AUDIO", `${m.filename} has no audio track to transcribe.`);
      const job = await enqueue("transcribe_media", `Transcribe ${m.filename}`, { mediaId: id, force: true, model: b.model || undefined }, m.projectId);
      return ok({ job });
    }
    case "locate": {
      const p = String(b.path || "").trim();
      if (!p || !fs.existsSync(p)) return fail("FILE_NOT_FOUND", `${p || "(empty path)"} does not exist.`);
      await db.update(media).set({ path: p, readable: true, analysisStatus: "queued" }).where(eq(media.id, id));
      const job = await enqueue("analyze_media", `Re-analyze ${m.filename}`, { mediaId: id, force: true }, m.projectId);
      return ok({ job });
    }
    case "import_transcript": {
      try {
        const { segments, interpolated } = parseTranscript(String(b.text || ""), String(b.format || "auto"));
        const text = segments.map((s) => s.text).join(" ");
        await db.update(media).set({ transcriptStatus: "done", transcriptError: null, transcriptKey: "manual", transcript: { segments, source: "manual", interpolated_word_timings: interpolated }, transcriptText: text }).where(eq(media.id, id));
        return ok({ segments: segments.length, interpolated });
      } catch (e) {
        return fail("TRANSCRIPT_PARSE_FAILED", `The transcript could not be imported: ${(e as Error).message}`);
      }
    }
    case "edit_segment": {
      const t = (m.transcript || {}) as { segments?: Seg[] };
      const segs = t.segments || [];
      const idx = Number(b.segmentId);
      const seg = segs[idx];
      if (!seg) return fail("NOT_FOUND", "Transcript segment not found.", 404);
      const newText = String(b.text || "").trim();
      const newWords = newText.split(/\s+/).filter(Boolean);
      // Keep real timings when the word count is unchanged (spelling fixes); otherwise re-distribute within the segment.
      if (newWords.length === seg.words.length) seg.words = seg.words.map((w, i) => ({ ...w, word: newWords[i] }));
      else {
        const step = (seg.end - seg.start) / Math.max(1, newWords.length);
        seg.words = newWords.map((w, i) => ({ word: w, start: +(seg.start + i * step).toFixed(3), end: +(seg.start + (i + 1) * step).toFixed(3), confidence: 0 }));
      }
      seg.text = newText;
      await db.update(media).set({ transcript: { ...t, segments: segs, edited: true }, transcriptText: segs.map((s) => s.text).join(" ") }).where(eq(media.id, id));
      return ok({ updated: true });
    }
    default:
      return fail("UNKNOWN_ACTION", `Unknown action ${String(b.action)}`);
  }
}

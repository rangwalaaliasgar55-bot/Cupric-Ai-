import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { db } from "@/db";
import { edls, media, projects } from "@/db/schema";
import { eq } from "drizzle-orm";
import { fail, listProjects, ok } from "@/lib/api";
import { getSettings } from "@/lib/settings";
import { enqueue } from "@/lib/jobs";
import { writeManifest } from "@/lib/pipeline";

export const dynamic = "force-dynamic";

export async function GET() {
  return ok({ projects: await listProjects() });
}

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "project";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const s = await getSettings();
  if (body.action === "import") {
    const dir = String(body.path || "").trim();
    const manifestPath = dir.endsWith(".json") ? dir : path.join(dir, "capcut-ai-project.json");
    if (!fs.existsSync(manifestPath)) return fail("MANIFEST_NOT_FOUND", `No capcut-ai-project.json found at ${manifestPath}.`, 404);
    let manifest: { project: Record<string, unknown>; media: { path: string }[]; current_edl: unknown };
    try {
      manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
    } catch (e) {
      return fail("MANIFEST_INVALID", `The project manifest could not be parsed: ${(e as Error).message}`);
    }
    const mp = manifest.project;
    const [p] = await db
      .insert(projects)
      .values({ name: `${mp.name} (imported)`, location: path.dirname(manifestPath), aspectRatio: String(mp.aspectRatio || "9:16"), width: Number(mp.width) || 1080, height: Number(mp.height) || 1920, fps: Number(mp.fps) || 30, targetDurationS: Number(mp.targetDurationS) || 30, draftName: String(mp.draftName || mp.name), directorBrief: (mp.directorBrief as Record<string, unknown>) || null })
      .returning();
    if (manifest.media?.length) await enqueue("import_media", `Import media for ${p.name}`, { projectId: p.id, paths: manifest.media.map((m) => m.path) }, p.id);
    if (manifest.current_edl) {
      const [e] = await db.insert(edls).values({ projectId: p.id, label: "Imported plan", source: "import", edl: manifest.current_edl as Record<string, unknown> }).returning();
      await db.update(projects).set({ currentEdlId: e.id }).where(eq(projects.id, p.id));
    }
    return ok({ project: p }, 201);
  }
  const name = String(body.name || "").trim();
  if (!name) return fail("NAME_REQUIRED", "Project name is required.");
  const width = Math.round(Number(body.width) || s.video.width);
  const height = Math.round(Number(body.height) || s.video.height);
  const fps = Math.round(Number(body.fps) || s.video.fps);
  const target = Number(body.targetDurationS) || 30;
  if (width < 240 || height < 240 || width > 8192 || height > 8192) return fail("BAD_RESOLUTION", `Resolution ${width}×${height} is outside the supported range (240–8192).`);
  if (fps < 12 || fps > 120) return fail("BAD_FPS", `FPS ${fps} is outside the supported range (12–120).`);
  const baseDir = String(body.location || "").trim() || s.storage.projectDir;
  const location = path.join(baseDir, `${slug(name)}-${crypto.randomBytes(3).toString("hex")}`);
  try {
    for (const sub of ["media", "backups", "versions", "logs"]) fs.mkdirSync(path.join(location, sub), { recursive: true });
  } catch (e) {
    return fail("LOCATION_NOT_WRITABLE", `Could not create the project workspace at ${location}: ${(e as Error).message}`);
  }
  const [p] = await db
    .insert(projects)
    .values({ name, location, aspectRatio: String(body.aspectRatio || "9:16"), width, height, fps, targetDurationS: target, draftName: name.replace(/[\\/:*?"<>|]/g, "_").slice(0, 80) })
    .returning();
  await writeManifest(p.id);
  return ok({ project: p }, 201);
}


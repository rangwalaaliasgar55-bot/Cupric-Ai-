import fs from "node:fs";
import path from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { fail, ok } from "@/lib/api";
import { MEDIA_EXT } from "@/lib/media";
import { enqueue } from "@/lib/jobs";
import "@/lib/pipeline";

export const dynamic = "force-dynamic";

/** Streams one dropped file into the project workspace (no buffering in memory), then queues ingestion. */
export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail("NOT_FOUND", "Project not found.", 404);
  const url = new URL(req.url);
  const raw = url.searchParams.get("name") || "";
  const name = path.basename(raw).replace(/[\\/:*?"<>|]/g, "_");
  if (!name || !MEDIA_EXT.has(path.extname(name).toLowerCase())) return fail("UNSUPPORTED_TYPE", `${raw || "File"} is not a supported video, audio or image type.`);
  if (!req.body) return fail("EMPTY", "Upload body was empty.");
  const dir = path.join(p.location, "media");
  fs.mkdirSync(dir, { recursive: true });
  let dest = path.join(dir, name);
  for (let i = 2; fs.existsSync(dest); i++) dest = path.join(dir, `${path.parse(name).name}_${i}${path.extname(name)}`);
  const tmp = `${dest}.part`;
  try {
    await pipeline(Readable.fromWeb(req.body as import("node:stream/web").ReadableStream), fs.createWriteStream(tmp));
    fs.renameSync(tmp, dest);
  } catch (e) {
    fs.rmSync(tmp, { force: true });
    return fail("UPLOAD_FAILED", `Copying ${name} into the project failed: ${(e as Error).message}`, 500);
  }
  if (url.searchParams.get("defer") === "1") return ok({ path: dest });
  const job = await enqueue("import_media", `Import ${name}`, { projectId: id, paths: [dest] }, id);
  return ok({ path: dest, job });
}

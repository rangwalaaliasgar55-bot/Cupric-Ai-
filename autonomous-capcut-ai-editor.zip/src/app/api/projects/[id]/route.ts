import fs from "node:fs";
import path from "node:path";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { edls, media, projects, versions } from "@/db/schema";
import { fail, ok, projectDetail } from "@/lib/api";
import { enqueue } from "@/lib/jobs";
import { BUILD_STAGES, saveEdl, writeManifest } from "@/lib/pipeline";
import { searchMedia, projectMedia, toMediaContext } from "@/lib/media";
import { buildContext, type DirectorBrief, type RegenMode } from "@/lib/ai/director";
import { validateEdl } from "@/lib/edl/validate";
import { toInventory } from "@/lib/media";
import { getSettings } from "@/lib/settings";
import type { Edl } from "@/shared/schemas/edl";

export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: Ctx) {
  const { id } = await params;
  const d = await projectDetail(id);
  if (!d) return fail("NOT_FOUND", "Project not found.", 404);
  return ok(d);
}

export async function PATCH(req: Request, { params }: Ctx) {
  const { id } = await params;
  const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const patch: Partial<typeof projects.$inferInsert> = { updatedAt: new Date() };
  if (typeof b.name === "string" && b.name.trim()) patch.name = b.name.trim();
  if (b.targetDurationS !== undefined) patch.targetDurationS = Math.max(1, Number(b.targetDurationS));
  if (b.directorBrief && typeof b.directorBrief === "object") patch.directorBrief = b.directorBrief as Record<string, unknown>;
  if (b.width) patch.width = Number(b.width);
  if (b.height) patch.height = Number(b.height);
  if (b.fps) patch.fps = Number(b.fps);
  if (typeof b.aspectRatio === "string") patch.aspectRatio = b.aspectRatio;
  const [p] = await db.update(projects).set(patch).where(eq(projects.id, id)).returning();
  if (!p) return fail("NOT_FOUND", "Project not found.", 404);
  void writeManifest(id).catch(() => {});
  return ok({ project: p });
}

export async function DELETE(req: Request, { params }: Ctx) {
  const { id } = await params;
  const url = new URL(req.url);
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail("NOT_FOUND", "Project not found.", 404);
  await db.delete(projects).where(eq(projects.id, id));
  const s = await getSettings();
  // Only remove the app-managed workspace, never source footage referenced in place or CapCut drafts.
  if (url.searchParams.get("removeFiles") === "1" && path.resolve(p.location).startsWith(path.resolve(s.storage.projectDir) + path.sep)) {
    fs.rmSync(p.location, { recursive: true, force: true });
  }
  return ok({ deleted: true });
}

export async function POST(req: Request, { params }: Ctx) {
  const { id } = await params;
  const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail("NOT_FOUND", "Project not found.", 404);
  switch (b.action) {
    case "import_paths": {
      const paths = (Array.isArray(b.paths) ? b.paths : String(b.paths || "").split("\n")).map(String).map((x) => x.trim()).filter(Boolean);
      if (!paths.length) return fail("NO_PATHS", "Enter at least one file or folder path.");
      const job = await enqueue("import_media", `Import ${paths.length} path(s) into ${p.name}`, { projectId: id, paths }, id);
      return ok({ job });
    }
    case "search": {
      const hits = await searchMedia(id, String(b.q || ""), { kind: (b.kind as string) || undefined, minDur: Number(b.minDur) || undefined, maxDur: Number(b.maxDur) || undefined });
      return ok({ hits });
    }
    case "director_preview": {
      const rows = (await projectMedia(id)).filter((m) => m.readable);
      const brief = { ...((p.directorBrief || {}) as Partial<DirectorBrief>), targetDurationS: p.targetDurationS, aspectRatio: p.aspectRatio, fps: p.fps } as DirectorBrief;
      const ctx = buildContext(brief, toMediaContext(rows));
      const text = JSON.stringify(ctx);
      return ok({ bytes: Buffer.byteLength(text), files: rows.length, sample: text.slice(0, 4000) });
    }
    case "director": {
      const mode = (b.mode || { kind: "full" }) as RegenMode;
      const job = await enqueue("ai_director", mode.kind === "full" ? `AI Director: ${p.name}` : `AI Director (${mode.kind}): ${p.name}`, { projectId: id, mode }, id, [
        { key: "context", label: "Prepare context" },
        { key: "gemini", label: "Gemini AI Director" },
        { key: "validate", label: "Validate EDL" },
      ]);
      return ok({ job });
    }
    case "save_edl": {
      const report = validateEdl(b.edl, toInventory(await projectMedia(id)), { repair: true });
      if (!report.edl) return fail("EDL_INVALID", `The edit plan failed schema validation: ${report.errors.slice(0, 3).map((e) => `${e.path}: ${e.message}`).join("; ")}`, 422, report);
      const { row } = await saveEdl(id, report.edl, "user", String(b.label || "Manual edit"), { parentId: p.currentEdlId });
      return ok({ edlId: row.id, report });
    }
    case "select_edl": {
      const [e] = await db.select().from(edls).where(and(eq(edls.id, String(b.edlId)), eq(edls.projectId, id)));
      if (!e) return fail("NOT_FOUND", "Edit plan not found.", 404);
      await db.update(projects).set({ currentEdlId: e.id, updatedAt: new Date() }).where(eq(projects.id, id));
      return ok({ edlId: e.id });
    }
    case "restore_version": {
      const [v] = await db.select().from(versions).where(and(eq(versions.id, String(b.versionId)), eq(versions.projectId, id)));
      if (!v) return fail("NOT_FOUND", "Version not found.", 404);
      const { row } = await saveEdl(id, v.edl as unknown as Edl, "restore", `Restored from v${String(v.number).padStart(3, "0")}`, { parentId: p.currentEdlId });
      return ok({ edlId: row.id });
    }
    case "restore_draft_backup": {
      const [v] = await db.select().from(versions).where(and(eq(versions.id, String(b.versionId)), eq(versions.projectId, id)));
      if (!v?.backupPath) return fail("NO_BACKUP", "This version has no draft backup to restore.");
      const job = await enqueue("restore_backup", `Restore CapCut draft backup (${path.basename(v.backupPath)})`, { projectId: id, backupPath: v.backupPath, draftName: (v.settings as { draftName?: string }).draftName || p.draftName }, id);
      return ok({ job });
    }
    case "skip_file": {
      if (!p.currentEdlId) return fail("NO_PLAN", "There is no edit plan to modify.");
      const [e] = await db.select().from(edls).where(eq(edls.id, p.currentEdlId));
      const f = String(b.filename);
      const edl = structuredClone(e.edl) as unknown as Edl;
      edl.sections = edl.sections.map((s) => ({ ...s, clips: s.clips.filter((c) => c.source_file !== f).map((c) => ({ ...c, broll: c.broll.filter((x) => x.source_file !== f), sfx: c.sfx.filter((x) => x.source_file !== f) })) })).filter((s) => s.clips.length);
      if (edl.music.source_file === f) edl.music.source_file = null;
      if (!edl.sections.length) return fail("PLAN_EMPTY", `Skipping ${f} would remove every clip from the plan.`);
      const { row } = await saveEdl(id, edl, "user", `Skipped ${f}`, { parentId: e.id });
      return ok({ edlId: row.id });
    }
    case "generate": {
      if (!p.currentEdlId) return fail("NO_PLAN", "Create or approve an edit plan before generating a CapCut draft.");
      const job = await enqueue("build_draft", `Generate CapCut draft: ${p.name}`, { projectId: id, edlId: p.currentEdlId, newDraftPerVersion: !!b.newDraftPerVersion }, id, BUILD_STAGES);
      return ok({ job });
    }
    case "duplicate": {
      const [np] = await db.insert(projects).values({ ...p, id: undefined, name: `${p.name} copy`, draftName: `${p.draftName} copy`, currentEdlId: null, createdAt: new Date(), updatedAt: new Date() }).returning();
      const rows = await db.select().from(media).where(eq(media.projectId, id));
      if (rows.length) await db.insert(media).values(rows.map((m) => ({ ...m, id: undefined, projectId: np.id, createdAt: new Date() })));
      if (p.currentEdlId) {
        const [e] = await db.select().from(edls).where(eq(edls.id, p.currentEdlId));
        const [ne] = await db.insert(edls).values({ projectId: np.id, label: "Copied plan", source: "copy", edl: e.edl, validation: e.validation }).returning();
        await db.update(projects).set({ currentEdlId: ne.id }).where(eq(projects.id, np.id));
      }
      return ok({ project: np }, 201);
    }
    default:
      return fail("UNKNOWN_ACTION", `Unknown action ${String(b.action)}`);
  }
}

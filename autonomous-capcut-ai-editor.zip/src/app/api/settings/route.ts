import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { aiRequests, stylePresets } from "@/db/schema";
import { fail, ok } from "@/lib/api";
import { detectCapcutDirs, getSettings, saveSettings, type AppSettings } from "@/lib/settings";
import { deleteSecret, getSecret, secretHint, setSecret } from "@/lib/secrets";
import { BUILTIN_PRESETS } from "@/lib/ai/presets";

export const dynamic = "force-dynamic";

async function presets() {
  const rows = await db.select().from(stylePresets);
  if (!rows.some((r) => r.builtin)) {
    await db.insert(stylePresets).values(BUILTIN_PRESETS.map((p) => ({ ...p, structure: p.structure ?? null, builtin: true })));
    return db.select().from(stylePresets);
  }
  return rows;
}

export async function GET() {
  return ok({
    settings: await getSettings(),
    gemini: await secretHint("gemini_api_key"), // never the key itself
    detectedCapcutDirs: detectCapcutDirs(),
    presets: await presets(),
    aiRequests: await db.select().from(aiRequests).orderBy(desc(aiRequests.createdAt)).limit(25),
  });
}

export async function PUT(req: Request) {
  const b = (await req.json().catch(() => ({}))) as Partial<AppSettings>;
  if (b.ai) {
    b.ai.temperature = Math.max(0, Math.min(2, Number(b.ai.temperature)));
    b.ai.retryCount = Math.max(0, Math.min(5, Math.round(Number(b.ai.retryCount))));
    b.ai.maxAttempts = Math.max(1, Math.min(6, Math.round(Number(b.ai.maxAttempts))));
  }
  return ok({ settings: await saveSettings(b) });
}

export async function POST(req: Request) {
  const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  switch (b.action) {
    case "set_key": {
      const key = String(b.key || "").trim();
      if (key.length < 20) return fail("KEY_INVALID", "That does not look like a Gemini API key.");
      await setSecret("gemini_api_key", key);
      return ok({ gemini: await secretHint("gemini_api_key") });
    }
    case "delete_key":
      await deleteSecret("gemini_api_key");
      return ok({ gemini: await secretHint("gemini_api_key") });
    case "test_gemini": {
      const key = await getSecret("gemini_api_key");
      if (!key) return fail("GEMINI_KEY_MISSING", "No Gemini API key is configured.");
      const s = await getSettings();
      try {
        const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(s.ai.model)}`, { headers: { "x-goog-api-key": key }, signal: AbortSignal.timeout(15000) });
        const j = (await r.json().catch(() => ({}))) as { error?: { message?: string }; displayName?: string };
        if (!r.ok) return fail("GEMINI_TEST_FAILED", `Gemini rejected the request (${r.status}): ${j.error?.message || r.statusText}`);
        return ok({ ok: true, model: j.displayName || s.ai.model });
      } catch (e) {
        return fail("GEMINI_UNREACHABLE", `Could not reach Gemini: ${(e as Error).message}`);
      }
    }
    case "add_preset": {
      const name = String(b.name || "").trim();
      const instructions = String(b.instructions || "").trim();
      if (!name || !instructions) return fail("PRESET_INVALID", "A preset needs a name and instructions.");
      const [row] = await db.insert(stylePresets).values({ name, description: String(b.description || ""), instructions, builtin: false }).returning();
      return ok({ preset: row });
    }
    case "delete_preset": {
      const [row] = await db.select().from(stylePresets).where(eq(stylePresets.id, String(b.id)));
      if (!row) return fail("NOT_FOUND", "Preset not found.", 404);
      if (row.builtin) return fail("BUILTIN", "Built-in presets cannot be deleted.");
      await db.delete(stylePresets).where(eq(stylePresets.id, row.id));
      return ok({ deleted: true });
    }
    default:
      return fail("UNKNOWN_ACTION", `Unknown action ${String(b.action)}`);
  }
}

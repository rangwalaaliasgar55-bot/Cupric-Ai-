import { spawn } from "node:child_process";
import fs from "node:fs";
import { fail, ok } from "@/lib/api";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

function launch(cmd: string, args: string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const c = spawn(cmd, args, { detached: true, stdio: "ignore" });
    c.on("error", reject);
    c.on("spawn", () => {
      c.unref();
      resolve();
    });
  });
}

/** Fixed, whitelisted OS handoffs only (open a folder / launch CapCut). No arbitrary commands. */
export async function POST(req: Request) {
  const b = (await req.json().catch(() => ({}))) as { action?: string; path?: string };
  const s = await getSettings();
  try {
    if (b.action === "open_folder") {
      const p = String(b.path || "");
      if (!p || !fs.existsSync(p)) return fail("NOT_FOUND", `${p || "Folder"} does not exist.`, 404);
      if (!p.startsWith(s.storage.draftDir) && !p.startsWith(s.storage.projectDir)) return fail("FORBIDDEN", "Only draft and project folders can be opened.", 403);
      if (process.platform === "win32") await launch("explorer.exe", [p]);
      else if (process.platform === "darwin") await launch("open", [p]);
      else await launch("xdg-open", [p]);
      return ok({ opened: true });
    }
    if (b.action === "open_capcut") {
      if (process.platform === "darwin") await launch("open", ["-a", "CapCut"]);
      else if (process.platform === "win32") {
        const exe = `${process.env.LOCALAPPDATA}\\CapCut\\Apps\\CapCut.exe`;
        if (!fs.existsSync(exe)) return fail("CAPCUT_NOT_FOUND", `CapCut was not found at ${exe}. Open CapCut manually — the draft will appear in its project list.`, 404);
        await launch(exe, []);
      } else return fail("UNSUPPORTED_PLATFORM", "CapCut desktop is not available on Linux. Copy the draft folder to a Windows/macOS machine's CapCut draft directory.", 400);
      return ok({ opened: true });
    }
  } catch (e) {
    return fail("LAUNCH_FAILED", `The system could not open it: ${(e as Error).message}. This host may not have a desktop session — use “Copy project path”.`, 500);
  }
  return fail("UNKNOWN_ACTION", `Unknown action ${String(b.action)}`);
}

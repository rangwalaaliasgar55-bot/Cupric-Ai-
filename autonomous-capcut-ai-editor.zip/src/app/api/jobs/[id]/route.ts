import { eq } from "drizzle-orm";
import { db } from "@/db";
import { jobs } from "@/db/schema";
import { fail, ok } from "@/lib/api";
import { cancelJob, retryJob } from "@/lib/jobs";
import "@/lib/pipeline";

export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ id: string }> };

export async function GET(_r: Request, { params }: Ctx) {
  const { id } = await params;
  const [j] = await db.select().from(jobs).where(eq(jobs.id, id));
  if (!j) return fail("NOT_FOUND", "Job not found.", 404);
  return ok({ job: j });
}

export async function POST(req: Request, { params }: Ctx) {
  const { id } = await params;
  const b = (await req.json().catch(() => ({}))) as { action?: string };
  if (b.action === "cancel") {
    await cancelJob(id);
    return ok({ cancelled: true });
  }
  if (b.action === "retry") {
    try {
      return ok({ job: await retryJob(id) });
    } catch (e) {
      return fail("RETRY_FAILED", (e as Error).message);
    }
  }
  return fail("UNKNOWN_ACTION", `Unknown action ${String(b.action)}`);
}

import { and, desc, eq, inArray, gte, or } from "drizzle-orm";
import { db } from "@/db";
import { jobs } from "@/db/schema";
import { ok } from "@/lib/api";
import { pump } from "@/lib/jobs";
import "@/lib/pipeline";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  void pump(); // resume queued work after restarts
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  const ids = url.searchParams.get("ids");
  const since = new Date(Date.now() - 1000 * 60 * 60 * 24 * 7);
  const where = ids
    ? inArray(jobs.id, ids.split(",").filter(Boolean))
    : and(projectId ? eq(jobs.projectId, projectId) : undefined, or(inArray(jobs.status, ["queued", "running"]), gte(jobs.createdAt, since)));
  const rows = await db.select().from(jobs).where(where).orderBy(desc(jobs.createdAt)).limit(Number(url.searchParams.get("limit")) || 60);
  const withLog = url.searchParams.get("log") === "1";
  return ok({ jobs: rows.map((j) => (withLog ? j : { ...j, log: j.log.slice(-1500) })) });
}

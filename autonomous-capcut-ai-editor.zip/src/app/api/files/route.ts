import fs from "node:fs";
import path from "node:path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { media } from "@/db/schema";
import { appHome, getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const TYPES: Record<string, string> = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif", ".mp4": "video/mp4", ".m4v": "video/mp4", ".mov": "video/quicktime", ".webm": "video/webm", ".mkv": "video/x-matroska", ".mp3": "audio/mpeg", ".wav": "audio/wav", ".m4a": "audio/mp4", ".aac": "audio/aac", ".ogg": "audio/ogg", ".flac": "audio/flac" };

/** Serves only app-managed files (cache/workspaces) or media explicitly registered in a project. Supports Range for scrubbing. */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const p = path.resolve(/*turbopackIgnore: true*/ url.searchParams.get("path") || "");
  const s = await getSettings();
  const roots = [appHome(), s.storage.cacheDir, s.storage.projectDir].map((r) => path.resolve(/*turbopackIgnore: true*/ r) + path.sep);
  let allowed = roots.some((r) => p.startsWith(r));
  if (!allowed) allowed = (await db.select({ id: media.id }).from(media).where(eq(media.path, p)).limit(1)).length > 0;
  if (!allowed) return new Response("Forbidden: file is not part of any project", { status: 403 });
  let st: fs.Stats;
  try {
    st = fs.statSync(/*turbopackIgnore: true*/ p);
  } catch {
    return new Response("Not found", { status: 404 });
  }
  const type = TYPES[path.extname(p).toLowerCase()] || "application/octet-stream";
  const range = req.headers.get("range");
  const toWeb = (stream: fs.ReadStream) => new ReadableStream({
    start(controller) {
      stream.on("data", (c) => controller.enqueue(new Uint8Array(c as Buffer)));
      stream.on("end", () => controller.close());
      stream.on("error", (e) => controller.error(e));
    },
    cancel() {
      stream.destroy();
    },
  });
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range);
    const start = m && m[1] ? Number(m[1]) : 0;
    const end = m && m[2] ? Math.min(Number(m[2]), st.size - 1) : Math.min(start + 4 * 1024 * 1024, st.size - 1);
    if (start >= st.size) return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${st.size}` } });
    return new Response(toWeb(fs.createReadStream(p, { start, end })), { status: 206, headers: { "Content-Type": type, "Content-Length": String(end - start + 1), "Content-Range": `bytes ${start}-${end}/${st.size}`, "Accept-Ranges": "bytes" } });
  }
  return new Response(toWeb(fs.createReadStream(p)), { headers: { "Content-Type": type, "Content-Length": String(st.size), "Accept-Ranges": "bytes", "Cache-Control": "private, max-age=300" } });
}

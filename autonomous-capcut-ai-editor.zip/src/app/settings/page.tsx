"use client";
import { useEffect, useState } from "react";
import { api, usePoll } from "@/components/hooks";
import { Badge, Button, ErrorBox, Field, Panel, Toggle, ago } from "@/components/ui";

type S = {
  onboarded: boolean;
  ai: { model: string; temperature: number; retryCount: number; maxAttempts: number };
  transcription: { model: string; language: string; device: string; computeType: string; wordTimestamps: boolean };
  video: { aspectRatio: string; width: number; height: number; fps: number };
  captions: { font: string; size: number; position: string; animation: string; maxWords: number; mode: string; emphasisColor: string };
  audio: { musicDucking: boolean; duckLevel: number; musicVolume: number; dialogueGain: number; sfxGain: number };
  storage: { projectDir: string; cacheDir: string; draftDir: string; backupRetention: number };
};
type Resp = { settings: S; gemini: { configured: boolean; hint: string | null; source: string | null }; detectedCapcutDirs: string[]; presets: { id: string; name: string; description: string; instructions: string; builtin: boolean }[]; aiRequests: { id: string; model: string; purpose: string; bytesSent: number; status: string; error: string | null; createdAt: string }[] };

export default function SettingsPage() {
  const { data, reload } = usePoll<Resp>("/api/settings", 0);
  const [s, setS] = useState<S | null>(null);
  const [key, setKey] = useState("");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState<{ message: string; code?: string } | null>(null);
  const [preset, setPreset] = useState({ name: "", description: "", instructions: "" });
  useEffect(() => { if (data && !s) setS(data.settings); }, [data, s]);
  if (!data || !s) return <div className="p-8 text-ink-400">Loading settings…</div>;
  const upd = <K extends keyof S>(sec: K, k: keyof S[K], v: unknown) => setS({ ...s, [sec]: { ...(s[sec] as object), [k]: v } });
  const run = async (fn: () => Promise<unknown>, ok: string) => {
    setErr(null); setMsg("");
    try { await fn(); setMsg(ok); await reload(); } catch (e) { setErr(e as { message: string }); }
  };
  const num = (v: string) => (v === "" ? 0 : Number(v));

  return (
    <div className="mx-auto max-w-[1100px] space-y-5 px-8 py-7">
      <div className="flex items-end justify-between">
        <div><div className="label">Application</div><h1 className="mt-1 text-[22px] font-semibold tracking-tight">Settings</h1></div>
        <Button variant="primary" onClick={() => run(() => api("/api/settings", "PUT", s), "Settings saved.")}>Save settings</Button>
      </div>
      <ErrorBox error={err} />
      {msg && <div className="rounded border border-ok/30 px-3 py-2 text-[12px] text-ok">{msg}</div>}

      <div className="grid grid-cols-2 gap-5">
        <Panel title="AI — Gemini">
          <div className="space-y-3">
            <Field label="API key" hint={data.gemini.configured ? <>Configured <Badge tone="ok">{data.gemini.hint}</Badge> · stored encrypted locally; never shown or logged.</> : "Stored encrypted on this machine only. Never transmitted anywhere except Google's Gemini API."}>
              <div className="flex gap-2">
                <input className="field tc" type="password" autoComplete="off" placeholder={data.gemini.configured ? "•••••••• (enter to replace)" : "AIza…"} value={key} onChange={(e) => setKey(e.target.value)} />
                <Button onClick={() => run(async () => { await api("/api/settings", "POST", { action: "set_key", key }); setKey(""); }, "API key saved (encrypted).")} disabled={!key}>Save</Button>
              </div>
            </Field>
            <div className="flex gap-2">
              <Button size="sm" onClick={() => run(() => api("/api/settings", "POST", { action: "test_gemini" }), "Gemini connection verified.")} disabled={!data.gemini.configured}>Test connection</Button>
              {data.gemini.source === "local" && <Button size="sm" variant="danger" onClick={() => run(() => api("/api/settings", "POST", { action: "delete_key" }), "API key removed.")}>Remove key</Button>}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Model"><input className="field tc" list="models" value={s.ai.model} onChange={(e) => upd("ai", "model", e.target.value)} /><datalist id="models"><option value="gemini-2.5-flash" /><option value="gemini-2.5-pro" /><option value="gemini-3-flash-preview" /><option value="gemini-3-pro-preview" /></datalist></Field>
              <Field label="Temperature"><input className="field tc" type="number" step="0.1" min={0} max={2} value={s.ai.temperature} onChange={(e) => upd("ai", "temperature", num(e.target.value))} /></Field>
              <Field label="Network retries"><input className="field tc" type="number" min={0} max={5} value={s.ai.retryCount} onChange={(e) => upd("ai", "retryCount", num(e.target.value))} /></Field>
              <Field label="Max generation attempts" hint="Validation-feedback loops"><input className="field tc" type="number" min={1} max={6} value={s.ai.maxAttempts} onChange={(e) => upd("ai", "maxAttempts", num(e.target.value))} /></Field>
            </div>
          </div>
        </Panel>

        <Panel title="Transcription — faster-whisper (local)">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Whisper model" hint="Downloaded once, then fully offline"><select className="field" value={s.transcription.model} onChange={(e) => upd("transcription", "model", e.target.value)}>{["tiny", "base", "small", "medium", "large-v3", "distil-large-v3"].map((m) => <option key={m}>{m}</option>)}</select></Field>
            <Field label="Language" hint="Empty = auto-detect"><input className="field tc" value={s.transcription.language} placeholder="auto" onChange={(e) => upd("transcription", "language", e.target.value)} /></Field>
            <Field label="Compute device"><select className="field" value={s.transcription.device} onChange={(e) => upd("transcription", "device", e.target.value)}>{["auto", "cpu", "cuda"].map((m) => <option key={m}>{m}</option>)}</select></Field>
            <Field label="Compute type"><select className="field" value={s.transcription.computeType} onChange={(e) => upd("transcription", "computeType", e.target.value)}>{["auto", "int8", "float16", "float32"].map((m) => <option key={m}>{m}</option>)}</select></Field>
            <Toggle checked={s.transcription.wordTimestamps} onChange={(v) => upd("transcription", "wordTimestamps", v)} label="Word-level timestamps" />
          </div>
        </Panel>

        <Panel title="Video defaults">
          <div className="grid grid-cols-4 gap-3">
            <Field label="Aspect"><select className="field" value={s.video.aspectRatio} onChange={(e) => upd("video", "aspectRatio", e.target.value)}>{["9:16", "16:9", "1:1", "4:5"].map((m) => <option key={m}>{m}</option>)}</select></Field>
            <Field label="Width"><input className="field tc" type="number" value={s.video.width} onChange={(e) => upd("video", "width", num(e.target.value))} /></Field>
            <Field label="Height"><input className="field tc" type="number" value={s.video.height} onChange={(e) => upd("video", "height", num(e.target.value))} /></Field>
            <Field label="FPS"><input className="field tc" type="number" value={s.video.fps} onChange={(e) => upd("video", "fps", num(e.target.value))} /></Field>
          </div>
        </Panel>

        <Panel title="Captions">
          <div className="grid grid-cols-3 gap-3">
            <Field label="Font" hint="pyJianYingDraft FontType name; empty = CapCut default"><input className="field tc" value={s.captions.font} onChange={(e) => upd("captions", "font", e.target.value)} placeholder="e.g. Anton" /></Field>
            <Field label="Size"><input className="field tc" type="number" step="0.5" value={s.captions.size} onChange={(e) => upd("captions", "size", num(e.target.value))} /></Field>
            <Field label="Emphasis colour"><input className="field tc h-[34px] p-1" type="color" value={s.captions.emphasisColor} onChange={(e) => upd("captions", "emphasisColor", e.target.value)} /></Field>
            <Field label="Default mode"><select className="field" value={s.captions.mode} onChange={(e) => upd("captions", "mode", e.target.value)}>{["phrase", "word", "karaoke"].map((m) => <option key={m}>{m}</option>)}</select></Field>
            <Field label="Position"><select className="field" value={s.captions.position} onChange={(e) => upd("captions", "position", e.target.value)}>{["bottom", "center", "top"].map((m) => <option key={m}>{m}</option>)}</select></Field>
            <Field label="Animation"><select className="field" value={s.captions.animation} onChange={(e) => upd("captions", "animation", e.target.value)}>{["none", "fade", "pop", "typewriter", "slide_up", "zoom"].map((m) => <option key={m}>{m}</option>)}</select></Field>
          </div>
        </Panel>

        <Panel title="Audio">
          <div className="grid grid-cols-2 gap-3">
            <Toggle checked={s.audio.musicDucking} onChange={(v) => upd("audio", "musicDucking", v)} label="Duck music under dialogue" />
            <div />
            <Field label="Ducked music level (0–1)"><input className="field tc" type="number" step="0.02" value={s.audio.duckLevel} onChange={(e) => upd("audio", "duckLevel", num(e.target.value))} /></Field>
            <Field label="Default music volume"><input className="field tc" type="number" step="0.05" value={s.audio.musicVolume} onChange={(e) => upd("audio", "musicVolume", num(e.target.value))} /></Field>
            <Field label="Dialogue gain"><input className="field tc" type="number" step="0.05" value={s.audio.dialogueGain} onChange={(e) => upd("audio", "dialogueGain", num(e.target.value))} /></Field>
            <Field label="SFX gain"><input className="field tc" type="number" step="0.05" value={s.audio.sfxGain} onChange={(e) => upd("audio", "sfxGain", num(e.target.value))} /></Field>
          </div>
        </Panel>

        <Panel title="Storage">
          <div className="space-y-3">
            <Field label="CapCut draft directory" hint={data.detectedCapcutDirs.length ? `Detected: ${data.detectedCapcutDirs.join(" · ")}` : "No CapCut installation detected on this machine."}><input className="field tc text-[12px]" value={s.storage.draftDir} onChange={(e) => upd("storage", "draftDir", e.target.value)} /></Field>
            <Field label="Project directory"><input className="field tc text-[12px]" value={s.storage.projectDir} onChange={(e) => upd("storage", "projectDir", e.target.value)} /></Field>
            <Field label="Cache directory"><input className="field tc text-[12px]" value={s.storage.cacheDir} onChange={(e) => upd("storage", "cacheDir", e.target.value)} /></Field>
            <Field label="Backup retention (per draft)"><input className="field tc w-32" type="number" min={1} value={s.storage.backupRetention} onChange={(e) => upd("storage", "backupRetention", num(e.target.value))} /></Field>
          </div>
        </Panel>
      </div>

      <Panel title="Style presets">
        <div className="grid grid-cols-[1fr_360px] gap-5">
          <div className="grid grid-cols-2 gap-2">
            {data.presets.map((p) => (
              <div key={p.id} className="rounded-md border border-ink-700 p-3">
                <div className="flex items-center gap-2"><span className="font-medium">{p.name}</span>{p.builtin ? <Badge>built-in</Badge> : <Badge tone="accent">custom</Badge>}{!p.builtin && <button className="ml-auto text-[11px] text-bad" onClick={() => run(() => api("/api/settings", "POST", { action: "delete_preset", id: p.id }), "Preset deleted.")}>delete</button>}</div>
                <div className="mt-1 line-clamp-3 text-[11.5px] text-ink-400">{p.instructions}</div>
              </div>
            ))}
          </div>
          <div className="space-y-2">
            <div className="label">New custom preset</div>
            <input className="field" placeholder="Name" value={preset.name} onChange={(e) => setPreset({ ...preset, name: e.target.value })} />
            <input className="field" placeholder="Short description" value={preset.description} onChange={(e) => setPreset({ ...preset, description: e.target.value })} />
            <textarea className="field h-28" placeholder="Director instructions (pacing, captions, look, structure…)" value={preset.instructions} onChange={(e) => setPreset({ ...preset, instructions: e.target.value })} />
            <Button onClick={() => run(async () => { await api("/api/settings", "POST", { action: "add_preset", ...preset }); setPreset({ name: "", description: "", instructions: "" }); }, "Preset created.")}>Add preset</Button>
          </div>
        </div>
      </Panel>

      <Panel title="Privacy ledger — requests sent to Gemini">
        {data.aiRequests.length === 0 ? <div className="text-ink-400">Nothing has been sent to Gemini yet.</div> : (
          <div className="divide-y divide-ink-700/60 text-[12px]">
            {data.aiRequests.map((r) => (
              <div key={r.id} className="grid grid-cols-[110px_200px_100px_1fr] gap-3 py-1.5">
                <span className="text-ink-400">{ago(r.createdAt)}</span><span className="tc">{r.purpose}</span><span className="tc">{(r.bytesSent / 1024).toFixed(1)} KB</span>
                <span className={r.status === "ok" ? "text-ok" : "text-bad"}>{r.status}{r.error ? ` — ${r.error}` : ""} · {r.model}</span>
              </div>
            ))}
          </div>
        )}
      </Panel>
    </div>
  );
}

"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api, setActiveProject } from "@/components/hooks";
import { Button, ErrorBox, Field, cx } from "@/components/ui";
import { MediaImporter } from "@/features/media/MediaImporter";

const PRESETS = [
  { key: "9:16", label: "9:16 Short-form", w: 1080, h: 1920, note: "TikTok · Reels · Shorts" },
  { key: "16:9", label: "16:9 YouTube", w: 1920, h: 1080, note: "YouTube · web" },
  { key: "1:1", label: "1:1 Social", w: 1080, h: 1080, note: "Feed posts" },
  { key: "4:5", label: "4:5 Social", w: 1080, h: 1350, note: "Instagram portrait" },
  { key: "custom", label: "Custom", w: 1920, h: 1080, note: "Any resolution" },
];

export default function NewProject() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ name: "", location: "", aspectRatio: "9:16", width: 1080, height: 1920, fps: 30, targetDurationS: 30 });
  const [projectId, setProjectId] = useState<string | null>(null);
  const [err, setErr] = useState<{ message: string; code?: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: string, v: string | number) => setForm((f) => ({ ...f, [k]: v }));

  const create = async () => {
    setErr(null);
    setBusy(true);
    try {
      const r = await api<{ project: { id: string } }>("/api/projects", "POST", form);
      setProjectId(r.project.id);
      setActiveProject(r.project.id);
      setStep(2);
    } catch (e) {
      setErr(e as { message: string });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-[860px] px-8 py-8">
      <div className="label">New project</div>
      <h1 className="mt-1 text-[22px] font-semibold tracking-tight">{step === 1 ? "Project information" : "Import media"}</h1>
      <div className="mt-4 flex gap-2">
        {["Project information", "Import media"].map((s, i) => (
          <div key={s} className={cx("flex items-center gap-2 rounded-md border px-3 py-1.5 text-[12px]", step === i + 1 ? "border-accent/50 text-ink-100" : "border-ink-700 text-ink-400")}>
            <span className={cx("tc grid h-4 w-4 place-items-center rounded-full text-[10px]", step > i + 1 ? "bg-ok text-ink-950" : step === i + 1 ? "bg-accent text-ink-950" : "bg-ink-700")}>{step > i + 1 ? "✓" : i + 1}</span>
            {s}
          </div>
        ))}
      </div>

      {step === 1 && (
        <div className="fade-up mt-6 space-y-6 rounded-lg border border-ink-700 bg-ink-900 p-6">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Project name">
              <input className="field" autoFocus value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Launch teaser — Acme Analytics" />
            </Field>
            <Field label="Project location" hint="Leave empty to use the default project directory from Settings.">
              <input className="field tc text-[12px]" value={form.location} onChange={(e) => set("location", e.target.value)} placeholder="(default)" />
            </Field>
          </div>
          <div>
            <div className="label mb-2">Target format</div>
            <div className="grid grid-cols-5 gap-2">
              {PRESETS.map((p) => (
                <button key={p.key} onClick={() => setForm((f) => ({ ...f, aspectRatio: p.key, width: p.w, height: p.h }))} className={cx("rounded-md border p-3 text-left transition-colors", form.aspectRatio === p.key ? "border-accent/60 bg-accent/[0.06]" : "border-ink-600 hover:border-ink-500")}>
                  <div className="mb-2 flex h-10 items-end">
                    <div className="rounded-sm border border-ink-300" style={{ width: p.key === "custom" ? 28 : (p.w / Math.max(p.w, p.h)) * 36, height: p.key === "custom" ? 18 : (p.h / Math.max(p.w, p.h)) * 36 }} />
                  </div>
                  <div className="text-[12px] font-medium">{p.label}</div>
                  <div className="mt-0.5 text-[10.5px] text-ink-400">{p.note}</div>
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-4 gap-4">
            <Field label="Width"><input className="field tc" type="number" value={form.width} onChange={(e) => (set("width", +e.target.value), set("aspectRatio", "custom"))} /></Field>
            <Field label="Height"><input className="field tc" type="number" value={form.height} onChange={(e) => (set("height", +e.target.value), set("aspectRatio", "custom"))} /></Field>
            <Field label="FPS">
              <select className="field tc" value={form.fps} onChange={(e) => set("fps", +e.target.value)}>
                {[24, 25, 30, 50, 60].map((f) => <option key={f}>{f}</option>)}
              </select>
            </Field>
            <Field label="Target duration (s)"><input className="field tc" type="number" min={3} value={form.targetDurationS} onChange={(e) => set("targetDurationS", +e.target.value)} /></Field>
          </div>
          <ErrorBox error={err} />
          <div className="flex justify-end">
            <Button variant="primary" size="lg" disabled={!form.name.trim() || busy} onClick={create}>{busy ? "Creating workspace…" : "Create project →"}</Button>
          </div>
        </div>
      )}

      {step === 2 && projectId && (
        <div className="fade-up mt-6 space-y-4 rounded-lg border border-ink-700 bg-ink-900 p-6">
          <p className="text-ink-300">Imported files are probed immediately; analysis (thumbnails, scenes, audio levels) and local Whisper transcription run as background jobs — you can keep working while they finish.</p>
          <MediaImporter projectId={projectId} onQueued={() => router.push(`/projects/${projectId}/media`)} />
          <div className="flex justify-between">
            <Button variant="ghost" onClick={() => router.push(`/projects/${projectId}/media`)}>Skip for now</Button>
          </div>
        </div>
      )}
    </div>
  );
}

"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/components/hooks";
import { Badge, Button, Empty, ErrorBox, Field, Panel, Progress, StatusDot, Toggle, cx, fmtTime } from "@/components/ui";
import { useProject } from "@/features/project/ProjectContext";
import { Timeline } from "@/features/timeline/Timeline";
import { useLatestJob } from "@/features/generation/useJob";
import { COLOR_MOODS, SECTION_ROLES, TRANSITIONS, CAPTION_MODES, CAPTION_POSITIONS, type Edl, type EdlClip } from "@/shared/schemas/edl";

const MODIFIERS: [string, string][] = [["faster", "Faster"], ["calmer", "Calmer"], ["cinematic", "More cinematic"], ["energetic", "More energetic"], ["minimal", "More minimal"], ["retention", "Retention-focused"], ["fewer_effects", "Fewer effects"], ["stronger_captions", "Stronger captions"], ["stronger_hook", "Stronger hook"]];

export default function PlanPage() {
  const { detail, reload } = useProject();
  const router = useRouter();
  const p = detail.project;
  const cur = detail.current;
  const [edl, setEdl] = useState<Edl | null>(cur?.edl ?? null);
  const [dirty, setDirty] = useState(false);
  const [sel, setSel] = useState<string | null>(null);
  const [err, setErr] = useState<{ message: string; code?: string; details?: unknown } | null>(null);
  const [instr, setInstr] = useState("");
  const { job } = useLatestJob(p.id, "ai_director", () => void reload());
  const running = job && (job.status === "running" || job.status === "queued");

  useEffect(() => {
    if (!dirty) setEdl(cur?.edl ?? null);
  }, [cur?.id, cur?.edl, dirty]);

  const files = detail.media.filter((m) => m.readable);
  const visuals = files.filter((m) => m.kind === "video" || m.kind === "image");
  const audios = files.filter((m) => m.kind === "audio");

  const mutate = (fn: (e: Edl) => void) => setEdl((e) => { if (!e) return e; const n = structuredClone(e); fn(n); setDirty(true); return n; });
  const mutClip = (id: string, fn: (c: EdlClip) => void) => mutate((e) => e.sections.forEach((s) => s.clips.forEach((c) => c.id === id && fn(c))));

  const save = async () => {
    setErr(null);
    try {
      await api(`/api/projects/${p.id}`, "POST", { action: "save_edl", edl, label: "Manual edit" });
      setDirty(false);
      await reload();
    } catch (e) {
      setErr(e as { message: string });
    }
  };
  const regen = async (mode: Record<string, unknown>) => {
    setErr(null);
    try {
      if (dirty) await save();
      await api(`/api/projects/${p.id}`, "POST", { action: "director", mode });
    } catch (e) {
      setErr(e as { message: string });
    }
  };
  const starter = async () => {
    const vids = visuals.slice(0, 8);
    const plan = {
      project: { target_duration_s: p.targetDurationS, aspect_ratio: ["9:16", "16:9", "1:1", "4:5"].includes(p.aspectRatio) ? p.aspectRatio : "custom", fps: p.fps },
      sections: [{ role: "body", clips: vids.map((m) => ({ source_file: m.filename, in_s: 0, out_s: Math.min(m.kind === "image" ? 3 : m.durationS || 3, Math.max(1.5, p.targetDurationS / vids.length)), use_audio: !!m.hasAudio })) }],
      music: { source_file: audios[0]?.filename ?? null },
    };
    try {
      await api(`/api/projects/${p.id}`, "POST", { action: "save_edl", edl: plan, label: "Manual starter plan" });
      await reload();
    } catch (e) {
      setErr(e as { message: string });
    }
  };

  if (!edl) {
    return (
      <div className="mx-auto max-w-3xl p-8">
        <Empty title="No edit plan yet" action={<div className="flex gap-2"><Button variant="primary" onClick={() => router.push(`/projects/${p.id}/director`)}>Open AI Director</Button><Button onClick={starter} disabled={!visuals.length}>Start a manual plan</Button></div>}>
          Let the AI Director create an EDL from your footage, or start a simple manual plan (each clip&apos;s opening seconds, in import order) and edit it by hand.
        </Empty>
        <div className="mt-4"><ErrorBox error={err} /></div>
      </div>
    );
  }

  const v = cur?.validation;
  const compiled = cur?.compiled;
  const selClip = edl.sections.flatMap((s) => s.clips.map((c) => ({ c, s }))).find((x) => x.c.id === sel);
  const total = edl.sections.reduce((a, s) => a + s.clips.reduce((b, c) => b + (c.out_s - c.in_s) / c.speed, 0), 0);

  return (
    <div className="space-y-5 p-6">
      <div className="flex flex-wrap items-center gap-2">
        <select className="field w-72" value={cur?.id} onChange={async (e) => { await api(`/api/projects/${p.id}`, "POST", { action: "select_edl", edlId: e.target.value }); setDirty(false); await reload(); }}>
          {detail.edlHistory.map((h) => <option key={h.id} value={h.id}>{h.label} · {new Date(h.createdAt).toLocaleString()}</option>)}
        </select>
        {v && (v.ok ? <Badge tone="ok">Valid EDL</Badge> : <Badge tone="bad">{v.errors.length} error(s)</Badge>)}
        {dirty && <Badge tone="warn">Unsaved changes</Badge>}
        <span className="tc text-[12px] text-ink-400">{fmtTime(total)} / target {fmtTime(edl.project.target_duration_s)} · {edl.sections.reduce((a, s) => a + s.clips.length, 0)} clips</span>
        <div className="ml-auto flex gap-2">
          {dirty && <Button onClick={() => { setEdl(cur?.edl ?? null); setDirty(false); }}>Discard</Button>}
          <Button onClick={save} disabled={!dirty}>Save changes</Button>
          <Button variant="primary" disabled={dirty || !v?.ok} onClick={() => router.push(`/projects/${p.id}/generate`)}>Approve → Generate</Button>
        </div>
      </div>
      <ErrorBox error={err} />
      {v && !v.ok && <ErrorBox error={{ message: `This plan cannot be built until these are fixed: ${v.errors.slice(0, 5).map((e) => `${e.path}: ${e.message}`).join(" · ")}`, code: "EDL_INVALID" }} />}
      {v && v.warnings.length > 0 && <div className="rounded-md border border-warn/30 px-3 py-2 text-[12px] text-warn">{v.warnings.map((w) => w.message).join(" · ")}</div>}

      {compiled && <Timeline items={compiled.timeline} total={compiled.plan.total_duration} target={edl.project.target_duration_s} selected={sel} onSelect={setSel} />}
      {dirty && <div className="text-[11.5px] text-ink-400">Timeline preview refreshes after saving.</div>}

      <div className="grid grid-cols-[1fr_340px] gap-5">
        <div className="space-y-4">
          {edl.sections.map((s, si) => (
            <Panel key={s.id || si} title={<span className="flex items-center gap-2">Section {si + 1} · <select className="rounded bg-ink-800 px-1 py-0.5 text-[11px] uppercase text-ink-100" value={s.role} onChange={(e) => mutate((x) => { x.sections[si].role = e.target.value as typeof s.role; })}>{SECTION_ROLES.map((r) => <option key={r}>{r}</option>)}</select></span>} actions={<>
              <Button size="sm" variant="ghost" disabled={!!running} onClick={() => regen({ kind: "section", sectionId: s.id, instruction: instr })}>↻ Regenerate section</Button>
              <Button size="sm" variant="ghost" className="text-bad" onClick={() => mutate((x) => { x.sections.splice(si, 1); })} disabled={edl.sections.length < 2}>Remove</Button>
            </>} pad={false}>
              <div className="divide-y divide-ink-700/70">
                {s.clips.map((c, ci) => {
                  const m = files.find((f) => f.filename === c.source_file);
                  return (
                    <div key={c.id || ci} onClick={() => setSel(c.id || null)} className={cx("grid cursor-pointer grid-cols-[96px_1fr_auto] gap-3 px-4 py-3", sel === c.id ? "bg-accent/[0.06]" : "hover:bg-ink-850")}>
                      <div className="aspect-video overflow-hidden rounded bg-ink-800">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        {m?.thumbnail && <img src={`/api/files?path=${encodeURIComponent(m.thumbnail)}`} alt="" className="h-full w-full object-cover" />}
                      </div>
                      <div className="min-w-0 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="truncate font-medium">{c.source_file}</span>
                          <span className="tc text-[11.5px] text-ink-300">{c.in_s.toFixed(2)} → {c.out_s.toFixed(2)}s</span>
                          <span className="tc text-[11px] text-ink-500">({((c.out_s - c.in_s) / c.speed).toFixed(2)}s)</span>
                        </div>
                        {c.purpose && <div className="text-[12px] text-ink-400">{c.purpose}</div>}
                        <div className="flex flex-wrap gap-1">
                          {c.transition_in !== "hard_cut" && <Badge tone="signal">{c.transition_in}</Badge>}
                          {c.audio_offset !== "none" && <Badge tone="ok">{c.audio_offset.type} {c.audio_offset.seconds}s</Badge>}
                          {c.keyframe_zoom && <Badge>zoom {c.keyframe_zoom.start_scale}→{c.keyframe_zoom.end_scale}</Badge>}
                          {c.speed !== 1 && <Badge>{c.speed}×</Badge>}
                          {c.broll.length > 0 && <Badge tone="signal">{c.broll.length} B-roll</Badge>}
                          {c.sfx.filter((x) => x.enabled).length > 0 && <Badge tone="warn">{c.sfx.filter((x) => x.enabled).length} SFX</Badge>}
                          {c.captions.length > 0 && <Badge>{c.captions.length} captions</Badge>}
                          {!c.use_audio && <Badge>muted</Badge>}
                        </div>
                      </div>
                      <div className="flex flex-col gap-1">
                        <Button size="sm" variant="ghost" disabled={!!running} onClick={(e) => { e.stopPropagation(); void regen({ kind: "clip", clipId: c.id, instruction: instr }); }}>↻</Button>
                        <Button size="sm" variant="ghost" className="text-bad" onClick={(e) => { e.stopPropagation(); mutate((x) => { x.sections[si].clips.splice(ci, 1); if (!x.sections[si].clips.length) x.sections.splice(si, 1); }); }}>✕</Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Panel>
          ))}
        </div>

        <div className="space-y-4">
          <Panel title="Regenerate">
            <div className="space-y-3">
              <input className="field" placeholder="Optional instruction for section/clip regeneration" value={instr} onChange={(e) => setInstr(e.target.value)} />
              <div className="flex flex-wrap gap-1.5">
                {MODIFIERS.map(([k, l]) => <Button key={k} size="sm" disabled={!!running} onClick={() => regen({ kind: "modifier", modifier: k })}>{l}</Button>)}
              </div>
              <Button className="w-full" disabled={!!running} onClick={() => regen({ kind: "full" })}>↻ Regenerate entire edit</Button>
              {job && (running || job.status === "failed") && (
                <div className="space-y-1.5 rounded border border-ink-700 p-2.5">
                  <div className="flex items-center gap-2 text-[12px]"><StatusDot status={job.status} />{job.title}</div>
                  {running && <Progress value={job.progress} active />}
                  {job.error && <div className="text-[12px] text-bad">{job.error.message}</div>}
                </div>
              )}
              <p className="text-[11px] text-ink-500">Section/clip regeneration splices only that part; everything else stays byte-identical. “Fewer effects” and “Stronger captions” run locally without AI.</p>
            </div>
          </Panel>

          {selClip && (
            <Panel title={`Clip · ${selClip.c.id}`}>
              <div className="space-y-3">
                <Field label="Source (replace clip)">
                  <select className="field" value={selClip.c.source_file} onChange={(e) => mutClip(selClip.c.id!, (c) => { c.source_file = e.target.value; })}>{visuals.map((m) => <option key={m.id}>{m.filename}</option>)}</select>
                </Field>
                <div className="grid grid-cols-3 gap-2">
                  <Field label="In (s)"><input className="field tc" type="number" step="0.05" value={selClip.c.in_s} onChange={(e) => mutClip(selClip.c.id!, (c) => { c.in_s = +e.target.value; })} /></Field>
                  <Field label="Out (s)"><input className="field tc" type="number" step="0.05" value={selClip.c.out_s} onChange={(e) => mutClip(selClip.c.id!, (c) => { c.out_s = +e.target.value; })} /></Field>
                  <Field label="Speed"><input className="field tc" type="number" step="0.05" value={selClip.c.speed} onChange={(e) => mutClip(selClip.c.id!, (c) => { c.speed = +e.target.value || 1; })} /></Field>
                </div>
                <Field label="Section">
                  <select className="field" value={selClip.s.id} onChange={(e) => mutate((x) => { const from = x.sections.find((s) => s.id === selClip.s.id)!; const to = x.sections.find((s) => s.id === e.target.value)!; const idx = from.clips.findIndex((c) => c.id === selClip.c.id); const [clip] = from.clips.splice(idx, 1); to.clips.push(clip); x.sections = x.sections.filter((s) => s.clips.length); })}>
                    {edl.sections.map((s, i) => <option key={s.id} value={s.id}>{i + 1}. {s.role}</option>)}
                  </select>
                </Field>
                <Field label="Transition in"><select className="field" value={selClip.c.transition_in} onChange={(e) => mutClip(selClip.c.id!, (c) => { c.transition_in = e.target.value as typeof c.transition_in; })}>{TRANSITIONS.map((t) => <option key={t}>{t}</option>)}</select></Field>
                <div className="flex flex-col gap-2">
                  <Toggle checked={!!selClip.c.keyframe_zoom} onChange={(on) => mutClip(selClip.c.id!, (c) => { c.keyframe_zoom = on ? { start_scale: 1, end_scale: 1.05 } : null; })} label="Subtle punch-in (1.00 → 1.05, eased)" />
                  <Toggle checked={selClip.c.use_audio} onChange={(on) => mutClip(selClip.c.id!, (c) => { c.use_audio = on; })} label="Use clip audio (dialogue)" />
                  <Toggle checked={selClip.c.sfx.every((x) => x.enabled)} onChange={(on) => mutClip(selClip.c.id!, (c) => { c.sfx.forEach((x) => (x.enabled = on)); })} label={`SFX enabled (${selClip.c.sfx.length})`} />
                  {selClip.c.captions.length > 0 && <Button size="sm" variant="ghost" onClick={() => mutClip(selClip.c.id!, (c) => { c.captions = []; })}>Reset captions to auto (from transcript)</Button>}
                </div>
                {selClip.c.captions.length > 0 && <div className="space-y-1 text-[11.5px] text-ink-300">{selClip.c.captions.map((cap, i) => <div key={i}>“{cap.text}” <span className="tc text-ink-500">{cap.start_s.toFixed(2)}s</span></div>)}</div>}
              </div>
            </Panel>
          )}

          <Panel title="Project look & sound">
            <div className="space-y-3">
              <Field label="Target duration (s)"><input className="field tc" type="number" value={edl.project.target_duration_s} onChange={(e) => mutate((x) => { x.project.target_duration_s = Math.max(1, +e.target.value); })} /></Field>
              <Field label="Colour mood"><select className="field" value={edl.color_grade_mood} onChange={(e) => mutate((x) => { x.color_grade_mood = e.target.value as typeof x.color_grade_mood; })}>{COLOR_MOODS.map((c) => <option key={c}>{c}</option>)}</select></Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Vignette"><input className="field tc" type="number" min={0} max={100} value={edl.look.vignette} onChange={(e) => mutate((x) => { x.look.vignette = +e.target.value; })} /></Field>
                <Field label="Look intensity"><input className="field tc" type="number" min={0} max={100} value={edl.look.intensity} onChange={(e) => mutate((x) => { x.look.intensity = +e.target.value; })} /></Field>
              </div>
              <Toggle checked={edl.look.normalize} onChange={(on) => mutate((x) => { x.look.normalize = on; })} label="Normalise exposure before the look" />
              <div className="border-t border-ink-700 pt-3" />
              <Toggle checked={edl.captions.enabled} onChange={(on) => mutate((x) => { x.captions.enabled = on; })} label="Captions" />
              <div className="grid grid-cols-3 gap-2">
                <Field label="Mode"><select className="field" value={edl.captions.mode} onChange={(e) => mutate((x) => { x.captions.mode = e.target.value as typeof x.captions.mode; })}>{CAPTION_MODES.map((c) => <option key={c}>{c}</option>)}</select></Field>
                <Field label="Words"><input className="field tc" type="number" min={1} max={12} value={edl.captions.max_words} onChange={(e) => mutate((x) => { x.captions.max_words = +e.target.value; })} /></Field>
                <Field label="Position"><select className="field" value={edl.captions.position} onChange={(e) => mutate((x) => { x.captions.position = e.target.value as typeof x.captions.position; })}>{CAPTION_POSITIONS.map((c) => <option key={c}>{c}</option>)}</select></Field>
              </div>
              <div className="text-[11.5px] text-ink-400">Emphasis: {edl.captions.emphasis_words.join(", ") || "—"}</div>
              <div className="border-t border-ink-700 pt-3" />
              <Field label={`Music${edl.music_mood ? ` · mood “${edl.music_mood}”` : ""}`}>
                <select className="field" value={edl.music.source_file || ""} onChange={(e) => mutate((x) => { x.music.source_file = e.target.value || null; })}>
                  <option value="">No music</option>
                  {audios.map((m) => <option key={m.id}>{m.filename}</option>)}
                </select>
              </Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Music volume"><input className="field tc" type="number" step="0.05" min={0} max={1} value={edl.music.volume} onChange={(e) => mutate((x) => { x.music.volume = +e.target.value; })} /></Field>
                <div className="pt-6"><Toggle checked={edl.music.duck_under_dialogue} onChange={(on) => mutate((x) => { x.music.duck_under_dialogue = on; })} label="Duck under speech" /></div>
              </div>
            </div>
          </Panel>
          {compiled?.notes?.length ? <div className="space-y-1 text-[11px] text-ink-500">{compiled.notes.map((n, i) => <div key={i}>• {n}</div>)}</div> : null}
        </div>
      </div>
    </div>
  );
}

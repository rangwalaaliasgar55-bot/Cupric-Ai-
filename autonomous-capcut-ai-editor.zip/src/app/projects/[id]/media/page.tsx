"use client";
import { useMemo, useRef, useState } from "react";
import { api } from "@/components/hooks";
import { Badge, Button, Empty, ErrorBox, Panel, StatusDot, cx, fileUrl, fmtBytes, fmtTime } from "@/components/ui";
import { useProject } from "@/features/project/ProjectContext";
import { MediaImporter } from "@/features/media/MediaImporter";
import type { MediaItem } from "@/shared/types";

type Hit = { mediaId: string; filename: string; score: number; reasons: string[]; matches: { start: number; end: number; text: string }[] };

function Waveform({ data, silences, duration, onSeek }: { data: number[]; silences?: { start_s: number; end_s: number }[]; duration: number; onSeek?: (t: number) => void }) {
  return (
    <div className="relative h-14 cursor-pointer rounded bg-ink-850" onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); onSeek?.(((e.clientX - r.left) / r.width) * duration); }}>
      {silences?.map((s, i) => <div key={i} className="absolute inset-y-0 bg-ink-700/60" style={{ left: `${(s.start_s / duration) * 100}%`, width: `${((s.end_s - s.start_s) / duration) * 100}%` }} title="silence" />)}
      <div className="absolute inset-0 flex items-center gap-px px-px">
        {data.map((v, i) => <div key={i} className="flex-1 rounded-sm bg-signal/70" style={{ height: `${Math.max(3, v * 100)}%` }} />)}
      </div>
    </div>
  );
}

function Preview({ m, onClose }: { m: MediaItem; onClose: () => void }) {
  const { reload } = useProject();
  const video = useRef<HTMLVideoElement & HTMLAudioElement>(null);
  const [t, setT] = useState(0);
  const [err, setErr] = useState<{ message: string; code?: string } | null>(null);
  const [edit, setEdit] = useState<number | null>(null);
  const [editText, setEditText] = useState("");
  const [showImport, setShowImport] = useState(false);
  const [importText, setImportText] = useState("");
  const [locate, setLocate] = useState("");
  const segs = m.transcript?.segments || [];
  const dur = m.durationS || 1;
  const seek = (s: number) => { if (video.current) { video.current.currentTime = s; void video.current.play().catch(() => {}); } };
  const act = async (body: Record<string, unknown>) => {
    setErr(null);
    try {
      await api(`/api/media/${m.id}`, "POST", body);
      await reload();
      return true;
    } catch (e) {
      setErr(e as { message: string });
      return false;
    }
  };
  const a = m.analysis;
  return (
    <aside className="fade-up flex w-[440px] shrink-0 flex-col border-l border-ink-700 bg-ink-900">
      <div className="flex h-10 items-center justify-between border-b border-ink-700 px-4">
        <div className="truncate font-medium">{m.filename}</div>
        <Button size="sm" variant="ghost" onClick={onClose}>✕</Button>
      </div>
      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4">
        <div className="overflow-hidden rounded-md bg-black">
          {m.kind === "video" && <video ref={video} src={fileUrl(m.path)} controls className="max-h-[300px] w-full" onTimeUpdate={(e) => setT(e.currentTarget.currentTime)} />}
          {m.kind === "audio" && <audio ref={video} src={fileUrl(m.path)} controls className="w-full" onTimeUpdate={(e) => setT(e.currentTarget.currentTime)} />}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {m.kind === "image" && <img src={fileUrl(m.path)} alt="" className="max-h-[300px] w-full object-contain" />}
        </div>
        {a?.audio?.waveform && <Waveform data={a.audio.waveform} silences={a.audio.silences} duration={dur} onSeek={seek} />}
        <div className="grid grid-cols-3 gap-x-3 gap-y-2.5 text-[12px]">
          {[["Duration", fmtTime(m.durationS)], ["Resolution", m.width ? `${m.width}×${m.height}` : "—"], ["FPS", m.fps ? `${m.fps}${m.variableFps ? " VFR" : ""}` : "—"], ["Codec", m.codec || m.audioCodec || "—"], ["Audio", m.hasAudio ? m.audioCodec : "none"], ["Size", fmtBytes(m.sizeBytes)], ["Aspect", m.aspectRatio || "—"], ["Shot", a?.classification?.shot_type?.replace(/_/g, " ") || "—"], ["Level", a?.audio?.mean_db !== undefined ? `${a.audio.mean_db} dB` : "—"]].map(([k, v]) => (
            <div key={k}><div className="label">{k}</div><div className="tc mt-0.5 truncate text-ink-100">{v}</div></div>
          ))}
        </div>
        <div className="tc truncate text-[10.5px] text-ink-500" title={m.path}>{m.path}</div>
        {a?.description && <p className="text-[12px] text-ink-300">{a.description}</p>}
        {!!a?.scenes_s?.length && (
          <div>
            <div className="label mb-1.5">Scene boundaries</div>
            <div className="flex flex-wrap gap-1">{a.scenes_s.slice(0, 30).map((s) => <button key={s} onClick={() => seek(s)} className="tc rounded bg-ink-800 px-1.5 py-0.5 text-[11px] hover:bg-ink-700">{fmtTime(s)}</button>)}</div>
          </div>
        )}
        {(m.warnings || []).length > 0 && (
          <div className="space-y-1.5">
            {(m.warnings || []).map((w, i) => <div key={i} className={cx("rounded border px-2.5 py-1.5 text-[12px]", w.severity === "error" ? "border-bad/40 text-bad" : w.severity === "warning" ? "border-warn/40 text-warn" : "border-ink-600 text-ink-300")}>{w.message}</div>)}
          </div>
        )}
        {m.analysisError && (
          <div className="space-y-2">
            <ErrorBox error={{ message: `Analysis failed: ${m.analysisError}` }} actions={<Button size="sm" onClick={() => act({ action: "reanalyze" })}>Retry analysis</Button>} />
            <div className="flex gap-2"><input className="field tc text-[12px]" placeholder="Locate file: new absolute path" value={locate} onChange={(e) => setLocate(e.target.value)} /><Button size="sm" onClick={() => act({ action: "locate", path: locate })}>Locate</Button></div>
          </div>
        )}
        <ErrorBox error={err} />
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={() => act({ action: "reanalyze" })}>Re-analyze</Button>
          {m.hasAudio && <Button size="sm" onClick={() => act({ action: "retranscribe" })}>Re-transcribe</Button>}
          <Button size="sm" onClick={() => setShowImport(!showImport)}>Import transcript</Button>
          <Button size="sm" variant="danger" onClick={async () => { if (confirm(`Remove ${m.filename} from the project? The file on disk is not deleted.`)) { await api(`/api/media/${m.id}`, "DELETE"); onClose(); await reload(); } }}>Remove</Button>
        </div>
        {showImport && (
          <div className="space-y-2">
            <textarea className="field tc h-32 text-[11.5px]" placeholder="Paste SRT, WebVTT or JSON (word list or segments)…" value={importText} onChange={(e) => setImportText(e.target.value)} />
            <Button size="sm" variant="primary" onClick={async () => (await act({ action: "import_transcript", text: importText })) && setShowImport(false)}>Import</Button>
          </div>
        )}
        <div>
          <div className="mb-2 flex items-center justify-between">
            <div className="label">Transcript</div>
            <div className="flex items-center gap-2 text-[11px] text-ink-400"><StatusDot status={m.transcriptStatus} />{m.transcriptStatus.replace("_", " ")}{m.transcript?.language ? ` · ${m.transcript.language}` : ""}{m.transcript?.source ? ` · ${m.transcript.source}` : ""}</div>
          </div>
          {m.transcriptError && <ErrorBox error={{ message: `Transcription failed: ${m.transcriptError}` }} actions={<><Button size="sm" onClick={() => act({ action: "retranscribe" })}>Retry</Button><Button size="sm" onClick={() => setShowImport(true)}>Import transcript manually</Button></>} />}
          {m.transcriptStatus === "done" && segs.length === 0 && <div className="text-[12px] text-ink-400">No speech detected.</div>}
          {m.transcript?.interpolated_word_timings && <div className="mb-2 text-[11px] text-warn">Word timings interpolated from cue timings (manual import).</div>}
          <div className="space-y-1">
            {segs.map((s) => (
              <div key={s.id} className={cx("group rounded px-2 py-1.5", t >= s.start && t < s.end ? "bg-accent/10" : "hover:bg-ink-850")}>
                <div className="flex items-center gap-2">
                  <button className="tc text-[10.5px] text-signal hover:underline" onClick={() => seek(s.start)}>{fmtTime(s.start)}</button>
                  <button className="ml-auto text-[10.5px] text-ink-500 opacity-0 hover:text-ink-200 group-hover:opacity-100" onClick={() => { setEdit(s.id); setEditText(s.text); }}>edit</button>
                </div>
                {edit === s.id ? (
                  <div className="mt-1 flex gap-1.5"><input className="field text-[12px]" value={editText} onChange={(e) => setEditText(e.target.value)} /><Button size="sm" onClick={async () => (await act({ action: "edit_segment", segmentId: s.id, text: editText })) && setEdit(null)}>Save</Button></div>
                ) : (
                  <p className="mt-0.5 leading-relaxed text-ink-200">
                    {s.words?.length ? s.words.map((w, i) => (
                      <span key={i} onClick={() => seek(w.start)} title={`${w.start.toFixed(2)}–${w.end.toFixed(2)}s · conf ${w.confidence ?? "—"}`} className={cx("cursor-pointer rounded-sm hover:bg-ink-700", t >= w.start && t < w.end && "bg-accent/40 text-ink-50", (w.confidence ?? 1) < 0.5 && "underline decoration-warn/60 decoration-dotted")}>{w.word} </span>
                    )) : s.text}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
}

export default function MediaPage() {
  const { detail, reload } = useProject();
  const [sel, setSel] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [kind, setKind] = useState("");
  const [hits, setHits] = useState<Hit[] | null>(null);
  const [showImport, setShowImport] = useState(detail.media.length === 0);
  const selected = detail.media.find((m) => m.id === sel) || null;
  const search = async (query: string, k: string) => {
    if (!query.trim() && !k) return setHits(null);
    const r = await api<{ hits: Hit[] }>(`/api/projects/${detail.project.id}`, "POST", { action: "search", q: query, kind: k });
    setHits(r.hits);
  };
  const list = useMemo(() => (hits ? hits.map((h) => detail.media.find((m) => m.id === h.mediaId)).filter(Boolean) as MediaItem[] : detail.media), [hits, detail.media]);
  const problems = detail.media.flatMap((m) => (m.warnings || []).filter((w) => w.severity !== "info").map((w) => ({ ...w, file: m.filename })));

  return (
    <div className="flex h-full">
      <div className="min-w-0 flex-1 space-y-4 overflow-y-auto p-6">
        <div className="flex items-center gap-2">
          <input className="field max-w-md" placeholder='Search footage — filename, transcript words, scene… e.g. "product dashboard"' value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && search(q, kind)} />
          <select className="field w-36" value={kind} onChange={(e) => { setKind(e.target.value); void search(q, e.target.value); }}>
            <option value="">All types</option><option value="video">Video</option><option value="audio">Audio</option><option value="image">Image</option>
          </select>
          <Button onClick={() => search(q, kind)}>Search</Button>
          {hits && <Button variant="ghost" onClick={() => { setQ(""); setKind(""); setHits(null); }}>Clear</Button>}
          <Button variant="primary" className="ml-auto" onClick={() => setShowImport(!showImport)}>+ Import media</Button>
        </div>
        {showImport && <Panel title="Import media"><MediaImporter projectId={detail.project.id} compact onQueued={() => { setShowImport(false); void reload(); }} /></Panel>}
        {problems.length > 0 && (
          <div className="rounded-lg border border-warn/30 bg-warn/[0.05] px-4 py-3">
            <div className="label mb-1.5 text-warn">{problems.length} media issue(s) detected</div>
            <ul className="space-y-0.5 text-[12px] text-ink-200">{problems.slice(0, 6).map((p, i) => <li key={i}>• {p.message}</li>)}</ul>
          </div>
        )}
        {detail.media.length === 0 && !showImport && <Empty title="No media yet" action={<Button variant="primary" onClick={() => setShowImport(true)}>Import media</Button>}>Drop footage to start. Every file is probed, analysed and transcribed locally.</Empty>}
        {hits && <div className="text-[12px] text-ink-400">{hits.length} result(s)</div>}
        <div className="grid grid-cols-[repeat(auto-fill,minmax(210px,1fr))] gap-3">
          {list.map((m) => {
            const hit = hits?.find((h) => h.mediaId === m.id);
            const bad = !m.readable;
            return (
              <button key={m.id} onClick={() => setSel(m.id)} className={cx("overflow-hidden rounded-md border bg-ink-900 text-left transition-colors", sel === m.id ? "border-accent/70" : bad ? "border-bad/50" : "border-ink-700 hover:border-ink-500")}>
                <div className="relative aspect-video bg-ink-850">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  {m.thumbnail ? <img src={fileUrl(m.thumbnail)} alt="" className="h-full w-full object-cover" /> : m.kind === "audio" && m.analysis?.audio?.waveform ? (
                    <div className="flex h-full items-center gap-px px-2">{m.analysis.audio.waveform.filter((_, i) => i % 3 === 0).map((v, i) => <div key={i} className="flex-1 bg-signal/60" style={{ height: `${Math.max(4, v * 90)}%` }} />)}</div>
                  ) : <div className="grid h-full place-items-center text-[11px] uppercase tracking-widest text-ink-500">{m.analysisStatus === "running" ? "analysing…" : m.kind}</div>}
                  <div className="absolute left-1.5 top-1.5 flex gap-1">
                    <Badge tone={m.kind === "video" ? "signal" : m.kind === "audio" ? "accent" : "neutral"}>{m.kind}</Badge>
                    {bad && <Badge tone="bad">unreadable</Badge>}
                    {(m.warnings || []).some((w) => w.code === "DUPLICATE") && <Badge tone="warn">dup</Badge>}
                  </div>
                  {m.durationS && <div className="tc absolute bottom-1.5 right-1.5 rounded bg-black/75 px-1 text-[10.5px]">{fmtTime(m.durationS)}</div>}
                </div>
                <div className="space-y-1.5 p-2.5">
                  <div className="truncate text-[12.5px] font-medium">{m.filename}</div>
                  <div className="flex items-center gap-3 text-[10.5px] text-ink-400">
                    <span className="flex items-center gap-1"><StatusDot status={m.analysisStatus} />analysis</span>
                    <span className="flex items-center gap-1"><StatusDot status={m.transcriptStatus} />{m.transcriptStatus === "done" ? `${m.transcriptWordCount} words` : "transcript"}</span>
                    {m.analysis?.classification?.shot_type && <span className="ml-auto truncate">{m.analysis.classification.shot_type.replace(/_/g, " ")}</span>}
                  </div>
                  {hit && hit.matches[0] && <div className="line-clamp-2 text-[11px] text-ink-300">“{hit.matches[0].text}” <span className="tc text-signal">{fmtTime(hit.matches[0].start)}</span></div>}
                  {hit && !hit.matches.length && hit.reasons.length > 0 && <div className="text-[11px] text-ink-400">{hit.reasons.join(" · ")}</div>}
                </div>
              </button>
            );
          })}
        </div>
      </div>
      {selected && <Preview key={selected.id} m={selected} onClose={() => setSel(null)} />}
    </div>
  );
}

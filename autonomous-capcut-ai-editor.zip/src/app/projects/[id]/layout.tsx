import type { ReactNode } from "react";
import { ProjectProvider } from "@/features/project/ProjectContext";

export default async function ProjectLayout({ children, params }: { children: ReactNode; params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <ProjectProvider id={id}>{children}</ProjectProvider>;
}

"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/components/hooks";
import { Badge, Button, ErrorBox, Panel, Progress, Toggle, cx, fmtTime } from "@/components/ui";
import { useProject } from "@/features/project/ProjectContext";
import { useLatestJob } from "@/features/generation/useJob";

function Elapsed({ from, to }: { from: string | null; to: string | null }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (to) return;
    const t = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(t);
  }, [to]);
  if (!from) return <>—</>;
  return <>{fmtTime(((to ? new Date(to).getTime() : now) - new Date(from).getTime()) / 1000)}</>;
}

export default function GeneratePage() {
  const { detail, reload } = useProject();
  const router = useRouter();
  const p = detail.project;
  const [perVersion, setPerVersion] = useState(false);
  const [err, setErr] = useState<{ message: string; code?: string } | null>(null);
  const [locatePath, setLocatePath] = useState("");
  const [copied, setCopied] = useState(false);
  const [sysMsg, setSysMsg] = useState<{ message: string; code?: string } | null>(null);
  const { job } = useLatestJob(p.id, "build_draft", () => void reload());
  const running = job && (job.status === "running" || job.status === "queued");
  const v = detail.current?.validation;
  const pipelineReady = { analysed: detail.media.length > 0 && detail.media.every((m) => !["queued", "running"].includes(m.analysisStatus)), transcribed: detail.media.every((m) => !["queued", "running"].includes(m.transcriptStatus)), planned: !!detail.current, valid: !!v?.ok };

  const generate = async () => {
    setErr(null);
    try {
      await api(`/api/projects/${p.id}`, "POST", { action: "generate", newDraftPerVersion: perVersion });
    } catch (e) {
      setErr(e as { message: string });
    }
  };
  const sys = async (action: string, path?: string) => {
    setSysMsg(null);
    try {
      await api("/api/system", "POST", { action, path });
    } catch (e) {
      setSysMsg(e as { message: string });
    }
  };
  const errFile = (job?.error?.details as { filename?: string } | undefined)?.filename;
  const errMedia = detail.media.find((m) => m.filename === errFile);
  const result = job?.status === "succeeded" ? (job.result as { draftPath: string; backupPath: string | null; number: number; draftName: string }) : null;
  const eta = job && job.status === "running" && job.startedAt && job.progress > 5 ? ((Date.now() - new Date(job.startedAt).getTime()) / 1000) * (100 / job.progress - 1) : null;
  const pre = [
    ["Analyzing footage", pipelineReady.analysed],
    ["Transcribing", pipelineReady.transcribed],
    ["AI Director / edit plan", pipelineReady.planned],
    ["Validating EDL", pipelineReady.valid],
  ] as const;

  return (
    <div className="mx-auto grid max-w-[1200px] grid-cols-[1fr_380px] gap-5 p-6">
      <div className="space-y-5">
        <Panel title="Generation center" actions={job && <Badge tone={job.status === "succeeded" ? "ok" : job.status === "failed" ? "bad" : running ? "accent" : "neutral"}>{job.status}</Badge>}>
          <div className="space-y-1">
            {pre.map(([l, ok]) => (
              <div key={l} className="flex h-8 items-center gap-3 border-b border-ink-700/50">
                <span className={cx("grid h-4 w-4 place-items-center rounded-full text-[10px]", ok ? "bg-ok text-ink-950" : "border border-ink-500")}>{ok ? "✓" : ""}</span>
                <span className={ok ? "text-ink-200" : "text-ink-400"}>{l}</span>
              </div>
            ))}
            {(job?.stages || []).map((s) => (
              <div key={s.key} className="flex h-8 items-center gap-3 border-b border-ink-700/50 last:border-0">
                <span className={cx("grid h-4 w-4 place-items-center rounded-full text-[10px]", s.status === "done" && "bg-ok text-ink-950", s.status === "running" && "bg-accent pulse-dot", s.status === "failed" && "bg-bad text-ink-950", (s.status === "pending" || s.status === "skipped") && "border border-ink-500")}>{s.status === "done" ? "✓" : s.status === "failed" ? "!" : ""}</span>
                <span className={s.status === "running" ? "font-medium text-ink-100" : s.status === "done" ? "text-ink-200" : s.status === "failed" ? "text-bad" : "text-ink-400"}>{s.label}</span>
              </div>
            ))}
          </div>
          {job && (
            <div className="mt-4 space-y-2">
              <Progress value={job.progress} active={!!running} tone={job.status === "failed" ? "bad" : job.status === "succeeded" ? "ok" : "accent"} />
              <div className="flex items-center gap-4 text-[12px] text-ink-400">
                <span className="truncate">{job.message || "—"}</span>
                <span className="tc ml-auto shrink-0">elapsed <Elapsed from={job.startedAt} to={job.finishedAt} /></span>
                {eta !== null && <span className="tc shrink-0">~{fmtTime(eta)} left</span>}
                {running && <Button size="sm" variant="danger" onClick={() => api(`/api/jobs/${job.id}`, "POST", { action: "cancel" })}>Cancel</Button>}
              </div>
            </div>
          )}
        </Panel>

        {job?.status === "failed" && job.error && (
          <ErrorBox error={job.error} actions={<>
            {job.error.actions?.includes("retry") && <Button size="sm" onClick={generate}>Retry</Button>}
            {job.error.actions?.includes("skip") && errFile && <Button size="sm" onClick={async () => { await api(`/api/projects/${p.id}`, "POST", { action: "skip_file", filename: errFile }); await reload(); await generate(); }}>Skip {errFile}</Button>}
            {job.error.actions?.includes("settings") && <Button size="sm" onClick={() => router.push("/settings")}>Open Settings</Button>}
            {job.error.actions?.includes("edit_plan") && <Button size="sm" onClick={() => router.push(`/projects/${p.id}/plan`)}>Fix edit plan</Button>}
            {job.error.actions?.includes("cancel") && <Button size="sm" variant="ghost" onClick={() => router.push(`/projects/${p.id}/plan`)}>Cancel generation</Button>}
            {job.error.actions?.includes("locate") && errMedia && (
              <span className="flex gap-1.5"><input className="field tc h-7 w-72 py-0 text-[11.5px]" placeholder={`New path for ${errFile}`} value={locatePath} onChange={(e) => setLocatePath(e.target.value)} /><Button size="sm" onClick={async () => { try { await api(`/api/media/${errMedia.id}`, "POST", { action: "locate", path: locatePath }); await reload(); await generate(); } catch (e) { setErr(e as { message: string }); } }}>Locate file</Button></span>
            )}
          </>} />
        )}

        {result && (
          <Panel title="Draft ready">
            <div className="space-y-4">
              <div>
                <div className="text-[16px] font-semibold">Your CapCut project has been generated successfully.</div>
                <div className="mt-1 text-ink-300">Draft <span className="font-medium text-ink-100">“{result.draftName}”</span> · version v{String(result.number).padStart(3, "0")}</div>
                <div className="tc mt-2 break-all rounded bg-ink-950 px-2.5 py-2 text-[11.5px] text-ink-200">{result.draftPath}</div>
                {result.backupPath && <div className="mt-1.5 text-[11.5px] text-ink-400">Previous draft backed up to <span className="tc">{result.backupPath}</span></div>}
              </div>
              <div className="flex flex-wrap gap-2">
                <Button onClick={() => sys("open_folder", result.draftPath)}>Open Draft Folder</Button>
                <Button onClick={() => sys("open_capcut")}>Open CapCut</Button>
                <Button onClick={async () => { await navigator.clipboard.writeText(result.draftPath).catch(() => {}); setCopied(true); setTimeout(() => setCopied(false), 1500); }}>{copied ? "Copied ✓" : "Copy Project Path"}</Button>
                <Button variant="primary" onClick={() => router.push(`/projects/${p.id}/plan`)}>Generate New Version</Button>
              </div>
              <ErrorBox error={sysMsg} />
              <div className="rounded-md border border-ink-700 bg-ink-850 p-3 text-[12px] leading-relaxed text-ink-300">
                <b className="text-ink-100">Final export happens in CapCut.</b> Open CapCut, pick the draft from your project list, review the edit, then use CapCut&apos;s Export button. Current CapCut versions don&apos;t offer a supported programmatic export, so Cutline deliberately stops at a validated draft rather than automating clicks. Drafts are written by pyJianYingDraft; very recent CapCut builds that encrypt their draft files may not open externally generated drafts — if the draft doesn&apos;t appear, use a CapCut version supported by pyJianYingDraft.
              </div>
            </div>
          </Panel>
        )}
      </div>

      <div className="space-y-5">
        <Panel title="Generate CapCut draft">
          <div className="space-y-3">
            <div className="text-[12px] text-ink-300">Plan: <span className="text-ink-100">{detail.current?.label || "none"}</span></div>
            <div className="text-[12px] text-ink-300">Draft folder: <span className="tc break-all text-ink-200">{detail.draftDir}</span></div>
            <Toggle checked={perVersion} onChange={setPerVersion} label="Create a separate CapCut draft per version" />
            <p className="text-[11px] text-ink-500">{perVersion ? `Creates “${p.draftName} v###”.` : `Updates “${p.draftName}”. The existing draft is copied to a timestamped backup first, and only replaced after the new one is built and validated.`}</p>
            <Button variant="primary" size="lg" className="w-full" disabled={!!running || !pipelineReady.valid} onClick={generate}>{running ? "Generating…" : "GENERATE CAPCUT DRAFT"}</Button>
            {!pipelineReady.valid && <div className="text-[12px] text-warn">{detail.current ? "The current edit plan has validation errors — fix them in Edit Plan." : "Create an edit plan first."}</div>}
            <ErrorBox error={err} />
          </div>
        </Panel>
        {job?.log && (
          <Panel title="Log">
            <pre className="tc max-h-[420px] overflow-auto whitespace-pre-wrap text-[10.5px] leading-relaxed text-ink-400">{job.log.split("\n").slice(-80).join("\n")}</pre>
          </Panel>
        )}
      </div>
    </div>
  );
}

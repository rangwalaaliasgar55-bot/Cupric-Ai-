"use client";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/components/hooks";
import { Badge, Button, Empty, ErrorBox, Panel, ago, cx, fmtTime } from "@/components/ui";
import { useProject } from "@/features/project/ProjectContext";
import type { Version } from "@/shared/types";

function summarize(v: Version) {
  const clips = v.edl.sections.flatMap((s) => s.clips.map((c) => ({ ...c, role: s.role })));
  return {
    clips,
    duration: clips.reduce((a, c) => a + (c.out_s - c.in_s) / c.speed, 0),
    sections: v.edl.sections.map((s) => s.role).join(" → "),
    sfx: clips.reduce((a, c) => a + c.sfx.length, 0),
    broll: clips.reduce((a, c) => a + c.broll.length, 0),
  };
}

export default function HistoryPage() {
  const { detail, reload } = useProject();
  const router = useRouter();
  const p = detail.project;
  const [cmp, setCmp] = useState<string[]>([]);
  const [err, setErr] = useState<{ message: string; code?: string } | null>(null);
  const [msg, setMsg] = useState("");
  const act = async (body: Record<string, unknown>, ok: string) => {
    setErr(null);
    try {
      await api(`/api/projects/${p.id}`, "POST", body);
      setMsg(ok);
      await reload();
    } catch (e) {
      setErr(e as { message: string });
    }
  };
  const pair = useMemo(() => cmp.map((id) => detail.versions.find((v) => v.id === id)).filter(Boolean) as Version[], [cmp, detail.versions]);

  if (!detail.versions.length) return <div className="mx-auto max-w-3xl p-8"><Empty title="No versions yet" action={<Button variant="primary" onClick={() => router.push(`/projects/${p.id}/generate`)}>Go to Generate</Button>}>Every CapCut draft generation is stored as a version with its EDL, settings, media references, prompt version and app version.</Empty></div>;

  return (
    <div className="mx-auto max-w-[1200px] space-y-5 p-6">
      <ErrorBox error={err} />
      {msg && <div className="rounded border border-ok/30 px-3 py-2 text-[12px] text-ok">{msg}</div>}
      <Panel title="Versions" actions={<span className="text-[11px] text-ink-400">Select two to compare</span>} pad={false}>
        <div className="divide-y divide-ink-700/70">
          {detail.versions.map((v) => {
            const s = summarize(v);
            return (
              <div key={v.id} className="grid grid-cols-[28px_70px_1fr_auto] items-center gap-4 px-4 py-3">
                <input type="checkbox" className="accent-[#e8b44c]" checked={cmp.includes(v.id)} onChange={(e) => setCmp((c) => (e.target.checked ? [...c, v.id].slice(-2) : c.filter((x) => x !== v.id)))} />
                <div className="tc text-[15px] font-semibold">v{String(v.number).padStart(3, "0")}</div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Badge tone={v.status === "succeeded" ? "ok" : "bad"}>{v.status}</Badge>
                    <span className="text-ink-300">{new Date(v.createdAt).toLocaleString()} · {ago(v.createdAt)}</span>
                  </div>
                  <div className="mt-1 truncate text-[12px] text-ink-400">{s.sections} · {s.clips.length} clips · {fmtTime(s.duration)} · {v.edl.color_grade_mood} · prompt {v.promptVersion} · app {v.appVersion}</div>
                  {v.draftPath && <div className="tc mt-0.5 truncate text-[11px] text-ink-500">{v.draftPath}</div>}
                  {v.report?.error && <div className="mt-0.5 text-[12px] text-bad">{v.report.error.message}</div>}
                  {v.report?.unsupported?.length ? <div className="mt-0.5 text-[11px] text-warn">{v.report.unsupported.join(" · ")}</div> : null}
                </div>
                <div className="flex gap-1.5">
                  <Button size="sm" onClick={() => act({ action: "restore_version", versionId: v.id }, `Plan from v${v.number} restored as the current edit plan.`)}>Restore plan</Button>
                  <Button size="sm" onClick={async () => { await act({ action: "restore_version", versionId: v.id }, `v${v.number} duplicated into a new editable plan.`); router.push(`/projects/${p.id}/plan`); }}>Duplicate</Button>
                  {v.backupPath && <Button size="sm" variant="ghost" onClick={() => confirm(`Restore the CapCut draft backup taken before v${v.number}? The current draft is backed up first.`) && act({ action: "restore_draft_backup", versionId: v.id }, "Draft restore queued (current draft backed up first).")}>Restore draft backup</Button>}
                </div>
              </div>
            );
          })}
        </div>
      </Panel>

      {pair.length === 2 && (
        <Panel title={`Compare v${pair[0].number} ↔ v${pair[1].number}`}>
          <div className="grid grid-cols-2 gap-5">
            {pair.map((v, k) => {
              const s = summarize(v);
              const other = summarize(pair[1 - k]);
              const otherKeys = new Set(other.clips.map((c) => `${c.source_file}@${c.in_s}-${c.out_s}`));
              return (
                <div key={v.id} className="space-y-2">
                  <div className="grid grid-cols-4 gap-2 text-[12px]">
                    {[["Duration", fmtTime(s.duration)], ["Clips", s.clips.length], ["B-roll", s.broll], ["SFX", s.sfx]].map(([l, val]) => <div key={String(l)}><div className="label">{l}</div><div className="tc mt-0.5">{val}</div></div>)}
                  </div>
                  <div className="text-[11.5px] text-ink-400">{s.sections} · {v.edl.color_grade_mood} · captions {v.edl.captions.enabled ? v.edl.captions.mode : "off"} · music {v.edl.music.source_file || "none"}</div>
                  <div className="space-y-0.5">
                    {s.clips.map((c, i) => {
                      const changed = !otherKeys.has(`${c.source_file}@${c.in_s}-${c.out_s}`);
                      return <div key={i} className={cx("tc rounded px-2 py-1 text-[11px]", changed ? "bg-accent/10 text-ink-100" : "text-ink-400")}>{c.role.padEnd(8)} {c.source_file} {c.in_s.toFixed(2)}→{c.out_s.toFixed(2)}</div>;
                    })}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-3 text-[11px] text-ink-500">Highlighted clips differ between the two versions.</div>
        </Panel>
      )}
    </div>
  );
}

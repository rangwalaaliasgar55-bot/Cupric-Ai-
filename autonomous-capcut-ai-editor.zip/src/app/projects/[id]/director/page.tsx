"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, usePoll } from "@/components/hooks";
import { Badge, Button, ErrorBox, Field, Panel, Progress, StatusDot, cx, fmtTime } from "@/components/ui";
import { useProject } from "@/features/project/ProjectContext";
import { useLatestJob } from "@/features/generation/useJob";
import type { StylePreset } from "@/db/schema";

type Brief = { style: string; audience: string; platform: string; mustKeep: string; prohibited: string; reference: string; presetName?: string; presetInstructions?: string; presetStructure?: { role: string; share: number }[] | null };
const EMPTY: Brief = { style: "", audience: "", platform: "", mustKeep: "", prohibited: "", reference: "" };

export default function DirectorPage() {
  const { detail, reload } = useProject();
  const router = useRouter();
  const p = detail.project;
  const [brief, setBrief] = useState<Brief>({ ...EMPTY, ...((p.directorBrief || {}) as Partial<Brief>) });
  const [target, setTarget] = useState(p.targetDurationS);
  const [err, setErr] = useState<{ message: string; code?: string } | null>(null);
  const [preview, setPreview] = useState<{ bytes: number; files: number; sample: string } | null>(null);
  const [showSample, setShowSample] = useState(false);
  const { data: s } = usePoll<{ presets: StylePreset[]; gemini: { configured: boolean; hint: string | null }; settings: { ai: { model: string } } }>("/api/settings", 0);
  const { job } = useLatestJob(p.id, "ai_director", (j) => { void reload(); if (j.status === "succeeded") router.push(`/projects/${p.id}/plan`); });
  const running = job && (job.status === "running" || job.status === "queued");

  useEffect(() => {
    api<{ bytes: number; files: number; sample: string }>(`/api/projects/${p.id}`, "POST", { action: "director_preview" }).then(setPreview).catch(() => {});
  }, [p.id, detail.media.length]);

  const save = async () => api(`/api/projects/${p.id}`, "PATCH", { directorBrief: brief, targetDurationS: target });
  const run = async () => {
    setErr(null);
    try {
      await save();
      await api(`/api/projects/${p.id}`, "POST", { action: "director", mode: { kind: "full" } });
    } catch (e) {
      setErr(e as { message: string });
    }
  };
  const pending = detail.media.filter((m) => ["queued", "running"].includes(m.analysisStatus) || ["queued", "running"].includes(m.transcriptStatus)).length;
  const words = detail.media.reduce((a, m) => a + m.transcriptWordCount, 0);
  const set = (k: keyof Brief, v: string) => setBrief((b) => ({ ...b, [k]: v }));

  return (
    <div className="mx-auto grid max-w-[1300px] grid-cols-[1fr_360px] gap-5 p-6">
      <div className="space-y-5">
        <Panel title="Style preset">
          <div className="grid grid-cols-5 gap-2">
            {(s?.presets || []).map((pr) => (
              <button key={pr.id} onClick={() => setBrief((b) => ({ ...b, presetName: b.presetName === pr.name ? undefined : pr.name, presetInstructions: b.presetName === pr.name ? undefined : pr.instructions, presetStructure: b.presetName === pr.name ? null : pr.structure }))} className={cx("rounded-md border p-2.5 text-left transition-colors", brief.presetName === pr.name ? "border-accent/60 bg-accent/[0.07]" : "border-ink-600 hover:border-ink-500")}>
                <div className="text-[12px] font-medium">{pr.name}</div>
                <div className="mt-0.5 line-clamp-2 text-[10.5px] text-ink-400">{pr.description}</div>
                {!pr.builtin && <Badge className="mt-1">custom</Badge>}
              </button>
            ))}
          </div>
          {brief.presetStructure && (
            <div className="mt-4 flex h-8 overflow-hidden rounded border border-ink-600">
              {brief.presetStructure.map((st, i) => (
                <div key={i} className="flex items-center justify-center border-r border-ink-600 text-[10.5px] uppercase tracking-wider text-ink-200 last:border-0" style={{ width: `${st.share * 100}%`, background: `color-mix(in srgb, var(--color-accent) ${8 + i * 5}%, transparent)` }}>
                  {st.role} <span className="tc ml-1 text-ink-400">{fmtTime(st.share * target)}</span>
                </div>
              ))}
            </div>
          )}
        </Panel>
        <Panel title="Editing brief">
          <div className="space-y-4">
            <Field label="Editing style" hint="Describe the edit in your own words — pacing, tone, energy, what matters.">
              <textarea className="field h-24" value={brief.style} onChange={(e) => set("style", e.target.value)} placeholder="Punchy launch teaser. Open on the dashboard reveal, explain the pain in one line, show 3 features fast, end on 'Start free today'." />
            </Field>
            <div className="grid grid-cols-3 gap-4">
              <Field label="Audience"><input className="field" value={brief.audience} onChange={(e) => set("audience", e.target.value)} placeholder="Startup founders, ops leads" /></Field>
              <Field label="Platform"><input className="field" value={brief.platform} onChange={(e) => set("platform", e.target.value)} placeholder="TikTok / Reels" /></Field>
              <Field label="Target duration (s)"><input className="field tc" type="number" value={target} onChange={(e) => setTarget(+e.target.value)} /></Field>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Must-keep moments"><textarea className="field h-20" value={brief.mustKeep} onChange={(e) => set("mustKeep", e.target.value)} placeholder={'The line "we cut reporting time by 80%"'} /></Field>
              <Field label="Prohibited elements"><textarea className="field h-20" value={brief.prohibited} onChange={(e) => set("prohibited", e.target.value)} placeholder="No flash transitions. Don't show the pricing page." /></Field>
            </div>
            <Field label="Reference style (optional)"><input className="field" value={brief.reference} onChange={(e) => set("reference", e.target.value)} placeholder="Like Linear's launch videos: calm, precise, minimal captions" /></Field>
          </div>
        </Panel>
      </div>

      <div className="space-y-5">
        <Panel title="Generate edit plan">
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3 text-[12px]">
              <div><div className="label">Files</div><div className="tc mt-0.5 text-[15px]">{detail.media.filter((m) => m.readable).length}</div></div>
              <div><div className="label">Transcript words</div><div className="tc mt-0.5 text-[15px]">{words}</div></div>
            </div>
            {pending > 0 && <div className="rounded border border-warn/30 px-2.5 py-2 text-[12px] text-warn">{pending} file(s) are still being analysed/transcribed. You can wait, or run now with partial context.</div>}
            {!s?.gemini.configured && <ErrorBox error={{ message: "No Gemini API key configured. Add it in Settings → AI to use the AI Director.", code: "GEMINI_KEY_MISSING" }} actions={<Button size="sm" onClick={() => router.push("/settings")}>Open Settings</Button>} />}
            <Button variant="primary" size="lg" className="w-full" disabled={!!running || !detail.media.length} onClick={run}>{running ? "AI Director working…" : detail.current ? "Generate new edit plan" : "Generate edit plan"}</Button>
            <Button variant="ghost" className="w-full" onClick={async () => { await save(); await reload(); }}>Save brief</Button>
            <ErrorBox error={err} />
            {job && (
              <div className="space-y-2 rounded-md border border-ink-700 bg-ink-850 p-3">
                <div className="flex items-center gap-2 text-[12px]"><StatusDot status={job.status} /><span className="font-medium">{job.title}</span></div>
                {running && <Progress value={job.progress} active />}
                {(job.stages || []).map((st) => <div key={st.key} className="flex items-center gap-2 text-[12px] text-ink-300"><StatusDot status={st.status} />{st.label}</div>)}
                {job.message && running && <div className="text-[11.5px] text-ink-400">{job.message}</div>}
                {job.error && <ErrorBox error={job.error} actions={<Button size="sm" onClick={() => api(`/api/jobs/${job.id}`, "POST", { action: "retry" })}>Retry</Button>} />}
              </div>
            )}
          </div>
        </Panel>
        <Panel title="Privacy — what is sent to Gemini">
          <div className="space-y-2 text-[12px] text-ink-300">
            <p><span className="text-ok">Sent:</span> filenames, durations, resolutions, heuristic shot labels, scene/silence timings, transcript text with word timings, and your brief.</p>
            <p><span className="text-bad">Never sent:</span> video, audio or image files, thumbnails, file-system paths, API keys.</p>
            {preview && <p className="tc text-ink-200">{(preview.bytes / 1024).toFixed(1)} KB context · {preview.files} file(s) · model {s?.settings.ai.model}</p>}
            <Button size="sm" variant="ghost" onClick={() => setShowSample(!showSample)}>{showSample ? "Hide" : "Inspect"} payload</Button>
            {showSample && preview && <pre className="tc max-h-64 overflow-auto whitespace-pre-wrap rounded bg-ink-950 p-2 text-[10.5px] text-ink-300">{preview.sample}{preview.bytes > 4000 ? "\n…" : ""}</pre>}
          </div>
        </Panel>
      </div>
    </div>
  );
}

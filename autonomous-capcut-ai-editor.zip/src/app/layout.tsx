import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Sidebar } from "@/components/Sidebar";
import { JobTray } from "@/components/JobTray";

export const metadata: Metadata = {
  title: "Cutline — Autonomous CapCut AI Editor",
  description: "Raw footage → analysis → transcript → AI edit plan → validated CapCut draft.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="h-screen overflow-hidden bg-ink-950 text-ink-100 antialiased text-[13px]">
        <div className="flex h-full">
          <Sidebar />
          <div className="flex min-w-0 flex-1 flex-col">
            <main className="min-h-0 flex-1 overflow-y-auto">{children}</main>
            <JobTray />
          </div>
        </div>
      </body>
    </html>
  );
}

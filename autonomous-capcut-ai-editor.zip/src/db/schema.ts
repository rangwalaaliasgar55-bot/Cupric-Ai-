import { boolean, doublePrecision, integer, jsonb, pgTable, text, timestamp, uuid, bigint, index } from "drizzle-orm/pg-core";

export const projects = pgTable("projects", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  location: text("location").notNull(),
  aspectRatio: text("aspect_ratio").notNull().default("9:16"),
  width: integer("width").notNull().default(1080),
  height: integer("height").notNull().default(1920),
  fps: integer("fps").notNull().default(30),
  targetDurationS: doublePrecision("target_duration_s").notNull().default(30),
  draftName: text("draft_name").notNull(),
  currentEdlId: uuid("current_edl_id"),
  directorBrief: jsonb("director_brief").$type<Record<string, unknown>>(),
  status: text("status").notNull().default("new"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const media = pgTable(
  "media",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
    filename: text("filename").notNull(),
    path: text("path").notNull(),
    kind: text("kind").notNull(),
    hash: text("hash"),
    sizeBytes: bigint("size_bytes", { mode: "number" }),
    mtimeMs: bigint("mtime_ms", { mode: "number" }),
    durationS: doublePrecision("duration_s"),
    width: integer("width"),
    height: integer("height"),
    fps: doublePrecision("fps"),
    variableFps: boolean("variable_fps").default(false),
    codec: text("codec"),
    audioCodec: text("audio_codec"),
    hasAudio: boolean("has_audio").default(false),
    aspectRatio: text("aspect_ratio"),
    readable: boolean("readable").default(true),
    warnings: jsonb("warnings").$type<{ code: string; severity: string; message: string }[]>().default([]),
    thumbnail: text("thumbnail"),
    analysisStatus: text("analysis_status").notNull().default("pending"),
    analysisKey: text("analysis_key"),
    analysis: jsonb("analysis").$type<Record<string, unknown>>(),
    analysisError: text("analysis_error"),
    transcriptStatus: text("transcript_status").notNull().default("pending"),
    transcriptKey: text("transcript_key"),
    transcript: jsonb("transcript").$type<Record<string, unknown>>(),
    transcriptError: text("transcript_error"),
    transcriptText: text("transcript_text"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("media_project_idx").on(t.projectId)],
);

export const edls = pgTable("edls", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  label: text("label").notNull(),
  source: text("source").notNull(),
  edl: jsonb("edl").$type<Record<string, unknown>>().notNull(),
  validation: jsonb("validation").$type<Record<string, unknown>>(),
  prompt: jsonb("prompt").$type<Record<string, unknown>>(),
  parentId: uuid("parent_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const versions = pgTable("versions", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  number: integer("number").notNull(),
  edlId: uuid("edl_id"),
  edl: jsonb("edl").$type<Record<string, unknown>>().notNull(),
  settings: jsonb("settings").$type<Record<string, unknown>>().notNull(),
  mediaRefs: jsonb("media_refs").$type<Record<string, unknown>[]>().notNull(),
  draftPath: text("draft_path"),
  backupPath: text("backup_path"),
  status: text("status").notNull(),
  report: jsonb("report").$type<Record<string, unknown>>(),
  promptVersion: text("prompt_version"),
  appVersion: text("app_version").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const jobs = pgTable("jobs", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id"),
  type: text("type").notNull(),
  title: text("title").notNull(),
  status: text("status").notNull().default("queued"),
  progress: doublePrecision("progress").notNull().default(0),
  stage: text("stage"),
  message: text("message"),
  stages: jsonb("stages").$type<{ key: string; label: string; status: string }[]>().default([]),
  payload: jsonb("payload").$type<Record<string, unknown>>(),
  result: jsonb("result").$type<Record<string, unknown>>(),
  error: jsonb("error").$type<{ code: string; message: string; details?: unknown; actions?: string[] }>(),
  log: text("log").notNull().default(""),
  startedAt: timestamp("started_at"),
  finishedAt: timestamp("finished_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

/** Secrets are AES-256-GCM encrypted with a machine-local key file; never stored in plaintext. */
export const secrets = pgTable("secrets", {
  key: text("key").primaryKey(),
  ciphertext: text("ciphertext").notNull(),
  iv: text("iv").notNull(),
  tag: text("tag").notNull(),
  hint: text("hint"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const stylePresets = pgTable("style_presets", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  instructions: text("instructions").notNull(),
  structure: jsonb("structure").$type<{ role: string; share: number; note?: string }[]>(),
  builtin: boolean("builtin").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Privacy ledger: exactly what was sent to Gemini and when. */
export const aiRequests = pgTable("ai_requests", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id"),
  model: text("model").notNull(),
  purpose: text("purpose").notNull(),
  bytesSent: integer("bytes_sent").notNull(),
  summary: jsonb("summary").$type<Record<string, unknown>>(),
  status: text("status").notNull(),
  error: text("error"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Project = typeof projects.$inferSelect;
export type Media = typeof media.$inferSelect;
export type Edl = typeof edls.$inferSelect;
export type Version = typeof versions.$inferSelect;
export type Job = typeof jobs.$inferSelect;
export type StylePreset = typeof stylePresets.$inferSelect;

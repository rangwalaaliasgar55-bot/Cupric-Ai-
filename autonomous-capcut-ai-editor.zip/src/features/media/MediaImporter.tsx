"use client";
import { useRef, useState } from "react";
import { api } from "@/components/hooks";
import { Button, ErrorBox, Progress, cx } from "@/components/ui";

/** Drag-and-drop / multi-file upload (streamed into the workspace) + in-place folder/file path import. */
export function MediaImporter({ projectId, onQueued, compact }: { projectId: string; onQueued?: () => void; compact?: boolean }) {
  const [drag, setDrag] = useState(false);
  const [uploads, setUploads] = useState<{ name: string; pct: number; error?: string }[]>([]);
  const [paths, setPaths] = useState("");
  const [err, setErr] = useState<{ message: string; code?: string } | null>(null);
  const input = useRef<HTMLInputElement>(null);

  const upload = async (files: FileList | File[]) => {
    const list = Array.from(files);
    setUploads(list.map((f) => ({ name: f.name, pct: 0 })));
    const done: string[] = [];
    for (let i = 0; i < list.length; i++) {
      const f = list[i];
      await new Promise<void>((resolve) => {
        const xhr = new XMLHttpRequest();
        xhr.open("PUT", `/api/projects/${projectId}/upload?defer=1&name=${encodeURIComponent(f.name)}`);
        xhr.upload.onprogress = (e) => e.lengthComputable && setUploads((u) => u.map((x, k) => (k === i ? { ...x, pct: (e.loaded / e.total) * 100 } : x)));
        xhr.onload = () => {
          let msg: string | undefined;
          try {
            const j = JSON.parse(xhr.responseText);
            if (j.error) msg = j.error.message;
            else done.push(j.path);
          } catch {
            msg = `Upload failed (HTTP ${xhr.status})`;
          }
          setUploads((u) => u.map((x, k) => (k === i ? { ...x, pct: 100, error: msg } : x)));
          resolve();
        };
        xhr.onerror = () => {
          setUploads((u) => u.map((x, k) => (k === i ? { ...x, error: "Connection to the local engine was lost during upload." } : x)));
          resolve();
        };
        xhr.send(f);
      });
    }
    if (done.length) {
      await api(`/api/projects/${projectId}`, "POST", { action: "import_paths", paths: done });
      onQueued?.();
    }
  };

  const importPaths = async () => {
    setErr(null);
    try {
      await api(`/api/projects/${projectId}`, "POST", { action: "import_paths", paths });
      setPaths("");
      onQueued?.();
    } catch (e) {
      setErr(e as { message: string });
    }
  };

  return (
    <div className="space-y-3">
      <div
        onDragOver={(e) => (e.preventDefault(), setDrag(true))}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          if (e.dataTransfer.files.length) void upload(e.dataTransfer.files);
        }}
        onClick={() => input.current?.click()}
        className={cx("cursor-pointer rounded-lg border border-dashed text-center transition-colors", compact ? "px-4 py-5" : "px-6 py-10", drag ? "border-accent bg-accent/[0.06]" : "border-ink-500 hover:border-ink-400 hover:bg-ink-850")}
      >
        <div className="text-[14px] font-medium text-ink-100">Drop footage, audio or images here</div>
        <div className="mt-1 text-ink-400">or click to choose files — MP4, MOV, MKV, WebM, MP3, WAV, M4A, JPG, PNG…</div>
        <input ref={input} type="file" multiple hidden accept="video/*,audio/*,image/*" onChange={(e) => e.target.files && upload(e.target.files)} />
      </div>
      {uploads.length > 0 && (
        <div className="space-y-1.5 rounded-md border border-ink-700 bg-ink-850 p-3">
          {uploads.map((u) => (
            <div key={u.name} className="grid grid-cols-[1fr_160px] items-center gap-3 text-[12px]">
              <span className={cx("truncate", u.error ? "text-bad" : "text-ink-200")}>{u.name}{u.error ? ` — ${u.error}` : ""}</span>
              <Progress value={u.pct} tone={u.error ? "bad" : u.pct >= 100 ? "ok" : "accent"} active={u.pct < 100} />
            </div>
          ))}
        </div>
      )}
      <div className="flex gap-2">
        <textarea className="field tc min-h-[38px] flex-1 resize-y text-[12px]" rows={1} placeholder="…or reference files in place: paste folder / file paths (one per line)" value={paths} onChange={(e) => setPaths(e.target.value)} />
        <Button onClick={importPaths} disabled={!paths.trim()}>Import paths</Button>
      </div>
      <ErrorBox error={err} />
    </div>
  );
}

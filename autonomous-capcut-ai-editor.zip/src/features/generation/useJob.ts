"use client";
import { useEffect, useState } from "react";
import { api } from "@/components/hooks";
import type { Job } from "@/shared/types";

/** Tracks the latest job of a type for a project (survives navigation) with fast polling while active. */
export function useLatestJob(projectId: string, type: string, onDone?: (j: Job) => void) {
  const [job, setJob] = useState<Job | null>(null);
  useEffect(() => {
    let alive = true;
    let t: ReturnType<typeof setTimeout>;
    let prevStatus: string | null = null;
    const tick = async () => {
      try {
        const r = await api<{ jobs: Job[] }>(`/api/jobs?projectId=${projectId}&limit=30&log=1`);
        const j = r.jobs.find((x) => x.type === type) || null;
        if (!alive) return;
        setJob(j);
        if (j && prevStatus && (prevStatus === "running" || prevStatus === "queued") && j.status !== prevStatus) onDone?.(j);
        prevStatus = j?.status ?? null;
        t = setTimeout(tick, j && (j.status === "running" || j.status === "queued") ? 900 : 4000);
      } catch {
        t = setTimeout(tick, 4000);
      }
    };
    void tick();
    return () => {
      alive = false;
      clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId, type]);
  return { job, setJob };
}

"use client";
import { cx, fmtTime } from "@/components/ui";
import type { TimelineItem } from "@/shared/types";

const TRACKS: { key: string; label: string; color: string }[] = [
  { key: "Text", label: "Captions", color: "bg-ink-200/80 text-ink-950" },
  { key: "V2", label: "B-roll", color: "bg-signal/70 text-ink-950" },
  { key: "V1", label: "Main", color: "bg-accent/80 text-ink-950" },
  { key: "A1", label: "Dialogue A", color: "bg-ok/60 text-ink-950" },
  { key: "A2", label: "Dialogue B", color: "bg-ok/40 text-ink-100" },
  { key: "Music", label: "Music", color: "bg-[#9a7ae8]/60 text-ink-100" },
  { key: "SFX", label: "SFX", color: "bg-warn/70 text-ink-950" },
];
const ROLE_TINT: Record<string, string> = { hook: "#e8b44c", problem: "#ef5a5a", solution: "#4cc2e8", demo: "#4cc2e8", proof: "#57c48a", cta: "#e8b44c", story: "#9a7ae8", context: "#8a909c", payoff: "#57c48a", outro: "#5b616d", body: "#8a909c" };

export function Timeline({ items, total, target, selected, onSelect }: { items: TimelineItem[]; total: number; target: number; selected?: string | null; onSelect?: (ref: string) => void }) {
  const span = Math.max(total, target, 1);
  const pct = (s: number) => `${(s / span) * 100}%`;
  const ticks = Array.from({ length: Math.floor(span / (span > 90 ? 10 : span > 30 ? 5 : 2)) + 1 }, (_, i) => i * (span > 90 ? 10 : span > 30 ? 5 : 2));
  const sections = items.filter((i) => i.track === "V1");
  return (
    <div className="select-none rounded-lg border border-ink-700 bg-ink-900">
      <div className="grid grid-cols-[88px_1fr]">
        <div className="border-b border-r border-ink-700" />
        <div className="relative h-6 border-b border-ink-700">
          {ticks.map((t) => <div key={t} className="tc absolute top-1 -translate-x-1/2 text-[9.5px] text-ink-400" style={{ left: pct(t) }}>{fmtTime(t).replace(/\.\d$/, "")}</div>)}
          <div className="absolute inset-y-0 border-l border-dashed border-accent/70" style={{ left: pct(target) }} title="target duration" />
        </div>
        <div className="flex h-4 items-center border-b border-r border-ink-700 px-2 text-[9.5px] uppercase tracking-wider text-ink-500">Sections</div>
        <div className="relative h-4 border-b border-ink-700">
          {sections.map((s, i) => <div key={i} className="absolute inset-y-0.5 rounded-sm opacity-70" style={{ left: pct(s.start), width: pct(s.dur), background: ROLE_TINT[s.kind || "body"] || "#8a909c" }} title={s.kind} />)}
        </div>
        {TRACKS.map((tr) => (
          <div key={tr.key} className="contents">
            <div className="flex h-8 items-center border-b border-r border-ink-700/70 px-2 text-[10.5px] text-ink-300">{tr.label}</div>
            <div className="relative h-8 border-b border-ink-700/70">
              {items.filter((i) => i.track === tr.key).map((it, i) => (
                <button
                  key={i}
                  onClick={() => it.ref && onSelect?.(it.ref)}
                  title={`${it.label} · ${fmtTime(it.start)} → ${fmtTime(it.start + it.dur)}`}
                  className={cx("absolute inset-y-1 overflow-hidden rounded-[3px] px-1 text-left text-[10px] font-medium leading-6 whitespace-nowrap transition-shadow", tr.color, it.ref && selected === it.ref && "ring-2 ring-ink-50")}
                  style={{ left: pct(it.start), width: `max(3px, ${pct(it.dur)})` }}
                >
                  {it.label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

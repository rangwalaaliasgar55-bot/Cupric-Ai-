"use client";
import { useState } from "react";
import { api } from "@/components/hooks";
import { Button, ErrorBox, cx } from "@/components/ui";

type Check = { name: string; ok: boolean; detail: string; fix: string; level: string };

export function Diagnostics({ autoRun = false, onResult }: { autoRun?: boolean; onResult?: (checks: Check[]) => void }) {
  const [checks, setChecks] = useState<Check[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [installing, setInstalling] = useState(false);
  const [err, setErr] = useState<{ message: string; code?: string } | null>(null);
  const [started, setStarted] = useState(false);
  const run = async () => {
    setBusy(true);
    setErr(null);
    try {
      const r = await api<{ checks: Check[] }>("/api/diagnostics", "POST", {});
      setChecks(r.checks);
      onResult?.(r.checks);
    } catch (e) {
      setErr(e as { message: string });
    } finally {
      setBusy(false);
    }
  };
  if (autoRun && !started) {
    setStarted(true);
    void run();
  }
  const missingEngine = checks?.some((c) => !c.ok && ["faster-whisper", "pyJianYingDraft", "FFmpeg", "PyAV", "NumPy", "Pillow"].includes(c.name));
  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <Button variant="primary" onClick={run} disabled={busy}>{busy ? "Running diagnostics…" : "Run Diagnostics"}</Button>
        {missingEngine && (
          <Button disabled={installing} onClick={async () => { setInstalling(true); setErr(null); try { await api("/api/diagnostics", "POST", { action: "install_engine" }); await run(); } catch (e) { setErr(e as { message: string }); } finally { setInstalling(false); } }}>{installing ? "Installing engine dependencies…" : "Install engine dependencies"}</Button>
        )}
      </div>
      <ErrorBox error={err} />
      {checks && (
        <div className="divide-y divide-ink-700/70 rounded-lg border border-ink-700 bg-ink-900">
          {checks.map((c) => (
            <div key={c.name} className="grid grid-cols-[22px_200px_1fr] items-start gap-3 px-4 py-2.5">
              <span className={cx("mt-0.5 text-[13px] font-bold", c.ok ? "text-ok" : c.level === "warning" ? "text-warn" : "text-bad")}>{c.ok ? "✓" : c.level === "warning" ? "!" : "✕"}</span>
              <span className="font-medium">{c.name}</span>
              <div className="min-w-0">
                <div className="tc break-all text-[11.5px] text-ink-300">{c.detail}</div>
                {!c.ok && c.fix && <div className="mt-0.5 text-[11.5px] text-ink-400">→ {c.fix}</div>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

"use client";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { setActiveProject, usePoll } from "@/components/hooks";
import { Badge, ErrorBox, cx, fmtTime } from "@/components/ui";
import type { ProjectDetail } from "@/shared/types";

type Ctx = { detail: ProjectDetail; reload: () => Promise<void>; setFast: (b: boolean) => void };
const C = createContext<Ctx | null>(null);
export const useProject = () => {
  const c = useContext(C);
  if (!c) throw new Error("useProject outside ProjectProvider");
  return c;
};

export function ProjectProvider({ id, children }: { id: string; children: ReactNode }) {
  const [fast, setFast] = useState(false);
  const { data, error, reload } = usePoll<ProjectDetail>(`/api/projects/${id}`, fast ? 1500 : 4000);
  const path = usePathname();
  useEffect(() => setActiveProject(id), [id]);
  const busy = data?.media.some((m) => ["queued", "running"].includes(m.analysisStatus) || ["queued", "running"].includes(m.transcriptStatus));
  useEffect(() => setFast(!!busy), [busy]);

  if (error && !data) return <div className="p-8"><ErrorBox error={{ message: error.code === "NOT_FOUND" ? "This project no longer exists." : `The project could not be loaded: ${error.message}`, code: error.code }} /></div>;
  if (!data) return <div className="p-8 text-ink-400">Loading project…</div>;
  const p = data.project;
  const tabs = [
    ["media", "Media"],
    ["director", "AI Director"],
    ["plan", "Edit Plan"],
    ["generate", "Generate"],
    ["history", "History"],
  ];
  const analysed = data.media.filter((m) => m.analysisStatus === "done").length;
  const transcribed = data.media.filter((m) => m.transcriptStatus === "done").length;
  return (
    <C.Provider value={{ detail: data, reload, setFast }}>
      <div className="flex h-full flex-col">
        <header className="shrink-0 border-b border-ink-700 bg-ink-900/60 px-6">
          <div className="flex h-12 items-center gap-4">
            <Link href="/" className="text-ink-400 hover:text-ink-100">Projects</Link>
            <span className="text-ink-600">/</span>
            <span className="font-semibold">{p.name}</span>
            <Badge>{p.aspectRatio} · {p.width}×{p.height} · {p.fps}fps</Badge>
            <span className="tc text-[11.5px] text-ink-400">target {fmtTime(p.targetDurationS)}</span>
            <div className="ml-auto flex items-center gap-4 text-[11.5px] text-ink-400">
              <span><span className="tc text-ink-200">{data.media.length}</span> files</span>
              <span><span className="tc text-ink-200">{analysed}</span> analysed</span>
              <span><span className="tc text-ink-200">{transcribed}</span> transcribed</span>
              {data.versions[0] && <span>last draft <span className="tc text-ink-200">v{String(data.versions[0].number).padStart(3, "0")}</span></span>}
            </div>
          </div>
          <nav className="-mb-px flex gap-5">
            {tabs.map(([k, l]) => (
              <Link key={k} href={`/projects/${id}/${k}`} className={cx("border-b-2 pb-2.5 text-[12.5px] font-medium transition-colors", path.endsWith(`/${k}`) ? "border-accent text-ink-100" : "border-transparent text-ink-400 hover:text-ink-200")}>
                {l}
              </Link>
            ))}
          </nav>
        </header>
        <div className="min-h-0 flex-1 overflow-y-auto">{children}</div>
      </div>
    </C.Provider>
  );
}

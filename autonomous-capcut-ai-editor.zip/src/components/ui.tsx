"use client";
import type { ButtonHTMLAttributes, ReactNode } from "react";

export function cx(...c: (string | false | null | undefined)[]) {
  return c.filter(Boolean).join(" ");
}

export function Button({ variant = "default", size = "md", className, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "default" | "primary" | "ghost" | "danger" | "subtle"; size?: "sm" | "md" | "lg" }) {
  return (
    <button
      {...p}
      className={cx(
        "inline-flex select-none items-center justify-center gap-1.5 rounded-md font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-40",
        size === "sm" && "h-7 px-2.5 text-[12px]",
        size === "md" && "h-8 px-3 text-[13px]",
        size === "lg" && "h-10 px-5 text-[14px]",
        variant === "default" && "border border-ink-600 bg-ink-800 text-ink-100 hover:border-ink-500 hover:bg-ink-700",
        variant === "primary" && "bg-accent text-ink-950 hover:bg-[#f2c465]",
        variant === "ghost" && "text-ink-200 hover:bg-ink-800 hover:text-ink-100",
        variant === "subtle" && "bg-ink-800 text-ink-200 hover:bg-ink-700",
        variant === "danger" && "border border-bad/40 bg-bad/10 text-bad hover:bg-bad/20",
        className,
      )}
    />
  );
}

export function Panel({ title, actions, children, className, pad = true }: { title?: ReactNode; actions?: ReactNode; children: ReactNode; className?: string; pad?: boolean }) {
  return (
    <section className={cx("rounded-lg border border-ink-700 bg-ink-900", className)}>
      {(title || actions) && (
        <header className="flex h-10 items-center justify-between gap-3 border-b border-ink-700 px-4">
          <div className="label">{title}</div>
          <div className="flex items-center gap-2">{actions}</div>
        </header>
      )}
      <div className={pad ? "p-4" : ""}>{children}</div>
    </section>
  );
}

export function Badge({ tone = "neutral", children, className }: { tone?: "neutral" | "ok" | "warn" | "bad" | "accent" | "signal"; children: ReactNode; className?: string }) {
  return (
    <span
      className={cx(
        "inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10.5px] font-semibold uppercase tracking-wide",
        tone === "neutral" && "bg-ink-700 text-ink-200",
        tone === "ok" && "bg-ok/15 text-ok",
        tone === "warn" && "bg-warn/15 text-warn",
        tone === "bad" && "bg-bad/15 text-bad",
        tone === "accent" && "bg-accent/15 text-accent",
        tone === "signal" && "bg-signal/15 text-signal",
        className,
      )}
    >
      {children}
    </span>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: ReactNode; children: ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <div className="label">{label}</div>
      {children}
      {hint && <div className="text-[11.5px] text-ink-400">{hint}</div>}
    </label>
  );
}

export function Progress({ value, active, tone = "accent" }: { value: number; active?: boolean; tone?: "accent" | "ok" | "bad" }) {
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-ink-700">
      <div className={cx("h-full rounded-full transition-[width] duration-300", tone === "accent" && "bg-accent", tone === "ok" && "bg-ok", tone === "bad" && "bg-bad", active && "progress-active")} style={{ width: `${Math.max(2, Math.min(100, value))}%` }} />
    </div>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button type="button" onClick={() => onChange(!checked)} className="inline-flex items-center gap-2 text-[12.5px] text-ink-200">
      <span className={cx("relative h-4 w-7 rounded-full transition-colors", checked ? "bg-accent" : "bg-ink-600")}>
        <span className={cx("absolute top-0.5 h-3 w-3 rounded-full bg-ink-950 transition-all", checked ? "left-3.5" : "left-0.5")} />
      </span>
      {label}
    </button>
  );
}

export function Empty({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-ink-600 px-6 py-14 text-center">
      <div className="text-[15px] font-semibold text-ink-100">{title}</div>
      {children && <div className="mt-1.5 max-w-md text-ink-300">{children}</div>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function ErrorBox({ error, actions }: { error: { code?: string; message: string } | null; actions?: ReactNode }) {
  if (!error) return null;
  return (
    <div className="fade-up rounded-lg border border-bad/40 bg-bad/[0.07] p-4">
      <div className="flex items-start gap-3">
        <div className="mt-0.5 h-2 w-2 shrink-0 rounded-full bg-bad" />
        <div className="min-w-0 flex-1">
          <div className="text-[13px] font-medium text-ink-100">{error.message}</div>
          {error.code && <div className="tc mt-1 text-[11px] text-ink-400">{error.code}</div>}
          {actions && <div className="mt-3 flex flex-wrap gap-2">{actions}</div>}
        </div>
      </div>
    </div>
  );
}

export function StatusDot({ status }: { status: string }) {
  const map: Record<string, string> = { done: "bg-ok", succeeded: "bg-ok", running: "bg-accent pulse-dot", queued: "bg-ink-400", pending: "bg-ink-500", failed: "bg-bad", cancelled: "bg-ink-400", skipped: "bg-ink-500", not_applicable: "bg-ink-600" };
  return <span className={cx("inline-block h-1.5 w-1.5 shrink-0 rounded-full", map[status] || "bg-ink-500")} />;
}

export const fmtTime = (s: number | null | undefined) => {
  if (s === null || s === undefined || !isFinite(s)) return "—";
  const m = Math.floor(s / 60);
  const sec = s - m * 60;
  return `${m}:${sec.toFixed(1).padStart(4, "0")}`;
};
export const fmtBytes = (b: number | null | undefined) => (!b ? "—" : b > 1e9 ? `${(b / 1e9).toFixed(2)} GB` : b > 1e6 ? `${(b / 1e6).toFixed(1)} MB` : `${Math.round(b / 1e3)} KB`);
export const fileUrl = (p: string | null | undefined) => (p ? `/api/files?path=${encodeURIComponent(p)}` : "");
export const ago = (d: string | Date | null | undefined) => {
  if (!d) return "—";
  const s = (Date.now() - new Date(d).getTime()) / 1000;
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return new Date(d).toLocaleDateString();
};

"use client";
import { useState } from "react";
import Link from "next/link";
import { api, usePoll } from "./hooks";
import { Button, Progress, StatusDot, ago, cx } from "./ui";
import type { Job } from "@/shared/types";

export function JobTray() {
  const [open, setOpen] = useState(false);
  const [intv, setIntv] = useState(2500);
  const { data, reload } = usePoll<{ jobs: Job[] }>("/api/jobs?limit=40", intv);
  const jobs = data?.jobs || [];
  const active = jobs.filter((j) => j.status === "running" || j.status === "queued");
  const failed = jobs.filter((j) => j.status === "failed" && Date.now() - new Date(j.createdAt).getTime() < 3600_000);
  const running = active.find((j) => j.status === "running");
  const want = active.length ? 1200 : 5000;
  if (want !== intv) setIntv(want);

  return (
    <div className="relative shrink-0 border-t border-ink-700 bg-ink-900">
      <button onClick={() => setOpen(!open)} className="flex h-8 w-full items-center gap-3 px-4 text-left text-[12px] text-ink-300 hover:bg-ink-850">
        <StatusDot status={running ? "running" : failed.length ? "failed" : "done"} />
        {running ? (
          <>
            <span className="truncate text-ink-100">{running.title}</span>
            <span className="truncate text-ink-400">{running.message}</span>
            <span className="ml-auto flex w-56 items-center gap-2">
              <Progress value={running.progress} active />
              <span className="tc w-10 text-right">{Math.round(running.progress)}%</span>
            </span>
          </>
        ) : (
          <span>{active.length ? `${active.length} job(s) queued` : failed.length ? `${failed.length} job(s) failed in the last hour` : "All background jobs idle"}</span>
        )}
        <span className={cx("ml-2 text-ink-400", !running && "ml-auto")}>{active.length > 1 ? `+${active.length - 1} queued · ` : ""}Jobs {open ? "▾" : "▴"}</span>
      </button>
      {open && (
        <div className="fade-up absolute bottom-8 right-3 z-40 max-h-[60vh] w-[520px] overflow-y-auto rounded-lg border border-ink-600 bg-ink-850 shadow-2xl shadow-black/60">
          <div className="flex items-center justify-between border-b border-ink-700 px-4 py-2.5">
            <div className="label">Background jobs</div>
            <Button size="sm" variant="ghost" onClick={() => setOpen(false)}>Close</Button>
          </div>
          {jobs.length === 0 && <div className="p-6 text-center text-ink-400">No jobs yet.</div>}
          {jobs.map((j) => (
            <div key={j.id} className="border-b border-ink-700/60 px-4 py-2.5 last:border-0">
              <div className="flex items-center gap-2">
                <StatusDot status={j.status} />
                <span className="truncate font-medium text-ink-100">{j.title}</span>
                <span className="ml-auto shrink-0 text-[11px] text-ink-400">{ago(j.createdAt)}</span>
              </div>
              {j.status === "running" && (
                <div className="mt-2 flex items-center gap-2">
                  <Progress value={j.progress} active />
                  <span className="tc w-10 text-right text-[11px] text-ink-300">{Math.round(j.progress)}%</span>
                </div>
              )}
              {j.message && j.status === "running" && <div className="mt-1 truncate text-[11.5px] text-ink-400">{j.message}</div>}
              {j.error && <div className="mt-1 text-[11.5px] text-bad">{j.error.message}</div>}
              <div className="mt-1.5 flex gap-1.5">
                {(j.status === "running" || j.status === "queued") && (
                  <Button size="sm" variant="ghost" onClick={async () => (await api(`/api/jobs/${j.id}`, "POST", { action: "cancel" }), reload())}>Cancel</Button>
                )}
                {(j.status === "failed" || j.status === "cancelled") && (
                  <Button size="sm" variant="ghost" onClick={async () => (await api(`/api/jobs/${j.id}`, "POST", { action: "retry" }), reload())}>Retry</Button>
                )}
                {j.projectId && j.type === "build_draft" && (
                  <Link href={`/projects/${j.projectId}/generate`} className="inline-flex h-7 items-center px-2.5 text-[12px] text-ink-300 hover:text-ink-100">Open</Link>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

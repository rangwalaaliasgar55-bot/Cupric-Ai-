"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cx } from "./ui";
import { useActiveProject } from "./hooks";

const I = {
  projects: "M3 4h6v6H3zM11 4h6v6h-6zM3 12h6v4H3zM11 12h6v4h-6z",
  plus: "M10 4v12M4 10h12",
  media: "M3 5h14v10H3zM8 8l4 2-4 2z",
  director: "M10 3l1.8 4.2L16 9l-4.2 1.8L10 15l-1.8-4.2L4 9l4.2-1.8z",
  plan: "M3 6h14M3 10h9M3 14h11",
  generate: "M5 3l10 7-10 7z",
  history: "M10 4a6 6 0 1 1-6 6M4 5v5h5",
  settings: "M10 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM10 2v2M10 16v2M2 10h2M16 10h2M4.2 4.2l1.4 1.4M14.4 14.4l1.4 1.4M4.2 15.8l1.4-1.4M14.4 5.6l1.4-1.4",
  diag: "M3 10h3l2-5 4 10 2-5h3",
};

function Icon({ d }: { d: string }) {
  return (
    <svg viewBox="0 0 20 20" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
      <path d={d} />
    </svg>
  );
}

export function Sidebar() {
  const path = usePathname();
  const active = useActiveProject();
  const pid = /^\/projects\/([0-9a-f-]{36})/.exec(path)?.[1] || active;
  const items: { href: string; label: string; icon: string; needsProject?: boolean; match: (p: string) => boolean }[] = [
    { href: "/", label: "Projects", icon: I.projects, match: (p) => p === "/" },
    { href: "/projects/new", label: "New Project", icon: I.plus, match: (p) => p === "/projects/new" },
    { href: `/projects/${pid}/media`, label: "Media", icon: I.media, needsProject: true, match: (p) => p.endsWith("/media") },
    { href: `/projects/${pid}/director`, label: "AI Director", icon: I.director, needsProject: true, match: (p) => p.endsWith("/director") },
    { href: `/projects/${pid}/plan`, label: "Edit Plan", icon: I.plan, needsProject: true, match: (p) => p.endsWith("/plan") },
    { href: `/projects/${pid}/generate`, label: "Generate", icon: I.generate, needsProject: true, match: (p) => p.endsWith("/generate") },
    { href: `/projects/${pid}/history`, label: "History", icon: I.history, needsProject: true, match: (p) => p.endsWith("/history") },
  ];
  return (
    <aside className="flex w-[208px] shrink-0 flex-col border-r border-ink-700 bg-ink-900">
      <div className="flex h-12 items-center gap-2.5 border-b border-ink-700 px-4">
        <div className="grid h-6 w-6 place-items-center rounded bg-accent text-[11px] font-black text-ink-950">C</div>
        <div>
          <div className="text-[13px] font-semibold leading-none tracking-tight">Cutline</div>
          <div className="mt-0.5 text-[10px] leading-none text-ink-400">AI Editor for CapCut</div>
        </div>
      </div>
      <nav className="flex-1 space-y-0.5 p-2">
        {items.map((it, i) => {
          const disabled = it.needsProject && !pid;
          const on = it.match(path);
          return (
            <div key={it.label}>
              {i === 2 && <div className="label px-2.5 pb-1.5 pt-4">Project</div>}
              {disabled ? (
                <span className="flex h-8 cursor-not-allowed items-center gap-2.5 rounded-md px-2.5 text-ink-500" title="Open a project first">
                  <Icon d={it.icon} />
                  {it.label}
                </span>
              ) : (
                <Link href={it.href} className={cx("flex h-8 items-center gap-2.5 rounded-md px-2.5 transition-colors", on ? "bg-ink-700 text-ink-100" : "text-ink-300 hover:bg-ink-800 hover:text-ink-100")}>
                  <span className={on ? "text-accent" : ""}>
                    <Icon d={it.icon} />
                  </span>
                  {it.label}
                </Link>
              )}
            </div>
          );
        })}
      </nav>
      <div className="space-y-0.5 border-t border-ink-700 p-2">
        {[
          { href: "/diagnostics", label: "Diagnostics", icon: I.diag },
          { href: "/settings", label: "Settings", icon: I.settings },
        ].map((it) => (
          <Link key={it.href} href={it.href} className={cx("flex h-8 items-center gap-2.5 rounded-md px-2.5", path.startsWith(it.href) ? "bg-ink-700 text-ink-100" : "text-ink-300 hover:bg-ink-800 hover:text-ink-100")}>
            <Icon d={it.icon} />
            {it.label}
          </Link>
        ))}
        <div className="px-2.5 pt-2 text-[10px] text-ink-500">Local-first · v1.0.0</div>
      </div>
    </aside>
  );
}

"use client";
import { useCallback, useEffect, useRef, useState } from "react";

export type ApiError = { code: string; message: string; details?: unknown };

export async function api<T = Record<string, unknown>>(url: string, method = "GET", body?: unknown): Promise<T> {
  const res = await fetch(url, { method, headers: body ? { "content-type": "application/json" } : undefined, body: body ? JSON.stringify(body) : undefined, cache: "no-store" });
  const json = await res.json().catch(() => ({ error: { code: "BAD_RESPONSE", message: `The local engine returned an unreadable response (HTTP ${res.status}).` } }));
  if (!res.ok || json.error) {
    const err = json.error || { code: `HTTP_${res.status}`, message: res.statusText };
    throw Object.assign(new Error(err.message), err) as Error & ApiError;
  }
  return json as T;
}

/** Poll a JSON endpoint. Interval can change dynamically (fast while jobs run). */
export function usePoll<T>(url: string | null, interval = 3000) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState(true);
  const ref = useRef(interval);
  ref.current = interval;
  const load = useCallback(async () => {
    if (!url) return;
    try {
      setData(await api<T>(url));
      setError(null);
    } catch (e) {
      setError(e as ApiError);
    } finally {
      setLoading(false);
    }
  }, [url]);
  useEffect(() => {
    let alive = true;
    let t: ReturnType<typeof setTimeout>;
    const tick = async () => {
      await load();
      if (alive && ref.current > 0) t = setTimeout(tick, ref.current);
    };
    void tick();
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [load]);
  return { data, error, loading, reload: load, setData };
}

export function useActiveProject() {
  const [id, setId] = useState<string | null>(null);
  useEffect(() => {
    const read = () => setId(localStorage.getItem("activeProject"));
    read();
    window.addEventListener("active-project", read);
    return () => window.removeEventListener("active-project", read);
  }, []);
  return id;
}

export function setActiveProject(id: string | null) {
  if (id) localStorage.setItem("activeProject", id);
  else localStorage.removeItem("activeProject");
  window.dispatchEvent(new Event("active-project"));
}

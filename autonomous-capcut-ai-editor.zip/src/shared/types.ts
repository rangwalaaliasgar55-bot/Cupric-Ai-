import type { Edl } from "./schemas/edl";

export type Warning = { code: string; severity: string; message: string };
export type Word = { word: string; start: number; end: number; confidence?: number };
export type Segment = { id: number; start: number; end: number; text: string; words: Word[]; speaker?: string | null };

export type MediaItem = {
  id: string;
  projectId: string;
  filename: string;
  path: string;
  kind: string;
  hash: string | null;
  sizeBytes: number | null;
  durationS: number | null;
  width: number | null;
  height: number | null;
  fps: number | null;
  variableFps: boolean | null;
  codec: string | null;
  audioCodec: string | null;
  hasAudio: boolean | null;
  aspectRatio: string | null;
  readable: boolean | null;
  warnings: Warning[] | null;
  thumbnail: string | null;
  analysisStatus: string;
  analysisError: string | null;
  analysis: {
    classification?: { shot_type?: string; tags?: string[]; confidence?: number };
    description?: string;
    scenes_s?: number[];
    audio?: { waveform?: number[]; mean_db?: number; peak_db?: number; silences?: { start_s: number; end_s: number }[]; active_ratio?: number; spikes_s?: number[]; error?: string };
    visual?: { luma?: number; contrast?: number; warmth?: number; saturation?: number };
    filmstrip?: string[];
  } | null;
  transcriptStatus: string;
  transcriptError: string | null;
  transcript: { segments?: Segment[]; language?: string; source?: string; model?: string; interpolated_word_timings?: boolean } | null;
  transcriptWordCount: number;
};

export type Project = {
  id: string;
  name: string;
  location: string;
  aspectRatio: string;
  width: number;
  height: number;
  fps: number;
  targetDurationS: number;
  draftName: string;
  currentEdlId: string | null;
  directorBrief: Record<string, unknown> | null;
  status: string;
  createdAt: string;
  updatedAt: string;
};

export type Issue = { path: string; message: string };
export type TimelineItem = { track: string; start: number; dur: number; label: string; ref?: string; kind?: string };

export type Version = {
  id: string;
  number: number;
  edlId: string | null;
  edl: Edl;
  settings: Record<string, unknown> & { draftName?: string };
  mediaRefs: { filename: string; path: string; hash?: string }[];
  draftPath: string | null;
  backupPath: string | null;
  status: string;
  report: { validation?: { stats?: Record<string, unknown> }; notes?: string[]; unsupported?: string[]; error?: { code: string; message: string } } | null;
  promptVersion: string | null;
  appVersion: string;
  createdAt: string;
};

export type ProjectDetail = {
  project: Project;
  media: MediaItem[];
  current: {
    id: string;
    label: string;
    source: string;
    createdAt: string;
    edl: Edl;
    validation: { ok: boolean; errors: Issue[]; warnings: Issue[]; stats?: { clipCount: number; timelineDurationS: number } };
    compiled: { timeline: TimelineItem[]; notes: string[]; plan: { total_duration: number; captions: unknown[]; dialogue: unknown[]; music: { duck?: unknown[] }[] } } | null;
  } | null;
  edlHistory: { id: string; label: string; source: string; createdAt: string }[];
  versions: Version[];
  draftDir: string;
};

export type Job = {
  id: string;
  projectId: string | null;
  type: string;
  title: string;
  status: string;
  progress: number;
  stage: string | null;
  message: string | null;
  stages: { key: string; label: string; status: string }[] | null;
  result: Record<string, unknown> | null;
  error: { code: string; message: string; details?: unknown; actions?: string[] } | null;
  log: string;
  startedAt: string | null;
  finishedAt: string | null;
  createdAt: string;
};

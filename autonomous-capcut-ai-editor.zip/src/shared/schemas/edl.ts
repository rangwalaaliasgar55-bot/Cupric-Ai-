import { z } from "zod";

/** Stable application-level enums. The builder maps these onto pyJianYingDraft enum members. */
export const TRANSITIONS = ["hard_cut", "dissolve", "flash_white", "push_in", "pull_out", "blur", "slide"] as const;
export const SECTION_ROLES = ["hook", "problem", "context", "solution", "demo", "proof", "story", "payoff", "cta", "outro", "body"] as const;
export const COLOR_MOODS = ["neutral_clean", "cool_tech", "warm_cinematic", "bright_airy", "moody_dark", "natural", "vintage_film", "high_contrast", "luxury"] as const;
export const CAPTION_MODES = ["phrase", "word", "karaoke"] as const;
export const CAPTION_POSITIONS = ["bottom", "center", "top"] as const;
export const TEXT_ANIMS = ["none", "fade", "pop", "typewriter", "slide_up", "zoom"] as const;
export const ASPECTS = ["9:16", "16:9", "1:1", "4:5", "custom"] as const;

const sec = z.number().finite();

export const ZoomSchema = z.object({
  start_scale: z.number().min(0.5).max(2.5),
  end_scale: z.number().min(0.5).max(2.5),
});

export const CaptionSchema = z.object({
  text: z.string().trim().min(1).max(140),
  start_s: sec, // SOURCE time within the clip's source file
  end_s: sec,
  emphasis: z.array(z.string()).default([]),
});

export const SfxSchema = z.object({
  source_file: z.string().min(1),
  at_s: sec.min(0), // offset from the clip's start on the timeline
  in_s: sec.min(0).default(0),
  duration_s: z.number().positive().max(15),
  volume: z.number().min(0).max(2).default(0.7),
  enabled: z.boolean().default(true),
});

export const BrollSchema = z.object({
  source_file: z.string().min(1),
  in_s: sec.min(0),
  out_s: sec,
  at_s: sec.min(0), // offset from the parent clip's start on the timeline
  keyframe_zoom: ZoomSchema.nullable().default(null),
  purpose: z.string().max(200).default(""),
});

export const AudioOffsetSchema = z.union([
  z.literal("none"),
  z.object({ type: z.enum(["j_cut", "l_cut"]), seconds: z.number().min(0.05).max(2) }),
]);

export const ClipSchema = z.object({
  id: z.string().optional(),
  source_file: z.string().min(1),
  in_s: sec,
  out_s: sec,
  purpose: z.string().max(240).default(""),
  transition_in: z.enum(TRANSITIONS).default("hard_cut"),
  audio_offset: AudioOffsetSchema.default("none"),
  use_audio: z.boolean().default(true),
  speed: z.number().min(0.25).max(4).default(1),
  keyframe_zoom: ZoomSchema.nullable().default(null),
  position: z.object({ x: z.number().min(-1).max(1), y: z.number().min(-1).max(1) }).nullable().default(null),
  captions: z.array(CaptionSchema).default([]),
  sfx: z.array(SfxSchema).default([]),
  broll: z.array(BrollSchema).default([]),
});

export const SectionSchema = z.object({
  id: z.string().optional(),
  role: z.enum(SECTION_ROLES),
  clips: z.array(ClipSchema).min(1),
});

export const EdlSchema = z.object({
  schema_version: z.literal("1.0").default("1.0"),
  project: z.object({
    target_duration_s: z.number().positive().max(3600),
    aspect_ratio: z.enum(ASPECTS),
    fps: z.number().int().min(12).max(120),
  }),
  sections: z.array(SectionSchema).min(1),
  captions: z
    .object({
      enabled: z.boolean().default(true),
      mode: z.enum(CAPTION_MODES).default("phrase"),
      max_words: z.number().int().min(1).max(12).default(5),
      position: z.enum(CAPTION_POSITIONS).default("bottom"),
      animation: z.enum(TEXT_ANIMS).default("pop"),
      auto_from_transcript: z.boolean().default(true),
      emphasis_words: z.array(z.string()).default([]),
    })
    .default({ enabled: true, mode: "phrase", max_words: 5, position: "bottom", animation: "pop", auto_from_transcript: true, emphasis_words: [] }),
  music: z
    .object({
      enabled: z.boolean().default(true),
      source_file: z.string().nullable().default(null),
      in_s: sec.min(0).default(0),
      volume: z.number().min(0).max(1).default(0.45),
      duck_under_dialogue: z.boolean().default(true),
      fade_in_s: z.number().min(0).max(10).default(0.8),
      fade_out_s: z.number().min(0).max(10).default(1.5),
    })
    .default({ enabled: true, source_file: null, in_s: 0, volume: 0.45, duck_under_dialogue: true, fade_in_s: 0.8, fade_out_s: 1.5 }),
  color_grade_mood: z.enum(COLOR_MOODS).default("neutral_clean"),
  look: z
    .object({
      normalize: z.boolean().default(true),
      intensity: z.number().min(0).max(100).default(45),
      vignette: z.number().min(0).max(100).default(0),
      grain: z.number().min(0).max(100).default(0),
    })
    .default({ normalize: true, intensity: 45, vignette: 0, grain: 0 }),
  music_mood: z.string().max(80).default(""),
});

export type Edl = z.infer<typeof EdlSchema>;
export type EdlClip = z.infer<typeof ClipSchema>;
export type EdlSection = z.infer<typeof SectionSchema>;
export type EdlCaption = z.infer<typeof CaptionSchema>;

/** Compact human/AI-readable schema description embedded in the Director prompt. */
export const EDL_SCHEMA_DOC = `{
  "schema_version": "1.0",
  "project": { "target_duration_s": number, "aspect_ratio": ${ASPECTS.map((a) => `"${a}"`).join("|")}, "fps": integer },
  "sections": [ {
    "role": ${SECTION_ROLES.map((a) => `"${a}"`).join("|")},
    "clips": [ {
      "source_file": "<exact filename from MEDIA INVENTORY>",
      "in_s": number, "out_s": number,            // source seconds; out_s > in_s; within file duration
      "purpose": "<≤12 words: editorial reason for this beat>",
      "transition_in": ${TRANSITIONS.map((a) => `"${a}"`).join("|")},   // default "hard_cut"
      "audio_offset": "none" | { "type": "j_cut"|"l_cut", "seconds": 0.05-2 },
      "use_audio": boolean,                       // false for B-roll-only beats
      "speed": 0.25-4,                            // 1 unless there is a reason
      "keyframe_zoom": null | { "start_scale": number, "end_scale": number },  // subtle: 1.0→1.03-1.08
      "position": null | { "x": -1..1, "y": -1..1 },
      "captions": [ { "text": "<verbatim transcript words>", "start_s": number, "end_s": number, "emphasis": ["word"] } ], // source seconds, or [] to auto-caption
      "sfx": [ { "source_file": "<audio filename>", "at_s": number, "in_s": number, "duration_s": number, "volume": 0-2 } ],
      "broll": [ { "source_file": "<video/image filename>", "in_s": number, "out_s": number, "at_s": number, "keyframe_zoom": null|{...}, "purpose": "..." } ] // overlays while this clip's audio continues; at_s = offset from clip start
    } ]
  } ],
  "captions": { "enabled": boolean, "mode": ${CAPTION_MODES.map((a) => `"${a}"`).join("|")}, "max_words": 1-12, "position": ${CAPTION_POSITIONS.map((a) => `"${a}"`).join("|")}, "animation": ${TEXT_ANIMS.map((a) => `"${a}"`).join("|")}, "auto_from_transcript": boolean, "emphasis_words": ["word"] },
  "music": { "enabled": boolean, "source_file": null | "<audio filename>", "in_s": number, "volume": 0-1, "duck_under_dialogue": boolean, "fade_in_s": number, "fade_out_s": number },
  "color_grade_mood": ${COLOR_MOODS.map((a) => `"${a}"`).join("|")},
  "look": { "normalize": boolean, "intensity": 0-100, "vignette": 0-100, "grain": 0-100 },
  "music_mood": "<short mood label>"
}`;
